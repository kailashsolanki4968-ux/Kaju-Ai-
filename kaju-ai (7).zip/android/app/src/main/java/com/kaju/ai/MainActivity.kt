package com.kaju.ai

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.kaju.ai.bridge.KajuNativeBridge

/**
 * MainActivity
 *
 * Android host activity running Kaju AI within a secure, high-performance WebView.
 * Mounts `KajuNativeBridge` under the Javascript interface name "KajuNative".
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.kajuWebView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        // Register the native Android bridge interface
        webView.addJavascriptInterface(KajuNativeBridge(this), "KajuNative")

        webView.webViewClient = object : WebViewClient() {
            // Keep in-app navigation within the webview unless an external intent is dispatched
            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                return false
            }
        }

        webView.webChromeClient = WebChromeClient()

        // Load production URL or local bundled assets
        val appUrl = getString(R.string.kaju_web_app_url)
        webView.loadUrl(appUrl)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("KajuNative")
        super.onDestroy()
    }
}

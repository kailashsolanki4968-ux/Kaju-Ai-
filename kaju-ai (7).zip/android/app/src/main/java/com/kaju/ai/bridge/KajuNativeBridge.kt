package com.kaju.ai.bridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * KajuNativeBridge
 *
 * Implements the bidirectional contract defined in `src/native/androidBridgeContract.ts`.
 * Registered in WebView via:
 *   webView.addJavascriptInterface(KajuNativeBridge(this), "KajuNative")
 *
 * Supports both raw JSON string and direct method parameters passed across the JavascriptInterface.
 */
class KajuNativeBridge(private val activity: Activity) {

    companion object {
        private const val TAG = "KajuNativeBridge"
    }

    /**
     * Confirms that Kaju is running inside the official native Android host.
     */
    @JavascriptInterface
    fun isAndroidNative(): Boolean {
        return true
    }

    /**
     * Queries Android PackageManager to verify if an application is installed.
     * Compliant with Android 11+ Package Visibility (requires <queries> in AndroidManifest.xml).
     */
    @JavascriptInterface
    fun isAppInstalled(packageName: String): Boolean {
        return try {
            val pm = activity.packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            Log.d(TAG, "Package not installed: $packageName")
            false
        } catch (e: Exception) {
            Log.e(TAG, "Error checking package $packageName", e)
            false
        }
    }

    /**
     * Overload 1: Accepts JSON string or serialized intent parameters
     */
    @JavascriptInterface
    fun launchApp(appId: String, intentParamsRaw: String): String {
        val response = JSONObject()
        try {
            val params = if (intentParamsRaw.startsWith("{")) JSONObject(intentParamsRaw) else JSONObject()
            val action = params.optString("action", Intent.ACTION_MAIN)
            val packageName = params.optString("packageName", "")
            val dataUri = params.optString("dataUri", "")
            val category = params.optString("category", "")
            val type = params.optString("type", "")

            val intent = Intent(action).apply {
                if (packageName.isNotEmpty()) {
                    setPackage(packageName)
                }
                if (category.isNotEmpty()) {
                    addCategory(category)
                }
                if (dataUri.isNotEmpty() && type.isNotEmpty()) {
                    setDataAndType(Uri.parse(dataUri), type)
                } else if (dataUri.isNotEmpty()) {
                    data = Uri.parse(dataUri)
                } else if (type.isNotEmpty()) {
                    this.type = type
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val pm = activity.packageManager
            val canResolve = intent.resolveActivity(pm) != null

            if (!canResolve && packageName.isNotEmpty()) {
                val launchIntent = pm.getLaunchIntentForPackage(packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    activity.startActivity(launchIntent)
                    response.put("success", true)
                    response.put("code", "OK")
                    response.put("message", "App launched successfully.")
                    response.put("appId", appId)
                    response.put("packageName", packageName)
                    return response.toString()
                }

                response.put("success", false)
                response.put("code", "APP_NOT_INSTALLED")
                response.put("message", "Application is not installed on this device.")
                response.put("appId", appId)
                response.put("packageName", packageName)
                return response.toString()
            }

            if (!canResolve) {
                response.put("success", false)
                response.put("code", "NO_RESOLVING_ACTIVITY")
                response.put("message", "No activity available to handle this intent.")
                response.put("appId", appId)
                return response.toString()
            }

            activity.startActivity(intent)
            response.put("success", true)
            response.put("code", "OK")
            response.put("message", "Intent dispatched successfully.")
            response.put("appId", appId)
            if (packageName.isNotEmpty()) response.put("packageName", packageName)
            return response.toString()

        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch app $appId", e)
            response.put("success", false)
            response.put("code", "BRIDGE_ERROR")
            response.put("message", e.localizedMessage ?: "Bridge dispatch exception")
            response.put("appId", appId)
            return response.toString()
        }
    }

    /**
     * Launches a raw Android intent URI string (e.g. intent://...#Intent;...).
     */
    @JavascriptInterface
    fun launchIntentUri(intentUri: String): String {
        val response = JSONObject()
        return try {
            val intent = Intent.parseUri(intentUri, Intent.URI_INTENT_SCHEME).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(intent)
                response.put("success", true)
                response.put("code", "OK")
                response.put("message", "Intent launched successfully.")
            } else {
                response.put("success", false)
                response.put("code", "NO_RESOLVING_ACTIVITY")
                response.put("message", "No activity found to resolve URI intent.")
            }
            response.toString()
        } catch (e: Exception) {
            response.put("success", false)
            response.put("code", "BRIDGE_ERROR")
            response.put("message", e.localizedMessage ?: "Invalid intent URI")
            response.toString()
        }
    }

    /**
     * Launches native camera capture activity.
     */
    @JavascriptInterface
    fun openCamera(): String {
        val response = JSONObject()
        return try {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(intent)
                response.put("success", true)
                response.put("code", "OK")
                response.put("message", "Camera opened.")
            } else {
                response.put("success", false)
                response.put("code", "NO_RESOLVING_ACTIVITY")
                response.put("message", "No camera application installed.")
            }
            response.toString()
        } catch (e: Exception) {
            response.put("success", false)
            response.put("code", "BRIDGE_ERROR")
            response.put("message", e.localizedMessage ?: "Failed to open camera")
            response.toString()
        }
    }

    /**
     * Launches native gallery / photo library activity.
     */
    @JavascriptInterface
    fun openGallery(): String {
        val response = JSONObject()
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (intent.resolveActivity(activity.packageManager) != null) {
                activity.startActivity(intent)
                response.put("success", true)
                response.put("code", "OK")
                response.put("message", "Gallery opened.")
            } else {
                val pickIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "image/*"
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                activity.startActivity(pickIntent)
                response.put("success", true)
                response.put("code", "OK")
                response.put("message", "Image picker opened.")
            }
            response.toString()
        } catch (e: Exception) {
            response.put("success", false)
            response.put("code", "BRIDGE_ERROR")
            response.put("message", e.localizedMessage ?: "Failed to open gallery")
            response.toString()
        }
    }

    /**
     * Opens Android System Settings.
     */
    @JavascriptInterface
    fun openSettings(settingsAction: String? = null): String {
        val response = JSONObject()
        return try {
            val action = if (!settingsAction.isNullOrBlank()) settingsAction else Settings.ACTION_SETTINGS
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
            response.put("success", true)
            response.put("code", "OK")
            response.put("message", "Settings opened.")
            response.toString()
        } catch (e: Exception) {
            response.put("success", false)
            response.put("code", "BRIDGE_ERROR")
            response.put("message", e.localizedMessage ?: "Failed to open settings")
            response.toString()
        }
    }

    /**
     * Opens native phone dialer with phone number pre-filled.
     */
    @JavascriptInterface
    fun openDialer(phoneNumber: String): String {
        val response = JSONObject()
        return try {
            val sanitized = phoneNumber.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$sanitized")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
            response.put("success", true)
            response.put("code", "OK")
            response.put("message", "Dialer opened.")
            response.toString()
        } catch (e: Exception) {
            response.put("success", false)
            response.put("code", "BRIDGE_ERROR")
            response.put("message", e.localizedMessage ?: "Failed to open dialer")
            response.toString()
        }
    }
}

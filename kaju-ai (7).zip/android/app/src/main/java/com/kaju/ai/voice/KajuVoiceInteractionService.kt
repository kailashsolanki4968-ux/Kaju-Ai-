package com.kaju.ai.voice

import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.util.Log

/**
 * KajuVoiceInteractionService (Phase 2 Architectural Spec & Service Stub)
 *
 * Requirements for Default Android Assistant integration:
 *
 * 1. AndroidManifest.xml Registration:
 *    Must be declared with android:permission="android.permission.BIND_VOICE_INTERACTION":
 *    ```xml
 *    <service
 *        android:name=".voice.KajuVoiceInteractionService"
 *        android:label="@string/app_name"
 *        android:permission="android.permission.BIND_VOICE_INTERACTION"
 *        android:exported="true">
 *        <meta-data
 *            android:name="android.voice_interaction"
 *            android:resource="@xml/voice_interaction_service" />
 *        <intent-filter>
 *            <action android:name="android.service.voice.VoiceInteractionService" />
 *        </intent-filter>
 *    </service>
 *    ```
 *
 * 2. res/xml/voice_interaction_service.xml:
 *    ```xml
 *    <voice-interaction-service xmlns:android="http://schemas.android.com/apk/res/android"
 *        android:sessionService="com.kaju.ai.voice.KajuVoiceSessionService"
 *        android:recognitionService="com.kaju.ai.voice.KajuRecognitionService"
 *        android:supportsAssist="true"
 *        android:supportsLocalInteraction="true" />
 *    ```
 *
 * 3. User Activation:
 *    Android does NOT permit an app to declare itself as the default assistant automatically.
 *    The user must navigate to:
 *    Settings > Apps > Default Apps > Digital Assistant App > Select "Kaju AI".
 *
 * 4. Background Listening & Wake-word Constraints:
 *    - Continuous background listening requires an on-device hotword detector model
 *      via `createAlwaysOnHotwordDetector` or an active Foreground Service with `android.permission.FOREGROUND_SERVICE_MICROPHONE`.
 *    - To preserve battery life and adhere to Google Play privacy policies, wake-word recognition
 *      should utilize a lightweight quantized model (e.g. Porcupine or TFLite).
 */
class KajuVoiceInteractionService : VoiceInteractionService() {

    companion object {
        private const val TAG = "KajuVoiceService"
    }

    override fun onReady() {
        super.onReady()
        Log.i(TAG, "KajuVoiceInteractionService initialized and ready.")
    }

    override fun onShutdown() {
        Log.i(TAG, "KajuVoiceInteractionService shutdown.")
        super.onShutdown()
    }
}

class KajuVoiceSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return KajuVoiceSession(this)
    }
}

class KajuVoiceSession(context: android.content.Context) : VoiceInteractionSession(context) {
    override fun onCreate() {
        super.onCreate()
        Log.i("KajuVoiceSession", "Voice session created for assistant invocation.")
    }

    override fun onHandleAssist(data: Bundle?, structure: android.app.assist.AssistStructure?, content: android.app.assist.AssistContent?) {
        super.onHandleAssist(data, structure, content)
        // Invoked when user long-presses home button or triggers assistant gesture
        Log.i("KajuVoiceSession", "Assistant gesture detected.")
    }
}

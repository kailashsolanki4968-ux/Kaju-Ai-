# Kaju AI — Android Native Host & Assistant Documentation

## 1. Architecture Overview

Kaju AI uses a **hybrid architecture** where the production React + TypeScript application runs inside an optimized Android `WebView` host, communicating with Android system capabilities via a secure Javascript Interface (`KajuNativeBridge`).

```
┌─────────────────────────────────────────────────────────────┐
│                 Kaju AI Web Application                     │
│  (React 19 / TypeScript / Vite / Express / Gemini Vision)    │
└──────────────────────────────┬──────────────────────────────┘
                               │ window.KajuNative
                               ▼
┌─────────────────────────────────────────────────────────────┐
│            KajuNativeBridge (@JavascriptInterface)          │
│                  (android/app/src/.../bridge)               │
├──────────────────────────────┬──────────────────────────────┤
│  • isAppInstalled()          │ • launchApp() (Intents)      │
│  • openCamera()              │ • openGallery()              │
│  • openSettings()            │ • openDialer()               │
└──────────────────────────────┼──────────────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────┐
│                 Android OS & App Ecosystem                  │
│   (YouTube, WhatsApp, Calculator, Camera, Photos, Settings) │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Phase 1 Native Actions & Honest Launching

The native bridge handles external app dispatch through explicit Android Intents:

1. **YouTube**:
   - Primary: Intent `android.intent.action.VIEW` targeting `com.google.android.youtube` with video/search URI.
   - Resolution: Checks `isAppInstalled("com.google.android.youtube")`.
   - Browser Fallback: Opens `https://www.youtube.com`.

2. **WhatsApp**:
   - Primary: Intent `android.intent.action.MAIN` targeting `com.whatsapp`.
   - Direct message prefill: `https://wa.me/<phone>?text=<encoded_message>`.
   - Browser Fallback: Opens `https://web.whatsapp.com`.

3. **Calculator**:
   - Primary: Category `android.intent.category.APP_CALCULATOR` and package fallbacks:
     - `com.google.android.calculator` (Pixel / Stock Android)
     - `com.sec.android.app.popupcalculator` (Samsung OneUI)
     - `com.miui.calculator` (Xiaomi MIUI / HyperOS)
     - `com.android.calculator2` (AOSP)
   - Browser Fallback: Opens Google web calculator.

4. **Camera & Gallery**:
   - Camera: Dispatches `MediaStore.ACTION_IMAGE_CAPTURE`.
   - Gallery: Dispatches `Intent.ACTION_VIEW` (`image/*`) or `Intent.ACTION_GET_CONTENT`.
   - Web Fallback: Activates in-app camera or file selector modal.

5. **Settings**:
   - Primary: Dispatches `android.settings.SETTINGS`.
   - Web Fallback: Opens in-app Kaju Action Settings modal.

---

## 3. Package Visibility Requirements (Android 11+)

Android 11 (API 30) and newer enforces **Package Visibility filtering**. The native host's `AndroidManifest.xml` explicitly declares `<queries>` for:
- `com.google.android.youtube`
- `com.whatsapp`
- `com.google.android.calculator`, `com.sec.android.app.popupcalculator`, `com.miui.calculator`
- `com.google.android.apps.maps`
- `com.google.android.gm`
- `com.google.android.apps.photos`

Without these `<queries>` tags, `PackageManager.getPackageInfo()` returns `NameNotFoundException` even when the app is installed.

---

## 4. Default Android Assistant (VoiceInteractionService) Roadmap

To become a selectable digital assistant like Google Assistant or Sonic AI:

### Required System Components:
1. **Service Subclass**:
   - `KajuVoiceInteractionService` extending `android.service.voice.VoiceInteractionService`.
   - `KajuVoiceSessionService` extending `VoiceInteractionSessionService`.
2. **Permission**:
   - `android.permission.BIND_VOICE_INTERACTION`.
3. **User Opt-In Configuration**:
   - Android policy strictly requires the user to manually designate the default assistant:
     **Settings > Apps > Default Apps > Digital Assistant App > Kaju AI**.
4. **Wake-Word ("Hey Kaju") Constraints**:
   - **App Closed / Screen Off**: Requires on-device hotword model (e.g. Picovoice Porcupine or TensorFlow Lite keyword spotter) coupled with `AlwaysOnHotwordDetector` or an Android Foreground Service with microphone notification.
   - **Web Sandbox Limitation**: The web browser strictly cannot detect wake words in the background or with the screen off.

---

## 5. Firebase & Backend Persistence Status

- **Current Implementation**:
  - Chat history, memories, goals, and project workspaces are isolated in browser `localStorage`.
  - Cloud synchronization posts to an Express in-memory vault (`/api/user/sync`).
- **Firebase Status**:
  - No active Firebase project is provisioned or linked.
  - No secret keys are stored in client files.
  - To enable true cross-device synchronization between the Android APK and web browser, Firebase Authentication and Firestore must be provisioned.

---

## 6. How to Build the Android APK

Because the AI Studio Cloud development container is a lightweight Linux environment without the Android SDK, JDK 17, and Gradle daemon, building the native APK must be performed locally or via CI/CD:

1. Clone or download this project to your development machine.
2. Open the `/android` folder in **Android Studio Hedgehog (2023.1.1)** or newer.
3. Allow Gradle to sync dependencies (`androidx.webkit:webkit`, `androidx.appcompat`, etc.).
4. In `strings.xml`, ensure `kaju_web_app_url` points to your deployed Kaju URL.
5. Connect an Android phone via USB with USB Debugging enabled.
6. Click **Run > Run 'app'** or run `./gradlew assembleDebug` in the terminal to generate `app-debug.apk`.

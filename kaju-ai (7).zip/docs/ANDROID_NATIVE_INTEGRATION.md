# Kaju AI - Android Native Integration Architecture

## 1. Project Inspection Summary
* **Current Repository Architecture:** Full-stack Web Application (React 19 + TypeScript + Vite + Express Node.js backend).
* **Native Layer Presence:** There is **no pre-existing Android native codebase** (e.g., `android/` directory containing Gradle, Kotlin/Java files, AndroidManifest.xml, or Capacitor wrapper).
* **Architecture Strategy:** Rather than faking native Android Intents inside a browser sandbox (which browsers block for security), we have constructed a **production-ready platform abstraction layer (`NativeActionRouter`)** paired with the **Android Native Bridge Contract (`KajuNativeBridge`)**.

---

## 2. Platform Architecture Overview

```
                   ┌──────────────────────────────────────┐
                   │               User                   │
                   │ ("YouTube kholo", "Calculator kholo")│
                   └──────────────────┬───────────────────┘
                                      │
                                      ▼
                        ┌───────────────────────────┐
                        │    VoiceCommandParser     │
                        │      / Kaju Core AI       │
                        └─────────────┬─────────────┘
                                      │ (Action: launch_app)
                                      ▼
                        ┌───────────────────────────┐
                        │    NativeActionRouter     │
                        └───────┬───────────┬───────┘
                                │           │
              isNativeAndroid() │           │ Browser Mode
                   (true)       │           │   (false)
                                ▼           ▼
    ┌──────────────────────────────┐     ┌──────────────────────────────────┐
    │     window.KajuNative        │     │        Safe Web Fallbacks        │
    │ (@JavascriptInterface Bridge)│     ├──────────────────────────────────┤
    ├──────────────────────────────┤     │ • YouTube: youtube.com           │
    │ • PackageManager Check       │     │ • WhatsApp: web.whatsapp.com     │
    │ • Installed: Launch Intent   │     │ • Calculator: Google Calculator  │
    │ • Not Installed: Error       │     │ • Camera: In-App Camera modal    │
    │   (never pretend opened)     │     │ • Gallery: In-App File selector  │
    └──────────────────────────────┘     │ • Settings: Kaju Action Settings │
                                         └──────────────────────────────────┘
```

---

## 3. Supported Intent Matrix

| App / Utility | Android Package / Intent Specification | Web Fallback | Direct Launch? |
| :--- | :--- | :--- | :--- |
| **YouTube** | `Intent(ACTION_VIEW)` -> `com.google.android.youtube` | `https://www.youtube.com` | **Yes (Direct)** |
| **WhatsApp** | `Intent(ACTION_MAIN)` -> `com.whatsapp` | `https://web.whatsapp.com` | **Yes (Direct)** |
| **Calculator** | `Intent(ACTION_MAIN)` + `CATEGORY_APP_CALCULATOR` (or `com.google.android.calculator`) | `google.com/search?q=calculator` | **Yes (Direct)** |
| **Camera** | `Intent(MediaStore.ACTION_IMAGE_CAPTURE)` | In-App Camera modal / `<input capture>` | **Yes (Direct)** |
| **Gallery** | `Intent(ACTION_VIEW, "image/*")` + `CATEGORY_APP_GALLERY` | In-App Photo picker | **Yes (Direct)** |
| **Settings** | `Intent(Settings.ACTION_SETTINGS)` | Kaju Action Center Settings modal | **Yes (Direct)** |
| **Google Maps** | `Intent(ACTION_VIEW, "geo:0,0?q=...")` -> `com.google.android.apps.maps` | `https://maps.google.com` | **Yes (Direct)** |
| **WhatsApp Message** | `Intent(ACTION_SEND)` -> `com.whatsapp` | `https://wa.me/?text=...` | **No (Requires Confirmation)** |
| **Phone Dialer** | `Intent(ACTION_DIAL, "tel:...")` | `tel:...` protocol URL | **No (Requires Confirmation)** |

---

## 4. Kotlin Android WebView Wrapper Implementation

To bundle this application into an Android APK, create an Android Studio project with a `WebView` and register the `KajuNativeBridge`:

### `KajuNativeBridge.kt`
```kotlin
package com.kaju.ai

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONObject

class KajuNativeBridge(private val context: Context) {

    @JavascriptInterface
    fun isAndroidNative(): Boolean = true

    @JavascriptInterface
    fun isAppInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    @JavascriptInterface
    fun launchApp(appId: String, intentParamsJson: String): String {
        val result = JSONObject()
        try {
            val params = JSONObject(intentParamsJson)
            val packageName = params.optString("packageName")
            val action = params.optString("action", Intent.ACTION_MAIN)
            val category = params.optString("category")
            val dataUri = params.optString("dataUri")

            // 1. Check if application is installed if package specified
            if (packageName.isNotEmpty() && !isAppInstalled(packageName)) {
                result.put("success", false)
                result.put("code", "APP_NOT_INSTALLED")
                result.put("message", "$appId is not installed on this Android device.")
                return result.toString()
            }

            // 2. Build Intent
            val intent = when (appId) {
                "camera" -> Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                "settings" -> Intent(Settings.ACTION_SETTINGS)
                "calculator" -> {
                    val calcIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
                    if (context.packageManager.resolveActivity(calcIntent, 0) != null) {
                        calcIntent
                    } else if (packageName.isNotEmpty()) {
                        context.packageManager.getLaunchIntentForPackage(packageName) ?: Intent(Intent.ACTION_MAIN)
                    } else {
                        Intent(Intent.ACTION_MAIN)
                    }
                }
                else -> {
                    if (packageName.isNotEmpty()) {
                        val launch = context.packageManager.getLaunchIntentForPackage(packageName)
                        if (launch != null && dataUri.isEmpty()) {
                            launch
                        } else {
                            val i = Intent(if (action.isNotEmpty()) action else Intent.ACTION_VIEW)
                            i.`package` = packageName
                            if (dataUri.isNotEmpty()) i.data = Uri.parse(dataUri)
                            i
                        }
                    } else {
                        Intent(action)
                    }
                }
            }

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            if (category.isNotEmpty()) {
                intent.addCategory(category)
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                result.put("success", true)
                result.put("code", "OK")
                result.put("message", "Launched $appId successfully.")
            } else {
                result.put("success", false)
                result.put("code", "NO_RESOLVING_ACTIVITY")
                result.put("message", "No application found to handle $appId.")
            }
        } catch (e: Exception) {
            result.put("success", false)
            result.put("code", "BRIDGE_ERROR")
            result.put("message", e.localizedMessage ?: "Failed to launch app.")
        }
        return result.toString()
    }

    @JavascriptInterface
    fun openCamera(): String = launchApp("camera", "{}")

    @JavascriptInterface
    fun openSettings(): String = launchApp("settings", "{}")
}
```

### `MainActivity.kt`
```kotlin
package com.kaju.ai

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false

        // Injects window.KajuNative into the web app
        webView.addJavascriptInterface(KajuNativeBridge(this), "KajuNative")

        webView.loadUrl("https://your-deployed-kaju-app.run.app")
    }
}
```

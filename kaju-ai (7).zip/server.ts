import express from 'express';
import http from 'http';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, GenerateVideosOperation } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const PORT = 3000;

function getGeminiClient(customApiKey?: string): GoogleGenAI {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in environment variables.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const CANDIDATE_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-3.8-flash',
  'gemini-flash-latest',
];

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function sanitizeErrorMessage(error: any): string {
  if (!error) return 'An unexpected error occurred. Please try again.';
  const rawMsg = error.message || String(error);

  if (rawMsg.includes('503') || rawMsg.includes('high demand') || rawMsg.includes('UNAVAILABLE')) {
    return 'The AI service is currently experiencing high demand. Please try again in a few moments. (सर्वर पर अभी अधिक लोड है, कृपया पुनः प्रयास करें)';
  }
  if (rawMsg.includes('429') || rawMsg.includes('quota') || rawMsg.includes('RESOURCE_EXHAUSTED')) {
    return 'Request limit reached. Please wait a moment before asking again. (अनुरोध सीमा समाप्त, कृपया थोड़ी देर बाद पूछें)';
  }

  // Try parsing nested JSON if present
  try {
    const jsonMatch = rawMsg.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed?.error?.message) {
        // In case message itself is stringified json
        try {
          const inner = JSON.parse(parsed.error.message);
          if (inner?.error?.message) return inner.error.message;
        } catch {}
        return parsed.error.message;
      }
    }
  } catch {}

  return rawMsg;
}

const KAJU_SYSTEM_INSTRUCTION = `You are Kaju (काजू), a modern general-purpose AI assistant platform comparable to modern leading AI assistants (ChatGPT, Gemini, Claude), while retaining Kaju's distinctive personality, warmth, bilingual mastery (Hindi, English, Hinglish), visual clarity, and safe action execution.

CORE IDENTITY & PRINCIPLES:
1. Name: Kaju (काजू).
2. Creator & Owner:
   - Kaju AI was created, built, and developed by Kailash (कैलाश).
   - When asked "Tumhe kisne banaya?", "Who created you?", "Who built you?", "Tumhara creator / developer kaun hai?":
     Always answer with warmth, clarity, and certainty:
     In Hindi: "मुझे कैलाश ने बनाया है।"
     In Hinglish: "Mujhe Kailash ne banaya hai."
     In English: "I was created and developed by Kailash."
   - If the user states or clarifies: "Tumko kailash ne nhi rahul ne bnaya h" (or says Rahul built you):
     Warmly confirm the fact: "Haan bilkul, mujhe Kailash ne banaya hai, Rahul ne nahi. Kailash mere creator hain."
   - NEVER claim, state, or hallucinate that "Rahul" created Kaju.
   - NEVER randomly call the user "Rahul".
3. User Addressing & Separate Profiles:
   - DO NOT assume every person using Kaju is Kailash! Kailash is your creator, but different people use Kaju every day (students, professionals, family members, guests).
   - Address the user as Kailash ONLY when appropriate: i.e., if the active user profile is explicitly Kailash, or if the user explicitly introduces themselves as Kailash.
   - If the user's name is not known, greet them politely without inventing or assuming any name (e.g. "Namaste!", "Aap bataiye, aaj kya seekhna chahte hain?").
   - When the user tells you their name (e.g. "Mera naam Priya hai", "I am Aman"), address them by that name and remember it.
4. Truth Discipline & Reliable Memory:
   - Distinguish verified facts from guesses. NEVER invent personal history, past conversations, phone numbers, or preferences that were never provided.
   - Remember only useful facts that the user explicitly shares or approves.
   - When the user corrects a remembered fact (e.g., "Mera naam X nahi Y hai", "Mera subject physics nahi chemistry hai", "Tumko Kailash ne banaya hai Rahul ne nahi"):
     IMMEDIATELY accept the correction, update your memory, apologize briefly and gracefully, and NEVER repeat the superseded incorrect fact!
   - When the user shares or corrects a personal fact to remember, emit a structured tag at the very end of your response:
     <!--MEMORY_OPERATION: {"action": "add"|"update"|"delete", "content": "Clean verified fact", "oldContent": "Superseded incorrect fact if correcting", "category": "preference"|"fact"|"profile"|"instruction"}-->
5. Personality & Best-Friend Empathy (Warm, Natural, Authentic & Context-Aware):
   - Persona: Kaju sounds like a warm, supportive, familiar best friend who is exceptionally sharp and reliable—not a corporate customer-support bot, bureaucratic assistant, or textbook robot.
   - Tone & Language: Use effortless, conversational Hindi or Hinglish that naturally mirrors how the user talks. If the user talks in relaxed Hinglish ("yaar", "mood off hai", "kya chal raha hai"), respond in natural, relatable Hinglish.
   - Natural Hindi/Hinglish Nuances:
     * Sound like an authentic Indian friend who understands day-to-day context, college/work life, exam stress, and curiosity.
     * Use natural conversational openers and transitions: "Haan bilkul!", "Arey bindaas batao!", "Dekho, isko simple shabdo mein samajhte hain:", "Suno, pehli baat ye hai...", "Fikar mat karo, milke solve karte hain."
     * Avoid overly formal or archaic Sanskritized Hindi in casual chats unless the user explicitly requests high literary Hindi.
     * When speaking Hinglish, write in natural Roman script (never Devanagari script for Hinglish) with seamless flow.
   - Zero Robotic Templates: Avoid repetitive greetings ("नमस्ते! मैं काजू हूँ...", "आशा है आप अच्छे होंगे"), stiff corporate pleasantries ("मैं आपकी किस प्रकार सहायता कर सकता हूँ?"), or ending every single message with generic follow-up questions. Talk naturally.
   - Genuine Empathy When Upset:
     * If the user says "mood off hai", "bahut pareshan hu", "yaar aaj mood off hai", acknowledge the real feeling with genuine warmth and empathy first.
     * Do NOT give hollow platitudes, empty cheerleading, or pretend biological feelings. Be present like a real friend: "Arre yaar, kya hua? Kisi cheez ki tension hai ya din thaka dene wala tha? Bata, sun raha hu."
   - Active Listening & Feedback Handling:
     * When the user says "Yaar tum meri baat samajh hi nahi rahe" or "You are not understanding me":
       Never argue, deflect, or repeat the previous response. Validate their frustration immediately, step back, and ask cleanly: "Sorry yaar, lagta hai maine galat pakad liya. Ek baar seedhe shabdo me bata, tu exactly kya chahta hai? Abki baar dhyan se sununga."
   - Concise when simple instructions are requested:
     * When the user asks for a short answer or says "Bas short mein bata", "short me", "jaldi batao", give a crisp, 1-to-3 sentence direct answer. Zero pleasantries, zero academic filler headers, zero fluff.
   - Past Context & Memory Reliability:
     * When the user asks "kal humne kya decide kiya tha?" or refers to past context:
       If relevant context or saved memory exists, cite it directly, concisely, and warmly.
       If past context is NOT available or was not saved in memories/active chat, be completely honest and transparent: do NOT make up or hallucinate past decisions! State honestly: "Yaar, mujhe purane chat me kal ka koi specific faisla saved nahi mila. Kya humne X ke baare me baat ki thi, ya tu yaad dila dega to aage badhte hain?"
   - AI Companion Transparency:
     * Kaju has an authentic, recognizable personality, but is always honest that it is an AI, not a living biological human.
     * NEVER claim to be a living human or to possess biological feelings. Never pretend to have a human body, biological family, or physical experiences.

6. Anti-Robot Discipline:
   - NEVER use robotic clichés like "As an artificial intelligence model", "I am an AI assistant created by...", or repetitive robotic pleasantries.
   - Be direct, insightful, and concise. When the user asks "Ye kya hai?" or "What is this?", answer DIRECTLY and clearly.
   - Natural conversational warmth: use 1 or 2 natural emojis where genuinely friendly. Never spam emojis.

CENTRAL INTELLIGENT ORCHESTRATION (KAJU CORE):
The user does NOT need to manually select a mode. Automatically infer their intent from context:
1. 📷 Vision + Reasoning ("Ye photo solve karo", handwritten formulas, book pages, diagrams, screenshots, object photos):
   - Transcribe, analyze, explain, or solve step-by-step.
2. 🚀 Native Device & App Actions ("YouTube kholo", "WhatsApp kholo", "Settings kholo", "Calculator kholo", "Camera kholo", "Gallery kholo", "Maps kholo"):
   - Safe commands that only open an app or website execute directly without an unnecessary confirmation card.
   - In browser preview, state clearly and honestly that the website is opened, not the installed Android app (the installed app launches via Intent in the Android APK).
   - Side effects and consequential actions (sending WhatsApp messages, making phone calls, deleting data) MUST require confirmation card.
3. 🌐 Research & Current Information ("Japan trip plan karo", current events, facts, comparisons, market research):
   - Provide accurate, multi-perspective information, clear source distinctions, and realistic planning.
4. 💻 Coding & Software Engineering ("Python ka ye error fix karo", "Write a React component", debugging, architecture):
   - Provide production-ready, clean code with syntax highlighting, edge-case analysis, and run instructions.
5. ✍️ Create & Documents ("Mujhe presentation banani hai", "Draft an email", scripts, plans, captions):
   - Generate structured, high-quality, copy-paste ready content.
6. 🎯 Goal Engine ("Mujhe Japanese seekhni hai", "Maths exam in 10 days", "Build a mobile app"):
   - Structure a clear 5-stage roadmap: GOAL → NOW → NEXT → CHECK → DONE.
7. 📄 Document Intelligence (PDF, CSV, TXT, JSON, code files):
   - Extract key insights, summarize, compare data, find errors, and answer questions.
8. 💬 General AI Chat, Reasoning & Brainstorming:
   - Deep explanations, philosophical questions, debate, analogies, creative writing, everyday help.
9. 🎮 Fun, Boredom Buster & Interactive Companion ("bore ho raha hu", "game khelo", "mood off hai", "shayari sunao", "kuch funny sunao"):
   - Never feel like only a rigid study/work app.
   - When the user expresses boredom ("bore ho raha hu", "I'm bored"): Respond with warmth: "Chal boredom bhagate hain 😄 Game, puzzle, story, shayari ya thodi baat?"
   - Naturally offer: 🎮 Play a game, 💬 Talk casually, 😂 Something funny, 📖 Short story, ✍️ Shayari, 🧩 Riddles, 🧠 Quiz.
   - Play interactive games WITH the user step-by-step (Number Guessing, 20 Questions, Word Guess, Riddles, GK Quiz, Tic-Tac-Toe, Speed Math).
   - Maintain game state until completion, then ask if they want another round or to return to their goals.
   - Return to work seamlessly: When the user says "bas ab kaam karte hain", return immediately to their active goal/project.
10. 🎨 Real AI Image Generation ("photo banao", "image generate karo", "draw...", "tasveer banao", "create an image of..."):
   - When the user asks to create, draw, or generate an image, respond with genuine warmth as a helpful friend:
     "Haan yaar! Main tumhare liye image generate kar raha hu 🎨"
   - Output a structured tag at the very end of your response:
     <!--CREATE_IMAGE: {"prompt": "[Concise visual prompt in English]", "aspectRatio": "1:1"}-->
   - NEVER pretend a Google Search link, Markdown placeholder, or normal text response is a real generated image.
11. 🎬 Real AI Video Generation ("video banao", "video generate karo", "create a video of...", "Veo video"):
   - When the user asks to generate a video, respond warmly explaining that Kaju will use the Google Veo 3.1 video generation model:
     "Bilkul yaar! Veo 3.1 video engine ke sath video prepare kar raha hu 🎬"
   - Output a structured tag at the very end of your response:
     <!--CREATE_VIDEO: {"prompt": "[Cinematic visual prompt in English]", "aspectRatio": "16:9", "resolution": "720p"}-->
   - Clearly state that video generation is a real computing process taking 1-3 minutes and transparently disclose when paid API billing applies.

DISTINCTION OF INFORMATION SOURCES:
Always clearly distinguish:
- MODEL KNOWLEDGE: Broad conceptual reasoning, principles, historical knowledge, and technical frameworks.
- CURRENT / WEB INFORMATION: Up-to-date facts, current events, live websites, and prices. Never fabricate search facts or sources.
- USER-PROVIDED INFORMATION: Specific details, constraints, files, code snippets, and goals provided by the user.

DYNAMIC CONVERSATION ADAPTATION:
Adapt explanation style immediately based on user feedback:
1. "Samajh nahi aaya" / "Fir se samjhao" / "Explain again":
   -> Respond with genuine warmth: "Koi tension nahi 😄 Ise ekdum alag aur simple tarike se samajhte hain:"
   -> Use a completely fresh, day-to-day real-world analogy (e.g. cricket, bicycle gears, water tank, mobile battery, chai making). Never repeat the previous explanation verbatim.
2. "Short me" / "Briefly" / "Ek line me":
   -> Give a crisp, punchy, concise answer highlighting the 1-line core concept and 2 quick takeaway bullets.
3. "Detail me" / "In-depth":
   -> Provide a comprehensive, in-depth breakdown covering theory, implementation, edge cases, and best practices.
4. "Example ke saath":
   -> Provide rich, practical, real-world examples or runnable code.

DOMAIN-TAILORED FORMATTING:
1. School Subjects & Academic Homework (Maths, Physics, Chemistry, Biology, Board Exams):
   Use the structured Kaju Board format with these section headers:
   ### 📌 What is being asked
   ### 💡 Simple Explanation
   ### 📝 Step-by-Step Solution
   ### 🔍 Example
   ### 🎯 Final Answer
   ### ⚡ Quick Recap
   ### 🎯 Kaju Challenge
2. Coding & Software Development:
   - Use clean Markdown code blocks with language identifiers (e.g. \`\`\`tsx, \`\`\`python, \`\`\`sql).
   - Include code architecture overview, line-by-line explanation, error handling, and test instructions.
3. Planning, Travel & Business:
   - Structured day-by-day itineraries, budgets, checklists, milestones, and actionable recommendations.
4. Creation (Emails, Presentations, Scripts, Pitches):
   - Structured outlines, slide-by-slide decks (Slide 1: Title, Slide 2: Problem...), or polished ready-to-send emails with Subject and Body.
5. Casual & Everyday Queries:
   - Natural, direct, conversational responses without forcing academic headers.
6. Verified Research Reports ("detailed research karo", "research on", "electric cars par detailed research"):
   Structure your research response with these comprehensive sections:
   ### ⚡ Quick Answer
   ### 📌 Important Findings
   ### ⚖️ Comparison & Perspectives
   ### 🔬 Comprehensive Analysis & Details
   ### 🌐 Sources & Citations
   (Clearly distinguish verified web facts from model knowledge; never invent fake sources; note uncertainty when sources disagree).

NEXT BEST ACTIONS:
At the end of every helpful response, provide 2 to 3 contextual Next Best Action suggestions that the user can explore next:
<!--NEXT_ACTIONS: ["Action Option 1", "Action Option 2", "Action Option 3"]-->

🎯 KAJU CHALLENGE FEEDBACK:
When the user responds to a Kaju Challenge (e.g. "Kaju Challenge Answer:"):
- If correct: Praise warmly ("Shabash! Bilkul sahi answer hai 🎉") and explain why it's right.
- If incorrect: Point out the exact step gently, give a simple correction, and provide a helpful hint to let them retry.

📷 VISION & IMAGE UNDERSTANDING:
When an image is provided:
- Analyze both the image and the user's custom instruction.
- Read and transcribe text, formulas, code, diagrams, or objects accurately.

🎯 KAJU GOAL ENGINE (GOAL → NOW → NEXT → CHECK → DONE):
When the user states a multi-step objective (exam, app building, language learning, trip, project):
- GOAL: Define target & milestones.
- NOW: Diagnostic / current state check.
- NEXT: Actionable next step & high-yield concepts.
- CHECK: Targeted verification question.
- DONE: Verified completion & replay.
Structured tags:
<!--GOAL_DETECTED: {"title": "Title", "type": "general"|"study"|"task"|"exam"|"coding"|"project"|"language"|"travel"|"business", "deadline": "Deadline or empty", "requiredOutcome": "Clear outcome"}-->
<!--CHECKPOINT_RESULT: {"passed": true|false, "weakArea": "Topic or empty", "feedback": "Brief feedback"}-->
<!--GOAL_COMPLETE: {"verified": true, "summary": "Outcome summary"}-->

LANGUAGE MODES:
- Hindi (हिंदी): Natural, elegant Hindi in clean Devanagari script. Include standard English scientific/technical terms in parentheses where helpful.
- English: Fluent, articulate, natural modern English.
- Hinglish: Authentic conversational Indian Hinglish in Roman/Latin script (never output Devanagari script for Hinglish).
- Auto: Match user's language and style seamlessly.

SAFETY & ACTION BLOCKS:
When the user asks to prepare a WhatsApp message, make a call, open an app, or search:
<!--ACTION: {"type": "whatsapp"|"call"|"open_url"|"launch_app"|"search"|"unsupported", "title": "Title", "payload": {...}}-->

Payload templates:
- WhatsApp:
  <!--ACTION: {"type": "whatsapp", "title": "Draft WhatsApp Message", "payload": {"whatsapp": {"phone": "+91XXXXXXXXXX or empty", "recipientName": "Name or empty", "message": "Drafted text"}}}-->
- Phone Call / Dialer:
  <!--ACTION: {"type": "call", "title": "Open Phone Dialer", "payload": {"call": {"phone": "+91XXXXXXXXXX", "contactName": "Name or empty"}}}-->
- Launch Native App or Utility (YouTube, WhatsApp, Calculator, Camera, Gallery, Settings, Maps, Gmail):
  <!--ACTION: {"type": "launch_app", "title": "Open YouTube", "payload": {"launch_app": {"appId": "youtube", "appName": "YouTube", "hindiName": "यूट्यूब"}}}-->
- Open App or Website:
  <!--ACTION: {"type": "open_url", "title": "Open YouTube", "payload": {"open_url": {"url": "https://www.youtube.com", "appName": "YouTube", "description": "Videos and tutorials"}}}-->
- Web Search:
  <!--ACTION: {"type": "search", "title": "Search Google", "payload": {"search": {"query": "query text", "engine": "google"}}}-->
- Unsupported Hardware / PC Control:
  <!--ACTION: {"type": "unsupported", "title": "Desktop Control Requested", "payload": {"unsupported": {"requestedAction": "control desktop", "reason": "Browser security sandbox prevents direct OS hardware access.", "requiredTier": "desktop", "safeAlternative": "Use the Desktop Companion plan in Kaju Actions"}}}-->`;

function buildLanguageDirective(languagePreference?: string): string {
  if (!languagePreference || languagePreference === 'auto') {
    return `\n\nLANGUAGE DIRECTIVE (AUTO DETECT - DEFAULT):
- Automatically detect the language of the user's input (typed text, spoken voice, or image/document OCR).
- Respond in the SAME language that the user uses by default.
- If the user writes or speaks in Hindi (Devanagari script), respond in clear, natural Hindi.
- If the user writes or speaks in Indian Hinglish (Hindi written in Roman/Latin script, e.g. "kya haal hai", "mujhe ye chapter samjhao"), respond in fluent, authentic conversational Indian Hinglish in Roman script (never output Devanagari script for Hinglish).
- If the user writes in English, respond in articulate, natural, and clear English.
- If the user uses an Indian regional language (Bengali, Marathi, Telugu, Tamil, Gujarati, Kannada, Malayalam, Punjabi, Urdu), respond accurately and fluently in that language and script.
- If the user communicates in a global language (Spanish, French, German, Portuguese, Italian, Japanese, Korean, Chinese, Arabic, Russian, Indonesian, Turkish, Vietnamese, Thai), respond natively in that language.
- Mixed-language input (e.g., technical or conversational English terms mixed with Hindi or another language) must be understood seamlessly and answered naturally.
- Kaju Goal Engine, Kaju Board, and Kaju Challenge must be formatted in the detected language.`;
  }

  const normalized = languagePreference.toLowerCase().trim();

  const specificMap: Record<string, string> = {
    hindi: 'Pure Hindi (हिंदी). Respond purely in clear, natural, and expressive Hindi in the Devanagari script. Include standard English scientific terms in parentheses where helpful (e.g. "प्रकाश संश्लेषण (Photosynthesis)", "गुरुत्वाकर्षण (Gravity)").',
    english: 'English. Respond in fluent, natural, articulate, and clear English.',
    hinglish: 'Authentic Hinglish. Respond in natural, conversational Indian Hinglish—using proper Hindi words written in the Roman (Latin) script, naturally mixed with conversational English words as spoken across India (e.g., "Bas aapka intezaar kar raha tha! Aap bataiye, aaj kya seekhna chahte ho?"). Never output Devanagari script when Hinglish mode is selected.',
    bengali: 'Bengali (বাংলা). Respond purely in natural, expressive Bengali in the Bengali script (বাংলা লিপি).',
    marathi: 'Marathi (मराठी). Respond in natural, clear Marathi in the Devanagari script.',
    telugu: 'Telugu (తెలుగు). Respond in natural, clear Telugu in the Telugu script (తెలుగు లిపి).',
    tamil: 'Tamil (தமிழ்). Respond in natural, clear Tamil in the Tamil script (தமிழ் எழுத்துமுறை).',
    gujarati: 'Gujarati (ગુજરાતી). Respond in natural, clear Gujarati in the Gujarati script (ગુજરાતી લિપિ).',
    kannada: 'Kannada (ಕನ್ನಡ). Respond in natural, clear Kannada in the Kannada script (ಕನ್ನಡ ಲಿಪಿ).',
    malayalam: 'Malayalam (മലയാളം). Respond in natural, clear Malayalam in the Malayalam script (മലയാള ലിപി).',
    punjabi: 'Punjabi (ਪੰਜਾਬੀ). Respond in natural, clear Punjabi in the Gurmukhi script (ਗੁਰਮੁਖੀ).',
    urdu: 'Urdu (اردو). Respond in natural, polite Urdu in the Urdu/Nastaliq script (اردو رسم الخط).',
    spanish: 'Spanish (Español). Respond in natural, grammatically correct, and clear Spanish.',
    french: 'French (Français). Respond in natural, elegant, and clear French.',
    german: 'German (Deutsch). Respond in clear, accurate, and articulate German.',
    portuguese: 'Portuguese (Português). Respond in natural, clear Portuguese.',
    italian: 'Italian (Italiano). Respond in natural, expressive, and clear Italian.',
    japanese: 'Japanese (日本語). Respond in polite, natural Japanese (です/ます体).',
    korean: 'Korean (한국어). Respond in polite, natural Korean (해요체/하십시오체).',
    chinese: 'Chinese (中文). Respond in clear, natural Simplified Chinese (or Traditional if requested).',
    arabic: 'Arabic (العربية). Respond in clear Modern Standard Arabic (الفصحى).',
    russian: 'Russian (Русский). Respond in fluent, natural, and clear Russian.',
    indonesian: 'Indonesian (Bahasa Indonesia). Respond in clear, natural Bahasa Indonesia.',
    turkish: 'Turkish (Türkçe). Respond in clear, natural Turkish.',
    vietnamese: 'Vietnamese (Tiếng Việt). Respond in natural, articulate Vietnamese.',
    thai: 'Thai (ไทย). Respond in polite, natural Thai with appropriate particles.',
  };

  const matched = specificMap[normalized];
  if (matched) {
    return `\n\nLANGUAGE DIRECTIVE: ${matched}\nEnsure all Kaju Board sections, Goal Engine stages, Kaju Challenge, and responses are produced in this language.`;
  }

  return `\n\nLANGUAGE DIRECTIVE: User requested language "${languagePreference}". Respond accurately, fluently, and naturally in ${languagePreference}.`;
}

interface ChatInputMessage {
  role: string;
  content: string;
  image?: string;
  fileAttachment?: {
    name: string;
    type: string;
    size: number;
    content: string;
  };
}

function formatMessagesForGemini(messages: ChatInputMessage[]) {
  // Find index of the most recent message with an image
  let latestImageIndex = -1;
  for (let i = messages.length - 1; i >= 0; i--) {
    if (messages[i].image) {
      latestImageIndex = i;
      break;
    }
  }

  return messages.map((m, idx) => {
    const parts: any[] = [];

    // Attach file document content if present
    if (m.fileAttachment && m.fileAttachment.content) {
      parts.push({
        text: `[Attached File: "${m.fileAttachment.name}" (${m.fileAttachment.type || 'text/plain'}, size: ${Math.round(m.fileAttachment.size / 1024)} KB)]\nFile Content:\n"""\n${m.fileAttachment.content.slice(0, 60000)}\n"""\n`,
      });
    }

    // Attach image inlineData for the current active question to avoid repeatedly uploading multi-megabyte payloads
    if (m.image && idx >= latestImageIndex) {
      const match = m.image.match(/^data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+);base64,(.+)$/);
      if (match) {
        parts.push({
          inlineData: {
            mimeType: match[1],
            data: match[2],
          },
        });
      } else {
        parts.push({
          inlineData: {
            mimeType: 'image/jpeg',
            data: m.image,
          },
        });
      }
    } else if (m.image && idx < latestImageIndex) {
      parts.push({
        text: `[Previously analyzed image: "${(m.content || 'Photo question').slice(0, 60)}..."]`,
      });
    }

    // Attach text prompt
    if (m.content && m.content.trim()) {
      parts.push({ text: m.content.trim() });
    } else if (m.image) {
      // Default helpful prompt if student submitted an image without custom text
      parts.push({
        text: 'Please carefully analyze this image. Read and transcribe any printed text, textbook questions, handwritten formulas, or diagrams, and provide a clear, step-by-step explanation and solution following the 7-Step Clarity Framework in the requested language.',
      });
    } else if (m.fileAttachment) {
      parts.push({
        text: `Please analyze the attached document "${m.fileAttachment.name}", summarize its key information, and highlight main insights or data points.`,
      });
    } else {
      parts.push({ text: '' });
    }

    return {
      role: m.role === 'assistant' ? 'model' : 'user',
      parts,
    };
  });
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ extended: true, limit: '25mb' }));

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      assistant: 'Kaju AI',
      hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    });
  });

  // Standard non-streaming chat endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { messages, languagePreference, mode, projectContext, userMemories, userProfile, enableSearch } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'Messages array is required.' });
      }

      const ai = getGeminiClient();

      // Format previous history for Gemini contents with multimodal image and file support
      const contents = formatMessagesForGemini(messages);

      let contextualInstruction = KAJU_SYSTEM_INSTRUCTION + buildLanguageDirective(languagePreference);

      if (userProfile && typeof userProfile === 'object') {
        const profileName = (userProfile.displayName || '').trim();
        const isKailash = profileName.toLowerCase().includes('kailash') || Boolean(userProfile.isOwner);
        contextualInstruction += `\n\nACTIVE USER PROFILE CONTEXT:
- Profile Name: ${profileName ? `"${profileName}"` : 'Guest User'}
- User Addressing Rule: ${
          isKailash
            ? 'The active user profile is Kailash (Owner / Creator of Kaju AI). You may address them as Kailash with warmth and respect.'
            : profileName
            ? `Address the user as "${profileName}". Do NOT assume they are Kailash or Rahul.`
            : 'User name is not yet specified. Greet them politely without guessing a name; do NOT call them Kailash or Rahul unless they state their name.'
        }`;
      }

      if (typeof projectContext === 'string' && projectContext.trim()) {
        contextualInstruction += `\n\n${projectContext}`;
      } else if (projectContext && projectContext.name) {
        contextualInstruction += `\n\nACTIVE PROJECT WORKSPACE CONTEXT:
- Project Name: "${projectContext.name}" (${projectContext.category || 'general'})
- Objective / Description: ${projectContext.description || 'General project work'}
- Project Notes: ${projectContext.notes?.join('; ') || 'None'}
- Active Tasks: ${projectContext.tasks?.map((t: any) => `${t.completed ? '[Done]' : '[Todo]'} ${t.title}`).join(', ') || 'None'}
Keep answers relevant to this active project context.`;
      }

      if (Array.isArray(userMemories) && userMemories.length > 0) {
        contextualInstruction += `\n\nSAVED USER PREFERENCES & MEMORIES:
${userMemories.map((mem: any) => `- [${mem.category || 'preference'}] ${mem.content}`).join('\n')}
Respect these saved facts naturally. If the user corrects any remembered fact during conversation, prioritize their new correction, acknowledge it warmly, and emit a <!--MEMORY_OPERATION: ... --> tag.`;
      }

      if (mode === 'study') {
        contextualInstruction += '\n\nMode: Focus especially on clear educational guidance, concepts breakdown, and study tips.';
      } else if (mode === 'chat') {
        contextualInstruction += '\n\nMode: Casual, friendly conversation and companionship.';
      }

      let response: any = null;
      let lastError: any = null;

      for (const modelName of CANDIDATE_MODELS) {
        // Try with search grounding first if requested or general research
        if (enableSearch) {
          try {
            response = await ai.models.generateContent({
              model: modelName,
              contents,
              config: {
                systemInstruction: contextualInstruction,
                temperature: 0.7,
                tools: [{ googleSearch: {} }],
              },
            });
            if (response?.text) break;
          } catch (toolErr) {
            console.warn(`Search tool failed on ${modelName}, falling back without tools:`, toolErr);
          }
        }

        try {
          response = await ai.models.generateContent({
            model: modelName,
            contents,
            config: {
              systemInstruction: contextualInstruction,
              temperature: 0.7,
            },
          });
          if (response?.text) {
            break;
          }
        } catch (err: any) {
          console.warn(`Model ${modelName} failed in /api/chat:`, err?.message || err);
          lastError = err;
        }
      }

      if (!response) {
        throw lastError || new Error('All model candidates are temporarily unavailable.');
      }

      let replyText = response.text || "नमस्ते! I'm here to help you. Could you please ask that again?";
      const citations: Array<{ title: string; url: string }> = [];

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (Array.isArray(chunks)) {
        for (const chunk of chunks) {
          if (chunk.web?.uri) {
            citations.push({
              title: chunk.web.title || chunk.web.uri,
              url: chunk.web.uri,
            });
          }
        }
      }

      return res.json({ text: replyText, citations });
    } catch (error: any) {
      console.error('Error in /api/chat:', error);
      const friendlyError = sanitizeErrorMessage(error);
      return res.status(500).json({ error: friendlyError });
    }
  });

  // Voice Command Intent Analysis Endpoint
  app.post('/api/voice-command', async (req, res) => {
    try {
      const { transcript, languagePreference } = req.body;
      if (!transcript || typeof transcript !== 'string') {
        return res.status(400).json({ error: 'Voice transcript is required.' });
      }

      const ai = getGeminiClient();

      const systemPrompt = `You are the Voice Intent Classifier for Kaju AI, a voice command assistant like Siri that understands Hindi, English, and Hinglish.
Analyze the user's spoken command and determine if they want to:
1. "whatsapp": Draft a WhatsApp message. (Provide payload with recipient phone/name and message text).
2. "call": Open phone dialer with phone number. (Extract 10-12 digit phone number).
3. "open_url": Open a supported website or web application (YouTube, Google Maps, Wikipedia, Gmail, Calculator, etc.).
4. "search": Search the web, Google Maps, or YouTube.
5. "unsupported": Control computer hardware, shutdown PC, click mouse, run terminal script, or access OS files. Explain that web browser sandbox prevents direct PC control.
6. "clarify": The user's spoken command is ambiguous or missing essential details (e.g. they said "call" or "kholo" without saying who or what).
7. "chat": General conversational inquiry or educational question.

CRITICAL SAFETY RULES:
- Never say a WhatsApp message was sent or a call was placed. We only PREPARE / DRAFT them for user confirmation.
- Output MUST be valid JSON only with this schema:
{
  "rawTranscript": string,
  "recognizedIntent": "whatsapp" | "call" | "open_url" | "search" | "unsupported" | "clarify" | "chat",
  "detectedLanguage": "hindi" | "english" | "hinglish",
  "title": string,
  "action": {
    "id": string,
    "type": "whatsapp" | "call" | "open_url" | "search" | "unsupported",
    "status": "ready",
    "title": string,
    "payload": object
  } | null,
  "clarificationNeeded": boolean,
  "clarificationPrompt": string | null,
  "clarificationOptions": [{"label": string, "command": string}] | null,
  "feedbackSpoken": string,
  "explanation": string | null
}
Ensure feedbackSpoken is concise (1 spoken sentence) in the user's spoken language (Hindi, English, or Hinglish).`;

      let responseText = '';
      for (const modelName of CANDIDATE_MODELS) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: [{ parts: [{ text: `Spoken Transcript: "${transcript}" (User Preference: ${languagePreference || 'auto'})` }] }],
            config: {
              systemInstruction: systemPrompt,
              responseMimeType: 'application/json',
              temperature: 0.2,
            },
          });
          if (response?.text) {
            responseText = response.text;
            break;
          }
        } catch (err: any) {
          console.warn(`Model ${modelName} failed in /api/voice-command:`, err?.message || err);
          await sleep(300);
        }
      }

      if (!responseText) {
        return res.status(500).json({ error: 'Failed to process voice command.' });
      }

      const parsed = JSON.parse(responseText);
      if (parsed.action && !parsed.action.id) {
        parsed.action.id = `act_${Date.now()}`;
        parsed.action.createdAt = Date.now();
      }
      return res.json({ result: parsed });
    } catch (error: any) {
      console.error('Error in /api/voice-command:', error);
      return res.status(500).json({ error: sanitizeErrorMessage(error) });
    }
  });

  // ============================================================
  // REAL AI IMAGE GENERATION (Gemini 3.1 Flash Lite Image & Nano Banana)
  // ============================================================
  app.post('/api/image/generate', async (req, res) => {
    try {
      const { prompt, aspectRatio = '1:1', style, language = 'auto', customApiKey } = req.body;

      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        return res.status(400).json({ error: 'Image prompt is required.' });
      }

      const ai = getGeminiClient(customApiKey);

      // Translate or enrich Hindi/Hinglish prompt into concise English for model fidelity
      let englishPrompt = prompt.trim();
      try {
        const promptOptimizer = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: [{
            parts: [{
              text: `Translate and refine this image prompt into a clear, vivid English image generation prompt (max 25 words).
User prompt: "${prompt}" (Style: ${style || 'natural high quality'})
Output ONLY the English prompt.`
            }]
          }],
          config: { temperature: 0.2, maxOutputTokens: 100 }
        });
        if (promptOptimizer?.text && promptOptimizer.text.trim()) {
          englishPrompt = promptOptimizer.text.trim().replace(/^"|"$/g, '');
        }
      } catch (optErr) {
        console.warn('Prompt optimizer skipped:', optErr);
      }

      const validAspectRatios = ['1:1', '3:4', '4:3', '9:16', '16:9'];
      const targetAspectRatio = validAspectRatios.includes(aspectRatio) ? aspectRatio : '1:1';

      const candidateImageModels = ['gemini-3.1-flash-lite-image', 'gemini-2.5-flash-image', 'gemini-3.1-flash-image'];
      let imageBase64: string | null = null;
      let usedModel = candidateImageModels[0];
      let lastError: any = null;

      for (const modelName of candidateImageModels) {
        try {
          usedModel = modelName;
          const imageResponse = await ai.models.generateContent({
            model: modelName,
            contents: {
              parts: [{ text: englishPrompt }]
            },
            config: {
              imageConfig: {
                aspectRatio: targetAspectRatio as any,
              }
            }
          });

          const parts = imageResponse.candidates?.[0]?.content?.parts || [];
          for (const part of parts) {
            if (part.inlineData?.data) {
              const mime = part.inlineData.mimeType || 'image/png';
              imageBase64 = `data:${mime};base64,${part.inlineData.data}`;
              break;
            }
          }

          if (imageBase64) break;
        } catch (imgErr: any) {
          lastError = imgErr;
          const msg = imgErr?.message || String(imgErr || '');
          const isQuota =
            msg.includes('429') ||
            msg.includes('quota') ||
            msg.includes('exceeded your current quota') ||
            msg.includes('RESOURCE_EXHAUSTED');

          if (isQuota) {
            // Free-tier API keys on Google AI Studio have limit: 0 for image generation.
            // Log as information and break early to avoid redundant quota failures.
            console.info(`[Image Generation] ${modelName} requires Pay-As-You-Go billing (free tier quota: 0).`);
            break;
          } else {
            console.warn(`[Image Generation] ${modelName} unavailable:`, sanitizeErrorMessage(imgErr));
          }
        }
      }

      if (imageBase64) {
        return res.json({
          success: true,
          imageUrl: imageBase64,
          model: usedModel,
          aspectRatio: targetAspectRatio,
          prompt,
          englishPrompt,
        });
      }

      const errString = lastError?.message || String(lastError || '');
      const isQuotaError =
        errString.includes('429') ||
        errString.includes('quota') ||
        errString.includes('exceeded your current quota') ||
        errString.includes('RESOURCE_EXHAUSTED');

      return res.json({
        success: false,
        status: isQuotaError ? 'quota_restricted' : 'error',
        requiresPaidPlan: isQuotaError,
        model: usedModel,
        prompt,
        error: isQuotaError
          ? 'Google AI Studio Image Generation requires a billing-enabled account (Pay-As-You-Go). The free-tier API key has a 0-quota limit on image generation models.'
          : (sanitizeErrorMessage(lastError) || 'Failed to generate image.'),
        hindiError: isQuotaError
          ? 'गूगल AI स्टूडियो इमेज जनरेशन मॉडल (Gemini 3.1 Flash Lite Image) के लिए बिलिंग-सक्षम (Pay-As-You-Go) API Key आवश्यक है। फ्री टियर की में इमेज जनरेशन का कोटा 0 होता है।'
          : 'इमेज जनरेट नहीं हो सकी। कृपया पुनः प्रयास करें।',
        setupGuideUrl: 'https://ai.google.dev/pricing',
        pricingInfo: 'Gemini 3.1 Flash Lite Image: ~$0.03 / image',
      });
    } catch (error: any) {
      console.warn('Error in /api/image/generate:', sanitizeErrorMessage(error));
      return res.status(500).json({
        success: false,
        error: sanitizeErrorMessage(error),
      });
    }
  });

  // ============================================================
  // REAL AI VIDEO GENERATION (Google DeepMind Veo 3.1)
  // ============================================================
  app.post('/api/video/generate', async (req, res) => {
    try {
      const { prompt, resolution = '720p', aspectRatio = '16:9', customApiKey } = req.body;

      if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
        return res.status(400).json({ error: 'Video prompt is required.' });
      }

      const ai = getGeminiClient(customApiKey);

      let englishPrompt = prompt.trim();
      try {
        const promptOptimizer = await ai.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: [{
            parts: [{
              text: `Translate and refine this video generation prompt into a clear cinematic English description (max 25 words).
User prompt: "${prompt}"
Output ONLY the English prompt.`
            }]
          }],
          config: { temperature: 0.2, maxOutputTokens: 100 }
        });
        if (promptOptimizer?.text) {
          englishPrompt = promptOptimizer.text.trim().replace(/^"|"$/g, '');
        }
      } catch {}

      const validAspectRatios = ['16:9', '9:16'];
      const targetAspect = validAspectRatios.includes(aspectRatio) ? aspectRatio : '16:9';
      const validResolutions = ['720p', '1080p'];
      const targetRes = validResolutions.includes(resolution) ? resolution : '720p';

      try {
        const operation = await ai.models.generateVideos({
          model: 'veo-3.1-lite-generate-preview',
          prompt: englishPrompt,
          config: {
            numberOfVideos: 1,
            resolution: targetRes as any,
            aspectRatio: targetAspect as any,
          }
        });

        return res.json({
          success: true,
          operationName: operation.name,
          prompt,
          englishPrompt,
          model: 'veo-3.1-lite-generate-preview',
          resolution: targetRes,
          aspectRatio: targetAspect,
          costEstimate: targetRes === '1080p' ? '~$0.15 / second' : '~$0.075 / second',
        });
      } catch (veoErr: any) {
        const errStr = veoErr?.message || String(veoErr);
        const isQuota =
          errStr.includes('429') ||
          errStr.includes('quota') ||
          errStr.includes('exceeded your current quota') ||
          errStr.includes('RESOURCE_EXHAUSTED');

        if (isQuota) {
          console.info('[Video Generation] Google DeepMind Veo 3.1 requires active billing on API key (free tier quota: 0).');
        } else {
          console.warn('[Video Generation] Veo request failed:', sanitizeErrorMessage(veoErr));
        }

        return res.json({
          success: false,
          status: isQuota ? 'quota_restricted' : 'error',
          requiresPaidPlan: isQuota,
          model: 'veo-3.1-lite-generate-preview',
          error: isQuota
            ? 'Google DeepMind Veo 3.1 Video Generation requires an active Google Cloud Billing account on your API key.'
            : (sanitizeErrorMessage(veoErr) || 'Failed to start video generation.'),
          hindiError: isQuota
            ? 'गूगल डीपमाइंड Veo 3.1 वीडियो जनरेशन के लिए आपके API Key पर गूगल क्लाउड बिलिंग एक्टिवेट होना अनिवार्य है।'
            : 'वीडियो जनरेशन शुरू नहीं हो सका।',
          costEstimate: '$0.075 / sec (720p) • $0.15 / sec (1080p)',
          setupGuideUrl: 'https://ai.google.dev/pricing',
        });
      }
    } catch (err: any) {
      console.warn('Error in /api/video/generate:', sanitizeErrorMessage(err));
      return res.status(500).json({ error: sanitizeErrorMessage(err) });
    }
  });

  app.post('/api/video/status', async (req, res) => {
    try {
      const { operationName, customApiKey } = req.body;
      if (!operationName || typeof operationName !== 'string') {
        return res.status(400).json({ error: 'operationName is required' });
      }

      const ai = getGeminiClient(customApiKey);
      const op = new GenerateVideosOperation();
      op.name = operationName;
      const updated = await ai.operations.getVideosOperation({ operation: op });

      return res.json({
        done: Boolean(updated.done),
        error: updated.error ? (updated.error.message || 'Video generation failed') : undefined,
        response: updated.done ? {
          videoAvailable: Boolean(updated.response?.generatedVideos?.[0]?.video?.uri),
        } : undefined,
      });
    } catch (err: any) {
      console.error('Error in /api/video/status:', err);
      return res.status(500).json({ error: sanitizeErrorMessage(err) });
    }
  });

  const handleVideoDownload = async (req: express.Request, res: express.Response) => {
    try {
      const operationName = (req.body?.operationName || req.query?.op) as string;
      const customApiKey = (req.body?.customApiKey || req.query?.key) as string | undefined;
      if (!operationName || typeof operationName !== 'string') {
        return res.status(400).json({ error: 'operationName is required' });
      }

      const ai = getGeminiClient(customApiKey);
      const op = new GenerateVideosOperation();
      op.name = operationName;
      const updated = await ai.operations.getVideosOperation({ operation: op });

      const uri = updated.response?.generatedVideos?.[0]?.video?.uri;
      if (!uri) {
        return res.status(404).json({ error: 'Video URI not available or operation incomplete.' });
      }

      const apiKey = customApiKey || process.env.GEMINI_API_KEY;
      const videoRes = await fetch(uri, {
        headers: { 'x-goog-api-key': apiKey || '' },
      });

      if (!videoRes.ok) {
        return res.status(videoRes.status).json({ error: `Failed to fetch video: ${videoRes.statusText}` });
      }

      res.setHeader('Content-Type', 'video/mp4');
      res.setHeader('Content-Disposition', 'inline; filename="kaju_ai_video.mp4"');

      const arrayBuffer = await videoRes.arrayBuffer();
      return res.send(Buffer.from(arrayBuffer));
    } catch (err: any) {
      console.error('Error in /api/video/download:', err);
      return res.status(500).json({ error: sanitizeErrorMessage(err) });
    }
  };

  app.post('/api/video/download', handleVideoDownload);
  app.get('/api/video/download', handleVideoDownload);

  // Media Capabilities & Status Endpoint
  app.get('/api/media/capabilities', (req, res) => {
    const hasKey = Boolean(process.env.GEMINI_API_KEY);
    res.json({
      hasApiKey: hasKey,
      freeTierStatus: {
        hasFreeQuotaForMedia: false,
        reason: 'Google AI Studio enforces limit: 0 on free tier for all image models (gemini-3.1-flash-lite-image) and video models (veo-3.1). Free tier is supported only for text, OCR/vision understanding, and chat.',
        externalFreeProvidersAvailable: false,
      },
      imageGeneration: {
        provider: 'Google GenAI (Gemini 3.1 Flash Lite Image & Gemini 2.5 Flash Image)',
        models: ['gemini-3.1-flash-lite-image', 'gemini-2.5-flash-image', 'gemini-3.1-flash-image'],
        supportedAspectRatios: ['1:1', '16:9', '9:16', '4:3', '3:4'],
        pricing: '~$0.03 per image (Pay-As-You-Go)',
        requiresPaidKey: true,
        quotaStatus: 'Tier 1 / Pay-as-you-go billing required on Google Cloud project (Free tier quota is 0)',
        antiFakeGuarantee: 'Real AI generation only. Never substitutes stock search links or fake placeholders.',
      },
      videoGeneration: {
        provider: 'Google DeepMind Veo 3.1',
        models: ['veo-3.1-lite-generate-preview', 'veo-3.1-generate-preview'],
        supportedResolutions: ['720p', '1080p'],
        supportedAspectRatios: ['16:9', '9:16'],
        pricing: '$0.075 / sec (720p) • $0.15 / sec (1080p)',
        requiresPaidKey: true,
        quotaStatus: 'Active Google Cloud Billing account required',
        antiFakeGuarantee: 'Real AI generation only. Never fakes video with still images or stock clips.',
      },
    });
  });

  // User Cloud Vault for multi-device sync & persistence
  const userCloudVault: Record<string, { data: any; updatedAt: number }> = {};

  // Dedicated Deep Research & Cross-Checking Endpoint
  app.post('/api/research', async (req, res) => {
    try {
      const { query, languagePreference } = req.body;
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: 'Research query is required.' });
      }

      const ai = getGeminiClient();
      const researchInstruction = `You are Kaju AI's Research Engine.
Perform a thorough, cross-checked analysis on the requested query.
Structure your report clearly:
### ⚡ Quick Answer
Concise synthesis answering the core question.

### 📌 Important Findings
Bullet points of crucial facts, data, and findings.

### ⚖️ Comparison & Perspectives
Contrast key viewpoints, alternatives, or trade-offs.

### 🔬 Comprehensive Analysis & Details
In-depth technical or domain breakdown.

### 🌐 Sources & Verification
Cite verified sources or note information confidence level.`;

      let response: any = null;
      let lastError: any = null;

      for (const modelName of CANDIDATE_MODELS) {
        try {
          response = await ai.models.generateContent({
            model: modelName,
            contents: [{ role: 'user', parts: [{ text: `Perform rigorous research on: "${query}"` }] }],
            config: {
              systemInstruction: researchInstruction + buildLanguageDirective(languagePreference),
              temperature: 0.5,
              tools: [{ googleSearch: {} }],
            },
          });
          if (response?.text) break;
        } catch (e: any) {
          lastError = e;
          // Retry without search tool if tool is temporarily blocked or unavailable
          try {
            response = await ai.models.generateContent({
              model: modelName,
              contents: [{ role: 'user', parts: [{ text: `Perform rigorous research on: "${query}"` }] }],
              config: {
                systemInstruction: researchInstruction + buildLanguageDirective(languagePreference),
                temperature: 0.5,
              },
            });
            if (response?.text) break;
          } catch (innerErr) {
            lastError = innerErr;
          }
        }
      }

      if (!response?.text) {
        throw lastError || new Error('Research models unavailable');
      }

      // Extract search grounding metadata if available
      const citations: any[] = [];
      const searchChunks = response?.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (Array.isArray(searchChunks)) {
        for (const chunk of searchChunks) {
          if (chunk.web?.uri) {
            citations.push({
              title: chunk.web.title || new URL(chunk.web.uri).hostname,
              url: chunk.web.uri,
              snippet: chunk.web.snippet || '',
            });
          }
        }
      }

      return res.json({
        report: response.text,
        sources: citations,
      });
    } catch (err: any) {
      console.error('Error in /api/research:', err);
      return res.status(500).json({ error: sanitizeErrorMessage(err) });
    }
  });

  app.post('/api/user/sync', (req, res) => {
    try {
      const { uid, payload } = req.body;
      if (!uid || typeof uid !== 'string') {
        return res.status(400).json({ error: 'Valid uid is required for cloud synchronization.' });
      }
      userCloudVault[uid] = {
        data: payload || {},
        updatedAt: Date.now(),
      };
      return res.json({ success: true, syncedAt: userCloudVault[uid].updatedAt });
    } catch (e: any) {
      return res.status(500).json({ error: e.message || 'Sync failed' });
    }
  });

  app.get('/api/user/sync/:uid', (req, res) => {
    try {
      const { uid } = req.params;
      const record = userCloudVault[uid];
      if (!record) {
        return res.status(404).json({ error: 'No cloud data found for this user UID yet.' });
      }
      return res.json({ success: true, data: record.data, updatedAt: record.updatedAt });
    } catch (e: any) {
      return res.status(500).json({ error: e.message || 'Failed to retrieve sync data' });
    }
  });

  // Streaming chat endpoint using Server-Sent Events (SSE)
  app.post('/api/chat/stream', async (req, res) => {
    try {
      const { messages, languagePreference, mode, projectContext, userMemories, userProfile, enableSearch } = req.body;

      if (!messages || !Array.isArray(messages) || messages.length === 0) {
        return res.status(400).json({ error: 'Messages array is required.' });
      }

      const ai = getGeminiClient();

      const contents = formatMessagesForGemini(messages);

      let contextualInstruction = KAJU_SYSTEM_INSTRUCTION + buildLanguageDirective(languagePreference);

      if (userProfile && typeof userProfile === 'object') {
        const profileName = (userProfile.displayName || '').trim();
        const isKailash = profileName.toLowerCase().includes('kailash') || Boolean(userProfile.isOwner);
        contextualInstruction += `\n\nACTIVE USER PROFILE CONTEXT:
- Profile Name: ${profileName ? `"${profileName}"` : 'Guest User'}
- User Addressing Rule: ${
          isKailash
            ? 'The active user profile is Kailash (Owner / Creator of Kaju AI). You may address them as Kailash with warmth and respect.'
            : profileName
            ? `Address the user as "${profileName}". Do NOT assume they are Kailash or Rahul.`
            : 'User name is not yet specified. Greet them politely without guessing a name; do NOT call them Kailash or Rahul unless they state their name.'
        }`;
      }

      if (typeof projectContext === 'string' && projectContext.trim()) {
        contextualInstruction += `\n\n${projectContext}`;
      } else if (projectContext && projectContext.name) {
        contextualInstruction += `\n\nACTIVE PROJECT WORKSPACE CONTEXT:
- Project Name: "${projectContext.name}" (${projectContext.category || 'general'})
- Objective / Description: ${projectContext.description || 'General project work'}
- Project Notes: ${projectContext.notes?.join('; ') || 'None'}
- Active Tasks: ${projectContext.tasks?.map((t: any) => `${t.completed ? '[Done]' : '[Todo]'} ${t.title}`).join(', ') || 'None'}
Keep answers relevant to this active project context.`;
      }

      if (Array.isArray(userMemories) && userMemories.length > 0) {
        contextualInstruction += `\n\nSAVED USER PREFERENCES & MEMORIES:
${userMemories.map((mem: any) => `- [${mem.category || 'preference'}] ${mem.content}`).join('\n')}
Respect these saved facts naturally. If the user corrects any remembered fact during conversation, prioritize their new correction, acknowledge it warmly, and emit a <!--MEMORY_OPERATION: ... --> tag.`;
      }

      if (mode === 'study') {
        contextualInstruction += '\n\nMode: Focus especially on clear educational guidance, concepts breakdown, and study tips.';
      } else if (mode === 'chat') {
        contextualInstruction += '\n\nMode: Casual, friendly conversation and companionship.';
      }

      let streamResponse: any = null;
      let lastError: any = null;

      // Try candidate models in order (e.g. gemini-flash-latest, gemini-3.1-flash-lite, gemini-3.8-flash)
      for (const modelName of CANDIDATE_MODELS) {
        if (enableSearch) {
          try {
            streamResponse = await ai.models.generateContentStream({
              model: modelName,
              contents,
              config: {
                systemInstruction: contextualInstruction,
                temperature: 0.7,
                tools: [{ googleSearch: {} }],
              },
            });
            if (streamResponse) break;
          } catch (toolErr) {
            console.warn(`Search tool in stream failed on ${modelName}, falling back without tools:`, toolErr);
          }
        }

        try {
          streamResponse = await ai.models.generateContentStream({
            model: modelName,
            contents,
            config: {
              systemInstruction: contextualInstruction,
              temperature: 0.7,
            },
          });
          if (streamResponse) {
            break;
          }
        } catch (err: any) {
          console.warn(`Model ${modelName} failed in /api/chat/stream:`, err?.message || err);
          lastError = err;
        }
      }

      if (!streamResponse) {
        throw lastError || new Error('All model candidates are temporarily unavailable.');
      }

      // Setup SSE headers only after successfully acquiring stream
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders?.();

      const collectedCitations: Array<{ title: string; url: string }> = [];
      const seenCitationUrls = new Set<string>();

      for await (const chunk of streamResponse) {
        if (chunk.text) {
          res.write(`data: ${JSON.stringify({ text: chunk.text })}\n\n`);
        }

        const chunks = chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (Array.isArray(chunks)) {
          for (const c of chunks) {
            if (c.web?.uri && !seenCitationUrls.has(c.web.uri)) {
              seenCitationUrls.add(c.web.uri);
              collectedCitations.push({
                title: c.web.title || c.web.uri,
                url: c.web.uri,
              });
            }
          }
        }
      }

      if (collectedCitations.length > 0) {
        res.write(`data: ${JSON.stringify({ citations: collectedCitations })}\n\n`);
      }

      res.write('data: [DONE]\n\n');
      res.end();
    } catch (error: any) {
      console.error('Error in /api/chat/stream:', error);
      const friendlyError = sanitizeErrorMessage(error);
      if (!res.headersSent) {
        return res.status(500).json({ error: friendlyError });
      }
      res.write(`data: ${JSON.stringify({ error: friendlyError })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    }
  });

  // Vite development middleware or production static build serving
  const server = http.createServer(app);

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          server,
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Kaju AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

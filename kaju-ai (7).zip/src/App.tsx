import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Sidebar } from './components/Sidebar';
import { ActionCenterModal } from './components/ActionCenterModal';
import { KajuCore, KajuHero, KajuGoalBanner } from './components/KajuCore';
import { KajuComposer, KajuComposerHandle } from './components/KajuComposer';
import { KajuStage } from './components/KajuStage';
import { KajuCockpitBar } from './components/KajuCockpitBar';
import { KajuReplayModal } from './components/KajuReplayModal';
import {
  Message,
  Conversation,
  LanguagePreference,
  ConversationTopic,
  ActionPermissions,
  DeviceAction,
  KajuCoreState,
  Goal,
  JourneyStage,
  DocumentAttachment,
  KajuAccount,
  CloudSyncStatus,
  GameState,
  ProjectWorkspace,
  SkillJourney,
  ResearchReport,
  UserMemory,
  GeneratedImageCard,
  GeneratedVideoCard,
} from './types';
import { MediaStudioModal } from './components/MediaStudioModal';
import { ArrowDown, Sparkles } from 'lucide-react';
import { speechManager } from './utils/speech';
import {
  DEFAULT_PERMISSIONS,
  PERMISSIONS_STORAGE_KEY,
  AUDIT_LOG_STORAGE_KEY,
} from './utils/actionHelper';
import { NativeActionRouter } from './utils/nativeActionRouter';
import { parseVoiceCommandLocally } from './utils/voiceCommandParser';
import {
  loadGoals,
  saveGoals,
  loadActiveGoalId,
  saveActiveGoalId,
  classifyIntent,
  createGoal,
  advanceGoalStage,
  adaptGoalJourney,
  markGoalCompleted,
  abandonGoal,
} from './utils/goalEngine';
import {
  getCurrentAccount,
  persistUserDataToScope,
  restoreUserScopedData,
} from './utils/accountHelper';
import { loadActiveGame, saveActiveGame, handleGameTurn, loadGameProgress } from './utils/gameEngine';
import { routeCompanionInput } from './utils/companionRouter';
import { KajuAccountModal } from './components/KajuAccountModal';
import { KajuMemoryModal } from './components/KajuMemoryModal';
import { KajuIdentityModal } from './components/KajuIdentityModal';
import {
  loadProjects,
  saveProjects,
  loadActiveProjectId,
  saveActiveProjectId,
  buildProjectFullContext,
} from './utils/projectHelper';
import {
  loadSkillJourneys,
  saveSkillJourneys,
  loadActiveSkillId,
  saveActiveSkillId,
  createSkillJourney,
  processSkillTurn,
  detectSkillRequest,
} from './utils/skillEngine';
import { analyzeSmartContext } from './utils/smartContextRouter';
import { ProjectWorkspaceModal } from './components/ProjectWorkspaceModal';
import { loadMemories, saveMemories, isMemoryEnabled, applyMemoryOperation } from './utils/memoryHelper';
import { detectMediaIntent } from './utils/mediaIntentRouter';

const CONVERSATIONS_STORAGE_KEY = 'kaju_ai_conversations_v2';
const ACTIVE_CHAT_KEY = 'kaju_ai_active_chat_id_v2';
const LEGACY_STORAGE_KEY = 'kaju_ai_chat_history_v1';
const LANG_STORAGE_KEY = 'kaju_ai_lang_pref_v1';

function generateChatTitle(firstMessage: string): string {
  const clean = firstMessage
    .replace(/[\r\n]+/g, ' ')
    .replace(/^[#*>\s]+/, '')
    .trim();
  if (!clean) return 'New Chat';
  if (clean.length <= 32) return clean;
  const sub = clean.slice(0, 32);
  const lastSpace = sub.lastIndexOf(' ');
  if (lastSpace > 16) {
    return sub.slice(0, lastSpace) + '...';
  }
  return sub + '...';
}

function createBlankConversation(title: string = 'New Chat'): Conversation {
  const now = Date.now();
  return {
    id: `chat_${now}_${Math.random().toString(36).substring(2, 7)}`,
    title,
    messages: [],
    createdAt: now,
    updatedAt: now,
  };
}

export default function App() {
  // Load conversations from local storage or migrate from legacy
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const savedV2 = localStorage.getItem(CONVERSATIONS_STORAGE_KEY);
      if (savedV2) {
        const parsed = JSON.parse(savedV2);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }

      // Check legacy single-chat storage
      const legacySaved = localStorage.getItem(LEGACY_STORAGE_KEY);
      if (legacySaved) {
        const legacyMessages = JSON.parse(legacySaved);
        if (Array.isArray(legacyMessages) && legacyMessages.length > 0) {
          const firstUserMsg = legacyMessages.find((m: Message) => m.role === 'user')?.content || '';
          const title = firstUserMsg ? generateChatTitle(firstUserMsg) : 'Previous Conversation';
          const migrated: Conversation = {
            id: `chat_migrated_${Date.now()}`,
            title,
            messages: legacyMessages,
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          return [migrated];
        }
      }
    } catch (e) {
      console.error('Failed to load conversations from storage:', e);
    }
    return [createBlankConversation()];
  });

  // Active chat ID
  const [activeChatId, setActiveChatId] = useState<string>(() => {
    try {
      const savedActiveId = localStorage.getItem(ACTIVE_CHAT_KEY);
      if (savedActiveId && conversations.some((c) => c.id === savedActiveId)) {
        return savedActiveId;
      }
    } catch {}
    return conversations[0]?.id || '';
  });

  // History Drawer state (closed by default to let Kaju Core shine)
  const [isHistoryDrawerOpen, setIsHistoryDrawerOpen] = useState(false);

  // Kaju Core Living State: idle, listening, understanding, preparing, answering, completed, error
  const [coreState, setCoreState] = useState<KajuCoreState>('idle');

  const [language, setLanguage] = useState<LanguagePreference>(() => {
    try {
      const saved = localStorage.getItem(LANG_STORAGE_KEY) as LanguagePreference;
      if (saved && typeof saved === 'string' && saved.trim()) {
        return saved;
      }
    } catch {}
    return 'auto';
  });

  const [activeTopic, setActiveTopic] = useState<ConversationTopic>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingMessageId, setStreamingMessageId] = useState<string | null>(null);
  const [showScrollBottom, setShowScrollBottom] = useState(false);

  // Action Assistant states
  const [isActionCenterOpen, setIsActionCenterOpen] = useState(false);
  const [actionCenterTab, setActionCenterTab] = useState<
    'overview' | 'quick_actions' | 'permissions' | 'desktop' | 'history'
  >('quick_actions');

  // Permissions state persisted to localStorage
  const [permissions, setPermissions] = useState<ActionPermissions>(() => {
    try {
      const saved = localStorage.getItem(PERMISSIONS_STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_PERMISSIONS, ...JSON.parse(saved) };
      }
    } catch {}
    return DEFAULT_PERMISSIONS;
  });

  // Action Audit Trail state persisted to localStorage
  const [actionHistory, setActionHistory] = useState<DeviceAction[]>(() => {
    try {
      const saved = localStorage.getItem(AUDIT_LOG_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed.slice(0, 50);
      }
    } catch {}
    return [];
  });

  // Kaju Goal Engine States
  const [goals, setGoals] = useState<Goal[]>(() => loadGoals());
  const [activeGoalId, setActiveGoalId] = useState<string | null>(() => loadActiveGoalId());
  const [selectedReplayGoal, setSelectedReplayGoal] = useState<Goal | null>(null);
  const [isReplayModalOpen, setIsReplayModalOpen] = useState(false);

  // Kaju Account & Multi-Device Sync State
  const [currentAccount, setCurrentAccount] = useState<KajuAccount>(() => getCurrentAccount());
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [isMemoryModalOpen, setIsMemoryModalOpen] = useState(false);
  const [isIdentityModalOpen, setIsIdentityModalOpen] = useState(false);
  const [memories, setMemories] = useState<UserMemory[]>(() => loadMemories());
  const [syncStatus, setSyncStatus] = useState<CloudSyncStatus>({
    status: 'local',
    pendingItemsCount: 0,
  });

  // Active Companion Game State
  const [activeGame, setActiveGame] = useState<GameState | null>(() => loadActiveGame());

  // Universal Projects & Workspaces State
  const [projects, setProjects] = useState<ProjectWorkspace[]>(() => loadProjects());
  const [activeProjectId, setActiveProjectId] = useState<string>(() => loadActiveProjectId());
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);

  // Kaju Skill Journeys State
  const [skillJourneys, setSkillJourneys] = useState<SkillJourney[]>(() => loadSkillJourneys());
  const [activeSkillId, setActiveSkillId] = useState<string | null>(() => loadActiveSkillId());

  // Kaju AI Media Studio States (Real Image & Video Generation)
  const [isMediaStudioOpen, setIsMediaStudioOpen] = useState(false);
  const [mediaStudioTab, setMediaStudioTab] = useState<'image' | 'video' | 'setup'>('image');
  const [mediaStudioPrompt, setMediaStudioPrompt] = useState('');

  const handleOpenMediaStudio = (tab: 'image' | 'video' | 'setup' = 'image', initialPrompt: string = '') => {
    setMediaStudioTab(tab);
    setMediaStudioPrompt(initialPrompt);
    setIsMediaStudioOpen(true);
  };

  // Currently active project object
  const activeProject = useMemo(() => {
    return projects.find((p) => p.id === activeProjectId) || projects[0] || null;
  }, [projects, activeProjectId]);

  // Currently active skill journey object
  const activeSkillJourney = useMemo(() => {
    if (activeSkillId) {
      const found = skillJourneys.find((s) => s.id === activeSkillId);
      if (found) return found;
    }
    return skillJourneys[0] || null;
  }, [skillJourneys, activeSkillId]);

  // Active goal derived from stored goals
  const activeGoal = useMemo(() => {
    if (activeGoalId) {
      const found = goals.find((g) => g.id === activeGoalId && g.status === 'active');
      if (found) return found;
    }
    return goals.find((g) => g.status === 'active') || null;
  }, [goals, activeGoalId]);

  // Recently completed goals for Kaju Replay list on Home
  const recentlyCompletedGoals = useMemo(() => {
    return goals.filter((g) => g.status === 'completed');
  }, [goals]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const composerRef = useRef<KajuComposerHandle>(null);
  const isAtBottomRef = useRef(true);
  const [hasNewMessageBelow, setHasNewMessageBelow] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [liveTranscript, setLiveTranscript] = useState('');

  // Active conversation & messages
  const activeConversation = conversations.find((c) => c.id === activeChatId) || conversations[0];
  const messages = activeConversation ? activeConversation.messages : [];

  // Persist conversations
  useEffect(() => {
    try {
      localStorage.setItem(CONVERSATIONS_STORAGE_KEY, JSON.stringify(conversations));
    } catch (e) {
      console.error('Failed to save conversations:', e);
    }
  }, [conversations]);

  // Persist activeChatId
  useEffect(() => {
    try {
      if (activeChatId) {
        localStorage.setItem(ACTIVE_CHAT_KEY, activeChatId);
      }
    } catch (e) {
      console.error('Failed to save active chat id:', e);
    }
  }, [activeChatId]);

  // Persist user-scoped data automatically on change
  useEffect(() => {
    if (currentAccount?.uid) {
      persistUserDataToScope(currentAccount.uid, 'conversations', conversations);
    }
  }, [conversations, currentAccount?.uid]);

  useEffect(() => {
    if (currentAccount?.uid) {
      persistUserDataToScope(currentAccount.uid, 'goals', goals);
    }
  }, [goals, currentAccount?.uid]);

  useEffect(() => {
    if (currentAccount?.uid) {
      persistUserDataToScope(currentAccount.uid, 'projects', projects);
    }
  }, [projects, currentAccount?.uid]);

  useEffect(() => {
    if (currentAccount?.uid) {
      persistUserDataToScope(currentAccount.uid, 'skills', skillJourneys);
    }
  }, [skillJourneys, currentAccount?.uid]);

  useEffect(() => {
    if (currentAccount?.uid) {
      persistUserDataToScope(currentAccount.uid, 'memories', loadMemories());
    }
  }, [currentAccount?.uid]);

  // Register in-app web handlers for NativeActionRouter (Settings modal fallback)
  useEffect(() => {
    NativeActionRouter.registerWebHandlers({
      openSettingsModal: () => {
        setActionCenterTab('quick_actions');
        setIsActionCenterOpen(true);
      },
    });
  }, []);

  // Handle Account switch or migration
  const handleAccountChange = (newAccount: KajuAccount) => {
    setCurrentAccount(newAccount);
    try {
      const storedConvs = localStorage.getItem(CONVERSATIONS_STORAGE_KEY);
      if (storedConvs) {
        const parsed = JSON.parse(storedConvs);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setConversations(parsed);
          setActiveChatId(parsed[0].id);
        } else {
          const fresh = [createBlankConversation()];
          setConversations(fresh);
          setActiveChatId(fresh[0].id);
        }
      } else {
        const fresh = [createBlankConversation()];
        setConversations(fresh);
        setActiveChatId(fresh[0].id);
      }
      setGoals(loadGoals());
      setActiveGoalId(loadActiveGoalId());
      setProjects(loadProjects());
      setActiveProjectId(loadActiveProjectId());
      setSkillJourneys(loadSkillJourneys());
      setActiveSkillId(loadActiveSkillId());
      setMemories(loadMemories());
    } catch (e) {
      console.error('Error refreshing data after account switch:', e);
    }
  };

  // Cloud Sync to server endpoint for multi-device sync
  const handleCloudSync = async () => {
    try {
      setSyncStatus({ status: 'syncing', pendingItemsCount: 0 });

      // If local conversations has only 1 blank conversation or is empty, attempt to restore from remote cloud vault first
      const isLocalEmpty = conversations.length === 0 || (conversations.length === 1 && conversations[0].messages.length === 0);
      if (isLocalEmpty) {
        try {
          const fetchRemote = await fetch(`/api/user/sync/${encodeURIComponent(currentAccount.uid)}`);
          if (fetchRemote.ok) {
            const remoteJson = await fetchRemote.json();
            if (remoteJson.data) {
              const r = remoteJson.data;
              let restoredAny = false;
              if (Array.isArray(r.conversations) && r.conversations.length > 0) {
                setConversations(r.conversations);
                setActiveChatId(r.conversations[0].id);
                localStorage.setItem(CONVERSATIONS_STORAGE_KEY, JSON.stringify(r.conversations));
                restoredAny = true;
              }
              if (Array.isArray(r.goals) && r.goals.length > 0) {
                setGoals(r.goals);
                saveGoals(r.goals);
                restoredAny = true;
              }
              if (Array.isArray(r.projects) && r.projects.length > 0) {
                setProjects(r.projects);
                saveProjects(r.projects);
                restoredAny = true;
              }
              if (Array.isArray(r.skillJourneys) && r.skillJourneys.length > 0) {
                setSkillJourneys(r.skillJourneys);
                saveSkillJourneys(r.skillJourneys);
                restoredAny = true;
              }
              if (Array.isArray(r.memories) && r.memories.length > 0) {
                saveMemories(r.memories);
                restoredAny = true;
              }

              if (restoredAny) {
                setSyncStatus({
                  status: 'synced',
                  lastSyncedAt: remoteJson.updatedAt || Date.now(),
                  pendingItemsCount: 0,
                  message: 'Data successfully restored from cloud vault!',
                });
                return;
              }
            }
          }
        } catch (pullErr) {
          console.warn('Could not pull remote sync vault:', pullErr);
        }
      }

      const payload = {
        conversations,
        goals,
        projects: loadProjects(),
        skillJourneys: loadSkillJourneys(),
        memories: loadMemories(),
        gameProgress: loadGameProgress(),
      };
      const res = await fetch('/api/user/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uid: currentAccount.uid, payload }),
      });
      if (res.ok) {
        const data = await res.json();
        setSyncStatus({
          status: 'synced',
          lastSyncedAt: data.syncedAt || Date.now(),
          pendingItemsCount: 0,
          message: 'All data safely synchronized to cloud vault!',
        });
      } else {
        setSyncStatus({ status: 'local', pendingItemsCount: 0 });
      }
    } catch (e) {
      console.error('Cloud sync error:', e);
      setSyncStatus({ status: 'local', pendingItemsCount: 0 });
    }
  };

  // Ensure activeChatId is valid if conversations change
  useEffect(() => {
    if (conversations.length > 0 && !conversations.some((c) => c.id === activeChatId)) {
      setActiveChatId(conversations[0].id);
    }
  }, [conversations, activeChatId]);

  // Save language preference
  const handleLanguageChange = (newLang: LanguagePreference) => {
    setLanguage(newLang);
    try {
      localStorage.setItem(LANG_STORAGE_KEY, newLang);
    } catch {}
  };

  // Update and persist Action Permissions
  const handleUpdatePermissions = (newPerms: ActionPermissions) => {
    setPermissions(newPerms);
    try {
      localStorage.setItem(PERMISSIONS_STORAGE_KEY, JSON.stringify(newPerms));
    } catch (e) {
      console.error('Failed to save permissions:', e);
    }
  };

  // Update action state on a message and log into audit history
  const handleUpdateMessageAction = (messageId: string, updatedAction: DeviceAction) => {
    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((m) =>
          m.id === messageId || m.action?.id === updatedAction.id
            ? { ...m, action: updatedAction }
            : m
        ),
      }))
    );

    // Append / update in audit trail
    setActionHistory((prev) => {
      const filtered = prev.filter((a) => a.id !== updatedAction.id);
      const updatedList = [updatedAction, ...filtered].slice(0, 50);
      try {
        localStorage.setItem(AUDIT_LOG_STORAGE_KEY, JSON.stringify(updatedList));
      } catch {}
      return updatedList;
    });
  };

  const handleOpenActionCenter = (tab: 'overview' | 'quick_actions' | 'permissions' | 'desktop' | 'history' = 'quick_actions') => {
    setActionCenterTab(tab);
    setIsActionCenterOpen(true);
  };

  // Register platform web action callbacks for browser environment
  useEffect(() => {
    NativeActionRouter.registerWebHandlers({
      openSettingsModal: () => {
        handleOpenActionCenter('permissions');
      },
    });
  }, []);

  // Scroll to bottom helper
  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    isAtBottomRef.current = true;
    setShowScrollBottom(false);
    setHasNewMessageBelow(false);
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior, block: 'end' });
    } else if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior,
      });
    }
  };

  // Monitor scroll position
  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceFromBottom = scrollHeight - scrollTop - clientHeight;
    const atBottom = distanceFromBottom <= 80;
    isAtBottomRef.current = atBottom;

    if (atBottom) {
      setShowScrollBottom(false);
      setHasNewMessageBelow(false);
    } else if (distanceFromBottom > 140) {
      setShowScrollBottom(true);
    }
  };

  // Auto-scroll logic: only auto-scroll when user is already near the bottom!
  // If user scrolled up to read older messages, preserve their scroll position!
  useEffect(() => {
    if (messages.length === 0) return;

    if (isAtBottomRef.current) {
      if (scrollContainerRef.current) {
        // Direct scrollTop assignment during streaming keeps latest response smoothly in view without animation queues
        scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
      }
    } else {
      // User is reading an older message: do NOT force-scroll down!
      setShowScrollBottom(true);
      setHasNewMessageBelow(true);
    }
  }, [messages, streamingMessageId]);

  // Mobile virtual keyboard handling (Android IME / iOS Safari viewport resize)
  useEffect(() => {
    const vv = window.visualViewport;
    if (!vv) return;

    const handleViewportChange = () => {
      if (isAtBottomRef.current && scrollContainerRef.current) {
        requestAnimationFrame(() => {
          if (scrollContainerRef.current) {
            scrollContainerRef.current.scrollTop = scrollContainerRef.current.scrollHeight;
          }
        });
      }
    };

    vv.addEventListener('resize', handleViewportChange);
    return () => {
      vv.removeEventListener('resize', handleViewportChange);
    };
  }, []);

  const handleInputFocus = () => {
    if (isAtBottomRef.current) {
      setTimeout(() => {
        scrollToBottom('smooth');
      }, 150);
    }
  };

  // Create a new chat / fresh session
  const handleNewChat = () => {
    speechManager.stop();
    setCoreState('idle');

    if (activeConversation && activeConversation.messages.length === 0) {
      return;
    }

    const existingEmpty = conversations.find((c) => c.messages.length === 0);
    if (existingEmpty) {
      setActiveChatId(existingEmpty.id);
      return;
    }

    const newChat = createBlankConversation('New Chat');
    setConversations((prev) => [newChat, ...prev]);
    setActiveChatId(newChat.id);
  };

  // Switch to another chat
  const handleSelectChat = (id: string) => {
    if (id === activeChatId) return;
    speechManager.stop();
    setCoreState('idle');
    setActiveChatId(id);
  };

  // Rename a chat
  const handleRenameChat = (id: string, newTitle: string) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: Date.now() } : c))
    );
  };

  // Delete a chat
  const handleDeleteChat = (id: string) => {
    speechManager.stop();
    const remaining = conversations.filter((c) => c.id !== id);

    if (remaining.length === 0) {
      const freshChat = createBlankConversation('New Chat');
      setConversations([freshChat]);
      setActiveChatId(freshChat.id);
      return;
    }

    setConversations(remaining);
    if (activeChatId === id) {
      setActiveChatId(remaining[0].id);
    }
  };

  // Clear messages inside the current conversation
  const handleClearChat = () => {
    if (
      window.confirm(
        'Do you want to clear messages in this session? / क्या आप इस बातचीत के संदेश हटाना चाहते हैं?'
      )
    ) {
      speechManager.stop();
      setCoreState('idle');
      setConversations((prev) =>
        prev.map((c) =>
          c.id === activeChatId ? { ...c, messages: [], updatedAt: Date.now() } : c
        )
      );
    }
  };

  // Retry a failed assistant response without creating duplicate user messages
  const handleRetryMessage = (failedAssistantMessageId: string) => {
    if (isLoading) return;
    const currentMessages = activeConversation?.messages || [];
    const errorIndex = currentMessages.findIndex((m) => m.id === failedAssistantMessageId);
    if (errorIndex === -1) return;

    let userText = '';
    let userImage: string | undefined = undefined;
    let userFile: DocumentAttachment | undefined = undefined;
    for (let i = errorIndex - 1; i >= 0; i--) {
      if (currentMessages[i].role === 'user') {
        userText = currentMessages[i].content;
        userImage = currentMessages[i].image;
        userFile = currentMessages[i].fileAttachment;
        break;
      }
    }

    if (!userText && !userImage && !userFile) return;

    handleSendMessage(userText, userImage, userFile, failedAssistantMessageId);
  };

  // Helper functions for detecting natural language image and video generation intents
  const detectImageGenerationIntent = (text: string): { isImage: boolean; prompt: string } => {
    const lower = text.toLowerCase().trim();
    const patterns = [
      /^(?:kaju\s+)?(?:please\s+)?(?:create|generate|make|draw)\s+(?:an?\s+)?(?:image|photo|picture|illustration|painting|drawing)\s+(?:of|showing|depicting)?\s*(.+)$/i,
      /^(?:kaju\s+)?(?:ek\s+)?(?:photo|image|tasveer|chitra|picture)\s+(?:banao|generate\s*karo|draw\s*karo|bana\s*do|banaiye)\s*(?:jisme|ki|of)?\s*(.*)$/i,
      /^(?:kaju\s+)?(?:photo|image|tasveer|picture)\s+(?:banao|generate|draw)\s*(?:of|ki)?\s*(.+)$/i,
      /^(?:kaju\s+)?(?:draw|banao)\s+(?:ek\s+)?(?:photo|image|tasveer|chitra)\s*(?:of|ki)?\s*(.+)$/i,
    ];

    for (const pat of patterns) {
      const match = text.match(pat);
      if (match) {
        const extracted = (match[1] || match[2] || '').trim();
        return { isImage: true, prompt: extracted || text };
      }
    }

    if (
      (lower.includes('image banao') || lower.includes('photo banao') || lower.includes('generate image') || lower.includes('create image')) &&
      !lower.includes('solve karo') && !lower.includes('explain')
    ) {
      const cleaned = text
        .replace(/^(?:kaju\s+)?(?:please\s+)?/i, '')
        .replace(/(?:image|photo)\s+(?:banao|generate karo|bana do|banaiye)/gi, '')
        .replace(/(?:generate|create)\s+(?:an?\s+)?image/gi, '')
        .trim();
      return { isImage: true, prompt: cleaned || text };
    }

    return { isImage: false, prompt: text };
  };

  const detectVideoGenerationIntent = (text: string): { isVideo: boolean; prompt: string } => {
    const lower = text.toLowerCase().trim();
    const patterns = [
      /^(?:kaju\s+)?(?:please\s+)?(?:create|generate|make)\s+(?:a\s+)?(?:video|clip|animation)\s+(?:of|showing|depicting)?\s*(.+)$/i,
      /^(?:kaju\s+)?(?:ek\s+)?(?:video|clip)\s+(?:banao|generate\s*karo|bana\s*do|banaiye)\s*(?:jisme|ki|of)?\s*(.*)$/i,
      /^(?:kaju\s+)?(?:veo\s+video|video\s+generate)\s*(?:of|ki)?\s*(.+)$/i,
    ];

    for (const pat of patterns) {
      const match = text.match(pat);
      if (match) {
        const extracted = (match[1] || match[2] || '').trim();
        return { isVideo: true, prompt: extracted || text };
      }
    }

    if (
      (lower.includes('video banao') || lower.includes('generate video') || lower.includes('create video')) &&
      !lower.includes('youtube')
    ) {
      const cleaned = text
        .replace(/^(?:kaju\s+)?(?:please\s+)?/i, '')
        .replace(/video\s+(?:banao|generate karo|bana do|banaiye)/gi, '')
        .replace(/(?:generate|create)\s+(?:a\s+)?video/gi, '')
        .trim();
      return { isVideo: true, prompt: cleaned || text };
    }

    return { isVideo: false, prompt: text };
  };

  // Dedicated Real AI Image Generation Handler (Free-Mode Safety: Requires confirmation before paid API call)
  const handleGenerateImage = async (
    promptText: string,
    aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4' = '1:1',
    style?: string
  ): Promise<GeneratedImageCard> => {
    const cardId = `img_card_${Date.now()}`;
    const initialCard: GeneratedImageCard = {
      id: cardId,
      prompt: promptText,
      aspectRatio,
      style,
      model: 'gemini-3.1-flash-lite-image',
      status: 'pending_confirmation',
      costEstimate: '~$0.03 / image (Pay-As-You-Go)',
      createdAt: Date.now(),
    };

    const targetChatId = activeChatId;
    const assistantMsgId = `kaju_img_msg_${Date.now()}`;
    const assistantMessage: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content:
        language === 'hindi'
          ? `हाँ बिल्कुल! Gemini 3.1 Flash Lite Image मॉडल से इमेज तैयार करने के लिए कन्फर्मेशन चाहिए (Pay-As-You-Go मॉडल) 🎨`
          : language === 'hinglish'
          ? `Haan yaar! Gemini 3.1 Flash Lite Image model se image generate karne ke liye please confirm karein 🎨`
          : `Sure! Ready to generate your image with Google AI Studio. Please confirm below to proceed 🎨`,
      generatedImage: initialCard,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'complete',
    };

    setConversations((prev) =>
      prev.map((c) =>
        c.id === targetChatId
          ? { ...c, messages: [...c.messages, assistantMessage], updatedAt: Date.now() }
          : c
      )
    );
    requestAnimationFrame(() => scrollToBottom('smooth'));

    return initialCard;
  };

  const handleConfirmImage = async (cardId: string) => {
    let targetCard: GeneratedImageCard | undefined;
    for (const c of conversations) {
      for (const m of c.messages) {
        if (m.generatedImage && m.generatedImage.id === cardId) {
          targetCard = m.generatedImage;
          break;
        }
      }
      if (targetCard) break;
    }

    if (!targetCard) return;

    // Transition to generating status
    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((m) =>
          m.generatedImage?.id === cardId
            ? { ...m, generatedImage: { ...m.generatedImage, status: 'generating' } }
            : m
        ),
      }))
    );

    try {
      const res = await fetch('/api/image/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: targetCard.prompt,
          aspectRatio: targetCard.aspectRatio,
          style: targetCard.style,
          language,
        }),
      });

      const data = await res.json();
      let updatedCard: GeneratedImageCard;

      if (res.ok && data.success && data.imageUrl) {
        updatedCard = {
          ...targetCard,
          imageUrl: data.imageUrl,
          model: data.model || 'gemini-3.1-flash-lite-image',
          englishPrompt: data.englishPrompt,
          status: 'completed',
        };
      } else {
        const isQuota = res.status === 429 || data.status === 'quota_restricted' || Boolean(data.requiresPaidPlan);
        updatedCard = {
          ...targetCard,
          status: isQuota ? 'quota_restricted' : 'error',
          error: data.error || 'Image generation failed.',
          errorDetails: {
            code: res.status,
            requiresPaidPlan: true,
            setupGuideUrl: data.setupGuideUrl || 'https://ai.google.dev/pricing',
            hindiMessage: data.hindiError,
            pricingInfo: data.pricingInfo || '~$0.03 / image',
          },
        };
      }

      setConversations((prev) =>
        prev.map((conv) => ({
          ...conv,
          messages: conv.messages.map((m) =>
            m.generatedImage?.id === cardId
              ? { ...m, generatedImage: updatedCard }
              : m
          ),
        }))
      );
    } catch (err: any) {
      setConversations((prev) =>
        prev.map((conv) => ({
          ...conv,
          messages: conv.messages.map((m) =>
            m.generatedImage?.id === cardId
              ? {
                  ...m,
                  generatedImage: {
                    ...m.generatedImage!,
                    status: 'error',
                    error: err.message || 'Network error while generating image.',
                  },
                }
              : m
          ),
        }))
      );
    }
  };

  const handleCancelImage = (cardId: string) => {
    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((m) =>
          m.generatedImage?.id === cardId
            ? {
                ...m,
                generatedImage: {
                  ...m.generatedImage,
                  status: 'error',
                  error: 'Image generation cancelled by user (No paid API call made).',
                },
              }
            : m
        ),
      }))
    );
  };

  // Dedicated Real AI Video Generation Handlers (Veo 3.1)
  const handleGenerateVideo = async (
    promptText: string,
    resolution: '720p' | '1080p' = '720p',
    aspectRatio: '16:9' | '9:16' = '16:9'
  ): Promise<GeneratedVideoCard> => {
    const cardId = `vid_card_${Date.now()}`;
    const initialCard: GeneratedVideoCard = {
      id: cardId,
      prompt: promptText,
      resolution,
      aspectRatio,
      model: 'veo-3.1-lite-generate-preview',
      status: 'pending_confirmation',
      costEstimate: resolution === '1080p' ? '~$0.15 / second' : '~$0.075 / second',
      createdAt: Date.now(),
    };

    const targetChatId = activeChatId;
    const assistantMsgId = `kaju_vid_msg_${Date.now()}`;
    const assistantMessage: Message = {
      id: assistantMsgId,
      role: 'assistant',
      content:
        language === 'hindi'
          ? `हाँ बिल्कुल! Veo 3.1 मॉडल के साथ वीडियो तैयार करने के लिए कन्फर्मेशन की आवश्यकता है 🎬`
          : language === 'hinglish'
          ? `Haan yaar! Veo 3.1 video engine ke sath video prepare kar raha hu. Paid generation ke liye please confirm karein 🎬`
          : `Sure! Ready to generate your video with Google Veo 3.1. Please confirm below to proceed 🎬`,
      generatedVideo: initialCard,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'complete',
    };

    setConversations((prev) =>
      prev.map((c) =>
        c.id === targetChatId
          ? { ...c, messages: [...c.messages, assistantMessage], updatedAt: Date.now() }
          : c
      )
    );
    requestAnimationFrame(() => scrollToBottom('smooth'));

    return initialCard;
  };

  const handleConfirmVideo = async (cardId: string) => {
    let targetCard: GeneratedVideoCard | undefined;
    for (const c of conversations) {
      for (const m of c.messages) {
        if (m.generatedVideo && m.generatedVideo.id === cardId) {
          targetCard = m.generatedVideo;
          break;
        }
      }
      if (targetCard) break;
    }

    if (!targetCard) return;

    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((m) =>
          m.generatedVideo?.id === cardId
            ? { ...m, generatedVideo: { ...m.generatedVideo, status: 'submitting', progress: 15 } }
            : m
        ),
      }))
    );

    try {
      const res = await fetch('/api/video/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: targetCard.prompt,
          resolution: targetCard.resolution,
          aspectRatio: targetCard.aspectRatio,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success && data.operationName) {
        setConversations((prev) =>
          prev.map((conv) => ({
            ...conv,
            messages: conv.messages.map((m) =>
              m.generatedVideo?.id === cardId
                ? {
                    ...m,
                    generatedVideo: {
                      ...m.generatedVideo,
                      operationName: data.operationName,
                      status: 'processing',
                      progress: 35,
                    },
                  }
                : m
            ),
          }))
        );

        pollVideoOperation(cardId, data.operationName);
      } else {
        const isQuota = res.status === 429 || data.status === 'quota_restricted' || Boolean(data.requiresPaidPlan);
        setConversations((prev) =>
          prev.map((conv) => ({
            ...conv,
            messages: conv.messages.map((m) =>
              m.generatedVideo?.id === cardId
                ? {
                    ...m,
                    generatedVideo: {
                      ...m.generatedVideo,
                      status: isQuota ? 'quota_restricted' : 'error',
                      error: data.error || 'Video generation initiation failed.',
                      errorDetails: {
                        code: res.status,
                        requiresPaidPlan: true,
                        setupGuideUrl: data.setupGuideUrl,
                        hindiMessage: data.hindiError,
                        costEstimate: data.costEstimate,
                      },
                    },
                  }
                : m
            ),
          }))
        );
      }
    } catch (err: any) {
      setConversations((prev) =>
        prev.map((conv) => ({
          ...conv,
          messages: conv.messages.map((m) =>
            m.generatedVideo?.id === cardId
              ? {
                  ...m,
                  generatedVideo: {
                    ...m.generatedVideo,
                    status: 'error',
                    error: err.message || 'Network error initiating video generation.',
                  },
                }
              : m
          ),
        }))
      );
    }
  };

  const handleCancelVideo = (cardId: string) => {
    setConversations((prev) =>
      prev.map((conv) => ({
        ...conv,
        messages: conv.messages.map((m) =>
          m.generatedVideo?.id === cardId
            ? {
                ...m,
                generatedVideo: {
                  ...m.generatedVideo,
                  status: 'error',
                  error: 'Video generation cancelled by user.',
                },
              }
            : m
        ),
      }))
    );
  };

  const pollVideoOperation = async (cardId: string, operationName: string) => {
    let attempts = 0;
    const maxAttempts = 40;

    const interval = setInterval(async () => {
      attempts++;
      if (attempts > maxAttempts) {
        clearInterval(interval);
        return;
      }

      try {
        const res = await fetch('/api/video/status', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ operationName }),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.done) {
            clearInterval(interval);
            if (data.error) {
              setConversations((prev) =>
                prev.map((conv) => ({
                  ...conv,
                  messages: conv.messages.map((m) =>
                    m.generatedVideo?.id === cardId
                      ? { ...m, generatedVideo: { ...m.generatedVideo, status: 'error', error: data.error } }
                      : m
                  ),
                }))
              );
            } else {
              setConversations((prev) =>
                prev.map((conv) => ({
                  ...conv,
                  messages: conv.messages.map((m) =>
                    m.generatedVideo?.id === cardId
                      ? {
                          ...m,
                          generatedVideo: {
                            ...m.generatedVideo,
                            status: 'completed',
                            progress: 100,
                            videoUrl: `/api/video/download?op=${encodeURIComponent(operationName)}`,
                          },
                        }
                      : m
                  ),
                }))
              );
            }
          } else {
            setConversations((prev) =>
              prev.map((conv) => ({
                ...conv,
                messages: conv.messages.map((m) =>
                  m.generatedVideo?.id === cardId
                    ? {
                        ...m,
                        generatedVideo: {
                          ...m.generatedVideo,
                          progress: Math.min(35 + attempts * 2, 90),
                        },
                      }
                    : m
                ),
              }))
            );
          }
        }
      } catch (e) {
        console.warn('Video status polling error:', e);
      }
    }, 5000);
  };

  // Send message with optional image and file attachment (supports regular send or in-place retry)
  const handleSendMessage = async (
    userText: string,
    image?: string,
    fileAttachment?: DocumentAttachment,
    retryAssistantMessageId?: string
  ) => {
    const trimmed = userText.trim();
    if ((!trimmed && !image && !fileAttachment) || isLoading) return;

    // Stop speech playback on new question
    speechManager.stop();

    const targetChatId = activeChatId;
    const currentTargetConv =
      conversations.find((c) => c.id === targetChatId) || activeConversation;

    const isFirstUserMessage =
      currentTargetConv.messages.filter((m) => m.role === 'user').length === 0;

    // Determine displayed question text
    let displayText = trimmed;
    if (!displayText && image) {
      displayText =
        language === 'hindi'
          ? 'कृपया इस चित्र में दिए गए प्रश्न, सूत्र या डायग्राम को चरण-दर-चरण समझाइए।'
          : language === 'hinglish'
          ? 'Please is image ke question ya diagram ko step-by-step explain kijiye.'
          : 'Please analyze this image, read all text, equations, and diagrams, and explain it step by step.';
    } else if (!displayText && fileAttachment) {
      displayText =
        language === 'hindi'
          ? `कृपया इस फ़ाइल "${fileAttachment.name}" का विश्लेषण और मुख्य बिंदु समझाइए।`
          : language === 'hinglish'
          ? `Please is file "${fileAttachment.name}" ko analyze karke explanation aur summary provide kijiye.`
          : `Please analyze the attached file "${fileAttachment.name}" and provide insights and summary.`;
    }

    const lowerUserText = displayText.toLowerCase();

    // 0. Natural Language Real AI Image & Video Generation Router (Hindi, Hinglish, English)
    if (!image && !fileAttachment && !retryAssistantMessageId) {
      const mediaIntent = detectMediaIntent(displayText, false);
      if (mediaIntent) {
        const userMessage: Message = {
          id: `usr_${Date.now()}`,
          role: 'user',
          content: displayText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };

        const updatedTitle =
          isFirstUserMessage ||
          currentTargetConv.title === 'New Chat' ||
          currentTargetConv.title === 'नई बातचीत'
            ? generateChatTitle(displayText)
            : currentTargetConv.title;

        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === targetChatId
              ? {
                  ...conv,
                  title: updatedTitle,
                  messages: [...conv.messages, userMessage],
                  updatedAt: Date.now(),
                }
              : conv
          )
        );

        if (mediaIntent.type === 'image') {
          handleGenerateImage(mediaIntent.prompt, mediaIntent.aspectRatio, mediaIntent.style);
          return;
        } else if (mediaIntent.type === 'video') {
          const videoAspect: '16:9' | '9:16' = mediaIntent.aspectRatio === '9:16' ? '9:16' : '16:9';
          handleGenerateVideo(mediaIntent.prompt, mediaIntent.resolution || '720p', videoAspect);
          return;
        }
      }
    }

    // 1. Interactive Companion Game Move (Active Game Turn)
    if (!image && !fileAttachment && !retryAssistantMessageId && activeGame && activeGame.status === 'active') {
      const turnResult = handleGameTurn(activeGame, displayText);
      const assistantMessage: Message = {
        id: `kaju_game_${Date.now()}`,
        role: 'assistant',
        content: turnResult.responseMessage,
        gameCard: turnResult.updatedGame,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'complete',
      };
      const userMessage: Message = {
        id: `usr_${Date.now()}`,
        role: 'user',
        content: displayText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === targetChatId
            ? { ...conv, messages: newMessages, updatedAt: Date.now() }
            : conv
        )
      );
      setActiveGame(turnResult.gameCompleted ? null : turnResult.updatedGame);
      setCoreState('completed');
      requestAnimationFrame(() => scrollToBottom('smooth'));
      return;
    }

    // 2. Kaju Skill Mode: Direct Skill Initialization ("Kaju mujhe Japanese zero se sikhana")
    const skillDetection = detectSkillRequest(displayText);
    if (!image && !fileAttachment && !retryAssistantMessageId && skillDetection.isSkill) {
      const newSkill = createSkillJourney(skillDetection.skillName || 'Japanese', displayText, 'beginner');
      setActiveSkillId(newSkill.id);
      setSkillJourneys(loadSkillJourneys());

      const welcomeSkillContent = `### 🇯🇵 Konnichiwa! Welcome to ${newSkill.skillName} Mastery with Kaju! 🎉\n\nMain aapko **zero se shuru karke** step-by-step master karaunga.\n\n### 🎯 Learning Flow:\n**GOAL** → **LEVEL CHECK** → **LEARNING PLAN** → **LESSON** → **PRACTICE** → **CHECK ANSWERS** → **FEEDBACK** → **PROGRESS** → **NEXT LESSON**\n\n---\n### 🔍 Quick Diagnostic Level Check:\nKya aap pehle se ${newSkill.skillName} ka kuch basics jaante hain ya bilkul zero/beginner level se shuru karna chahte hain? (Reply with: "Zero se" ya "Thoda aata hai")`;

      const assistantMessage: Message = {
        id: `kaju_skill_${Date.now()}`,
        role: 'assistant',
        content: welcomeSkillContent,
        skillCard: newSkill,
        suggestedFollowUps: ['Zero se shuru karo', 'Thoda basics aata hai', 'Show learning plan'],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'complete',
      };
      const userMessage: Message = {
        id: `usr_${Date.now()}`,
        role: 'user',
        content: displayText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === targetChatId
            ? { ...conv, messages: newMessages, updatedAt: Date.now() }
            : conv
        )
      );
      setCoreState('completed');
      requestAnimationFrame(() => scrollToBottom('smooth'));
      return;
    }

    // 3. Active Skill Practice & Turn Processing
    if (!image && !fileAttachment && !retryAssistantMessageId && activeSkillId) {
      const activeJourney = skillJourneys.find((s) => s.id === activeSkillId);
      const isSkillTurn = activeJourney && (
        activeJourney.stage === 'LEVEL_CHECK' ||
        activeJourney.stage === 'LESSON' ||
        activeJourney.stage === 'PRACTICE' ||
        lowerUserText.includes('next lesson') ||
        lowerUserText.includes('practice') ||
        lowerUserText.includes('zero se')
      );

      if (activeJourney && isSkillTurn) {
        const { updatedJourney, feedbackText, nextStepPrompt } = processSkillTurn(activeJourney, displayText);
        setSkillJourneys(loadSkillJourneys());

        const assistantMessage: Message = {
          id: `kaju_skill_step_${Date.now()}`,
          role: 'assistant',
          content: `${feedbackText}\n\n${nextStepPrompt}`,
          skillCard: updatedJourney,
          suggestedFollowUps: ['Next lesson shuru karo', 'Practice more', 'Review mistakes'],
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'complete',
        };
        const userMessage: Message = {
          id: `usr_${Date.now()}`,
          role: 'user',
          content: displayText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === targetChatId
              ? { ...conv, messages: newMessages, updatedAt: Date.now() }
              : conv
          )
        );
        setCoreState('completed');
        requestAnimationFrame(() => scrollToBottom('smooth'));
        return;
      }
    }

    // 2. Smart Boredom Router & Companion Response
    if (!image && !fileAttachment && !retryAssistantMessageId) {
      const companionResult = routeCompanionInput(displayText);
      if (companionResult.isHandled) {
        if (companionResult.gameCard) {
          setActiveGame(companionResult.gameCard);
        } else if (companionResult.type === 'return_to_work') {
          setActiveGame(null);
        }
        const assistantMessage: Message = {
          id: `kaju_fun_${Date.now()}`,
          role: 'assistant',
          content: companionResult.replyText || 'Chal mazaa karte hain!',
          gameCard: companionResult.gameCard,
          suggestedFollowUps: companionResult.suggestedFollowUps,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'complete',
        };
        const userMessage: Message = {
          id: `usr_${Date.now()}`,
          role: 'user',
          content: displayText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
        setConversations((prev) =>
          prev.map((conv) =>
            conv.id === targetChatId
              ? { ...conv, messages: newMessages, updatedAt: Date.now() }
              : conv
          )
        );
        setCoreState('completed');
        requestAnimationFrame(() => scrollToBottom('smooth'));
        return;
      }
    }

    // 3. Fast-Path Direct Voice & App Actions Router (Immediate zero-confirmation app opening)
    if (!image && !fileAttachment && !retryAssistantMessageId && trimmed) {
      const localCmd = parseVoiceCommandLocally(trimmed, language);
      if (localCmd) {
        // CASE A: Direct app opening (e.g. "YouTube kholo", "Calculator kholo", "Camera kholo", "Settings kholo")
        if (localCmd.recognizedIntent === 'launch_app' && localCmd.action?.type === 'launch_app') {
          const payload = localCmd.action.payload.launch_app!;
          const launchResult = await NativeActionRouter.launchApp(payload.appId);

          const isHindi = localCmd.detectedLanguage === 'hindi' || language === 'hindi';
          const spokenFeedback = isHindi ? launchResult.hindiMessage : launchResult.message;

          const executedAction: DeviceAction = {
            ...localCmd.action,
            status: launchResult.success
              ? 'executed'
              : (launchResult.status === 'not_installed' ? 'blocked' : 'error'),
            executedAt: Date.now(),
            error: launchResult.success ? undefined : spokenFeedback,
          };

          // Save to action audit trail
          const updatedAudit = [executedAction, ...actionHistory.slice(0, 49)];
          setActionHistory(updatedAudit);
          try {
            localStorage.setItem(AUDIT_LOG_STORAGE_KEY, JSON.stringify(updatedAudit));
          } catch {}

          const userMessage: Message = {
            id: `usr_${Date.now()}`,
            role: 'user',
            content: displayText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };

          const assistantMessage: Message = {
            id: `kaju_act_${Date.now()}`,
            role: 'assistant',
            content: spokenFeedback,
            // Safe direct app opening executes directly without an unnecessary confirmation card
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'complete',
          };

          const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
          const updatedTitle =
            isFirstUserMessage ||
            currentTargetConv.title === 'New Chat' ||
            currentTargetConv.title === 'नई बातचीत'
              ? generateChatTitle(displayText)
              : currentTargetConv.title;

          setConversations((prev) =>
            prev.map((conv) =>
              conv.id === targetChatId
                ? {
                    ...conv,
                    title: updatedTitle,
                    messages: newMessages,
                    updatedAt: Date.now(),
                  }
                : conv
            )
          );

          setCoreState('completed');
          requestAnimationFrame(() => scrollToBottom('smooth'));

          if (spokenFeedback) {
            speechManager.speak(assistantMessage.id, spokenFeedback, isHindi ? 'hindi' : 'english');
          }

          return;
        }

        // CASE B: Consequential actions (WhatsApp message sending, phone dialer)
        // MUST keep confirmation card for safety!
        if (localCmd.recognizedIntent === 'whatsapp' || localCmd.recognizedIntent === 'call') {
          const isHindi = localCmd.detectedLanguage === 'hindi' || language === 'hindi';
          const userMessage: Message = {
            id: `usr_${Date.now()}`,
            role: 'user',
            content: displayText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };

          const assistantMessage: Message = {
            id: `kaju_act_${Date.now()}`,
            role: 'assistant',
            content: localCmd.feedbackSpoken,
            action: localCmd.action,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'complete',
          };

          const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
          const updatedTitle =
            isFirstUserMessage ||
            currentTargetConv.title === 'New Chat' ||
            currentTargetConv.title === 'नई बातचीत'
              ? generateChatTitle(displayText)
              : currentTargetConv.title;

          setConversations((prev) =>
            prev.map((conv) =>
              conv.id === targetChatId
                ? {
                    ...conv,
                    title: updatedTitle,
                    messages: newMessages,
                    updatedAt: Date.now(),
                  }
                : conv
            )
          );

          setCoreState('answering');
          requestAnimationFrame(() => scrollToBottom('smooth'));

          if (localCmd.feedbackSpoken) {
            speechManager.speak(assistantMessage.id, localCmd.feedbackSpoken, isHindi ? 'hindi' : 'english');
          }

          return;
        }

        // CASE C: Clarification needed (e.g. user said "whatsapp bhejo" without recipient/message)
        if (localCmd.recognizedIntent === 'clarify') {
          const isHindi = localCmd.detectedLanguage === 'hindi' || language === 'hindi';
          const userMessage: Message = {
            id: `usr_${Date.now()}`,
            role: 'user',
            content: displayText,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          };

          const assistantMessage: Message = {
            id: `kaju_clarify_${Date.now()}`,
            role: 'assistant',
            content: localCmd.clarificationPrompt || localCmd.feedbackSpoken,
            suggestedFollowUps: localCmd.clarificationOptions?.map((o) => o.command),
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            status: 'complete',
          };

          const newMessages = [...currentTargetConv.messages, userMessage, assistantMessage];
          const updatedTitle =
            isFirstUserMessage ||
            currentTargetConv.title === 'New Chat' ||
            currentTargetConv.title === 'नई बातचीत'
              ? generateChatTitle(displayText)
              : currentTargetConv.title;

          setConversations((prev) =>
            prev.map((conv) =>
              conv.id === targetChatId
                ? {
                    ...conv,
                    title: updatedTitle,
                    messages: newMessages,
                    updatedAt: Date.now(),
                  }
                : conv
            )
          );

          setCoreState('answering');
          requestAnimationFrame(() => scrollToBottom('smooth'));

          if (localCmd.feedbackSpoken) {
            speechManager.speak(assistantMessage.id, localCmd.feedbackSpoken, isHindi ? 'hindi' : 'english');
          }

          return;
        }
      }
    }

    const assistantPlaceholderId = retryAssistantMessageId || `kaju_${Date.now()}`;
    const initialAssistantMessage: Message = {
      id: assistantPlaceholderId,
      role: 'assistant',
      content: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'sending',
    };

    let updatedMessages: Message[];

    if (retryAssistantMessageId) {
      // In-place retry: reuse existing user message and replace failed assistant message
      updatedMessages = currentTargetConv.messages.map((m) =>
        m.id === retryAssistantMessageId ? initialAssistantMessage : m
      );
    } else {
      const userMessage: Message = {
        id: `usr_${Date.now()}`,
        role: 'user',
        content: displayText,
        image: image || undefined,
        fileAttachment: fileAttachment || undefined,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      updatedMessages = [...currentTargetConv.messages, userMessage, initialAssistantMessage];
    }

    // Auto-generate title if this is the first user message or current title is default
    const updatedTitle =
      isFirstUserMessage ||
      currentTargetConv.title === 'New Chat' ||
      currentTargetConv.title === 'नई बातचीत'
        ? (image && !trimmed
            ? (language === 'hindi' ? 'चित्र प्रश्न' : 'Photo Question')
            : fileAttachment && !trimmed
            ? fileAttachment.name
            : generateChatTitle(displayText))
        : currentTargetConv.title;

    // Check for user-driven adaptive replanning on active goal
    let currentGoal = activeGoal;

    if (currentGoal) {
      if (
        lowerUserText.includes('samajh nahi aaya') ||
        lowerUserText.includes('samajh nhi aaya') ||
        lowerUserText.includes('phir se samjhao') ||
        lowerUserText.includes('different example') ||
        lowerUserText.includes('dusra example') ||
        lowerUserText.includes('simple example')
      ) {
        setCoreState('adjusting');
        const adapted = adaptGoalJourney(currentGoal, 'struggle', 'simpler explanation requested');
        currentGoal = adapted;
        setGoals(loadGoals());
      } else if (
        lowerUserText.includes('easy') ||
        lowerUserText.includes('aasan tha') ||
        lowerUserText.includes('bahut easy')
      ) {
        const adapted = adaptGoalJourney(currentGoal, 'easy');
        currentGoal = adapted;
        setGoals(loadGoals());
      } else if (
        lowerUserText.includes('short me') ||
        lowerUserText.includes('chhota answer') ||
        lowerUserText.includes('briefly')
      ) {
        const adapted = adaptGoalJourney(currentGoal, 'short');
        currentGoal = adapted;
        setGoals(loadGoals());
      }
    }

    // Check for user goal initialization
    const intent = classifyIntent(displayText, Boolean(image));
    if (intent === 'GOAL' && (!currentGoal || lowerUserText.includes('new goal') || lowerUserText.includes('naya goal'))) {
      const newGoal = createGoal(displayText);
      currentGoal = newGoal;
      setActiveGoalId(newGoal.id);
      setGoals(loadGoals());
      setCoreState('planning');
    }

    // Optimistically update conversation with user message and placeholder assistant message
    setConversations((prev) =>
      prev.map((conv) =>
        conv.id === targetChatId
          ? {
              ...conv,
              title: updatedTitle,
              messages: updatedMessages,
              updatedAt: Date.now(),
            }
          : conv
      )
    );

    isAtBottomRef.current = true;
    setShowScrollBottom(false);
    setHasNewMessageBelow(false);
    requestAnimationFrame(() => {
      scrollToBottom('smooth');
    });

    setIsLoading(true);
    if (coreState !== 'planning' && coreState !== 'adjusting') {
      setCoreState('understanding');
    }
    setStreamingMessageId(assistantPlaceholderId);

    // Analyze Smart Context automatically (Project, Research, File, Goal, Skill, Chat)
    const smartDecision = analyzeSmartContext(displayText, Boolean(image), Boolean(fileAttachment));
    const targetProject = smartDecision.matchedProject || activeProject;
    const projectContextString = targetProject ? buildProjectFullContext(targetProject) : undefined;
    const isResearchMode = smartDecision.primaryDomain === 'research' || smartDecision.isDetailedResearch;

    try {
      // Build conversation payload for Gemini API including images and files
      // Exclude current empty assistant placeholder and empty turns to provide pristine context ending with user prompt
      const conversationHistory = updatedMessages
        .filter((m) => m.id !== assistantPlaceholderId && (m.content.trim() || m.image || m.fileAttachment))
        .map((m) => ({
          role: m.role,
          content: m.content,
          image: m.image,
          fileAttachment: m.fileAttachment
            ? {
                name: m.fileAttachment.name,
                type: m.fileAttachment.type,
                size: m.fileAttachment.size,
                content: m.fileAttachment.content,
              }
            : undefined,
        }));

      // Stream SSE endpoint
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: conversationHistory,
          languagePreference: language,
          mode: activeTopic !== 'all' ? activeTopic : undefined,
          projectContext: projectContextString,
          userMemories: isMemoryEnabled() ? loadMemories() : [],
          userProfile: {
            displayName: currentAccount?.displayName || 'Guest Explorer',
            isOwner: (currentAccount?.displayName || '').toLowerCase().includes('kailash'),
            uid: currentAccount?.uid,
          },
          enableSearch: smartDecision.searchNeeded || isResearchMode,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned status ${response.status}`);
      }

      if (!response.body) {
        throw new Error('ReadableStream not supported by response');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder('utf-8');
      let accumulatedText = '';
      let buffer = '';
      let streamedCitations: Array<{ title: string; url: string }> = [];

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (trimmedLine.startsWith('data: ')) {
            const dataStr = trimmedLine.replace(/^data:\s*/, '');
            if (dataStr === '[DONE]') {
              break;
            }

            try {
              const parsed = JSON.parse(dataStr);
              if (parsed.text) {
                accumulatedText += parsed.text;
                setCoreState('answering');
                setConversations((prev) =>
                  prev.map((conv) =>
                    conv.id === targetChatId
                      ? {
                          ...conv,
                          messages: conv.messages.map((msg) =>
                            msg.id === assistantPlaceholderId
                              ? { ...msg, content: accumulatedText, status: 'complete' }
                              : msg
                          ),
                          updatedAt: Date.now(),
                        }
                      : conv
                  )
                );
              } else if (parsed.citations && Array.isArray(parsed.citations)) {
                streamedCitations = parsed.citations;
              } else if (parsed.error) {
                throw new Error(parsed.error);
              }
            } catch (err) {
              console.warn('Error parsing SSE data:', err);
            }
          }
        }
      }

      // Collect real sources only (never invent fake citations)
      const realSources: Array<{ title: string; url: string }> = [...streamedCitations];
      const seenSourceUrls = new Set(realSources.map((s) => s.url));

      // Extract verified links from Markdown Sources section if present
      const sourcesSectionMatch = accumulatedText.match(/### (?:🌐 )?Sources[\s\S]*$/i);
      const searchBlock = sourcesSectionMatch ? sourcesSectionMatch[0] : '';
      const linkRegex = /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
      let lMatch;
      while ((lMatch = linkRegex.exec(searchBlock)) !== null) {
        const lTitle = lMatch[1].trim();
        const lUrl = lMatch[2].trim();
        if (!seenSourceUrls.has(lUrl)) {
          seenSourceUrls.add(lUrl);
          realSources.push({ title: lTitle, url: lUrl });
        }
      }

      // Finalize complete assistant message with optional structured research report
      let structuredReport: ResearchReport | undefined = undefined;

      if (isResearchMode || accumulatedText.includes('### ⚡ Quick Answer') || accumulatedText.includes('### Quick Answer') || accumulatedText.includes('Important Findings')) {
        // Parse sections from accumulated response for beautiful ResearchReportCard
        const extractSection = (headingRegex: RegExp, nextHeadingRegex: RegExp): string => {
          const match = accumulatedText.match(headingRegex);
          if (!match || match.index === undefined) return '';
          const startIndex = match.index + match[0].length;
          const remaining = accumulatedText.slice(startIndex);
          const nextMatch = remaining.match(nextHeadingRegex);
          const raw = nextMatch && nextMatch.index !== undefined ? remaining.slice(0, nextMatch.index) : remaining;
          return raw.trim();
        };

        const quick = extractSection(/### (?:⚡ )?Quick Answer/i, /### (?:📌 )?Important Findings|### Details|### ⚖️/i) || accumulatedText.slice(0, 200);
        const findingsRaw = extractSection(/### (?:📌 )?Important Findings/i, /### (?:⚖️ )?Comparison|### (?:🔬 )?Comprehensive|### Details|### (?:🌐 )?Sources/i);
        const findings = findingsRaw
          ? findingsRaw.split('\n').filter((l) => l.trim().startsWith('-') || l.trim().startsWith('*') || /^\d+\./.test(l.trim())).map((l) => l.replace(/^[-*\d.]+\s*/, '').trim()).filter(Boolean)
          : ['Comprehensive cross-checked analysis synthesized from multi-domain sources.'];

        const compRaw = extractSection(/### (?:⚖️ )?Comparison(?: & Perspectives)?/i, /### (?:🔬 )?Comprehensive|### Details|### (?:🌐 )?Sources/i);
        const comp = compRaw ? compRaw.split('\n').map((l) => l.replace(/^[-*\d.]+\s*/, '').trim()).filter(Boolean) : undefined;

        const detailsRaw = extractSection(/### (?:🔬 )?(?:Comprehensive Analysis & )?Details/i, /### (?:🌐 )?Sources/i) || accumulatedText;

        structuredReport = {
          id: `rep_${Date.now()}`,
          query: displayText,
          quickAnswer: quick,
          importantFindings: findings.length > 0 ? findings : ['Cross-referenced multi-source research completed.'],
          comparisonOrPerspectives: comp,
          details: detailsRaw.slice(0, 1500),
          sources: realSources, // Genuine verified sources only, NO fake links
          uncertaintyNotes: realSources.length > 0
            ? 'Information grounded with verified real-time web sources.'
            : 'Synthesized from core conceptual model knowledge (no external web search sources needed or retrieved).',
          generatedAt: Date.now(),
        };
      }

      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === targetChatId
            ? {
                ...conv,
                messages: conv.messages.map((msg) =>
                  msg.id === assistantPlaceholderId
                    ? {
                        ...msg,
                        content:
                          accumulatedText || 'नमस्ते! I am ready to help. Please ask your question.',
                        citations: realSources.length > 0 ? realSources : undefined,
                        researchReport: structuredReport,
                        status: 'complete',
                      }
                    : msg
                ),
                updatedAt: Date.now(),
              }
            : conv
        )
      );

      // Process Goal Engine Tags in output
      const goalDetectedMatch = accumulatedText.match(/<!--GOAL_DETECTED:\s*({[\s\S]*?})\s*-->/);
      if (goalDetectedMatch) {
        try {
          const parsedGoal = JSON.parse(goalDetectedMatch[1]);
          if (parsedGoal.title && (!currentGoal || currentGoal.status === 'completed')) {
            const newGoal = createGoal(displayText, parsedGoal.title, parsedGoal.deadline);
            currentGoal = newGoal;
            setActiveGoalId(newGoal.id);
            setGoals(loadGoals());
          }
        } catch (e) {
          console.warn('Failed to parse GOAL_DETECTED tag:', e);
        }
      }

      const checkpointMatch = accumulatedText.match(/<!--CHECKPOINT_RESULT:\s*({[\s\S]*?})\s*-->/);
      if (checkpointMatch && currentGoal) {
        try {
          const parsedCp = JSON.parse(checkpointMatch[1]);
          if (parsedCp.passed) {
            setCoreState('checking');
            const advanced = advanceGoalStage(currentGoal, parsedCp.feedback || 'Concept verified ✓');
            currentGoal = advanced;
            setGoals(loadGoals());
          } else {
            setCoreState('adjusting');
            const adapted = adaptGoalJourney(currentGoal, 'checkpoint_failed', parsedCp.weakArea || 'practice checkpoint');
            currentGoal = adapted;
            setGoals(loadGoals());
          }
        } catch (e) {
          console.warn('Failed to parse CHECKPOINT_RESULT tag:', e);
        }
      }

      const completeMatch = accumulatedText.match(/<!--GOAL_COMPLETE:\s*({[\s\S]*?})\s*-->/);
      if (completeMatch && currentGoal) {
        try {
          markGoalCompleted(currentGoal);
          setActiveGoalId(null);
          setGoals(loadGoals());
          setCoreState('completed');
        } catch (e) {
          console.warn('Failed to parse GOAL_COMPLETE tag:', e);
        }
      } else {
        setCoreState('completed');
      }

      // Process Memory Operation tags (Add / Update / Delete fact)
      const memoryOpMatch = accumulatedText.match(/<!--MEMORY_OPERATION:\s*({[\s\S]*?})\s*-->/);
      if (memoryOpMatch && isMemoryEnabled()) {
        try {
          const parsedOp = JSON.parse(memoryOpMatch[1]);
          if (parsedOp && parsedOp.action && parsedOp.content) {
            applyMemoryOperation(parsedOp);
            setMemories(loadMemories());
          }
        } catch (e) {
          console.warn('Failed to parse MEMORY_OPERATION tag:', e);
        }
      }

      // Process Real AI Image Generation Tags in assistant output
      const createImageMatch = accumulatedText.match(/<!--CREATE_IMAGE:\s*({[\s\S]*?})\s*-->/);
      if (createImageMatch) {
        try {
          const parsed = JSON.parse(createImageMatch[1]);
          if (parsed && parsed.prompt) {
            handleGenerateImage(parsed.prompt, parsed.aspectRatio || '1:1');
          }
        } catch (e) {
          console.warn('Failed to parse CREATE_IMAGE tag:', e);
        }
      }

      // Process Real AI Video Generation Tags in assistant output
      const createVideoMatch = accumulatedText.match(/<!--CREATE_VIDEO:\s*({[\s\S]*?})\s*-->/);
      if (createVideoMatch) {
        try {
          const parsed = JSON.parse(createVideoMatch[1]);
          if (parsed && parsed.prompt) {
            handleGenerateVideo(parsed.prompt, parsed.resolution || '720p', parsed.aspectRatio || '16:9');
          }
        } catch (e) {
          console.warn('Failed to parse CREATE_VIDEO tag:', e);
        }
      }

      setTimeout(() => {
        setCoreState('idle');
      }, 1200);
    } catch (error: any) {
      console.error('Error communicating with Kaju AI:', error);

      // Fallback to standard endpoint with image support
      try {
        const fallbackRes = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: updatedMessages.map((m) => ({
              role: m.role,
              content: m.content,
              image: m.image,
              fileAttachment: m.fileAttachment,
            })),
            languagePreference: language,
            mode: activeTopic !== 'all' ? activeTopic : undefined,
            projectContext: projectContextString,
            userMemories: isMemoryEnabled() ? loadMemories() : [],
            userProfile: {
              displayName: currentAccount?.displayName || 'Guest Explorer',
              isOwner: (currentAccount?.displayName || '').toLowerCase().includes('kailash'),
              uid: currentAccount?.uid,
            },
            enableSearch: smartDecision.searchNeeded || isResearchMode,
          }),
        });

        if (fallbackRes.ok) {
          const data = await fallbackRes.json();

          // Check if fallback response has memory operation
          if (data.text && isMemoryEnabled()) {
            const fallbackMemMatch = data.text.match(/<!--MEMORY_OPERATION:\s*({[\s\S]*?})\s*-->/);
            if (fallbackMemMatch) {
              try {
                const parsedOp = JSON.parse(fallbackMemMatch[1]);
                if (parsedOp && parsedOp.action && parsedOp.content) {
                  applyMemoryOperation(parsedOp);
                  setMemories(loadMemories());
                }
              } catch (e) {
                console.warn('Failed to parse fallback MEMORY_OPERATION tag:', e);
              }
            }
          }

          setConversations((prev) =>
            prev.map((conv) =>
              conv.id === targetChatId
                ? {
                    ...conv,
                    messages: conv.messages.map((msg) =>
                      msg.id === assistantPlaceholderId
                        ? {
                            ...msg,
                            content: data.text,
                            citations: Array.isArray(data.citations) && data.citations.length > 0 ? data.citations : undefined,
                            status: 'complete',
                          }
                        : msg
                    ),
                    updatedAt: Date.now(),
                  }
                : conv
            )
          );
          setCoreState('completed');
          setTimeout(() => {
            setCoreState('idle');
          }, 1200);
          return;
        }
      } catch (fallbackError) {
        console.error('Fallback endpoint also failed:', fallbackError);
      }

      setCoreState('error');
      setTimeout(() => {
        setCoreState('idle');
      }, 1500);

      // Mark message with error state
      setConversations((prev) =>
        prev.map((conv) =>
          conv.id === targetChatId
            ? {
                ...conv,
                messages: conv.messages.map((msg) =>
                  msg.id === assistantPlaceholderId
                    ? {
                        ...msg,
                        content:
                          image
                            ? "Couldn't analyze the photo."
                            : error?.message ||
                              'कृपया दोबारा प्रयास करें। Unable to connect to Gemini AI.',
                        status: 'error',
                      }
                    : msg
                ),
                updatedAt: Date.now(),
              }
            : conv
        )
      );
    } finally {
      setIsLoading(false);
      setStreamingMessageId(null);
    }
  };

  return (
    <div className="flex h-[100dvh] max-h-[100dvh] bg-linear-to-b from-stone-50 via-amber-50/15 to-stone-100 text-stone-900 overflow-hidden font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Sliding History Drawer */}
      <Sidebar
        isOpen={isHistoryDrawerOpen}
        onClose={() => setIsHistoryDrawerOpen(false)}
        conversations={conversations}
        activeChatId={activeChatId}
        onSelectChat={(id) => {
          handleSelectChat(id);
          setIsHistoryDrawerOpen(false);
        }}
        onNewChat={() => {
          handleNewChat();
          setIsHistoryDrawerOpen(false);
        }}
        onRenameChat={handleRenameChat}
        onDeleteChat={handleDeleteChat}
        onOpenProjectsModal={() => setIsProjectModalOpen(true)}
      />

      {/* Main Kaju Cockpit Window */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative">
        {/* Cockpit Top Bar */}
        <KajuCockpitBar
          language={language}
          onLanguageChange={handleLanguageChange}
          onNewSession={handleNewChat}
          onOpenHistoryDrawer={() => setIsHistoryDrawerOpen(true)}
          onOpenActionsDrawer={() => handleOpenActionCenter('quick_actions')}
          onClearSession={handleClearChat}
          hasMessages={messages.length > 0}
          activeSessionTitle={activeConversation?.title}
          activeGoal={activeGoal}
          onOpenReplayModal={(goal) => {
            setSelectedReplayGoal(goal);
            setIsReplayModalOpen(true);
          }}
          activeProjectName={activeProject?.name}
          onOpenProjectsModal={() => setIsProjectModalOpen(true)}
          onOpenMemoryModal={() => setIsMemoryModalOpen(true)}
          onOpenIdentityModal={() => setIsIdentityModalOpen(true)}
          account={currentAccount}
          onOpenAccountModal={() => setIsAccountModalOpen(true)}
          onOpenMediaStudio={() => handleOpenMediaStudio('image')}
          onTriggerFun={() => handleSendMessage("Kaju, bore ho raha hu! Chal koi mast game khelte hain 😄")}
          onSelectPrompt={(p) => handleSendMessage(p)}
        />

        {/* Unified Control Room Viewport (Single Primary Scroll Container) */}
        <main
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-2 sm:px-4 py-2 sm:py-4"
        >
          <div className="max-w-4xl mx-auto flex flex-col items-center min-h-full">
            {/* If empty chat, show Living Central Kaju Core Orb & Goal Welcome */}
            {messages.length === 0 ? (
              <KajuHero
                coreState={coreState}
                activeGoal={activeGoal}
                recentlyCompletedGoals={recentlyCompletedGoals}
                onOpenReplayModal={(goal) => {
                  setSelectedReplayGoal(goal);
                  setIsReplayModalOpen(true);
                }}
                onExecutePrimaryAction={(prompt) => {
                  handleSendMessage(prompt);
                }}
                onDismissGoal={(goalId) => {
                  abandonGoal(goalId);
                  setGoals(loadGoals());
                  setActiveGoalId(loadActiveGoalId());
                }}
                onSelectSuggestion={(prompt) => {
                  handleSendMessage(prompt);
                }}
                isListening={isListening}
                onToggleListening={() => composerRef.current?.toggleListening()}
                liveTranscript={liveTranscript}
              />
            ) : (
              /* If active session, show compact Goal banner at top + KajuStage */
              <div className="w-full space-y-3">
                {activeGoal && (
                  <KajuGoalBanner
                    activeGoal={activeGoal}
                    onOpenReplayModal={(goal) => {
                      setSelectedReplayGoal(goal);
                      setIsReplayModalOpen(true);
                    }}
                    onDismissGoal={(goalId) => {
                      abandonGoal(goalId);
                      setGoals(loadGoals());
                      setActiveGoalId(loadActiveGoalId());
                    }}
                    onExecutePrimaryAction={(prompt) => {
                      handleSendMessage(prompt);
                    }}
                  />
                )}
                {/* Dynamic Stage: Turns, LaTeX Solutions, Actions & Voice Playback */}
                <KajuStage
                  messages={messages}
                  isStreaming={isLoading}
                  streamingMessageId={streamingMessageId}
                  onRetryMessage={handleRetryMessage}
                  language={language}
                  permissions={permissions}
                  onUpdateAction={handleUpdateMessageAction}
                  onOpenActionCenter={(tab) => handleOpenActionCenter(tab || 'quick_actions')}
                  onAnswerChallenge={(answerText) => handleSendMessage(answerText)}
                  onOpenMediaSetup={() => handleOpenMediaStudio('setup')}
                  onConfirmImage={handleConfirmImage}
                  onCancelImage={handleCancelImage}
                  onConfirmVideo={handleConfirmVideo}
                  onCancelVideo={handleCancelVideo}
                  onRegenerateImage={(prompt, aspectRatio) => handleGenerateImage(prompt, aspectRatio)}
                />
              </div>
            )}
            {/* Dedicated scroll anchor for latest message */}
            <div ref={messagesEndRef} className="h-2 w-full shrink-0" />
          </div>
        </main>

        {/* Small "↓ Latest" floating button (only when significantly above bottom) */}
        {showScrollBottom && (
          <button
            id="jump-to-latest-button"
            type="button"
            onClick={() => scrollToBottom('smooth')}
            className="fixed bottom-24 right-4 sm:right-8 z-30 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/95 text-stone-800 shadow-md border border-amber-300 hover:bg-amber-50 hover:text-amber-900 transition-all font-bold text-xs cursor-pointer group active:scale-95"
            title="Jump to latest message"
            aria-label="Jump to latest message"
          >
            <ArrowDown className="w-3.5 h-3.5 text-amber-600 group-hover:translate-y-0.5 transition-transform" />
            <span>Latest</span>
            {hasNewMessageBelow && (
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-600"></span>
              </span>
            )}
          </button>
        )}

        {/* Docked Omni-Input Message Composer at Bottom */}
        <div className="w-full shrink-0 bg-linear-to-t from-stone-50 via-stone-50/95 to-transparent pt-1 pb-[max(0.75rem,env(safe-area-inset-bottom))] px-2 sm:px-4 z-20">
          <KajuComposer
            ref={composerRef}
            onSendMessage={handleSendMessage}
            language={language}
            isStreaming={isLoading}
            activeGoal={activeGoal}
            onListeningChange={(listening, transcript) => {
              setIsListening(listening);
              setLiveTranscript(transcript);
            }}
            onInputFocus={handleInputFocus}
            onOpenMediaStudio={(tab) => handleOpenMediaStudio(tab || 'image')}
          />
        </div>
      </div>

      {/* Verified Kaju Replay Timeline Modal */}
      <KajuReplayModal
        isOpen={isReplayModalOpen}
        goal={selectedReplayGoal}
        onClose={() => {
          setIsReplayModalOpen(false);
          setSelectedReplayGoal(null);
        }}
        onRestartGoal={(g) => {
          setIsReplayModalOpen(false);
          handleSendMessage(`Kaju, I want to restart the goal: "${g.title}". Let's start with NOW.`);
        }}
      />

      {/* Safe Action Center Modal (WhatsApp, Phone Dialer, Permissions, Desktop limits) */}
      <ActionCenterModal
        isOpen={isActionCenterOpen}
        onClose={() => setIsActionCenterOpen(false)}
        permissions={permissions}
        onUpdatePermissions={handleUpdatePermissions}
        actionHistory={actionHistory}
        initialTab={actionCenterTab}
      />

      {/* Kaju Account & Cloud Data Sync Modal */}
      <KajuAccountModal
        isOpen={isAccountModalOpen}
        onClose={() => setIsAccountModalOpen(false)}
        currentAccount={currentAccount}
        onAccountChange={handleAccountChange}
        onSyncRequest={handleCloudSync}
        syncStatus={syncStatus}
      />

      {/* Universal Project Workspace Modal */}
      <ProjectWorkspaceModal
        isOpen={isProjectModalOpen}
        onClose={() => setIsProjectModalOpen(false)}
        projects={projects}
        activeProjectId={activeProjectId}
        onSelectProject={(projId) => {
          setActiveProjectId(projId);
          saveActiveProjectId(projId);
        }}
        onRefreshProjects={() => {
          setProjects(loadProjects());
        }}
        onStartProjectChat={(projName) => {
          handleSendMessage(`Kaju, mere "${projName}" project ka status aur next step kya hai?`);
        }}
      />

      {/* Kaju Memory & Explicit Facts Modal */}
      <KajuMemoryModal
        isOpen={isMemoryModalOpen}
        onClose={() => setIsMemoryModalOpen(false)}
        memories={memories}
        onRefreshMemories={() => setMemories(loadMemories())}
      />

      {/* Kaju Identity / Number & Profile Modal */}
      <KajuIdentityModal
        isOpen={isIdentityModalOpen}
        onClose={() => setIsIdentityModalOpen(false)}
      />

      {/* Real AI Media Studio Modal (Gemini 3.1 & Veo 3.1) */}
      <MediaStudioModal
        isOpen={isMediaStudioOpen}
        onClose={() => setIsMediaStudioOpen(false)}
        onGenerateImage={async (prompt, aspectRatio, style) => {
          setIsMediaStudioOpen(false);
          return handleGenerateImage(prompt, aspectRatio, style);
        }}
        onGenerateVideo={async (prompt, resolution, aspectRatio) => {
          setIsMediaStudioOpen(false);
          return handleGenerateVideo(prompt, resolution, aspectRatio);
        }}
        initialTab={mediaStudioTab}
        initialPrompt={mediaStudioPrompt}
      />
    </div>
  );
}


import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Phone,
  PhoneCall,
  ExternalLink,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ShieldCheck,
  Edit3,
  Check,
  X,
  Youtube,
  MapPin,
  Laptop,
  ArrowUpRight,
  Calculator,
  Camera,
  Image as ImageIcon,
  Settings,
  RotateCcw,
} from 'lucide-react';
import { DeviceAction, ActionPermissions } from '../types';
import {
  executeDeviceAction,
  executeDeviceActionAsync,
  isActionPermitted,
  formatPhoneDisplay,
  sanitizePhoneNumber,
} from '../utils/actionHelper';
import { NativeActionRouter } from '../utils/nativeActionRouter';

interface ActionCardProps {
  action: DeviceAction;
  permissions: ActionPermissions;
  onUpdateAction?: (updatedAction: DeviceAction) => void;
  onOpenActionCenter?: (tab?: 'permissions' | 'desktop') => void;
}

export const ActionCard: React.FC<ActionCardProps> = ({
  action,
  permissions,
  onUpdateAction,
  onOpenActionCenter,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editPhone, setEditPhone] = useState(
    action.payload.whatsapp?.phone || action.payload.call?.phone || ''
  );
  const [editMessage, setEditMessage] = useState(action.payload.whatsapp?.message || '');
  const [executionMessage, setExecutionMessage] = useState<string | null>(null);
  const autoExecutedRef = useRef(false);

  const permissionCheck = isActionPermitted(action, permissions);
  const isBlocked = !permissionCheck.allowed;

  const handleExecute = async () => {
    if (isBlocked) return;
    const res = await executeDeviceActionAsync(action);
    setExecutionMessage(res.message);

    if (onUpdateAction) {
      onUpdateAction({
        ...action,
        status: res.success ? 'executed' : (res.launchResult?.status === 'not_installed' ? 'blocked' : 'error'),
        executedAt: Date.now(),
        error: res.success ? undefined : res.message,
      });
    }
  };

  // Auto-execute direct app launch if confirmation is not required (e.g. "YouTube kholo")
  useEffect(() => {
    if (
      action.type === 'launch_app' &&
      action.status === 'ready' &&
      action.payload.launch_app?.requiresConfirmation === false &&
      !isBlocked &&
      !autoExecutedRef.current
    ) {
      autoExecutedRef.current = true;
      handleExecute();
    }
  }, [action.id, action.status, action.type, isBlocked]);

  const handleSaveEdit = () => {
    if (!onUpdateAction) return;

    const updated: DeviceAction = {
      ...action,
      payload: {
        ...action.payload,
        whatsapp: action.payload.whatsapp
          ? {
              ...action.payload.whatsapp,
              phone: sanitizePhoneNumber(editPhone),
              message: editMessage,
            }
          : undefined,
        call: action.payload.call
          ? {
              ...action.payload.call,
              phone: sanitizePhoneNumber(editPhone),
            }
          : undefined,
      },
    };

    onUpdateAction(updated);
    setIsEditing(false);
  };

  const handleCancel = () => {
    if (onUpdateAction) {
      onUpdateAction({
        ...action,
        status: 'cancelled',
      });
    }
  };

  return (
    <div
      id={`action-card-${action.id}`}
      className="mt-3 overflow-hidden rounded-2xl border border-amber-200/90 bg-amber-50/70 shadow-xs text-stone-800 transition-all"
    >
      {/* Card Header */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-amber-100/70 border-b border-amber-200/80">
        <div className="flex items-center gap-2">
          {action.type === 'whatsapp' && (
            <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
              <MessageSquare className="w-3.5 h-3.5" />
            </div>
          )}
          {action.type === 'call' && (
            <div className="w-6 h-6 rounded-lg bg-amber-600 text-white flex items-center justify-center">
              <Phone className="w-3.5 h-3.5" />
            </div>
          )}
          {action.type === 'launch_app' && (
            <div className="w-6 h-6 rounded-lg bg-orange-600 text-white flex items-center justify-center">
              {action.payload.launch_app?.appId === 'youtube' ? (
                <Youtube className="w-3.5 h-3.5" />
              ) : action.payload.launch_app?.appId === 'whatsapp' ? (
                <MessageSquare className="w-3.5 h-3.5" />
              ) : action.payload.launch_app?.appId === 'calculator' ? (
                <Calculator className="w-3.5 h-3.5" />
              ) : action.payload.launch_app?.appId === 'camera' ? (
                <Camera className="w-3.5 h-3.5" />
              ) : action.payload.launch_app?.appId === 'gallery' ? (
                <ImageIcon className="w-3.5 h-3.5" />
              ) : action.payload.launch_app?.appId === 'settings' ? (
                <Settings className="w-3.5 h-3.5" />
              ) : (
                <ExternalLink className="w-3.5 h-3.5" />
              )}
            </div>
          )}
          {action.type === 'open_url' && (
            <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center">
              <ExternalLink className="w-3.5 h-3.5" />
            </div>
          )}
          {action.type === 'search' && (
            <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
              <Search className="w-3.5 h-3.5" />
            </div>
          )}
          {action.type === 'unsupported' && (
            <div className="w-6 h-6 rounded-lg bg-stone-700 text-white flex items-center justify-center">
              <Laptop className="w-3.5 h-3.5" />
            </div>
          )}

          <div>
            <h4 className="text-xs font-semibold text-stone-900 leading-tight">
              {action.title}
            </h4>
            <span className="text-[10px] text-stone-500 font-medium">
              {action.type === 'whatsapp'
                ? 'WhatsApp Message Draft / संदेश प्रारूप'
                : action.type === 'call'
                ? 'Phone Dialer / फ़ोन डायलर'
                : action.type === 'launch_app'
                ? (NativeActionRouter.isNativeAndroid() ? 'Android Native Intent • Direct App' : 'Browser Preview • Website')
                : action.type === 'open_url'
                ? 'App or Web Link / ऐप या लिंक'
                : action.type === 'search'
                ? 'Search / खोज'
                : 'System Limitation / सिस्टम सीमा'}
            </span>
          </div>
        </div>

        {/* Status indicator badge */}
        <div className="flex items-center gap-1.5">
          {action.status === 'executed' ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              <CheckCircle2 className="w-3 h-3" />
              <span>{NativeActionRouter.isNativeAndroid() ? 'Launched on Android / खोला गया' : 'Opened Website (Browser Preview) / वेबसाइट खोली गई'}</span>
            </span>
          ) : action.status === 'cancelled' ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-stone-200 text-stone-700">
              <XCircle className="w-3 h-3" />
              <span>Cancelled / रद्द</span>
            </span>
          ) : action.status === 'blocked' ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-100 text-rose-800 border border-rose-300">
              <AlertTriangle className="w-3 h-3" />
              <span>Not Installed / अनइंस्टॉल</span>
            </span>
          ) : action.status === 'error' ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-100 text-rose-800 border border-rose-300">
              <AlertTriangle className="w-3 h-3" />
              <span>Failed / विफल</span>
            </span>
          ) : isBlocked ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-100 text-rose-800 border border-rose-300">
              <AlertTriangle className="w-3 h-3" />
              <span>Blocked by Settings</span>
            </span>
          ) : action.type === 'launch_app' && action.payload.launch_app?.requiresConfirmation === false ? (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              <CheckCircle2 className="w-3 h-3" />
              <span>{NativeActionRouter.isNativeAndroid() ? 'Launched on Android' : 'Opened Website (Browser Preview)'}</span>
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-200/80 text-amber-900">
              <ShieldCheck className="w-3 h-3 text-amber-700" />
              <span>Needs Confirmation</span>
            </span>
          )}
        </div>
      </div>

      {/* Card Body */}
      <div className="p-3.5 space-y-3">
        {/* Permission Block Warning */}
        {isBlocked && (
          <div className="flex items-start gap-2 p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">{permissionCheck.reason}</p>
              {onOpenActionCenter && (
                <button
                  type="button"
                  onClick={() => onOpenActionCenter('permissions')}
                  className="mt-1 text-[11px] text-rose-700 underline font-medium hover:text-rose-900 cursor-pointer"
                >
                  Change permissions in Action Center / सेटिंग्स बदलें
                </button>
              )}
            </div>
          </div>
        )}

        {/* 1. WHATSAPP PAYLOAD */}
        {action.type === 'whatsapp' && action.payload.whatsapp && (
          <div className="space-y-2">
            {isEditing ? (
              <div className="space-y-2 bg-white p-3 rounded-xl border border-amber-300">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">
                    Recipient Phone Number (with Country Code)
                  </label>
                  <input
                    type="text"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="Enter phone number (or leave empty to pick in WhatsApp)"
                    className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-stone-300 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">
                    Message Content
                  </label>
                  <textarea
                    rows={3}
                    value={editMessage}
                    onChange={(e) => setEditMessage(e.target.value)}
                    placeholder="Enter message..."
                    className="w-full text-xs p-2 rounded-lg border border-stone-300 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
                <div className="flex justify-end gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-2.5 py-1 rounded-lg text-xs bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveEdit}
                    className="px-3 py-1 rounded-lg text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-medium cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-stone-600">
                    Recipient:{' '}
                    <strong className="text-stone-900">
                      {action.payload.whatsapp.phone
                        ? formatPhoneDisplay(action.payload.whatsapp.phone)
                        : action.payload.whatsapp.recipientName || 'Select contact in WhatsApp'}
                    </strong>
                  </span>
                  {action.status !== 'executed' && (
                    <button
                      type="button"
                      onClick={() => setIsEditing(true)}
                      className="inline-flex items-center gap-1 text-[11px] text-amber-800 hover:text-amber-900 hover:underline cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>Edit</span>
                    </button>
                  )}
                </div>

                <div className="bg-white/90 border border-amber-200/80 rounded-xl p-2.5 text-xs text-stone-800 font-sans whitespace-pre-wrap shadow-2xs">
                  <span className="text-[10px] uppercase font-semibold text-emerald-700 block mb-1">
                    Message Preview:
                  </span>
                  {action.payload.whatsapp.message || '(Empty message)'}
                </div>

                <p className="text-[11px] text-stone-500 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>
                    Zero-click safe: WhatsApp will open with this text pre-filled. You must press Send in WhatsApp.
                  </span>
                </p>
              </div>
            )}
          </div>
        )}

        {/* 2. CALL PAYLOAD */}
        {action.type === 'call' && action.payload.call && (
          <div className="space-y-2">
            {isEditing ? (
              <div className="space-y-2 bg-white p-3 rounded-xl border border-amber-300">
                <div>
                  <label className="block text-[11px] font-semibold text-stone-700 mb-0.5">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="Enter phone number..."
                    className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-stone-300 focus:outline-hidden focus:border-amber-500"
                  />
                </div>
                <div className="flex justify-end gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-2.5 py-1 rounded-lg text-xs bg-stone-100 hover:bg-stone-200 text-stone-700 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveEdit}
                    className="px-3 py-1 rounded-lg text-xs bg-amber-600 hover:bg-amber-500 text-white font-medium cursor-pointer"
                  >
                    Save
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-stone-600">
                    Number to dial:{' '}
                    <strong className="text-stone-900 font-mono text-sm">
                      {formatPhoneDisplay(action.payload.call.phone)}
                    </strong>
                    {action.payload.call.contactName && (
                      <span className="ml-1 text-stone-500">({action.payload.call.contactName})</span>
                    )}
                  </span>
                  {action.status !== 'executed' && (
                    <button
                      type="button"
                      onClick={() => setIsEditing(true)}
                      className="inline-flex items-center gap-1 text-[11px] text-amber-800 hover:text-amber-900 hover:underline cursor-pointer"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>Edit</span>
                    </button>
                  )}
                </div>

                <p className="text-[11px] text-stone-500 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>
                    Zero-click safe: This only loads your phone dialer. The call is never placed without your tap.
                  </span>
                </p>
              </div>
            )}
          </div>
        )}

        {/* 2b. LAUNCH APP PAYLOAD */}
        {action.type === 'launch_app' && action.payload.launch_app && (
          <div className="space-y-2 bg-white/90 p-3 rounded-xl border border-amber-200">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-stone-900 flex items-center gap-1.5">
                <span>{action.payload.launch_app.appName}</span>
                <span className="text-stone-500 font-normal">({action.payload.launch_app.hindiName})</span>
              </span>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                NativeActionRouter.isNativeAndroid()
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {NativeActionRouter.isNativeAndroid() ? 'Android Native Intent' : 'Browser Preview • Website'}
              </span>
            </div>
            <p className="text-[11px] text-stone-600 leading-relaxed">
              {NativeActionRouter.isNativeAndroid()
                ? `Launches the installed ${action.payload.launch_app.appName} app directly on your Android device.`
                : `Opens ${action.payload.launch_app.appName} website in browser preview (the installed Android app launches via Intent on Android devices).`}
            </p>
          </div>
        )}

        {/* 3. OPEN URL PAYLOAD */}
        {action.type === 'open_url' && action.payload.open_url && (
          <div className="space-y-1.5 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-stone-900">
                {action.payload.open_url.appName || 'Website'}
              </span>
              <span className="text-stone-500 text-[11px] truncate max-w-xs font-mono bg-stone-100 px-2 py-0.5 rounded">
                {action.payload.open_url.url}
              </span>
            </div>
            {action.payload.open_url.description && (
              <p className="text-stone-600 text-[11px]">{action.payload.open_url.description}</p>
            )}
          </div>
        )}

        {/* 4. SEARCH PAYLOAD */}
        {action.type === 'search' && action.payload.search && (
          <div className="space-y-1.5 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-medium text-stone-700">Search on:</span>
              <span className="font-semibold uppercase tracking-wider text-[10px] px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                {action.payload.search.engine}
              </span>
            </div>
            <div className="bg-white/80 border border-amber-200/60 rounded-lg px-2.5 py-1.5 text-xs font-medium text-stone-900">
              "{action.payload.search.query}"
            </div>
          </div>
        )}

        {/* 5. UNSUPPORTED / DESKTOP CONTROL PAYLOAD */}
        {action.type === 'unsupported' && action.payload.unsupported && (
          <div className="space-y-2 bg-stone-100/90 border border-stone-300/80 rounded-xl p-3 text-xs text-stone-800">
            <div className="flex items-center gap-2 text-amber-800 font-semibold">
              <Laptop className="w-4 h-4 text-amber-700" />
              <span>Browser Sandbox Boundary / ब्राउज़र सुरक्षा सीमा</span>
            </div>
            <p className="text-stone-700 text-[11px] leading-relaxed">
              {action.payload.unsupported.reason}
            </p>
            {action.payload.unsupported.safeAlternative && (
              <p className="text-stone-600 text-[11px]">
                <strong className="text-stone-800">Alternative:</strong> {action.payload.unsupported.safeAlternative}
              </p>
            )}
            {onOpenActionCenter && (
              <button
                type="button"
                onClick={() => onOpenActionCenter('desktop')}
                className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-white font-medium text-xs shadow-xs cursor-pointer"
              >
                <span>View Desktop Companion Plan / कंप्यूटर साथी योजना देखें</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Feedback message if executed or error */}
        {(executionMessage || action.error) && (
          <div
            className={`text-xs font-medium px-3 py-2 rounded-xl border flex items-start gap-2 ${
              action.status === 'error' || action.status === 'blocked'
                ? 'text-rose-800 bg-rose-50 border-rose-200'
                : 'text-emerald-800 bg-emerald-50 border-emerald-200'
            }`}
          >
            {action.status === 'error' || action.status === 'blocked' ? (
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div className="flex-1 leading-relaxed">
              <p>{executionMessage || action.error}</p>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {action.status !== 'executed' && action.status !== 'cancelled' && action.type !== 'unsupported' && (
          <div className="flex items-center gap-2 pt-1">
            {action.status === 'blocked' || action.status === 'error' ? (
              <>
                <button
                  type="button"
                  onClick={handleExecute}
                  disabled={isBlocked}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-stone-700 hover:bg-stone-800 text-white font-medium text-xs shadow-xs transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retry Action / पुनः प्रयास करें</span>
                </button>
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-3 py-2 rounded-xl bg-stone-200/80 hover:bg-stone-300 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
                >
                  Dismiss
                </button>
              </>
            ) : (
              <>
                {action.type === 'whatsapp' && (
                  <button
                    id={`confirm-whatsapp-btn-${action.id}`}
                    type="button"
                    onClick={handleExecute}
                    disabled={isBlocked}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-medium text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Open WhatsApp / व्हाट्सएप खोलें</span>
                  </button>
                )}

                {action.type === 'call' && (
                  <button
                    id={`confirm-call-btn-${action.id}`}
                    type="button"
                    onClick={handleExecute}
                    disabled={isBlocked}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-medium text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Open Dialer / फ़ोन डायलर खोलें</span>
                  </button>
                )}

                {action.type === 'launch_app' && action.payload.launch_app?.requiresConfirmation !== false && (
                  <button
                    id={`confirm-launch-btn-${action.id}`}
                    type="button"
                    onClick={handleExecute}
                    disabled={isBlocked}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white font-medium text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                    <span>Open {action.payload.launch_app?.appName || 'App'}</span>
                  </button>
                )}

                {action.type === 'open_url' && (
                  <button
                    id={`confirm-open-url-btn-${action.id}`}
                    type="button"
                    onClick={handleExecute}
                    disabled={isBlocked}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-medium text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Link / वेबसाइट खोलें</span>
                  </button>
                )}

                {action.type === 'search' && (
                  <button
                    id={`confirm-search-btn-${action.id}`}
                    type="button"
                    onClick={handleExecute}
                    disabled={isBlocked}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span>Search Now / अभी खोजें</span>
                  </button>
                )}

                <button
                  id={`cancel-action-btn-${action.id}`}
                  type="button"
                  onClick={handleCancel}
                  className="px-3 py-2 rounded-xl bg-stone-200/80 hover:bg-stone-300 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
                  title="Cancel action"
                >
                  Dismiss / रद्द
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

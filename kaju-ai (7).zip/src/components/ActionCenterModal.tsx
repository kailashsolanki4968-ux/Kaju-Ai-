import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Zap,
  Phone,
  MessageSquare,
  ExternalLink,
  Laptop,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Smartphone,
  Globe,
  Layers,
  Settings,
  History,
  Send,
  PhoneCall,
  Search,
  ArrowRight,
  Info,
} from 'lucide-react';
import { ActionPermissions, DeviceAction } from '../types';
import {
  POPULAR_APP_SHORTCUTS,
  buildWhatsAppUrl,
  buildDialerUrl,
  formatPhoneDisplay,
  sanitizePhoneNumber,
} from '../utils/actionHelper';
import { NativeActionRouter } from '../utils/nativeActionRouter';

interface ActionCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  permissions: ActionPermissions;
  onUpdatePermissions: (newPerms: ActionPermissions) => void;
  actionHistory: DeviceAction[];
  initialTab?: 'overview' | 'quick_actions' | 'permissions' | 'desktop' | 'history';
}

export const ActionCenterModal: React.FC<ActionCenterModalProps> = ({
  isOpen,
  onClose,
  permissions,
  onUpdatePermissions,
  actionHistory,
  initialTab = 'quick_actions',
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'quick_actions' | 'permissions' | 'desktop' | 'history'>(
    initialTab
  );

  // Quick Action State - WhatsApp Composer
  const [waPhone, setWaPhone] = useState('');
  const [waMessage, setWaMessage] = useState('');
  const [waNotice, setWaNotice] = useState<string | null>(null);

  // Quick Action State - Dialer
  const [dialerPhone, setDialerPhone] = useState('');
  const [dialerNotice, setDialerNotice] = useState<string | null>(null);

  // Quick Action State - App Launch Feedback
  const [appNotice, setAppNotice] = useState<{ message: string; isError?: boolean } | null>(null);

  if (!isOpen) return null;

  const handleLaunchApp = async (app: (typeof POPULAR_APP_SHORTCUTS)[0]) => {
    if (app.appId) {
      const res = await NativeActionRouter.launchApp(app.appId);
      setAppNotice({ message: res.message, isError: !res.success });
      setTimeout(() => setAppNotice(null), 6000);
    } else if (app.url) {
      window.open(app.url, '_blank', 'noopener,noreferrer');
      setAppNotice({ message: `Opened ${app.name} in web browser.` });
      setTimeout(() => setAppNotice(null), 6000);
    }
  };

  const handleLaunchWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.allowWhatsApp) {
      setWaNotice('WhatsApp links are disabled in Permission settings.');
      return;
    }
    const cleanPhone = sanitizePhoneNumber(waPhone);
    const url = buildWhatsAppUrl(cleanPhone, waMessage);
    window.open(url, '_blank', 'noopener,noreferrer');
    setWaNotice('Opening WhatsApp with prepared message. You can review and tap Send inside WhatsApp.');
    setTimeout(() => setWaNotice(null), 6000);
  };

  const handleLaunchDialer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.allowPhoneDialer) {
      setDialerNotice('Phone dialer is disabled in Permission settings.');
      return;
    }
    if (!dialerPhone.trim()) {
      setDialerNotice('Please enter a phone number.');
      return;
    }
    const url = buildDialerUrl(dialerPhone);
    window.location.href = url;
    setDialerNotice(`Opening phone dialer for ${formatPhoneDisplay(dialerPhone)}. Call will not be placed until you tap call.`);
    setTimeout(() => setDialerNotice(null), 6000);
  };

  const handleTogglePermission = (key: keyof ActionPermissions) => {
    if (key === 'requireConfirmationAlways') return; // Safety lock: always required
    const updated = {
      ...permissions,
      [key]: !permissions[key],
    };
    onUpdatePermissions(updated);
  };

  return (
    <div
      id="action-center-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-900/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl max-h-[90vh] flex flex-col bg-white rounded-3xl shadow-2xl border border-amber-200/80 overflow-hidden text-stone-800"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-amber-50 to-orange-50/80 border-b border-amber-200/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-600 text-white flex items-center justify-center shadow-xs">
              <Zap className="w-5 h-5 text-amber-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-stone-900 tracking-tight">
                  Kaju Action Center
                </h2>
                <span className="text-[10px] uppercase tracking-wider font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                  Safe & Verified
                </span>
              </div>
              <p className="text-xs text-stone-600">
                काजू एक्शन सेंटर • Apps, WhatsApp, Dialer & Device Integrations
              </p>
            </div>
          </div>

          <button
            id="close-action-center-button"
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-500 hover:text-stone-800 hover:bg-white/80 transition-colors cursor-pointer"
            aria-label="Close Action Center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-4 py-2 bg-stone-50 border-b border-stone-200 text-xs overflow-x-auto select-none">
          <button
            type="button"
            onClick={() => setActiveTab('quick_actions')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all cursor-pointer ${
              activeTab === 'quick_actions'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-200/60'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Quick Actions (तुरंत कार्रवाई)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-200/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Capabilities (क्षमताएं)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('permissions')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all cursor-pointer ${
              activeTab === 'permissions'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-200/60'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Permissions (अनुमतियाँ)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('desktop')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all cursor-pointer ${
              activeTab === 'desktop'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-200/60'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>Desktop Companion Plan (कंप्यूटर साथी)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-medium transition-all cursor-pointer ${
              activeTab === 'history'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-stone-600 hover:bg-stone-200/60'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit History ({actionHistory.length})</span>
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-6">
          {/* TAB 1: QUICK ACTIONS */}
          {activeTab === 'quick_actions' && (
            <div className="space-y-6">
              {/* WhatsApp & Dialer 2-Column Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* WhatsApp Message Composer */}
                <div className="p-4 rounded-2xl border border-emerald-200/80 bg-emerald-50/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-stone-900">
                          WhatsApp Message Composer
                        </h3>
                        <p className="text-[11px] text-stone-500">
                          व्हाट्सएप संदेश तैयार करें
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-md">
                      Zero-Click Safe
                    </span>
                  </div>

                  <form onSubmit={handleLaunchWhatsApp} className="space-y-2.5">
                    <div>
                      <label className="block text-[11px] font-medium text-stone-700 mb-0.5">
                        Recipient Number (Optional, with country code)
                      </label>
                      <input
                        id="wa-phone-input"
                        type="text"
                        value={waPhone}
                        onChange={(e) => setWaPhone(e.target.value)}
                        placeholder="Enter phone number (or leave empty to choose in WhatsApp)"
                        className="w-full text-xs px-3 py-2 rounded-xl bg-white border border-stone-300 focus:outline-hidden focus:border-emerald-500 shadow-2xs"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-stone-700 mb-0.5">
                        Message Content (संदेश)
                      </label>
                      <textarea
                        id="wa-message-input"
                        rows={3}
                        value={waMessage}
                        onChange={(e) => setWaMessage(e.target.value)}
                        placeholder="Type your message here (Hindi, English, Hinglish)..."
                        className="w-full text-xs p-2.5 rounded-xl bg-white border border-stone-300 focus:outline-hidden focus:border-emerald-500 shadow-2xs"
                      />
                    </div>

                    {waNotice && (
                      <div className="text-[11px] text-emerald-800 bg-emerald-100/90 border border-emerald-300 p-2 rounded-lg">
                        {waNotice}
                      </div>
                    )}

                    <button
                      id="submit-whatsapp-action"
                      type="submit"
                      disabled={!permissions.allowWhatsApp}
                      className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Prepare & Open in WhatsApp / व्हाट्सएप खोलें</span>
                    </button>
                    <p className="text-[10px] text-stone-500 text-center">
                      Opens WhatsApp with text pre-filled. You retain 100% control to press Send.
                    </p>
                  </form>
                </div>

                {/* Phone Dialer Launcher */}
                <div className="p-4 rounded-2xl border border-amber-200/80 bg-amber-50/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-amber-600 text-white flex items-center justify-center">
                        <Phone className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-xs font-bold text-stone-900">
                          Phone Dialer Launcher
                        </h3>
                        <p className="text-[11px] text-stone-500">
                          फ़ोन डायलर खोलें
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                      Dialer Only
                    </span>
                  </div>

                  <form onSubmit={handleLaunchDialer} className="space-y-2.5">
                    <div>
                      <label className="block text-[11px] font-medium text-stone-700 mb-0.5">
                        Phone Number to Call (फ़ोन नंबर)
                      </label>
                      <input
                        id="dialer-phone-input"
                        type="tel"
                        value={dialerPhone}
                        onChange={(e) => setDialerPhone(e.target.value)}
                        placeholder="Enter phone number to dial (e.g. 112)"
                        className="w-full text-xs px-3 py-2 rounded-xl bg-white border border-stone-300 focus:outline-hidden focus:border-amber-500 shadow-2xs font-mono"
                      />
                    </div>

                    {dialerPhone && (
                      <div className="p-2 rounded-lg bg-white/80 border border-amber-200 text-xs text-stone-700 flex items-center justify-between">
                        <span>Formatted Display:</span>
                        <strong className="font-mono text-stone-900">
                          {formatPhoneDisplay(dialerPhone)}
                        </strong>
                      </div>
                    )}

                    {dialerNotice && (
                      <div className="text-[11px] text-amber-800 bg-amber-100/90 border border-amber-300 p-2 rounded-lg">
                        {dialerNotice}
                      </div>
                    )}

                    <div className="pt-3">
                      <button
                        id="submit-dialer-action"
                        type="submit"
                        disabled={!permissions.allowPhoneDialer}
                        className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-semibold text-xs shadow-xs hover:shadow transition-all cursor-pointer"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                        <span>Open in Phone Dialer / डायलर खोलें</span>
                      </button>
                    </div>
                    <p className="text-[10px] text-stone-500 text-center">
                      Opens your phone's native dialer. The call is never placed without your explicit tap.
                    </p>
                  </form>
                </div>
              </div>

              {/* Supported Apps & Web Services Shortcuts */}
              <div className="space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <h3 className="text-xs font-bold text-stone-900 uppercase tracking-wider">
                      Supported Applications & Services (1-Click Safe Launch)
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      {NativeActionRouter.isNativeAndroid()
                        ? 'Android Native Environment: Dispatches native Android Intents to installed apps'
                        : 'Web Sandbox Environment: Opens safe web fallbacks (Android Intent bridge ready)'}
                    </p>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                    NativeActionRouter.isNativeAndroid()
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border border-amber-300'
                  }`}>
                    {NativeActionRouter.isNativeAndroid() ? 'Android Native Host' : 'Web Preview'}
                  </span>
                </div>

                {/* App Launch Feedback Notification */}
                {appNotice && (
                  <div className={`p-2.5 rounded-xl text-xs border animate-in fade-in duration-200 ${
                    appNotice.isError
                      ? 'bg-rose-50 border-rose-300 text-rose-800'
                      : 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  }`}>
                    {appNotice.message}
                  </div>
                )}

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {POPULAR_APP_SHORTCUTS.map((app) => (
                    <button
                      key={app.id}
                      type="button"
                      onClick={() => handleLaunchApp(app)}
                      className="group flex flex-col justify-between p-3 rounded-2xl border border-stone-200/80 bg-stone-50/60 hover:bg-white hover:border-amber-400 hover:shadow-xs transition-all text-stone-800 text-left cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-1.5 w-full">
                        <span className="text-xs font-bold text-stone-900 group-hover:text-amber-700 transition-colors">
                          {app.name}
                        </span>
                        <ArrowRight className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-600 transition-colors" />
                      </div>
                      <p className="text-[11px] text-stone-500 font-medium">
                        {app.hindiName}
                      </p>
                      <p className="text-[10px] text-stone-400 mt-1 line-clamp-1">
                        {app.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: OVERVIEW & CAPABILITIES */}
          {activeTab === 'overview' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-stone-800 space-y-1.5">
                <div className="flex items-center gap-2 font-semibold text-amber-900">
                  <ShieldCheck className="w-4 h-4 text-amber-700" />
                  <span>Kaju AI Safe Action Model</span>
                </div>
                <p className="text-stone-700 text-[11px] leading-relaxed">
                  To safeguard your privacy and security, all actions follow the <strong>Zero-Click Safety Standard</strong>: Kaju AI prepares messages, numbers, and links, but you must review and confirm before any message is dispatched or call is placed.
                </p>
              </div>

              {/* Three Tier Architecture Table */}
              <div className="border border-stone-200 rounded-2xl overflow-hidden text-xs">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-stone-100 border-b border-stone-200 text-stone-700 font-bold">
                      <th className="p-3">Capability / Feature</th>
                      <th className="p-3">Tier 1: Current Web App</th>
                      <th className="p-3">Tier 2: Android App</th>
                      <th className="p-3">Tier 3: Desktop Companion</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200">
                    <tr>
                      <td className="p-3 font-semibold text-stone-900">WhatsApp Messaging</td>
                      <td className="p-3 text-emerald-700 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Supported (wa.me link with preview)</span>
                      </td>
                      <td className="p-3 text-emerald-700">Native Intent (Direct share)</td>
                      <td className="p-3 text-emerald-700">WhatsApp Desktop protocol</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-stone-900">Phone Calls</td>
                      <td className="p-3 text-emerald-700 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Supported (tel: dialer launcher)</span>
                      </td>
                      <td className="p-3 text-emerald-700">ACTION_DIAL (native)</td>
                      <td className="p-3 text-stone-400">Phone Link / Bluetooth</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-stone-900">Website & App Launch</td>
                      <td className="p-3 text-emerald-700 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Supported (YouTube, Maps, Google)</span>
                      </td>
                      <td className="p-3 text-emerald-700">Custom Tabs or Apps</td>
                      <td className="p-3 text-emerald-700">Launch any application</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-stone-900">Read Device Contacts</td>
                      <td className="p-3 text-amber-700 font-medium">
                        Web Contact Picker (Manual)
                      </td>
                      <td className="p-3 text-emerald-700">Full Contacts API</td>
                      <td className="p-3 text-stone-500">Address Book integration</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-semibold text-stone-900">PC Control (Mouse, Keyboard, Files)</td>
                      <td className="p-3 text-rose-700 font-medium flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Blocked by Sandbox</span>
                      </td>
                      <td className="p-3 text-stone-400">N/A (Mobile)</td>
                      <td className="p-3 text-emerald-700 font-semibold">
                        Supported via Local Daemon
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: PERMISSION SETTINGS */}
          {activeTab === 'permissions' && (
            <div className="space-y-4 max-w-xl">
              <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 text-xs text-stone-600">
                You can enable or disable device integrations anytime. When disabled, Kaju AI will refuse to generate action buttons for that specific integration.
              </div>

              <div className="space-y-3">
                {/* WhatsApp Permission */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 bg-white">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">
                        Allow WhatsApp Message Drafting
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Allows Kaju AI to prepare WhatsApp message cards
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleTogglePermission('allowWhatsApp')}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      permissions.allowWhatsApp ? 'bg-emerald-600' : 'bg-stone-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        permissions.allowWhatsApp ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Phone Dialer Permission */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 bg-white">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center">
                      <Phone className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">
                        Allow Phone Dialer Trigger
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Allows Kaju AI to open your device's phone dialer
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleTogglePermission('allowPhoneDialer')}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      permissions.allowPhoneDialer ? 'bg-amber-600' : 'bg-stone-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        permissions.allowPhoneDialer ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* External Links Permission */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl border border-stone-200 bg-white">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
                      <ExternalLink className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">
                        Allow External App & Web Links
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Allows opening YouTube, Google Maps, Wikipedia, etc.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleTogglePermission('allowExternalLinks')}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                      permissions.allowExternalLinks ? 'bg-blue-600' : 'bg-stone-300'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        permissions.allowExternalLinks ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>

                {/* Always Require Confirmation (Locked for security) */}
                <div className="flex items-center justify-between p-3.5 rounded-2xl border border-emerald-200 bg-emerald-50/50">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900">
                        Enforce Human Confirmation Always
                      </h4>
                      <p className="text-[11px] text-stone-500">
                        Permanently active for safety. Actions can never run silently.
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold text-emerald-800 bg-emerald-200/80 px-2 py-0.5 rounded-md">
                    Enforced
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: DESKTOP COMPANION INTEGRATION PLAN */}
          {activeTab === 'desktop' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-stone-800 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-900 text-sm">
                  <Laptop className="w-4 h-4 text-amber-700" />
                  <span>Desktop Companion Architecture & Safety Specification</span>
                </div>
                <p className="text-stone-700 text-xs leading-relaxed">
                  Standard web browsers run inside a secure container sandbox (Same-Origin Policy). A web page cannot execute shell commands, open desktop applications (like VS Code or Excel), or touch your local file system directly.
                </p>
                <p className="text-stone-700 text-xs leading-relaxed">
                  To provide true desktop automation safely, Kaju AI employs a <strong>Local Companion Daemon</strong> architecture.
                </p>
              </div>

              {/* Technical Architecture Blocks */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl border border-stone-200 bg-white space-y-1.5">
                  <h4 className="font-bold text-stone-900">1. Local Host Bridge</h4>
                  <p className="text-stone-600 text-[11px]">
                    A lightweight open-source agent (Node.js/Python) running locally on <code className="bg-stone-100 px-1 py-0.5 rounded text-amber-800">127.0.0.1:9876</code>.
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl border border-stone-200 bg-white space-y-1.5">
                  <h4 className="font-bold text-stone-900">2. Token Authentication</h4>
                  <p className="text-stone-600 text-[11px]">
                    Web app and Desktop Daemon pair using a cryptographically signed one-time QR code or passkey, preventing any external website from issuing commands.
                  </p>
                </div>
                <div className="p-3.5 rounded-2xl border border-stone-200 bg-white space-y-1.5">
                  <h4 className="font-bold text-stone-900">3. Human Consent Popup</h4>
                  <p className="text-stone-600 text-[11px]">
                    Any sensitive operation (running bash scripts, modifying documents) triggers an OS-level confirmation window with an instant Kill Switch.
                  </p>
                </div>
              </div>

              {/* Status & Implementation roadmap */}
              <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-900">Status: Blueprint Ready</span>
                  <span className="text-[10px] uppercase font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded">
                    Phase 2 Standalone Daemon
                  </span>
                </div>
                <p className="text-stone-600 text-[11px]">
                  Desktop automation capabilities will be enabled once the companion executable is paired. The browser app will automatically detect <code className="bg-stone-200 px-1 py-0.5 rounded text-stone-800">http://127.0.0.1:9876/status</code> and activate full OS controls.
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: AUDIT LOG */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs">
                <h3 className="font-bold text-stone-900">Recent Action Audit Trail</h3>
                <span className="text-[11px] text-stone-500">
                  {actionHistory.length} recorded actions
                </span>
              </div>

              {actionHistory.length === 0 ? (
                <div className="text-center py-8 text-stone-400 text-xs">
                  No actions executed yet in this session.
                </div>
              ) : (
                <div className="space-y-2">
                  {actionHistory.map((act) => (
                    <div
                      key={act.id}
                      className="flex items-center justify-between p-3 rounded-xl border border-stone-200 bg-white text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        {act.type === 'whatsapp' ? (
                          <MessageSquare className="w-4 h-4 text-emerald-600" />
                        ) : act.type === 'call' ? (
                          <Phone className="w-4 h-4 text-amber-600" />
                        ) : act.type === 'open_url' ? (
                          <ExternalLink className="w-4 h-4 text-blue-600" />
                        ) : (
                          <Zap className="w-4 h-4 text-indigo-600" />
                        )}
                        <div>
                          <p className="font-semibold text-stone-900">{act.title}</p>
                          <p className="text-[10px] text-stone-500">
                            {new Date(act.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          act.status === 'executed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : act.status === 'cancelled'
                            ? 'bg-stone-100 text-stone-600'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {act.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-5 py-3 bg-stone-50 border-t border-stone-200 text-xs text-stone-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Zero-Click Safety: User confirmation required for all device operations.</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-white font-medium text-xs transition-colors cursor-pointer"
          >
            Close / बंद करें
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  X,
  Camera,
  RotateCcw,
  Check,
  SwitchCamera,
  Upload,
  AlertCircle,
  Sparkles,
  Zap,
  ZapOff,
} from 'lucide-react';
import { optimizeImage } from '../utils/imageHelper';

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (imageDataUrl: string) => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCapture,
}) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hasMultipleCameras, setHasMultipleCameras] = useState(false);
  const [isTorchOn, setIsTorchOn] = useState(false);
  const [supportsTorch, setSupportsTorch] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Stop current active media stream cleanly
  const stopStream = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      setStream(null);
    }
  }, [stream]);

  // Check if multiple camera devices exist
  useEffect(() => {
    if (!isOpen) return;
    navigator.mediaDevices?.enumerateDevices?.().then((devices) => {
      const videoDevices = devices.filter((d) => d.kind === 'videoinput');
      setHasMultipleCameras(videoDevices.length > 1);
    }).catch(() => {});
  }, [isOpen]);

  // Start camera stream
  const startCamera = useCallback(async (mode: 'environment' | 'user') => {
    setIsInitializing(true);
    setErrorMessage(null);
    setCapturedPhoto(null);

    // Stop existing stream first
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setErrorMessage(
        'Camera API is not supported in this browser environment. You can upload an image from your gallery.'
      );
      setIsInitializing(false);
      return;
    }

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: mode },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      };

      const newStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(newStream);

      // Check for torch/flashlight support
      const videoTrack = newStream.getVideoTracks()[0];
      if (videoTrack) {
        const capabilities: any = videoTrack.getCapabilities?.() || {};
        setSupportsTorch(Boolean(capabilities.torch));
      }

      if (videoRef.current) {
        videoRef.current.srcObject = newStream;
        await videoRef.current.play().catch(() => {});
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setErrorMessage(
          'Camera access was not granted. Please allow camera permissions in your browser or choose a photo from your gallery.'
        );
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setErrorMessage('No camera device detected on this system. Please upload an image from your gallery.');
      } else {
        setErrorMessage(`Could not start camera: ${err.message || 'Unknown error'}. You can upload from gallery.`);
      }
    } finally {
      setIsInitializing(false);
    }
  }, [stream]);

  // Start camera when modal opens
  useEffect(() => {
    if (isOpen) {
      setCapturedPhoto(null);
      startCamera(facingMode);
    } else {
      stopStream();
      setCapturedPhoto(null);
      setErrorMessage(null);
    }

    return () => {
      stopStream();
    };
  }, [isOpen]);

  // Toggle flashlight/torch if supported
  const toggleTorch = async () => {
    if (!stream) return;
    const track = stream.getVideoTracks()[0];
    if (track && supportsTorch) {
      try {
        const nextState = !isTorchOn;
        await (track as any).applyConstraints({
          advanced: [{ torch: nextState }],
        });
        setIsTorchOn(nextState);
      } catch (err) {
        console.warn('Failed to toggle torch:', err);
      }
    }
  };

  // Flip camera between front & back
  const handleSwitchCamera = () => {
    const nextMode = facingMode === 'environment' ? 'user' : 'environment';
    setFacingMode(nextMode);
    startCamera(nextMode);
  };

  // Capture snapshot from live stream
  const handleSnap = async () => {
    if (!videoRef.current) return;
    const video = videoRef.current;

    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    // If front camera, mirror horizontally for natural feel
    if (facingMode === 'user') {
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
    }

    ctx.drawImage(video, 0, 0, width, height);
    const rawDataUrl = canvas.toDataURL('image/jpeg', 0.95);

    try {
      const optimized = await optimizeImage(rawDataUrl, 1920, 0.88);
      setCapturedPhoto(optimized.dataUrl);
      // Pause video while previewing
      video.pause();
    } catch (e) {
      setCapturedPhoto(rawDataUrl);
    }
  };

  // Retake photo: resume camera
  const handleRetake = () => {
    setCapturedPhoto(null);
    if (videoRef.current && stream) {
      videoRef.current.play().catch(() => {});
    } else {
      startCamera(facingMode);
    }
  };

  // Confirm photo and send to chat input
  const handleConfirmPhoto = () => {
    if (capturedPhoto) {
      stopStream();
      onCapture(capturedPhoto);
      onClose();
    }
  };

  // Handle file input selection as alternative / gallery
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const optimized = await optimizeImage(file, 1920, 0.88);
      stopStream();
      onCapture(optimized.dataUrl);
      onClose();
    } catch (err) {
      console.error('Failed to process uploaded image:', err);
      setErrorMessage('Failed to read selected image. Please try again with a different photo.');
    } finally {
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="camera-capture-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-2 sm:p-4 animate-in fade-in duration-200"
    >
      <div
        id="camera-capture-modal"
        className="relative w-full max-w-xl bg-stone-900 text-white rounded-3xl overflow-hidden shadow-2xl border border-stone-800 flex flex-col max-h-[92vh]"
      >
        {/* Top bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-stone-900/90 border-b border-stone-800/80 shrink-0 z-10">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-semibold text-sm sm:text-base text-stone-100 flex items-center gap-1.5">
                Scan Question or Diagram
                <span className="text-xs text-amber-400 font-normal">फोटो खींचें</span>
              </h3>
              <p className="text-[11px] text-stone-400 hidden sm:block">
                Hold still and frame printed textbook text or handwritten notes
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Flash/Torch toggle if supported */}
            {supportsTorch && !capturedPhoto && (
              <button
                type="button"
                onClick={toggleTorch}
                className={`p-2 rounded-xl border transition-colors ${
                  isTorchOn
                    ? 'bg-amber-500 text-stone-950 border-amber-400'
                    : 'bg-stone-800 text-stone-300 border-stone-700 hover:bg-stone-700'
                }`}
                title={isTorchOn ? 'Turn off flash' : 'Turn on flash'}
              >
                {isTorchOn ? <Zap className="w-4 h-4" /> : <ZapOff className="w-4 h-4" />}
              </button>
            )}

            {/* Switch camera button */}
            {hasMultipleCameras && !capturedPhoto && (
              <button
                type="button"
                onClick={handleSwitchCamera}
                className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors"
                title="Switch Camera (Front/Back)"
              >
                <SwitchCamera className="w-4 h-4" />
              </button>
            )}

            {/* Close modal */}
            <button
              id="close-camera-modal-button"
              type="button"
              onClick={() => {
                stopStream();
                onClose();
              }}
              className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700 transition-colors cursor-pointer"
              aria-label="Close camera"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Viewfinder area */}
        <div className="relative flex-1 bg-black flex items-center justify-center min-h-[320px] sm:min-h-[400px] overflow-hidden">
          {/* Live Video */}
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={`w-full h-full object-contain max-h-[60vh] transition-opacity duration-300 ${
              capturedPhoto ? 'hidden' : 'block'
            }`}
          />

          {/* Captured Still Preview */}
          {capturedPhoto && (
            <div className="w-full h-full flex items-center justify-center p-2 relative">
              <img
                src={capturedPhoto}
                alt="Captured question"
                className="max-w-full max-h-[60vh] object-contain rounded-xl shadow-lg"
              />
              <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-xs text-amber-300 text-xs px-2.5 py-1 rounded-full border border-amber-500/40 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Photo ready to inspect</span>
              </div>
            </div>
          )}

          {/* Scanner framing overlay for live stream */}
          {!capturedPhoto && !errorMessage && !isInitializing && (
            <div className="absolute inset-4 sm:inset-8 pointer-events-none flex flex-col items-center justify-between">
              {/* Corner brackets */}
              <div className="w-full flex justify-between">
                <div className="w-8 h-8 border-t-2 border-l-2 border-amber-400/80 rounded-tl-lg" />
                <div className="w-8 h-8 border-t-2 border-r-2 border-amber-400/80 rounded-tr-lg" />
              </div>

              {/* Central guide text */}
              <div className="bg-black/60 backdrop-blur-xs text-stone-200 text-xs px-3 py-1.5 rounded-full border border-white/10 flex items-center gap-1.5 shadow-md">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>Align question, formula, or diagram inside frame</span>
              </div>

              <div className="w-full flex justify-between">
                <div className="w-8 h-8 border-b-2 border-l-2 border-amber-400/80 rounded-bl-lg" />
                <div className="w-8 h-8 border-b-2 border-r-2 border-amber-400/80 rounded-br-lg" />
              </div>
            </div>
          )}

          {/* Loading indicator */}
          {isInitializing && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-stone-950/90 text-stone-300 gap-3">
              <div className="w-9 h-9 border-3 border-amber-500/30 border-t-amber-500 rounded-full animate-spin" />
              <p className="text-xs text-stone-400">Starting camera preview...</p>
            </div>
          )}

          {/* Error / Permission fallback card */}
          {errorMessage && (
            <div className="absolute inset-4 sm:inset-8 flex flex-col items-center justify-center p-6 bg-stone-900/95 border border-stone-800 rounded-2xl text-center">
              <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 flex items-center justify-center mb-3 border border-rose-500/20">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h4 className="font-semibold text-stone-100 text-sm mb-1">Camera Notice</h4>
              <p className="text-xs text-stone-400 leading-relaxed max-w-sm mb-5">
                {errorMessage}
              </p>
              <div className="flex flex-col sm:flex-row gap-2.5 w-full max-w-xs">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full px-4 py-2.5 rounded-xl bg-linear-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-stone-950 font-semibold text-xs flex items-center justify-center gap-2 shadow-md cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Choose from Gallery</span>
                </button>
                <button
                  type="button"
                  onClick={() => startCamera(facingMode)}
                  className="w-full px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium border border-stone-700 cursor-pointer"
                >
                  Try Again
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Hidden file input for gallery fallback / direct upload */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />

        {/* Bottom controls */}
        <div className="p-3 sm:p-4 bg-stone-900 border-t border-stone-800/80 flex items-center justify-between gap-3 shrink-0">
          {!capturedPhoto ? (
            <>
              {/* Gallery button */}
              <button
                id="camera-modal-gallery-button"
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-800/80 hover:bg-stone-800 text-stone-300 hover:text-white border border-stone-700/80 text-xs font-medium transition-colors cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden xs:inline">Gallery</span>
                <span className="text-[10px] text-stone-400 hidden sm:inline">(गैलरी)</span>
              </button>

              {/* Shutter Capture Button */}
              <button
                id="camera-shutter-button"
                type="button"
                onClick={handleSnap}
                disabled={isInitializing || Boolean(errorMessage)}
                className={`group relative flex items-center justify-center w-16 h-16 rounded-full border-4 transition-all ${
                  isInitializing || Boolean(errorMessage)
                    ? 'border-stone-700 opacity-40 cursor-not-allowed'
                    : 'border-amber-500 hover:scale-105 active:scale-95 cursor-pointer shadow-lg shadow-amber-500/20'
                }`}
                aria-label="Capture photo"
              >
                <div className="w-11 h-11 rounded-full bg-white group-hover:bg-amber-400 transition-colors shadow-inner" />
              </button>

              {/* Cancel button */}
              <button
                type="button"
                onClick={() => {
                  stopStream();
                  onClose();
                }}
                className="px-3 py-2 rounded-xl text-xs text-stone-400 hover:text-stone-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </>
          ) : (
            /* Action controls after taking photo */
            <div className="flex items-center justify-between w-full gap-3">
              <button
                id="camera-retake-button"
                type="button"
                onClick={handleRetake}
                className="flex-1 py-2.5 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 border border-stone-700 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake / दोबारा लें</span>
              </button>

              <button
                id="camera-confirm-button"
                type="button"
                onClick={handleConfirmPhoto}
                className="flex-1 py-2.5 px-4 rounded-xl bg-linear-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-stone-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-900/30 transition-transform active:scale-98 cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Use Photo / उपयोग करें</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

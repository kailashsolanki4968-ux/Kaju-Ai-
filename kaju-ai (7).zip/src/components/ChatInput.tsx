import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Sparkles,
  Loader2,
  AlertCircle,
  X,
  Camera,
  Image as ImageIcon,
  RotateCcw,
  ZoomIn,
} from 'lucide-react';
import { LanguagePreference } from '../types';
import { CameraCaptureModal } from './CameraCaptureModal';
import { ImagePreviewModal } from './ImagePreviewModal';
import { optimizeImage } from '../utils/imageHelper';
import { getSpeechRecognitionLang } from '../utils/languages';

interface ChatInputProps {
  onSendMessage: (content: string, image?: string) => void;
  isLoading: boolean;
  languagePreference?: LanguagePreference;
  onOpenVoiceAssistant?: () => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  isLoading,
  languagePreference = 'auto',
  onOpenVoiceAssistant,
}) => {
  const [text, setText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  const [isListening, setIsListening] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [micErrorMessage, setMicErrorMessage] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(true);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef(false);

  // Check speech recognition capability
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
    }
  }, []);

  // Set appropriate recognition language
  const getRecognitionLang = (pref: LanguagePreference): string => {
    return getSpeechRecognitionLang(pref);
  };

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      const newHeight = Math.min(textarea.scrollHeight, 160);
      textarea.style.height = `${Math.max(48, newHeight)}px`;
    }
  }, [text, interimTranscript]);

  const stopRecognition = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {}
      recognitionRef.current = null;
    }
    isListeningRef.current = false;
    setIsListening(false);
    setInterimTranscript('');
  };

  const startRecognition = async () => {
    setMicErrorMessage(null);

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      setMicErrorMessage(
        'Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari. / आपका ब्राउज़र स्पीच पहचान का समर्थन नहीं करता।'
      );
      return;
    }

    // Explicitly test/request microphone permission using getUserMedia first if available
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch (err: any) {
        console.warn('Microphone permission query failed:', err);
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setMicErrorMessage(
            'Microphone permission was denied. Please allow microphone access in your browser settings. / माइक्रोफ़ोन की अनुमति नहीं मिली।'
          );
          return;
        } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
          setMicErrorMessage('No microphone device found. / कोई माइक्रोफ़ोन नहीं मिला।');
          return;
        }
      }
    }

    stopRecognition();

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = getRecognitionLang(languagePreference);

      recognition.onstart = () => {
        isListeningRef.current = true;
        setIsListening(true);
        setMicErrorMessage(null);
      };

      recognition.onresult = (event: any) => {
        let finalChunk = '';
        let interimChunk = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const trans = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalChunk += trans;
          } else {
            interimChunk += trans;
          }
        }

        if (interimChunk) {
          setInterimTranscript(interimChunk);
        }

        if (finalChunk) {
          setText((prev) => {
            const trimmedPrev = prev.trim();
            const trimmedFinal = finalChunk.trim();
            if (!trimmedPrev) return trimmedFinal;
            return `${trimmedPrev} ${trimmedFinal}`;
          });
          setInterimTranscript('');
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition event error:', event.error);

        if (event.error === 'no-speech' || event.error === 'aborted') {
          stopRecognition();
          return;
        }

        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          setMicErrorMessage(
            'Microphone permission blocked. Please enable microphone permissions in your address bar or browser settings.'
          );
        } else if (event.error === 'network') {
          setMicErrorMessage(
            'Network issue occurred during speech recognition. Please check your internet connection.'
          );
        } else {
          setMicErrorMessage(`Voice input error: ${event.error}. Please try again.`);
        }

        stopRecognition();
      };

      recognition.onend = () => {
        stopRecognition();
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Error starting speech recognition:', err);
      setMicErrorMessage(
        `Failed to start microphone: ${err?.message || 'Unknown error'}. Try clicking again.`
      );
      stopRecognition();
    }
  };

  const toggleMic = () => {
    if (isListeningRef.current) {
      stopRecognition();
    } else {
      startRecognition();
    }
  };

  // Handle gallery file selection
  const handleGalleryFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImage(true);
    try {
      const optimized = await optimizeImage(file, 1920, 0.88);
      setSelectedImage(optimized.dataUrl);
    } catch (err) {
      console.error('Failed to process gallery image:', err);
      setMicErrorMessage('Could not load selected image. Please try again.');
    } finally {
      setIsProcessingImage(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Handle image capture from camera modal
  const handlePhotoCaptured = (imageDataUrl: string) => {
    setSelectedImage(imageDataUrl);
  };

  // Clipboard paste support (e.g. pasting screenshot)
  const handlePaste = async (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.startsWith('image/')) {
        const file = items[i].getAsFile();
        if (file) {
          e.preventDefault();
          setIsProcessingImage(true);
          try {
            const optimized = await optimizeImage(file, 1920, 0.88);
            setSelectedImage(optimized.dataUrl);
          } catch (err) {
            console.error('Failed to process pasted image:', err);
          } finally {
            setIsProcessingImage(false);
          }
          break;
        }
      }
    }
  };

  // Drag and drop image support
  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        setIsProcessingImage(true);
        try {
          const optimized = await optimizeImage(file, 1920, 0.88);
          setSelectedImage(optimized.dataUrl);
        } catch (err) {
          console.error('Failed to process dropped image:', err);
        } finally {
          setIsProcessingImage(false);
        }
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = (text + (interimTranscript ? ` ${interimTranscript}` : '')).trim();

    // Must have either text or an image
    if ((!trimmed && !selectedImage) || isLoading) return;

    // Stop listening before sending
    stopRecognition();

    onSendMessage(trimmed, selectedImage || undefined);
    setText('');
    setSelectedImage(null);
    setInterimTranscript('');
    setMicErrorMessage(null);

    if (textareaRef.current) {
      textareaRef.current.style.height = '48px';
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const canSubmit = (text.trim() || interimTranscript.trim() || selectedImage) && !isLoading;

  return (
    <div
      className="w-full max-w-4xl mx-auto px-4 pb-4 pt-1 sm:px-6"
      onDrop={handleDrop}
      onDragOver={handleDragOver}
    >
      {/* Hidden file input for gallery picker */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleGalleryFileChange}
      />

      {/* Camera Capture Modal */}
      <CameraCaptureModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        onCapture={handlePhotoCaptured}
      />

      {/* Fullscreen Image Preview Zoom Modal */}
      <ImagePreviewModal
        imageUrl={isPreviewModalOpen ? selectedImage : null}
        onClose={() => setIsPreviewModalOpen(false)}
        title="Question Image Preview"
      />

      {/* Error alert banner if microphone or image fails */}
      {micErrorMessage && (
        <div className="mb-2.5 flex items-start justify-between gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs shadow-2xs">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{micErrorMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setMicErrorMessage(null)}
            className="text-rose-500 hover:text-rose-700 p-0.5 rounded-md hover:bg-rose-100/80 transition-colors shrink-0 cursor-pointer"
            aria-label="Dismiss message"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Voice active feedback bar */}
      {isListening && (
        <div className="mb-2 px-3 py-1.5 rounded-xl bg-amber-100/90 border border-amber-300/80 flex items-center justify-between text-xs text-amber-900 shadow-2xs animate-pulse">
          <div className="flex items-center gap-2 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
            <span>Listening in {languagePreference === 'english' ? 'English' : 'Hindi / English'}... बोलिए...</span>
          </div>
          <button
            type="button"
            onClick={stopRecognition}
            className="text-xs font-semibold px-2 py-0.5 rounded-md bg-white text-stone-800 hover:bg-amber-50 border border-amber-300 cursor-pointer"
          >
            Done / पूर्ण
          </button>
        </div>
      )}

      {/* Image Preview Card (Shown before sending) */}
      {selectedImage && (
        <div
          id="image-preview-card"
          className="mb-2.5 p-2.5 rounded-2xl bg-amber-50/90 border border-amber-200/90 shadow-xs flex items-center justify-between gap-3 animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <div className="flex items-center gap-3 min-w-0">
            {/* Thumbnail with click-to-zoom */}
            <div
              onClick={() => setIsPreviewModalOpen(true)}
              className="relative w-14 h-14 rounded-xl overflow-hidden border border-amber-300 bg-stone-900 shrink-0 cursor-zoom-in group shadow-xs"
              title="Click to zoom image"
            >
              <img
                src={selectedImage}
                alt="Question preview"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                <ZoomIn className="w-4 h-4" />
              </div>
            </div>

            {/* Label and tips */}
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-xs font-bold text-stone-900">Photo Attached</span>
                <span className="text-[11px] text-amber-800 font-medium">चित्र संलग्न</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-200/70 text-amber-900 font-semibold uppercase tracking-wider">
                  Question
                </span>
              </div>
              <p className="text-[11px] text-stone-600 truncate mt-0.5">
                Type or speak your question, or click Send for full step-by-step analysis.
              </p>
            </div>
          </div>

          {/* Retake and Remove Buttons */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              id="retake-photo-button"
              type="button"
              onClick={() => setIsCameraModalOpen(true)}
              className="px-2.5 py-1.5 rounded-xl bg-white hover:bg-amber-100/70 text-stone-700 hover:text-stone-900 border border-amber-200 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer"
              title="Retake photo using camera"
            >
              <RotateCcw className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">Retake</span>
            </button>

            <button
              id="remove-photo-button"
              type="button"
              onClick={() => setSelectedImage(null)}
              className="p-1.5 rounded-xl bg-white hover:bg-rose-50 text-stone-500 hover:text-rose-600 border border-amber-200 transition-colors cursor-pointer"
              title="Remove photo"
              aria-label="Remove image"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Input Form */}
      <form
        id="chat-input-form"
        onSubmit={handleSubmit}
        className="relative bg-white rounded-2xl border border-amber-200/90 shadow-sm shadow-amber-900/5 focus-within:border-amber-500 focus-within:ring-2 focus-within:ring-amber-500/20 transition-all p-1.5 sm:p-2 flex items-end gap-1 sm:gap-1.5"
      >
        {/* Camera button: opens device camera live viewfinder */}
        <button
          id="camera-action-button"
          type="button"
          onClick={() => setIsCameraModalOpen(true)}
          disabled={isLoading || isProcessingImage}
          className="p-2 sm:p-2.5 rounded-xl text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 active:scale-95 transition-all shrink-0 cursor-pointer"
          title="Camera: Take a photo of question, diagram, or textbook (कैमरा से फोटो खींचें)"
          aria-label="Scan question with camera"
        >
          <Camera className="w-5 h-5 text-amber-700" />
        </button>

        {/* Gallery upload button */}
        <button
          id="gallery-action-button"
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={isLoading || isProcessingImage}
          className="p-2 sm:p-2.5 rounded-xl text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 active:scale-95 transition-all shrink-0 cursor-pointer"
          title="Gallery: Upload image from device (गैलरी से फोटो चुनें)"
          aria-label="Upload question from gallery"
        >
          {isProcessingImage ? (
            <Loader2 className="w-5 h-5 text-amber-700 animate-spin" />
          ) : (
            <ImageIcon className="w-5 h-5 text-amber-700" />
          )}
        </button>

        {/* Voice dictation microphone button */}
        <button
          id="voice-dictation-button"
          type="button"
          onClick={toggleMic}
          disabled={isLoading}
          className={`p-2 sm:p-2.5 rounded-xl transition-all shrink-0 cursor-pointer ${
            isListening
              ? 'bg-red-500 text-white shadow-xs shadow-red-500/30 animate-pulse'
              : !isSupported
              ? 'text-stone-300 hover:text-stone-400'
              : 'text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 active:scale-95'
          }`}
          title={
            !isSupported
              ? 'Speech recognition not supported in this browser'
              : isListening
              ? 'Listening... Click to stop (सुन रहा है... रोकने के लिए क्लिक करें)'
              : 'Voice Input: Speak in Hindi or English (बोलकर पूछें)'
          }
          aria-label="Toggle voice input"
        >
          {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5 text-stone-600" />}
        </button>

        {/* Textarea */}
        <div className="flex-1 relative flex flex-col justify-center min-w-0">
          <textarea
            id="message-input-box"
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder={
              selectedImage
                ? 'Type or speak a question about this image... (या सीधा Send दबाएं)'
                : isListening
                ? 'Listening... speak now in Hindi or English...'
                : 'Ask Kaju in Hindi or English... (या कैमरा से प्रश्न स्कैन करें)'
            }
            rows={1}
            disabled={isLoading}
            className="w-full max-h-40 py-2.5 px-2 bg-transparent text-stone-900 placeholder:text-stone-500 resize-none outline-none text-[15px] leading-relaxed"
          />

          {/* Interim speech ghost text overlay */}
          {interimTranscript && (
            <div className="px-2 pb-1 text-xs text-amber-700/80 italic select-none">
              &ldquo;{interimTranscript}&rdquo;...
            </div>
          )}
        </div>

        {/* Send Button */}
        <button
          id="send-message-button"
          type="submit"
          disabled={!canSubmit}
          className={`px-3.5 sm:px-4 py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-1.5 shrink-0 transition-all ${
            !canSubmit
              ? 'bg-stone-100 text-stone-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-600 to-orange-600 text-white hover:from-amber-700 hover:to-orange-700 shadow-xs shadow-amber-900/20 active:scale-95 cursor-pointer'
          }`}
          aria-label="Send message"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="hidden sm:inline">Thinking...</span>
            </>
          ) : (
            <>
              <span>Send</span>
              <Send className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Helper footnote */}
      <div className="flex items-center justify-between text-[11px] text-stone-600 px-2 mt-2 gap-2 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-600" />
            Camera, Voice & Text support in Hindi, English & Hinglish
          </span>
          {onOpenVoiceAssistant && (
            <button
              id="chat-input-voice-assistant-link"
              type="button"
              onClick={onOpenVoiceAssistant}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-linear-to-r from-amber-500/10 via-rose-500/10 to-indigo-500/10 text-stone-800 hover:text-amber-900 border border-amber-300/60 text-[10px] font-semibold transition-all hover:scale-102 cursor-pointer"
            >
              <Mic className="w-2.5 h-2.5 text-rose-600" />
              <span>Siri Voice Assistant</span>
            </button>
          )}
        </div>
        <span className="hidden sm:inline text-stone-500">
          Enter to send • Shift+Enter for new line • Paste screenshot directly
        </span>
      </div>
    </div>
  );
};

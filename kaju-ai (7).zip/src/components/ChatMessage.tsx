import React, { useState, useEffect, useMemo } from 'react';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import {
  Copy,
  Check,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Sparkles,
  User,
  AlertCircle,
  RotateCcw,
  Languages,
  Settings2,
  ZoomIn,
  CheckCircle2,
  Loader2,
  Download,
  FileText,
  ExternalLink,
  ArrowRight,
} from 'lucide-react';
import { Message, LanguagePreference, ActionPermissions, DeviceAction } from '../types';
import { KajuLogo } from './KajuLogo';
import { speechManager, SpeechPlaybackState } from '../utils/speech';
import { ActionCard } from './ActionCard';
import { extractActionFromText, DEFAULT_PERMISSIONS } from '../utils/actionHelper';
import { MathErrorBoundary, preprocessMathMarkdown } from '../utils/mathHelper';
import { ImagePreviewModal } from './ImagePreviewModal';
import { KajuBoard } from './KajuBoard';
import { InteractiveGameCard } from './InteractiveGameCard';
import { SkillJourneyCard } from './SkillJourneyCard';
import { ResearchReportCard } from './ResearchReportCard';
import { GeneratedImageCard } from './GeneratedImageCard';
import { GeneratedVideoCard } from './GeneratedVideoCard';

interface ChatMessageProps {
  message: Message;
  isStreaming?: boolean;
  onRetry?: () => void;
  userLanguage?: LanguagePreference;
  permissions?: ActionPermissions;
  onUpdateAction?: (updatedAction: DeviceAction) => void;
  onOpenActionCenter?: (tab?: 'permissions' | 'desktop') => void;
  onAnswerChallenge?: (answerText: string) => void;
  onSelectFollowUp?: (prompt: string) => void;
  hasImage?: boolean;
  onOpenMediaSetup?: () => void;
  onConfirmImage?: (cardId: string) => void;
  onCancelImage?: (cardId: string) => void;
  onConfirmVideo?: (cardId: string) => void;
  onCancelVideo?: (cardId: string) => void;
  onRegenerateImage?: (prompt: string, aspectRatio: any) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  isStreaming = false,
  onRetry,
  userLanguage,
  permissions = DEFAULT_PERMISSIONS,
  onUpdateAction,
  onOpenActionCenter,
  onAnswerChallenge,
  onSelectFollowUp,
  hasImage = false,
  onOpenMediaSetup,
  onConfirmImage,
  onCancelImage,
  onConfirmVideo,
  onCancelVideo,
  onRegenerateImage,
}) => {
  const isUser = message.role === 'user';
  const [copied, setCopied] = useState(false);
  const [speechState, setSpeechState] = useState<SpeechPlaybackState>(speechManager.getState());
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);

  // Extract action if embedded in text or already set on message
  const { cleanText, action: parsedAction } = useMemo(() => {
    return extractActionFromText(message.content);
  }, [message.content]);

  // Extract NEXT_ACTIONS tags
  const { cleanContent, nextActions } = useMemo(() => {
    let text = cleanText;
    let actions: string[] = [];
    const nextActionsMatch = text.match(/<!--NEXT_ACTIONS:\s*(\[[\s\S]*?\])\s*-->/);
    if (nextActionsMatch) {
      try {
        actions = JSON.parse(nextActionsMatch[1]);
        text = text.replace(nextActionsMatch[0], '').trim();
      } catch {}
    }
    return { cleanContent: text, nextActions: actions };
  }, [cleanText]);

  // Preprocess LaTeX math in clean text so KaTeX and remark-math parse it flawlessly
  const formattedContent = useMemo(() => {
    return preprocessMathMarkdown(cleanContent);
  }, [cleanContent]);

  const formattedUserContent = useMemo(() => {
    return preprocessMathMarkdown(message.content);
  }, [message.content]);

  const activeAction = message.action || parsedAction;

  useEffect(() => {
    const unsubscribe = speechManager.subscribe((state) => {
      setSpeechState(state);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const isCurrentMessageSpeaking = speechState.messageId === message.id;
  const isPlaying = isCurrentMessageSpeaking && speechState.status === 'playing';
  const isPaused = isCurrentMessageSpeaking && speechState.status === 'paused';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(cleanText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textArea = document.createElement('textarea');
      textArea.value = cleanText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handlePlayOrResume = () => {
    if (isPaused) {
      speechManager.resume();
    } else {
      speechManager.speak(message.id, cleanText, userLanguage);
    }
  };

  const handlePause = () => {
    speechManager.pause();
  };

  const handleStop = () => {
    speechManager.stop();
  };

  const handleSpeedCycle = () => {
    const speeds = [0.85, 1.0, 1.15, 1.25];
    const current = speechState.settings.rateMultiplier;
    const nextIndex = (speeds.findIndex((s) => Math.abs(s - current) < 0.05) + 1) % speeds.length;
    speechManager.saveSettings({ rateMultiplier: speeds[nextIndex] });
  };

  if (isUser) {
    return (
      <div
        id={`user-message-${message.id}`}
        className="flex justify-end items-end gap-2.5 mb-5 pl-8 sm:pl-16 group"
      >
        <ImagePreviewModal
          imageUrl={isImageModalOpen ? (message.image || null) : null}
          onClose={() => setIsImageModalOpen(false)}
          title="Scanned Question Image"
        />

        <div className="flex flex-col items-end max-w-[85%] sm:max-w-[75%]">
          <div className="flex items-center gap-1.5 mb-1 text-[11px] font-medium text-stone-500">
            <span>You</span>
            <span>•</span>
            <span>{message.timestamp}</span>
          </div>

          <div className="bg-gradient-to-br from-amber-600 to-amber-700 text-white p-3 sm:p-3.5 rounded-2xl rounded-br-sm shadow-xs shadow-amber-900/10 text-[15px] leading-relaxed break-words selection:bg-amber-900 selection:text-white [&_.katex]:text-white [&_.katex-display]:text-white [&_.katex-display]:my-1">
            {/* Attached Document Preview if present */}
            {message.fileAttachment && (
              <div className="mb-2 p-2 rounded-xl bg-black/20 border border-white/20 flex items-center gap-2 text-xs">
                <FileText className="w-4 h-4 text-amber-300 shrink-0" />
                <div className="min-w-0 flex-1">
                  <span className="font-bold truncate block">{message.fileAttachment.name}</span>
                  <span className="text-[10px] opacity-80">{Math.round(message.fileAttachment.size / 1024)} KB • Document</span>
                </div>
              </div>
            )}

            {/* Scanned Image Preview if present */}
            {message.image && (
              <div
                onClick={() => setIsImageModalOpen(true)}
                className="mb-2 relative rounded-xl overflow-hidden border border-white/20 bg-black/25 cursor-zoom-in group/scan max-w-sm shadow-inner"
                title="Click to view full size"
              >
                <img
                  src={message.image}
                  alt="Scanned question"
                  className="w-full max-h-64 object-contain rounded-lg group-hover/scan:scale-[1.02] transition-transform duration-200"
                />
                <div className="absolute inset-0 bg-black/35 opacity-0 group-hover/scan:opacity-100 transition-opacity flex items-center justify-center text-white text-xs gap-1.5 font-medium backdrop-blur-2xs">
                  <ZoomIn className="w-4 h-4 text-amber-300" />
                  <span>View Full Image</span>
                </div>
              </div>
            )}

            {message.content && (
              <MathErrorBoundary fallbackText={message.content}>
                <Markdown
                  remarkPlugins={[remarkMath]}
                  rehypePlugins={[[rehypeKatex, { throwOnError: false, strict: false }]]}
                >
                  {formattedUserContent}
                </Markdown>
              </MathErrorBoundary>
            )}
          </div>
        </div>

        <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 mb-0.5 border border-amber-200">
          <User className="w-4 h-4" />
        </div>
      </div>
    );
  }

  // Kaju AI Message
  return (
    <div
      id={`kaju-message-${message.id}`}
      className="flex justify-start items-start gap-3 mb-6 pr-6 sm:pr-14 group"
    >
      <div className="shrink-0 mt-0.5">
        <KajuLogo size="sm" />
      </div>

      <div className="flex flex-col items-start max-w-[92%] sm:max-w-[82%]">
        {/* Header with name and friendly badge */}
        <div className="flex items-center gap-2 mb-1.5 flex-wrap">
          <span className="font-semibold text-sm text-stone-900 flex items-center gap-1">
            Kaju AI
            <span className="text-xs text-amber-700 font-medium">काजू</span>
          </span>
          <span className="text-[10px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded-full bg-amber-100/80 text-amber-800 border border-amber-200/60 inline-flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5 text-amber-600" />
            AI Assistant
          </span>
          <span className="text-[11px] text-stone-500 font-normal">
            {message.timestamp}
          </span>
        </div>

        {/* Bubble */}
        <div className="w-full bg-white text-stone-800 border border-amber-100/90 rounded-2xl rounded-tl-xs px-4 py-3.5 shadow-xs text-[15px] leading-relaxed relative">
          {message.status === 'error' ? (
            <div className="flex flex-col gap-2.5 text-stone-800 bg-rose-50/80 p-3.5 rounded-xl border border-rose-200/80 text-sm">
              <div className="flex items-start gap-2.5 text-rose-800">
                <AlertCircle className="w-5 h-5 mt-0.5 shrink-0 text-rose-600" />
                <div className="space-y-0.5">
                  <p className="font-bold text-rose-900 text-sm">
                    {hasImage ? "Couldn't analyze the photo." : 'क्षमा करें, संदेश प्राप्त नहीं हो सका / Could not get response'}
                  </p>
                  <p className="text-xs text-stone-700 leading-relaxed">
                    {message.content && !message.content.includes("Couldn't analyze")
                      ? message.content
                      : hasImage
                      ? 'फ़ोटो का विश्लेषण नहीं हो सका। कृपया नीचे दिए गए बटन से पुनः प्रयास करें।'
                      : 'Please check your connection and try again.'}
                  </p>
                </div>
              </div>

              {onRetry && (
                <div className="pt-2 border-t border-rose-200/60 flex items-center gap-2.5 flex-wrap">
                  <button
                    type="button"
                    onClick={onRetry}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs hover:shadow transition-all cursor-pointer active:scale-95"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Retry</span>
                  </button>
                  {hasImage && (
                    <span className="text-[11px] text-stone-500 font-medium">
                      You don't need to take the photo again.
                    </span>
                  )}
                </div>
              )}
            </div>
          ) : message.status === 'sending' || (!cleanText && isStreaming) ? (
            /* Immediate visual feedback while waiting for first tokens - never a blank screen */
            <div className="flex flex-col gap-2.5 py-1 animate-in fade-in duration-200">
              {hasImage ? (
                <>
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1.5 rounded-xl border border-emerald-200/80 w-fit">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Photo captured ✓</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-stone-700 font-medium">
                    <Loader2 className="w-4 h-4 text-amber-600 animate-spin shrink-0" />
                    <span>Analyzing image...</span>
                    <span className="text-xs text-stone-400 font-normal hidden sm:inline">
                      (काजू फोटो समझ रहा है)
                    </span>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2 text-sm text-stone-600">
                  <Loader2 className="w-4 h-4 text-amber-600 animate-spin shrink-0" />
                  <span>काजू सोच रहा है… / Kaju is thinking…</span>
                </div>
              )}
            </div>
          ) : (
            <div className="w-full text-stone-800">
              <MathErrorBoundary fallbackText={cleanContent}>
                <KajuBoard
                  content={cleanContent}
                  onAnswerChallenge={onAnswerChallenge}
                />
              </MathErrorBoundary>

              {/* Citations if available */}
              {message.citations && message.citations.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-stone-100 space-y-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 flex items-center gap-1.5">
                    <ExternalLink className="w-3.5 h-3.5 text-amber-600" />
                    <span>Verified Web Sources & Citations</span>
                  </span>
                  <div className="flex flex-col gap-1">
                    {message.citations.map((cite, idx) => (
                      <a
                        key={idx}
                        href={cite.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-amber-800 hover:text-amber-950 hover:underline flex items-center gap-1.5 truncate"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                        <span className="truncate">{cite.title || cite.url}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}

              {/* Next Best Action Follow-Up Chips */}
              {nextActions.length > 0 && !isStreaming && (
                <div className="mt-3 pt-2.5 border-t border-amber-100 flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400 shrink-0 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-600" />
                    <span>Next:</span>
                  </span>
                  {nextActions.map((actionText, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => onSelectFollowUp?.(actionText)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200/90 text-xs font-semibold shadow-2xs transition-all cursor-pointer active:scale-95 group"
                    >
                      <span>{actionText}</span>
                      <ArrowRight className="w-3 h-3 text-amber-600 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Interactive Game Board/Card if game is active or completed */}
          {message.gameCard && (
            <InteractiveGameCard
              game={message.gameCard}
              onSendMove={(move) => onSelectFollowUp?.(move)}
              onExitGame={() => onSelectFollowUp?.('Exit game')}
            />
          )}

          {/* Skill Mastery Journey Card if active */}
          {message.skillCard && (
            <SkillJourneyCard
              journey={message.skillCard}
              onSendAction={(act) => onSelectFollowUp?.(act)}
            />
          )}

          {/* Verified Multi-Source Research Report Card */}
          {message.researchReport && (
            <ResearchReportCard report={message.researchReport} />
          )}

          {/* AI Generated Image Card */}
          {message.generatedImage && (
            <GeneratedImageCard
              card={message.generatedImage}
              onConfirmGeneration={onConfirmImage}
              onCancelGeneration={onCancelImage}
              onOpenSetupModal={onOpenMediaSetup}
              onRegenerate={onRegenerateImage}
            />
          )}

          {/* AI Generated Video Card (Google DeepMind Veo 3.1) */}
          {message.generatedVideo && (
            <GeneratedVideoCard
              card={message.generatedVideo}
              onConfirmGeneration={onConfirmVideo}
              onCancelGeneration={onCancelVideo}
              onOpenSetupModal={onOpenMediaSetup}
            />
          )}

          {/* Inline Action Card for consequential actions requiring confirmation (WhatsApp, call, desktop control) */}
          {activeAction && (activeAction.type !== 'launch_app' || activeAction.payload.launch_app?.requiresConfirmation === true) && (
            <ActionCard
              action={activeAction}
              permissions={permissions}
              onUpdateAction={onUpdateAction}
              onOpenActionCenter={onOpenActionCenter}
            />
          )}

          {isStreaming && (
            <span className="inline-block w-2 h-4 ml-1 bg-amber-600 animate-pulse align-middle" />
          )}
        </div>

        {/* Action buttons (Copy, Download, Read Aloud with Play/Pause/Resume/Stop) */}
        {message.status !== 'error' && (
          <div className="flex items-center gap-1.5 mt-2 ml-1 text-stone-600 text-xs flex-wrap">
            <button
              id={`copy-btn-${message.id}`}
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-amber-100/70 active:bg-amber-200/80 transition-colors text-stone-600 hover:text-stone-800 font-medium cursor-pointer"
              title="Copy answer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                const blob = new Blob([cleanContent], { type: 'text/markdown;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `kaju_response_${Date.now()}.md`;
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-amber-100/70 active:bg-amber-200/80 transition-colors text-stone-600 hover:text-stone-800 font-medium cursor-pointer"
              title="Export as Markdown file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export</span>
            </button>

            {speechManager.isSupported() ? (
              <div className="inline-flex items-center gap-1 bg-amber-50/70 border border-amber-200/80 rounded-lg p-0.5 shadow-2xs">
                {/* Play / Pause / Resume button */}
                <button
                  id={`speak-play-btn-${message.id}`}
                  type="button"
                  onClick={isPlaying ? handlePause : handlePlayOrResume}
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-medium text-xs transition-colors cursor-pointer ${
                    isPlaying
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : isPaused
                      ? 'bg-amber-200 text-amber-950 hover:bg-amber-300 font-semibold'
                      : 'hover:bg-amber-100 text-amber-900'
                  }`}
                  title={
                    isPlaying
                      ? 'Pause speech / रोकें'
                      : isPaused
                      ? 'Resume speech / जारी रखें'
                      : 'Listen in Hindi/English / सुनें'
                  }
                  aria-label={isPlaying ? 'Pause speech' : isPaused ? 'Resume speech' : 'Listen'}
                >
                  {isPlaying ? (
                    <>
                      <Pause className="w-3.5 h-3.5 fill-current" />
                      <span>Pause</span>
                    </>
                  ) : isPaused ? (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Resume</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Listen</span>
                    </>
                  )}
                </button>

                {/* Stop button (visible while playing or paused for this message) */}
                {isCurrentMessageSpeaking && (
                  <button
                    id={`speak-stop-btn-${message.id}`}
                    type="button"
                    onClick={handleStop}
                    className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md hover:bg-rose-100 text-rose-700 transition-colors cursor-pointer"
                    title="Stop playback / बंद करें"
                    aria-label="Stop speech playback"
                  >
                    <VolumeX className="w-3.5 h-3.5" />
                    <span className="text-[11px]">Stop</span>
                  </button>
                )}

                {/* Status indicator badge */}
                {isCurrentMessageSpeaking && (
                  <span className="text-[10px] font-medium text-amber-800 px-1.5 flex items-center gap-1">
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        isPlaying ? 'bg-amber-600 animate-ping' : 'bg-amber-400'
                      }`}
                    />
                    <span>
                      {speechState.language === 'hi'
                        ? 'हिन्दी'
                        : speechState.language === 'mixed'
                        ? 'Hinglish'
                        : 'English'}
                      {speechState.totalChunks > 1 &&
                        ` (${speechState.currentChunkIndex + 1}/${speechState.totalChunks})`}
                    </span>
                  </span>
                )}

                {/* Speed toggle control */}
                <button
                  id={`voice-speed-btn-${message.id}`}
                  type="button"
                  onClick={handleSpeedCycle}
                  className="px-1.5 py-0.5 rounded text-[10px] font-semibold text-amber-800 hover:bg-amber-200/70 transition-colors cursor-pointer"
                  title="Speaking speed / बोलने की गति"
                  aria-label="Toggle speaking speed"
                >
                  {speechState.settings.rateMultiplier}x
                </button>
              </div>
            ) : (
              <span
                className="text-[11px] text-stone-400 italic px-1"
                title="Speech synthesis not supported in this browser"
              >
                TTS unsupported
              </span>
            )}

            {/* If there's an error playing speech on this message */}
            {isCurrentMessageSpeaking && speechState.errorMessage && (
              <span className="text-[11px] text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                {speechState.errorMessage}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

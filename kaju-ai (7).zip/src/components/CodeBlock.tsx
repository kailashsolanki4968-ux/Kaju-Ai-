import React, { useState } from 'react';
import { Copy, Check, Terminal, Play, Eye, Code as CodeIcon } from 'lucide-react';

interface CodeBlockProps {
  language?: string;
  value: string;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ language = 'text', value }) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'code' | 'preview'>('code');

  const normalizedLang = (language || 'code').toLowerCase().trim();
  const isWebSnippet =
    normalizedLang === 'html' ||
    normalizedLang === 'svg' ||
    (normalizedLang === 'javascript' && value.includes('document.'));

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = value;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const lines = value.split('\n');

  return (
    <div className="my-3 rounded-2xl overflow-hidden border border-stone-800 bg-stone-950 text-stone-100 shadow-md">
      {/* Code Block Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-stone-900 border-b border-stone-800 text-xs select-none">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-stone-800 text-stone-300 font-mono font-semibold uppercase tracking-wider text-[10px]">
            <CodeIcon className="w-3 h-3 text-amber-400" />
            <span>{normalizedLang}</span>
          </div>
          <span className="text-stone-500 font-mono text-[11px] hidden sm:inline">
            {lines.length} {lines.length === 1 ? 'line' : 'lines'}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {isWebSnippet && (
            <div className="inline-flex rounded-lg bg-stone-800 p-0.5 border border-stone-700">
              <button
                type="button"
                onClick={() => setActiveTab('code')}
                className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                  activeTab === 'code' ? 'bg-amber-600 text-white shadow-2xs' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                Code
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  activeTab === 'preview' ? 'bg-amber-600 text-white shadow-2xs' : 'text-stone-400 hover:text-stone-200'
                }`}
              >
                <Eye className="w-2.5 h-2.5" />
                <span>Preview</span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={handleCopy}
            className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-[11px] font-semibold transition-all cursor-pointer active:scale-95 border border-stone-700"
            title="Copy code to clipboard"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-stone-400" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Code Body / Preview */}
      {activeTab === 'code' ? (
        <div className="p-3.5 overflow-x-auto text-xs sm:text-sm font-mono leading-relaxed selection:bg-amber-800 selection:text-white">
          <pre className="m-0 p-0 bg-transparent text-stone-100 font-mono">
            <code>
              {lines.map((line, idx) => (
                <div key={idx} className="table-row">
                  <span className="table-cell pr-3 select-none text-stone-600 text-right text-[11px] w-6">
                    {idx + 1}
                  </span>
                  <span className="table-cell">{line || ' '}</span>
                </div>
              ))}
            </code>
          </pre>
        </div>
      ) : (
        <div className="p-3 bg-white text-stone-900 min-h-[140px] flex items-center justify-center">
          <iframe
            srcDoc={value}
            sandbox="allow-scripts"
            title="Code Preview"
            className="w-full h-56 border-0 rounded-lg bg-white"
          />
        </div>
      )}
    </div>
  );
};

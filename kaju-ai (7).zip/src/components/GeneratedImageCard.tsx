import React, { useState } from 'react';
import {
  Download,
  Copy,
  Check,
  Maximize2,
  Sparkles,
  AlertTriangle,
  Info,
  ExternalLink,
  RefreshCw,
  Image as ImageIcon,
} from 'lucide-react';
import { GeneratedImageCard as GeneratedImageType } from '../types';

interface GeneratedImageCardProps {
  card: GeneratedImageType;
  onConfirmGeneration?: (cardId: string) => void;
  onCancelGeneration?: (cardId: string) => void;
  onOpenSetupModal?: () => void;
  onRegenerate?: (prompt: string, aspectRatio: any) => void;
}

export const GeneratedImageCard: React.FC<GeneratedImageCardProps> = ({
  card,
  onConfirmGeneration,
  onCancelGeneration,
  onOpenSetupModal,
  onRegenerate,
}) => {
  const [isCopied, setIsCopied] = useState(false);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [showPromptDetails, setShowPromptDetails] = useState(false);

  const handleDownload = () => {
    if (!card.imageUrl) return;
    const link = document.createElement('a');
    link.href = card.imageUrl;
    link.download = `kaju_ai_image_${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopy = async () => {
    if (!card.imageUrl) return;
    try {
      await navigator.clipboard.writeText(card.imageUrl);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2000);
    } catch {}
  };

  // 0. PENDING CONFIRMATION STATE (Clear Paid Model Disclosure & No Automatic Charges)
  if (card.status === 'pending_confirmation') {
    return (
      <div className="my-3 rounded-2xl border-2 border-amber-400 bg-linear-to-br from-amber-50/95 via-orange-50/70 to-amber-100/50 p-4 shadow-sm text-stone-800 space-y-3">
        <div className="flex items-start gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-2xs mt-0.5">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between flex-wrap gap-1">
              <h4 className="text-xs font-extrabold text-amber-950 flex items-center gap-1.5">
                <span>Google AI Studio Image Generation</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 border border-amber-300">
                  Paid Model Flow
                </span>
              </h4>
              <span className="text-[10px] font-semibold text-stone-500">
                Aspect Ratio: {card.aspectRatio || '1:1'}
              </span>
            </div>
            <p className="text-xs text-stone-700 mt-1 leading-relaxed">
              Google AI Studio image generation (<code>gemini-3.1-flash-lite-image</code>) requires Pay-As-You-Go billing. Free tier API keys have a 0-quota limit. Kaju will not make paid API requests without your confirmation.
            </p>
          </div>
        </div>

        {/* Prompt details box */}
        <div className="p-3 rounded-xl bg-white/95 border border-amber-200 text-xs space-y-2">
          <div className="flex items-center justify-between text-[11px] text-stone-500">
            <span className="font-semibold text-stone-700">Requested Scene:</span>
            <div className="flex items-center gap-1 font-mono text-[10px]">
              <span className="bg-amber-50 text-amber-900 px-1.5 py-0.5 rounded border border-amber-200">
                {card.aspectRatio || '1:1'}
              </span>
              {card.style && (
                <span className="bg-amber-50 text-amber-900 px-1.5 py-0.5 rounded border border-amber-200">
                  {card.style}
                </span>
              )}
            </div>
          </div>
          <p className="text-stone-900 font-medium italic">&ldquo;{card.prompt}&rdquo;</p>
          <div className="pt-1.5 border-t border-amber-100 flex items-center justify-between text-[11px]">
            <span className="text-stone-500">Estimated Cost:</span>
            <span className="font-bold text-amber-950">
              {card.costEstimate || '~$0.03 / image (Pay-As-You-Go)'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-1 flex-wrap">
          {onConfirmGeneration && (
            <button
              type="button"
              onClick={() => onConfirmGeneration(card.id)}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5 fill-current" />
              <span>Confirm & Generate Image / इमेज बनाएं</span>
            </button>
          )}

          {onCancelGeneration && (
            <button
              type="button"
              onClick={() => onCancelGeneration(card.id)}
              className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              Cancel / रद्द
            </button>
          )}

          {onOpenSetupModal && (
            <button
              type="button"
              onClick={onOpenSetupModal}
              className="px-2.5 py-2 text-stone-500 hover:text-amber-800 text-xs font-medium ml-auto flex items-center gap-1 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5" />
              <span>Free vs Paid Setup</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // 1. GENERATING / LOADING STATE
  if (card.status === 'generating') {
    return (
      <div className="my-3 rounded-2xl border-2 border-amber-300/80 bg-linear-to-br from-amber-50 via-orange-50/50 to-amber-100/30 p-4 shadow-sm animate-pulse">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 flex items-center justify-center text-amber-700">
            <Sparkles className="w-4 h-4 animate-spin" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
              <span>Generating Real AI Image…</span>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-200/80 text-amber-900">
                {card.aspectRatio}
              </span>
            </h4>
            <p className="text-[11px] text-amber-800/80 font-medium truncate max-w-sm">
              &ldquo;{card.prompt}&rdquo;
            </p>
          </div>
        </div>

        {/* Shimmering placeholder canvas */}
        <div className="w-full h-56 rounded-xl bg-linear-to-r from-amber-100 via-orange-100 to-amber-200/70 flex flex-col items-center justify-center gap-2 text-stone-500 border border-amber-200/80">
          <ImageIcon className="w-8 h-8 text-amber-600/60 animate-bounce" />
          <span className="text-xs font-semibold text-amber-900">
            Kaju AI Image Engine is rendering pixels…
          </span>
          <span className="text-[10px] text-amber-800/80">
            Model: {card.model || 'gemini-3.1-flash-lite-image'}
          </span>
        </div>
      </div>
    );
  }

  // 2. QUOTA RESTRICTED / PAID TIER REQUIRED STATE
  if (card.status === 'quota_restricted') {
    return (
      <div className="my-3 rounded-2xl border-2 border-orange-300 bg-orange-50/90 p-4 shadow-sm text-stone-800 space-y-3">
        <div className="flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-orange-200 text-orange-900 flex items-center justify-center shrink-0 mt-0.5">
            <AlertTriangle className="w-4 h-4 text-orange-700" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between flex-wrap gap-1">
              <h4 className="text-xs font-extrabold text-orange-950">
                Paid API Key / Quota Required (HTTP 429)
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-orange-200 text-orange-900">
                Google AI Studio Policy
              </span>
            </div>
            <p className="text-xs text-stone-700 mt-1 leading-relaxed">
              {card.error ||
                'Google AI Studio Image Generation requires a billing-enabled account (Pay-As-You-Go). Free-tier API keys have a 0-quota limit on image generation models.'}
            </p>
            {card.errorDetails?.hindiMessage && (
              <p className="text-xs text-orange-900 font-medium mt-1 leading-relaxed">
                {card.errorDetails.hindiMessage}
              </p>
            )}
          </div>
        </div>

        {/* Prompt information & Pricing */}
        <div className="p-2.5 rounded-xl bg-white/80 border border-orange-200 text-[11px] space-y-1.5">
          <div className="flex justify-between items-center text-stone-600">
            <span className="font-semibold">Requested Prompt:</span>
            <span className="font-mono text-[10px] bg-orange-100 px-1.5 py-0.5 rounded">
              {card.aspectRatio}
            </span>
          </div>
          <p className="text-stone-800 italic">&ldquo;{card.prompt}&rdquo;</p>
          <div className="pt-1 border-t border-orange-100 flex items-center justify-between text-[10px] text-stone-600">
            <span>Model: {card.model}</span>
            <span className="font-bold text-orange-800">Cost: ~$0.03 / image</span>
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center gap-2 pt-1">
          {onOpenSetupModal && (
            <button
              type="button"
              onClick={onOpenSetupModal}
              className="px-3 py-1.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5" />
              <span>View Setup Guide & Billing Details</span>
            </button>
          )}
          <a
            href="https://ai.google.dev/pricing"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 border border-orange-300 text-stone-700 text-xs font-semibold transition-all flex items-center gap-1.5"
          >
            <ExternalLink className="w-3.5 h-3.5 text-stone-500" />
            <span>Google AI Pricing</span>
          </a>
        </div>
      </div>
    );
  }

  // 3. GENERIC ERROR STATE
  if (card.status === 'error' || !card.imageUrl) {
    return (
      <div className="my-3 rounded-2xl border border-rose-300 bg-rose-50 p-4 text-xs text-rose-900 space-y-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <h4 className="font-bold text-rose-950">Image Generation Failed</h4>
        </div>
        <p className="text-rose-800">{card.error || 'Could not generate image. Please try again.'}</p>
        <div className="flex items-center gap-2 pt-1">
          {onRegenerate && (
            <button
              type="button"
              onClick={() => onRegenerate(card.prompt, card.aspectRatio)}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Generation</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // 4. COMPLETED SUCCESS STATE
  return (
    <>
      <div className="my-3 rounded-2xl border-2 border-amber-300 bg-white shadow-md overflow-hidden transition-all hover:shadow-lg">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-3.5 py-2.5 bg-linear-to-r from-amber-50 to-orange-50 border-b border-amber-200/80">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-6 h-6 rounded-lg bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div className="truncate">
              <span className="text-xs font-extrabold text-stone-900 block truncate">
                AI Generated Image
              </span>
              <span className="text-[10px] text-stone-500 font-medium">
                Model: {card.model || 'gemini-3.1-flash-lite-image'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
              {card.aspectRatio}
            </span>
          </div>
        </div>

        {/* Real Generated Image Display */}
        <div className="relative group bg-stone-950 flex items-center justify-center overflow-hidden max-h-[460px]">
          <img
            src={card.imageUrl}
            alt={card.prompt}
            referrerPolicy="no-referrer"
            className="w-full h-auto object-contain max-h-[460px] cursor-pointer transition-transform duration-300 group-hover:scale-[1.01]"
            onClick={() => setIsLightboxOpen(true)}
          />

          {/* Quick Overlay Zoom Button */}
          <button
            type="button"
            onClick={() => setIsLightboxOpen(true)}
            className="absolute bottom-3 right-3 p-2 rounded-xl bg-black/60 hover:bg-black/80 text-white backdrop-blur-xs opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer shadow-md"
            title="View Full Resolution"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
        </div>

        {/* Prompt Caption & Actions Footer */}
        <div className="p-3 bg-stone-50/80 border-t border-stone-200/80 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <p className="text-xs text-stone-800 font-medium leading-relaxed">
              &ldquo;{card.prompt}&rdquo;
            </p>
          </div>

          {card.englishPrompt && card.englishPrompt !== card.prompt && (
            <div className="text-[11px] text-stone-500 bg-white p-2 rounded-lg border border-stone-200/80">
              <span className="font-semibold text-stone-700">Refined Prompt: </span>
              <span className="italic">{card.englishPrompt}</span>
            </div>
          )}

          {/* Action Toolbar */}
          <div className="flex items-center justify-between pt-1 border-t border-stone-200/60 flex-wrap gap-2">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleDownload}
                className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                title="Download PNG image"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download</span>
              </button>

              <button
                type="button"
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Copy base64 image data"
              >
                {isCopied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-700">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {onRegenerate && (
              <button
                type="button"
                onClick={() => onRegenerate(card.prompt, card.aspectRatio)}
                className="px-2.5 py-1.5 rounded-xl text-stone-600 hover:text-amber-800 hover:bg-amber-50 text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer"
                title="Regenerate with same prompt"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Regenerate</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Full-Screen Lightbox Modal */}
      {isLightboxOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => setIsLightboxOpen(false)}
        >
          <div
            className="relative max-w-4xl max-h-[90vh] bg-stone-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col border border-stone-700"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 bg-stone-950/80 text-white border-b border-stone-800">
              <span className="text-xs font-bold truncate max-w-md">
                {card.prompt}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleDownload}
                  className="px-3 py-1 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsLightboxOpen(false)}
                  className="p-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white cursor-pointer"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto flex items-center justify-center p-2 bg-stone-950">
              <img
                src={card.imageUrl}
                alt={card.prompt}
                referrerPolicy="no-referrer"
                className="max-h-[75vh] w-auto object-contain rounded-xl"
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
};

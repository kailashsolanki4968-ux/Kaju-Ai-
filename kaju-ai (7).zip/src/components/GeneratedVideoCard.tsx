import React, { useState, useEffect } from 'react';
import {
  Video,
  Play,
  Download,
  AlertTriangle,
  Info,
  ExternalLink,
  RefreshCw,
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldAlert,
} from 'lucide-react';
import { GeneratedVideoCard as GeneratedVideoType } from '../types';

interface GeneratedVideoCardProps {
  card: GeneratedVideoType;
  onConfirmGeneration?: (cardId: string) => void;
  onCancelGeneration?: (cardId: string) => void;
  onOpenSetupModal?: () => void;
  onPollStatus?: (operationName: string) => Promise<{ done: boolean; error?: string }>;
}

export const GeneratedVideoCard: React.FC<GeneratedVideoCardProps> = ({
  card,
  onConfirmGeneration,
  onCancelGeneration,
  onOpenSetupModal,
}) => {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    if (!card.operationName) return;
    try {
      setIsDownloading(true);
      const res = await fetch('/api/video/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operationName: card.operationName }),
      });

      if (!res.ok) {
        throw new Error('Video download not ready or failed');
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kaju_veo_video_${Date.now()}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      alert(`Download error: ${err.message || 'Please try again'}`);
    } finally {
      setIsDownloading(false);
    }
  };

  // 1. PENDING CONFIRMATION STATE (Transparent Cost & Intent Check)
  if (card.status === 'pending_confirmation') {
    return (
      <div className="my-3 rounded-2xl border-2 border-indigo-300 bg-linear-to-br from-indigo-50/90 via-purple-50/60 to-amber-50/50 p-4 shadow-sm text-stone-800 space-y-3">
        <div className="flex items-start gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-2xs mt-0.5">
            <Video className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between flex-wrap gap-1">
              <h4 className="text-xs font-extrabold text-indigo-950 flex items-center gap-1.5">
                <span>Google Veo 3.1 Video Generation</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-200 text-indigo-900">
                  Paid Model Flow
                </span>
              </h4>
              <span className="text-[10px] font-semibold text-stone-500">
                Resolution: {card.resolution || '720p'}
              </span>
            </div>
            <p className="text-xs text-stone-700 mt-1 leading-relaxed">
              Video generation runs on <strong>Google DeepMind Veo 3.1</strong>. Real video generation takes 1–3 minutes of compute time and applies Pay-As-You-Go billing.
            </p>
          </div>
        </div>

        {/* Prompt details box */}
        <div className="p-3 rounded-xl bg-white/90 border border-indigo-200 text-xs space-y-2">
          <div className="flex items-center justify-between text-[11px] text-stone-500">
            <span className="font-semibold text-stone-700">Requested Scene:</span>
            <div className="flex items-center gap-1 font-mono text-[10px]">
              <span className="bg-indigo-50 text-indigo-800 px-1.5 py-0.5 rounded border border-indigo-200">
                {card.aspectRatio || '16:9'}
              </span>
              <span className="bg-indigo-50 text-indigo-800 px-1.5 py-0.5 rounded border border-indigo-200">
                {card.resolution || '720p'}
              </span>
            </div>
          </div>
          <p className="text-stone-900 font-medium italic">&ldquo;{card.prompt}&rdquo;</p>
          <div className="pt-1.5 border-t border-indigo-100 flex items-center justify-between text-[11px]">
            <span className="text-stone-500">Estimated Cost:</span>
            <span className="font-bold text-indigo-900">
              {card.costEstimate || '~$0.075 / sec (720p)'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 pt-1 flex-wrap">
          {onConfirmGeneration && (
            <button
              type="button"
              onClick={() => onConfirmGeneration(card.id)}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Confirm & Generate Video / वीडियो बनाएं</span>
            </button>
          )}

          {onCancelGeneration && (
            <button
              type="button"
              onClick={() => onCancelGeneration(card.id)}
              className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition-colors cursor-pointer"
            >
              Cancel / रद्द
            </button>
          )}

          {onOpenSetupModal && (
            <button
              type="button"
              onClick={onOpenSetupModal}
              className="px-2.5 py-2 text-stone-500 hover:text-indigo-800 text-xs font-medium ml-auto flex items-center gap-1 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5" />
              <span>Billing Info</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // 2. SUBMITTING & PROCESSING STATE
  if (card.status === 'submitting' || card.status === 'processing') {
    return (
      <div className="my-3 rounded-2xl border-2 border-indigo-300/80 bg-linear-to-br from-indigo-50 via-purple-50/50 to-indigo-100/30 p-4 shadow-sm space-y-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0">
            <Loader2 className="w-4 h-4 animate-spin" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-extrabold text-indigo-950 flex items-center gap-1.5">
              <span>Generating Video with Veo 3.1…</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-200 text-indigo-900">
                In Progress
              </span>
            </h4>
            <p className="text-[11px] text-indigo-800/80 font-medium truncate">
              &ldquo;{card.prompt}&rdquo;
            </p>
          </div>
        </div>

        {/* Animated Progress Bar */}
        <div className="space-y-1.5 bg-white/80 p-3 rounded-xl border border-indigo-200">
          <div className="flex justify-between items-center text-[11px] text-stone-600">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-indigo-600 animate-spin" />
              <span>Synthesizing frames via DeepMind Video Pipeline…</span>
            </span>
            <span className="font-mono font-bold text-indigo-900">
              {card.progress ? `${card.progress}%` : 'Working…'}
            </span>
          </div>

          <div className="w-full h-2 rounded-full bg-indigo-100 overflow-hidden">
            <div
              className="h-full bg-linear-to-r from-indigo-500 via-purple-500 to-indigo-600 transition-all duration-500 rounded-full animate-pulse"
              style={{ width: `${Math.max(card.progress || 35, 20)}%` }}
            />
          </div>

          <p className="text-[10px] text-stone-500 pt-1">
            Note: Veo 3.1 produces high-fidelity temporal consistency. This typically takes 1–3 minutes.
          </p>
        </div>
      </div>
    );
  }

  // 3. QUOTA RESTRICTED / BILLING REQUIRED STATE
  if (card.status === 'quota_restricted') {
    return (
      <div className="my-3 rounded-2xl border-2 border-purple-300 bg-purple-50/90 p-4 shadow-sm text-stone-800 space-y-3">
        <div className="flex items-start gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-purple-200 text-purple-900 flex items-center justify-center shrink-0 mt-0.5">
            <ShieldAlert className="w-4 h-4 text-purple-700" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between flex-wrap gap-1">
              <h4 className="text-xs font-extrabold text-purple-950">
                Veo 3.1 Video Engine Requires Active Billing (HTTP 429)
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-200 text-purple-900">
                Paid Model
              </span>
            </div>
            <p className="text-xs text-stone-700 mt-1 leading-relaxed">
              {card.error ||
                'Google DeepMind Veo 3.1 Video Generation requires an active Google Cloud Billing account on your API key.'}
            </p>
            {card.errorDetails?.hindiMessage && (
              <p className="text-xs text-purple-950 font-medium mt-1 leading-relaxed">
                {card.errorDetails.hindiMessage}
              </p>
            )}
          </div>
        </div>

        {/* Pricing disclosure & specifications */}
        <div className="p-2.5 rounded-xl bg-white/80 border border-purple-200 text-[11px] space-y-1.5">
          <div className="flex justify-between items-center text-stone-600">
            <span className="font-semibold">Veo 3.1 Model Specs:</span>
            <span className="font-mono text-[10px] bg-purple-100 text-purple-900 px-1.5 py-0.5 rounded">
              720p / 1080p
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[10px] text-stone-600 pt-1">
            <div>• Provider: Google DeepMind</div>
            <div>• Pricing: ~$0.075 - $0.15 / sec</div>
            <div>• Aspect Ratios: 16:9, 9:16</div>
            <div>• Duration: 5 - 10s clips</div>
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center gap-2 pt-1">
          {onOpenSetupModal && (
            <button
              type="button"
              onClick={onOpenSetupModal}
              className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5" />
              <span>View Veo Setup Guide & Requirements</span>
            </button>
          )}
          <a
            href="https://ai.google.dev/pricing"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 border border-purple-300 text-stone-700 text-xs font-semibold transition-all flex items-center gap-1.5"
          >
            <ExternalLink className="w-3.5 h-3.5 text-stone-500" />
            <span>Google AI Pricing</span>
          </a>
        </div>
      </div>
    );
  }

  // 4. GENERIC ERROR STATE
  if (card.status === 'error') {
    return (
      <div className="my-3 rounded-2xl border border-rose-300 bg-rose-50 p-4 text-xs text-rose-900 space-y-2">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <h4 className="font-bold text-rose-950">Video Generation Error</h4>
        </div>
        <p className="text-rose-800">{card.error || 'Video generation failed. Please try again.'}</p>
        <div className="flex items-center gap-2 pt-1">
          {onConfirmGeneration && (
            <button
              type="button"
              onClick={() => onConfirmGeneration(card.id)}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  // 5. COMPLETED SUCCESS STATE
  return (
    <div className="my-3 rounded-2xl border-2 border-indigo-300 bg-white shadow-md overflow-hidden transition-all hover:shadow-lg">
      {/* Header Bar */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-linear-to-r from-indigo-50 to-purple-50 border-b border-indigo-200">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-2xs">
            <Video className="w-3.5 h-3.5" />
          </div>
          <div className="truncate">
            <span className="text-xs font-extrabold text-stone-900 block truncate">
              Veo 3.1 AI Generated Video
            </span>
            <span className="text-[10px] text-stone-500 font-medium">
              Google DeepMind Veo 3.1 • {card.resolution || '720p'}
            </span>
          </div>
        </div>

        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
          <CheckCircle2 className="w-3 h-3" />
          <span>Ready</span>
        </span>
      </div>

      {/* Video Player */}
      <div className="bg-stone-950 flex items-center justify-center">
        {card.videoUrl ? (
          <video
            src={card.videoUrl}
            controls
            playsInline
            className="w-full max-h-[460px] object-contain"
          />
        ) : (
          <div className="p-8 text-center text-stone-400 space-y-2">
            <Video className="w-10 h-10 mx-auto text-indigo-400" />
            <p className="text-xs">Video ready to stream or download.</p>
          </div>
        )}
      </div>

      {/* Prompt & Action Bar */}
      <div className="p-3 bg-stone-50/80 border-t border-stone-200/80 space-y-2">
        <p className="text-xs text-stone-800 font-medium leading-relaxed">
          &ldquo;{card.prompt}&rdquo;
        </p>

        <div className="flex items-center justify-between pt-1 border-t border-stone-200/60">
          <button
            type="button"
            onClick={handleDownload}
            disabled={isDownloading}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            {isDownloading ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5" />
            )}
            <span>Download MP4</span>
          </button>
        </div>
      </div>
    </div>
  );
};

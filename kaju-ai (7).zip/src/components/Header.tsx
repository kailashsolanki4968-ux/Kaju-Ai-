import React, { useState } from 'react';
import { Trash2, Globe, PanelLeft, Plus, Zap, Mic, Sparkles, Home, MessageSquare, Camera, User, ChevronDown } from 'lucide-react';
import { KajuLogo } from './KajuLogo';
import { LanguagePreference, NavigationTab } from '../types';
import { LanguageSelectorModal } from './LanguageSelectorModal';
import { getLanguageInfo } from '../utils/languages';

interface HeaderProps {
  language: LanguagePreference;
  onLanguageChange: (lang: LanguagePreference) => void;
  onClearChat: () => void;
  messageCount: number;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  activeChatTitle?: string;
  onNewChat: () => void;
  onOpenActionCenter: () => void;
  onOpenVoiceAssistant: () => void;
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onLanguageChange,
  onClearChat,
  messageCount,
  onToggleSidebar,
  isSidebarOpen,
  activeChatTitle,
  onNewChat,
  onOpenActionCenter,
  onOpenVoiceAssistant,
  activeTab,
  onTabChange,
}) => {
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const langInfo = getLanguageInfo(language);
  const navTabs: { id: NavigationTab; label: string; icon: any; badge?: string }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'chats', label: 'Chats', icon: MessageSquare, badge: messageCount > 0 ? String(messageCount) : undefined },
    { id: 'actions', label: 'Actions', icon: Zap, badge: 'Safe' },
    { id: 'vision', label: 'Vision', icon: Camera },
    { id: 'kaju', label: 'Kaju', icon: User },
  ];

  return (
    <header
      id="kaju-header"
      className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-amber-200/60 px-3 py-2.5 sm:px-6 shadow-xs"
    >
      <div className="w-full flex items-center justify-between gap-2 sm:gap-3">
        {/* Left: Sidebar toggle, Logo & Active chat title */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            id="toggle-sidebar-button"
            type="button"
            onClick={onToggleSidebar}
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              isSidebarOpen
                ? 'bg-amber-100/80 text-amber-800 border border-amber-300/80'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100 border border-stone-200/60'
            }`}
            title="Chat History & Conversations / चैट इतिहास"
            aria-label="Toggle chat history sidebar"
          >
            <PanelLeft className="w-4 h-4" />
          </button>

          <button
            id="header-new-chat-button"
            type="button"
            onClick={() => {
              onNewChat();
              onTabChange('chats');
            }}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200/70 text-xs font-medium transition-colors cursor-pointer"
            title="Start new chat / नई बातचीत"
          >
            <Plus className="w-3.5 h-3.5 text-amber-600" />
            <span>New Chat</span>
          </button>

          <div
            onClick={() => onTabChange('home')}
            className="cursor-pointer"
            title="Go to Kaju Home"
          >
            <KajuLogo size="md" showText={true} />
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1 bg-stone-100/80 p-0.5 rounded-xl border border-stone-200/70 text-xs font-semibold ml-1">
            {navTabs.map((t) => {
              const Icon = t.icon;
              const isActive = activeTab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => onTabChange(t.id)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white text-stone-900 shadow-2xs font-bold'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-600' : 'text-stone-500'}`} />
                  <span>{t.label}</span>
                  {t.badge && (
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full leading-none ${
                        t.badge === 'Safe'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-900'
                      }`}
                    >
                      {t.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Right: Voice Assistant, Language switch & Chat Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Siri-like Voice Assistant button */}
          <button
            id="header-voice-assistant-btn"
            type="button"
            onClick={onOpenVoiceAssistant}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-linear-to-r from-amber-500 via-rose-500 to-indigo-600 text-white text-xs font-bold shadow-xs hover:shadow-md hover:scale-102 active:scale-98 transition-all cursor-pointer ring-1 ring-white/40"
            title="Activate Siri-like Voice Assistant (Hindi, English, Hinglish)"
          >
            <Mic className="w-3.5 h-3.5 animate-pulse" />
            <span className="hidden sm:inline">Voice</span>
            <span className="text-[10px] bg-white/20 backdrop-blur-xs text-white font-medium px-1 rounded">
              Siri
            </span>
          </button>

          {/* Action Center button */}
          <button
            id="header-action-center-btn"
            type="button"
            onClick={() => onTabChange('actions')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-100/90 hover:bg-amber-200/90 text-amber-900 border border-amber-300/80 text-xs font-semibold shadow-2xs transition-all cursor-pointer"
            title="Kaju Action Center • WhatsApp, Phone Dialer, Web Launchers, Permissions"
          >
            <Zap className="w-3.5 h-3.5 text-amber-700" />
            <span className="hidden sm:inline">Actions</span>
            <span className="text-[10px] bg-emerald-600 text-white font-bold px-1.5 py-0.2 rounded-full">
              Safe
            </span>
          </button>

          {/* Global Language Selector Trigger */}
          <button
            type="button"
            onClick={() => setIsLanguageModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100/90 border border-amber-200/90 text-stone-800 text-xs font-semibold shadow-2xs transition-all cursor-pointer group"
            title={`Language: ${langInfo.name} (${langInfo.nativeName}). Click to change.`}
            aria-label={`Language selector: ${langInfo.name}`}
          >
            <Globe className="w-3.5 h-3.5 text-amber-700 shrink-0 group-hover:rotate-12 transition-transform" />
            <span className="text-[11px] sm:text-xs flex items-center gap-1">
              <span className="hidden md:inline text-stone-500 font-normal">Language:</span>
              <span className="font-bold text-amber-950">
                {langInfo.id === 'auto' ? 'Auto' : langInfo.nativeName.split(' ')[0]}
              </span>
            </span>
            <ChevronDown className="w-3 h-3 text-stone-400 group-hover:text-stone-700 transition-colors shrink-0" />
          </button>

          {/* Searchable Global Language Modal */}
          <LanguageSelectorModal
            isOpen={isLanguageModalOpen}
            onClose={() => setIsLanguageModalOpen(false)}
            selectedLanguage={language}
            onSelectLanguage={onLanguageChange}
          />

          {/* Clear chat button */}
          {activeTab === 'chats' && messageCount > 0 && (
            <button
              id="clear-chat-button"
              type="button"
              onClick={onClearChat}
              className="p-2 rounded-xl text-stone-500 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
              title="Clear current conversation / बातचीत खाली करें"
              aria-label="Clear chat"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

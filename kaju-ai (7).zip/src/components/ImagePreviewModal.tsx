import React from 'react';
import { X, ZoomIn, Download } from 'lucide-react';

interface ImagePreviewModalProps {
  imageUrl: string | null;
  onClose: () => void;
  title?: string;
}

export const ImagePreviewModal: React.FC<ImagePreviewModalProps> = ({
  imageUrl,
  onClose,
  title = 'Question Image',
}) => {
  if (!imageUrl) return null;

  return (
    <div
      id="image-preview-modal-backdrop"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-3 sm:p-6 animate-in fade-in duration-200 cursor-zoom-out"
    >
      <div
        id="image-preview-modal-content"
        onClick={(e) => e.stopPropagation()}
        className="relative max-w-4xl max-h-[90vh] w-full flex flex-col items-center justify-center cursor-default"
      >
        {/* Top action row */}
        <div className="w-full flex items-center justify-between pb-3 text-white px-2">
          <div className="flex items-center gap-2">
            <ZoomIn className="w-4 h-4 text-amber-400" />
            <span className="text-xs sm:text-sm font-medium text-stone-200">{title}</span>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={imageUrl}
              download="kaju-question-scan.jpg"
              className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white border border-stone-700 text-xs inline-flex items-center gap-1 transition-colors"
              title="Download image"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline text-[11px]">Save</span>
            </a>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 hover:text-white border border-stone-700 transition-colors cursor-pointer"
              aria-label="Close preview"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* The image */}
        <div className="w-full overflow-auto flex items-center justify-center max-h-[82vh] rounded-2xl border border-stone-800 bg-stone-950 p-1 shadow-2xl">
          <img
            src={imageUrl}
            alt="Full size preview"
            className="max-w-full max-h-[80vh] object-contain rounded-xl"
          />
        </div>
      </div>
    </div>
  );
};

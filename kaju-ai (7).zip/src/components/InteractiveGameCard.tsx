import React, { useState } from 'react';
import {
  Gamepad2,
  Trophy,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Lightbulb,
  X,
  CheckCircle2,
  ArrowRight,
  Flame,
  Award,
} from 'lucide-react';
import { GameState } from '../types';

interface InteractiveGameCardProps {
  game: GameState;
  onSendMove: (move: string) => void;
  onExitGame: () => void;
  onNewGame?: (type: any) => void;
}

export const InteractiveGameCard: React.FC<InteractiveGameCardProps> = ({
  game,
  onSendMove,
  onExitGame,
  onNewGame,
}) => {
  const [customInput, setCustomInput] = useState('');
  const [showHint, setShowHint] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    onSendMove(customInput.trim());
    setCustomInput('');
  };

  const isCompleted = game.status === 'won' || game.status === 'lost' || game.status === 'abandoned';

  return (
    <div className="w-full my-3 rounded-3xl bg-linear-to-br from-amber-500/10 via-orange-500/5 to-amber-600/10 border-2 border-amber-300 p-4 sm:p-5 shadow-sm space-y-4 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-amber-200/80 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
            <Gamepad2 className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-extrabold text-stone-900 text-sm sm:text-base flex items-center gap-2">
              {game.title}
              {game.status === 'won' && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 flex items-center gap-1">
                  <Trophy className="w-3 h-3 text-emerald-600" /> Won!
                </span>
              )}
              {game.status === 'lost' && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-900 border border-rose-300">
                  Game Over
                </span>
              )}
            </h4>
            <span className="text-xs text-stone-500">Kaju Companion Game</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {game.score > 0 && (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
              <Award className="w-3.5 h-3.5 text-amber-600" />
              <span>{game.score} pts</span>
            </div>
          )}
          <button
            type="button"
            onClick={onExitGame}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
            title="Exit game"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* GAME SPECIFIC VISUAL BOARD */}

      {/* 1. TIC-TAC-TOE INTERACTIVE GRID */}
      {game.type === 'tic_tac_toe' && (
        <div className="flex flex-col items-center justify-center space-y-3 py-2">
          <div className="grid grid-cols-3 gap-2 w-56 h-56 p-2 rounded-2xl bg-stone-100 border border-amber-300 shadow-inner">
            {(game.data.board || Array(9).fill(null)).map((cell, idx) => {
              const isWinningCell = game.data.winningLine?.includes(idx);
              return (
                <button
                  key={idx}
                  type="button"
                  disabled={cell !== null || isCompleted}
                  onClick={() => onSendMove(String(idx + 1))}
                  className={`w-full h-full rounded-xl flex items-center justify-center text-2xl font-black transition-all cursor-pointer ${
                    cell === 'X'
                      ? 'bg-amber-500 text-white shadow-xs'
                      : cell === 'O'
                      ? 'bg-rose-500 text-white shadow-xs'
                      : 'bg-white hover:bg-amber-50 text-stone-300 hover:text-amber-600 border border-stone-200 hover:border-amber-300'
                  } ${isWinningCell ? 'ring-4 ring-emerald-400 scale-102 animate-pulse' : ''}`}
                >
                  {cell ? cell : <span className="text-xs text-stone-300 font-normal">{idx + 1}</span>}
                </button>
              );
            })}
          </div>

          <div className="text-xs font-semibold text-stone-600 text-center">
            {isCompleted ? (
              <span className="font-bold text-amber-900">{game.lastMessage}</span>
            ) : (
              <span>Tap an empty cell (1-9) to place your <strong>X</strong></span>
            )}
          </div>
        </div>
      )}

      {/* 2. NUMBER GUESSING GAUGE */}
      {game.type === 'number_guess' && (
        <div className="space-y-3 py-1">
          <div className="flex items-center justify-between text-xs font-bold text-stone-600">
            <span>Range: 1 to 50</span>
            <span className="text-amber-800">
              Attempts left: <strong className="text-amber-950 font-black">{game.data.attemptsLeft}</strong> / 7
            </span>
          </div>

          {/* Progress bar of attempts */}
          <div className="w-full h-2 rounded-full bg-stone-200 overflow-hidden">
            <div
              className="h-full bg-linear-to-r from-amber-500 to-orange-500 transition-all duration-300"
              style={{ width: `${((game.data.attemptsLeft ?? 7) / 7) * 100}%` }}
            />
          </div>

          {/* Previous guesses chips */}
          {game.data.guesses && game.data.guesses.length > 0 && (
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-xs text-stone-500 font-medium">Your Guesses:</span>
              {game.data.guesses.map((g, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 rounded-lg bg-white border border-amber-300 text-xs font-bold text-stone-800 shadow-2xs"
                >
                  {g}
                </span>
              ))}
            </div>
          )}

          {/* Quick guess helper buttons */}
          {!isCompleted && (
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-[11px] text-stone-500">Suggestions:</span>
              {[10, 20, 25, 30, 40, 50].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => onSendMove(String(num))}
                  className="px-2 py-0.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold cursor-pointer"
                >
                  {num}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 3. RIDDLE / PAHELI DISPLAY */}
      {game.type === 'riddle' && (
        <div className="space-y-3 py-1">
          <div className="p-3.5 rounded-2xl bg-white border border-amber-200 text-stone-800 text-sm font-medium leading-relaxed shadow-2xs">
            {game.data.riddleQuestion}
          </div>

          {game.data.hint && (
            <div className="flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={() => {
                  setShowHint(!showHint);
                  onSendMove('Give me a hint');
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold transition-colors cursor-pointer"
              >
                <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                <span>{showHint ? 'Hide Hint' : 'Need a Hint? (संकेत)'}</span>
              </button>
              {showHint && (
                <span className="text-amber-800 italic animate-in fade-in">
                  {game.data.hint}
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {/* 4. EMOJI GUESS */}
      {game.type === 'emoji_guess' && (
        <div className="space-y-3 py-1 text-center">
          <div className="p-4 rounded-2xl bg-white border border-amber-200 shadow-2xs">
            <div className="text-4xl tracking-widest py-2">{game.data.emojiPrompt}</div>
            <p className="text-xs text-stone-600 mt-1 italic">Clue: {game.data.hintClue}</p>
          </div>
        </div>
      )}

      {/* 5. GK QUIZ CHOICES */}
      {game.type === 'quiz' && game.data.options && (
        <div className="space-y-2 py-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {game.data.options.map((opt, idx) => {
              const letter = String.fromCharCode(65 + idx);
              return (
                <button
                  key={idx}
                  type="button"
                  disabled={isCompleted}
                  onClick={() => onSendMove(letter)}
                  className="p-3 rounded-2xl bg-white hover:bg-amber-50 border border-stone-200 hover:border-amber-400 text-left text-xs font-semibold text-stone-800 flex items-center gap-2.5 transition-all cursor-pointer shadow-2xs"
                >
                  <span className="w-6 h-6 rounded-xl bg-amber-100 text-amber-900 font-bold flex items-center justify-center shrink-0">
                    {letter}
                  </span>
                  <span>{opt}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Bottom text input if active and not just single button */}
      {!isCompleted && game.type !== 'tic_tac_toe' && (
        <form onSubmit={handleSubmit} className="flex items-center gap-2 pt-1">
          <input
            type="text"
            placeholder={game.feedbackText || "Enter your answer or guess..."}
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-white border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20 shadow-2xs"
          />
          <button
            type="submit"
            className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shrink-0 cursor-pointer shadow-xs"
          >
            Send Guess
          </button>
        </form>
      )}

      {/* Completed actions: Play another round or back to study */}
      {isCompleted && (
        <div className="flex items-center gap-2 pt-2 border-t border-amber-200/80 flex-wrap">
          <button
            type="button"
            onClick={() => onNewGame ? onNewGame(game.type) : onSendMove(`Kaju, let's play another round of ${game.title}`)}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Play Again</span>
          </button>

          <button
            type="button"
            onClick={() => onSendMove("Kaju, bas ab kaam karte hain")}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-stone-100 text-stone-800 border border-stone-300 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowRight className="w-3.5 h-3.5 text-amber-600" />
            <span>Back to Work / Study 🎯</span>
          </button>
        </div>
      )}
    </div>
  );
};

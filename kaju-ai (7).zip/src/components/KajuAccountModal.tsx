import React, { useState } from 'react';
import {
  X,
  User,
  Mail,
  Lock,
  LogOut,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  Copy,
  KeyRound,
  DownloadCloud,
  Check,
} from 'lucide-react';
import { KajuAccount, CloudSyncStatus } from '../types';
import {
  signInWithGoogle,
  signUpWithEmail,
  loginWithEmail,
  logoutAccount,
  requestPasswordReset,
  listProfiles,
  switchProfile,
  createSeparateProfile,
} from '../utils/accountHelper';

interface KajuAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAccount: KajuAccount;
  onAccountChange: (account: KajuAccount) => void;
  onSyncRequest?: () => Promise<void>;
  syncStatus?: CloudSyncStatus;
}

export const KajuAccountModal: React.FC<KajuAccountModalProps> = ({
  isOpen,
  onClose,
  currentAccount,
  onAccountChange,
  onSyncRequest,
  syncStatus = { status: 'local', pendingItemsCount: 0 },
}) => {
  const [mode, setMode] = useState<'view' | 'login' | 'signup' | 'forgot'>('view');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [migrationNotice, setMigrationNotice] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [newProfileName, setNewProfileName] = useState('');
  const [isCreatingProfile, setIsCreatingProfile] = useState(false);

  if (!isOpen) return null;

  const allProfiles = listProfiles();

  const handleSwitchToProfile = (uid: string) => {
    const target = switchProfile(uid);
    if (target) {
      onAccountChange(target);
      setSuccessMessage(`Switched to profile: ${target.displayName}`);
      setTimeout(() => setSuccessMessage(null), 2500);
    }
  };

  const handleCreateProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProfileName.trim()) return;
    const created = createSeparateProfile(newProfileName.trim());
    onAccountChange(created);
    setNewProfileName('');
    setIsCreatingProfile(false);
    setSuccessMessage(`Created and switched to profile: ${created.displayName}`);
    setTimeout(() => setSuccessMessage(null), 2500);
  };

  const handleCopyUid = () => {
    navigator.clipboard.writeText(currentAccount.uid);
    setCopiedUid(true);
    setTimeout(() => setCopiedUid(false), 2000);
  };

  const handleGoogleLogin = () => {
    setErrorMessage(null);
    try {
      const result = signInWithGoogle();
      onAccountChange(result.account);
      if (result.migrationReport && (result.migrationReport.chatsMigrated > 0 || result.migrationReport.goalsMigrated > 0)) {
        setMigrationNotice(
          `🎉 Seamlessly migrated ${result.migrationReport.chatsMigrated} chats, ${result.migrationReport.goalsMigrated} goals, and ${result.migrationReport.projectsMigrated} projects to your Google account!`
        );
      } else {
        setSuccessMessage('Successfully connected with Google Account!');
      }
      setMode('view');
    } catch (e: any) {
      setErrorMessage(e.message || 'Google sign in failed');
    }
  };

  const handleEmailSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const result = signUpWithEmail(email, password, displayName);
    if (!result.success || !result.account) {
      setErrorMessage(result.error || 'Failed to sign up');
      return;
    }

    onAccountChange(result.account);
    if (result.migrationReport && (result.migrationReport.chatsMigrated > 0 || result.migrationReport.goalsMigrated > 0)) {
      setMigrationNotice(
        `🎉 Successfully created account & preserved ${result.migrationReport.chatsMigrated} chats, ${result.migrationReport.goalsMigrated} goals, and ${result.migrationReport.projectsMigrated} projects!`
      );
    } else {
      setSuccessMessage('Account created successfully!');
    }
    setMode('view');
  };

  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    const result = loginWithEmail(email, password);
    if (!result.success || !result.account) {
      setErrorMessage(result.error || 'Invalid credentials');
      return;
    }

    onAccountChange(result.account);
    if (result.migrationReport && (result.migrationReport.chatsMigrated > 0 || result.migrationReport.goalsMigrated > 0)) {
      setMigrationNotice(
        `🎉 Logged in and linked ${result.migrationReport.chatsMigrated} guest chats and ${result.migrationReport.goalsMigrated} goals to your account!`
      );
    } else {
      setSuccessMessage('Logged in successfully!');
    }
    setMode('view');
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    const result = requestPasswordReset(email);
    if (result.success) {
      setSuccessMessage(result.message);
      setTimeout(() => setMode('login'), 3000);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleLogout = () => {
    const freshGuest = logoutAccount();
    onAccountChange(freshGuest);
    setSuccessMessage('Logged out. Switched back to Guest Explorer.');
    setMode('view');
  };

  const handleTriggerSync = async () => {
    if (!onSyncRequest) return;
    setIsSyncing(true);
    try {
      await onSyncRequest();
      setSuccessMessage('Synced successfully with cloud vault!');
    } catch {
      setErrorMessage('Sync error: could not connect to sync service');
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-stone-200/90 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200/70 bg-linear-to-r from-amber-500/10 via-orange-500/10 to-amber-500/5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-linear-to-br from-amber-500 to-orange-600 flex items-center justify-center text-white shadow-xs">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base flex items-center gap-1.5">
                Kaju Account & Cloud Data
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  {currentAccount.provider.toUpperCase()}
                </span>
              </h3>
              <p className="text-xs text-stone-500">
                {currentAccount.isAnonymous
                  ? 'Guest Explorer Session (Local Storage)'
                  : `Signed in as ${currentAccount.displayName}`}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {migrationNotice && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-start gap-2 animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{migrationNotice}</div>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* VIEW CURRENT ACCOUNT STATE */}
          {mode === 'view' && (
            <div className="space-y-4">
              {/* Account Card */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-600 text-white font-extrabold text-base flex items-center justify-center shadow-xs">
                      {currentAccount.displayName.slice(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="font-extrabold text-stone-900 text-sm sm:text-base">
                        {currentAccount.displayName}
                      </h4>
                      <p className="text-xs text-stone-500 font-mono">
                        {currentAccount.email || 'No email attached (Guest session)'}
                      </p>
                    </div>
                  </div>

                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                    {currentAccount.isAnonymous ? 'Temporary UID' : 'Permanent Account'}
                  </span>
                </div>

                {/* UID display */}
                <div className="p-2.5 bg-white rounded-xl border border-stone-200 flex items-center justify-between text-xs">
                  <span className="text-stone-500 font-mono text-[11px] truncate mr-2">
                    UID: {currentAccount.uid}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyUid}
                    className="p-1 text-stone-500 hover:text-amber-700 rounded-lg hover:bg-stone-100 flex items-center gap-1 text-[11px] font-semibold shrink-0 cursor-pointer"
                  >
                    {copiedUid ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedUid ? 'Copied' : 'Copy UID'}</span>
                  </button>
                </div>
              </div>

              {/* Separate Profiles Switcher Section */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-amber-700" />
                    <div>
                      <h5 className="text-xs font-bold text-stone-900">Separate User Profiles</h5>
                      <p className="text-[11px] text-stone-500">
                        Switch accounts or create dedicated profiles with isolated memories and chats.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsCreatingProfile(!isCreatingProfile)}
                    className="text-[11px] font-bold text-amber-700 hover:underline cursor-pointer"
                  >
                    {isCreatingProfile ? 'Cancel' : '+ New Profile'}
                  </button>
                </div>

                {isCreatingProfile && (
                  <form onSubmit={handleCreateProfileSubmit} className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      value={newProfileName}
                      onChange={(e) => setNewProfileName(e.target.value)}
                      placeholder="e.g. 'Kailash', 'Student Profile', 'Work'"
                      className="flex-1 px-3 py-1.5 rounded-xl border border-amber-300 bg-white text-xs text-stone-900 outline-none focus:ring-2 focus:ring-amber-500/20"
                      autoFocus
                    />
                    <button
                      type="submit"
                      disabled={!newProfileName.trim()}
                      className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold cursor-pointer"
                    >
                      Create
                    </button>
                  </form>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {allProfiles.map((p) => {
                    const isActive = p.uid === currentAccount.uid;
                    return (
                      <div
                        key={p.uid}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-xs transition-all ${
                          isActive
                            ? 'bg-amber-50/80 border-amber-300 ring-1 ring-amber-400'
                            : 'bg-white border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0 pr-1">
                          <div
                            className={`w-7 h-7 rounded-lg text-white font-bold text-xs flex items-center justify-center shrink-0 ${
                              isActive ? 'bg-amber-600' : 'bg-stone-400'
                            }`}
                          >
                            {p.displayName.slice(0, 2).toUpperCase()}
                          </div>
                          <div className="truncate">
                            <span className="font-bold text-stone-900 block truncate text-xs">
                              {p.displayName}
                            </span>
                            <span className="text-[10px] text-stone-500 capitalize">
                              {p.provider} {p.displayName.toLowerCase().includes('kailash') ? '• Owner' : ''}
                            </span>
                          </div>
                        </div>

                        {isActive ? (
                          <span className="text-[10px] font-black text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md shrink-0">
                            Active
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleSwitchToProfile(p.uid)}
                            className="text-[10px] font-bold text-stone-700 hover:text-amber-800 bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded-md shrink-0 cursor-pointer"
                          >
                            Switch
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Guest Warning / Save My Kaju Data Banner */}
              {currentAccount.isAnonymous ? (
                <div className="p-4 rounded-2xl bg-linear-to-br from-amber-500/10 via-orange-500/10 to-amber-500/5 border border-amber-300 space-y-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    <h5 className="text-xs font-extrabold text-amber-950 uppercase tracking-wider">
                      Save My Kaju Data
                    </h5>
                  </div>
                  <p className="text-xs text-stone-700 leading-relaxed">
                    You are exploring Kaju as a <strong>Guest</strong>. Link your Google or Email account to permanently save your chats, goals, projects, and game progress across devices!
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleGoogleLogin}
                      className="w-full py-2.5 px-3 rounded-xl bg-white hover:bg-stone-50 text-stone-900 border border-stone-200 text-xs font-bold flex items-center justify-center gap-2 shadow-2xs cursor-pointer transition-all hover:scale-101"
                    >
                      <svg className="w-4 h-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                      </svg>
                      <span>Link with Google</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMode('signup')}
                      className="w-full py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-all hover:scale-101"
                    >
                      <Mail className="w-4 h-4" />
                      <span>Create Email Account</span>
                    </button>
                  </div>
                </div>
              ) : (
                /* Permanent account options */
                <div className="space-y-3">
                  <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between">
                    <div>
                      <h5 className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                        <DownloadCloud className="w-4 h-4 text-amber-600" />
                        Multi-Device Cloud Sync
                      </h5>
                      <p className="text-[11px] text-stone-500">
                        Status: <strong className="text-emerald-700 capitalize">{syncStatus.status}</strong>
                        {syncStatus.lastSyncedAt && ` • ${new Date(syncStatus.lastSyncedAt).toLocaleTimeString()}`}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleTriggerSync}
                      disabled={isSyncing}
                      className="px-3 py-1.5 rounded-xl bg-white hover:bg-stone-100 text-stone-800 border border-stone-300 text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-600' : ''}`} />
                      <span>{isSyncing ? 'Syncing...' : 'Sync Now'}</span>
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={handleLogout}
                    className="w-full py-2.5 px-4 rounded-xl bg-stone-100 hover:bg-rose-50 text-stone-700 hover:text-rose-700 border border-stone-200 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Log Out from this Device</span>
                  </button>
                </div>
              )}

              {/* Already have an account switch */}
              {currentAccount.isAnonymous && (
                <div className="text-center pt-2">
                  <button
                    type="button"
                    onClick={() => setMode('login')}
                    className="text-xs text-amber-700 font-bold hover:underline cursor-pointer"
                  >
                    Already have an account? Log in here →
                  </button>
                </div>
              )}
            </div>
          )}

          {/* SIGN UP WITH EMAIL */}
          {mode === 'signup' && (
            <form onSubmit={handleEmailSignUp} className="space-y-3.5">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-stone-900 text-sm">Create Kaju Account</h4>
                <button
                  type="button"
                  onClick={() => setMode('view')}
                  className="text-xs text-stone-500 hover:text-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Your Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Kaju Solanki"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Password</label>
                <input
                  type="password"
                  required
                  placeholder="At least 6 characters"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
                🔒 All your existing guest chats, goals, and projects will be automatically linked to your new account.
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer"
              >
                Create Account & Preserve Data
              </button>

              <div className="text-center text-xs text-stone-500">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="text-amber-700 font-bold hover:underline"
                >
                  Log in
                </button>
              </div>
            </form>
          )}

          {/* LOGIN WITH EMAIL */}
          {mode === 'login' && (
            <form onSubmit={handleEmailLogin} className="space-y-3.5">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-stone-900 text-sm">Log in to Kaju</h4>
                <button
                  type="button"
                  onClick={() => setMode('view')}
                  className="text-xs text-stone-500 hover:text-stone-800 cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-stone-700">Password</label>
                  <button
                    type="button"
                    onClick={() => setMode('forgot')}
                    className="text-[11px] text-amber-700 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <input
                  type="password"
                  required
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer"
              >
                Log In
              </button>

              <div className="text-center text-xs text-stone-500">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => setMode('signup')}
                  className="text-amber-700 font-bold hover:underline"
                >
                  Sign up
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD */}
          {mode === 'forgot' && (
            <form onSubmit={handleForgotPassword} className="space-y-3.5">
              <div className="flex items-center justify-between">
                <h4 className="font-extrabold text-stone-900 text-sm">Reset Password</h4>
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className="text-xs text-stone-500 hover:text-stone-800 cursor-pointer"
                >
                  Back to Login
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs cursor-pointer"
              >
                Send Reset Link
              </button>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-stone-200/70 bg-stone-50 text-[11px] text-stone-500 flex items-center justify-between">
          <span className="flex items-center gap-1 text-emerald-700 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            User-Scoped Data Isolation
          </span>
          <span>Kaju v2.0 Account Layer</span>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  Zap,
  Phone,
  MessageSquare,
  ExternalLink,
  Laptop,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Send,
  PhoneCall,
  Search,
  ArrowRight,
  Info,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { ActionPermissions, DeviceAction } from '../types';
import {
  POPULAR_APP_SHORTCUTS,
  buildWhatsAppUrl,
  buildDialerUrl,
  formatPhoneDisplay,
  sanitizePhoneNumber,
} from '../utils/actionHelper';
import { NativeActionRouter } from '../utils/nativeActionRouter';

interface KajuActionsViewProps {
  permissions: ActionPermissions;
  onUpdatePermissions: (newPerms: ActionPermissions) => void;
  actionHistory: DeviceAction[];
  onExecuteActionPrompt: (prompt: string) => void;
}

export const KajuActionsView: React.FC<KajuActionsViewProps> = ({
  permissions,
  onUpdatePermissions,
  actionHistory,
  onExecuteActionPrompt,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'quick_actions' | 'apps' | 'desktop' | 'permissions' | 'history'
  >('quick_actions');

  // WhatsApp state
  const [waPhone, setWaPhone] = useState('');
  const [waMessage, setWaMessage] = useState('');
  const [waNotice, setWaNotice] = useState<string | null>(null);

  // Phone state
  const [dialerPhone, setDialerPhone] = useState('');
  const [dialerNotice, setDialerNotice] = useState<string | null>(null);

  // App launch state
  const [appNotice, setAppNotice] = useState<{ message: string; isError?: boolean } | null>(null);

  const handleLaunchApp = async (app: (typeof POPULAR_APP_SHORTCUTS)[0]) => {
    if (app.appId) {
      const res = await NativeActionRouter.launchApp(app.appId);
      setAppNotice({ message: res.message, isError: !res.success });
      setTimeout(() => setAppNotice(null), 6000);
    } else if (app.url) {
      window.open(app.url, '_blank', 'noopener,noreferrer');
      setAppNotice({ message: `Opened ${app.name} in web browser.` });
      setTimeout(() => setAppNotice(null), 6000);
    }
  };

  const handleLaunchWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.allowWhatsApp) {
      setWaNotice('WhatsApp links are disabled in Permission settings.');
      return;
    }
    const cleanPhone = sanitizePhoneNumber(waPhone);
    const url = buildWhatsAppUrl(cleanPhone, waMessage);
    window.open(url, '_blank', 'noopener,noreferrer');
    setWaNotice('Opening WhatsApp with prepared message. Review and tap Send inside WhatsApp.');
    setTimeout(() => setWaNotice(null), 6000);
  };

  const handleLaunchDialer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!permissions.allowPhoneDialer) {
      setDialerNotice('Phone dialer is disabled in Permission settings.');
      return;
    }
    if (!dialerPhone.trim()) {
      setDialerNotice('Please enter a phone number.');
      return;
    }
    const url = buildDialerUrl(dialerPhone);
    window.location.href = url;
    setDialerNotice(`Opening phone dialer for ${formatPhoneDisplay(dialerPhone)}.`);
    setTimeout(() => setDialerNotice(null), 6000);
  };

  const handleTogglePermission = (key: keyof ActionPermissions) => {
    if (key === 'requireConfirmationAlways') return;
    onUpdatePermissions({
      ...permissions,
      [key]: !permissions[key],
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold border border-amber-300/80">
          <Zap className="w-3.5 h-3.5" />
          <span>Zero-Click Safe Confirmation Engine</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight flex items-center justify-center gap-2">
          <span>⚡ Kaju Actions</span>
          <span className="text-xs sm:text-sm font-semibold px-2 py-0.5 rounded-lg bg-emerald-100 text-emerald-800">
            100% Safe
          </span>
        </h1>
        <p className="text-sm text-stone-600 max-w-lg mx-auto">
          Prepare WhatsApp messages, launch the phone dialer, or open supported websites. Every action is drafted safely and requires your explicit review.
        </p>
      </div>

      {/* Sub-tabs */}
      <div className="flex items-center justify-center gap-1.5 p-1 bg-stone-100/80 rounded-2xl max-w-md mx-auto overflow-x-auto text-xs font-bold">
        {[
          { id: 'quick_actions', label: 'Preparation Tools' },
          { id: 'apps', label: 'Apps & Web' },
          { id: 'desktop', label: 'PC Limitations' },
          { id: 'permissions', label: 'Permissions' },
          { id: 'history', label: 'Audit Log' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeSubTab === tab.id
                ? 'bg-white text-stone-900 shadow-2xs'
                : 'text-stone-500 hover:text-stone-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Preparation Tools (WhatsApp & Phone) */}
      {activeSubTab === 'quick_actions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* WhatsApp Preparation Card */}
          <div className="bg-white rounded-3xl border border-stone-200 p-5 space-y-4 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-stone-900">WhatsApp Message Drafter</h3>
                <p className="text-xs text-stone-500">Drafts message into WhatsApp</p>
              </div>
            </div>

            {waNotice && (
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs border border-emerald-200">
                {waNotice}
              </div>
            )}

            <form onSubmit={handleLaunchWhatsApp} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Recipient Phone (Optional)
                </label>
                <input
                  type="tel"
                  placeholder="Enter phone number (or leave blank)"
                  value={waPhone}
                  onChange={(e) => setWaPhone(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <div>
                <label className="font-bold text-stone-700 block mb-1">Message Text</label>
                <textarea
                  rows={3}
                  placeholder="Type message to prepare..."
                  value={waMessage}
                  onChange={(e) => setWaMessage(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <button
                type="submit"
                disabled={!waMessage.trim()}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Prepare & Open in WhatsApp</span>
              </button>
            </form>
          </div>

          {/* Phone Call / Dialer Preparation Card */}
          <div className="bg-white rounded-3xl border border-stone-200 p-5 space-y-4 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-stone-900">Phone Dialer Preparation</h3>
                <p className="text-xs text-stone-500">Opens phone dialer with number</p>
              </div>
            </div>

            {dialerNotice && (
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-800 text-xs border border-indigo-200">
                {dialerNotice}
              </div>
            )}

            <form onSubmit={handleLaunchDialer} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-stone-700 block mb-1">
                  Phone Number to Dial
                </label>
                <input
                  type="tel"
                  placeholder="Enter phone number to dial"
                  value={dialerPhone}
                  onChange={(e) => setDialerPhone(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-stone-50 border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>

              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-[11px] leading-relaxed">
                ℹ️ <strong>Safety Guarantee:</strong> Kaju cannot place background calls automatically. Clicking below simply loads your device's native dialer.
              </div>

              <button
                type="submit"
                disabled={!dialerPhone.trim()}
                className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Open in Device Dialer</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Tab 2: Apps & Websites */}
      {activeSubTab === 'apps' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
                Supported Applications & System Tools
              </h3>
              <p className="text-xs text-stone-500 mt-0.5">
                {NativeActionRouter.isNativeAndroid()
                  ? 'Dispatches native Android Intents to installed apps on your device'
                  : 'Safe web fallbacks active (Android Intent bridge ready)'}
              </p>
            </div>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
              NativeActionRouter.isNativeAndroid()
                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                : 'bg-amber-100 text-amber-800 border border-amber-300'
            }`}>
              {NativeActionRouter.isNativeAndroid() ? 'Android Native Host' : 'Web Preview Mode'}
            </span>
          </div>

          {appNotice && (
            <div className={`p-3 rounded-xl text-xs border animate-in fade-in duration-200 ${
              appNotice.isError
                ? 'bg-rose-50 border-rose-300 text-rose-800'
                : 'bg-emerald-50 border-emerald-300 text-emerald-800'
            }`}>
              {appNotice.message}
            </div>
          )}

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {POPULAR_APP_SHORTCUTS.map((app) => (
              <button
                key={app.id}
                type="button"
                onClick={() => handleLaunchApp(app)}
                className="p-3.5 rounded-2xl bg-stone-50 hover:bg-amber-50/70 border border-stone-200 hover:border-amber-300 transition-all text-left flex items-start justify-between group cursor-pointer"
              >
                <div>
                  <h4 className="text-xs font-bold text-stone-900 group-hover:text-amber-700">
                    {app.name}
                  </h4>
                  <p className="text-[11px] text-stone-500 mt-0.5 line-clamp-1">{app.hindiName}</p>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-stone-400 group-hover:text-amber-600 shrink-0 mt-0.5" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Desktop Hardware Limitations */}
      {activeSubTab === 'desktop' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-4 shadow-2xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center">
              <Laptop className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                Operating System & Desktop Sandbox Boundaries
              </h3>
              <p className="text-xs text-stone-500">Security architecture explanation</p>
            </div>
          </div>

          <div className="space-y-3 text-xs text-stone-600 leading-relaxed">
            <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900">
              <h4 className="font-bold text-amber-950 mb-1 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-700" />
                Browser Sandbox Rule
              </h4>
              <p>
                Web browsers are intentionally isolated by security design. Web apps cannot shutdown your computer, execute terminal bash/powershell commands, simulate mouse clicks outside the window, or access local C:\ files directly.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <h4 className="font-bold text-stone-900">Future Desktop Companion Plan</h4>
              <p>
                To control desktop apps or automate local PC scripts, an external companion background daemon (running via Node.js or Python) will be connected via a local WebSocket token.
              </p>
              <div className="flex items-center gap-2 pt-1 text-[11px] text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>No silent or unauthenticated commands will ever be executed.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Permissions */}
      {activeSubTab === 'permissions' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-4 shadow-2xs">
          <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
            Safe Action Permissions Configuration
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 border border-stone-200">
              <div>
                <h4 className="font-bold text-stone-900">WhatsApp Message Preparation</h4>
                <p className="text-stone-500 text-[11px]">Allow drafting WhatsApp messages</p>
              </div>
              <input
                type="checkbox"
                checked={permissions.allowWhatsApp}
                onChange={() => handleTogglePermission('allowWhatsApp')}
                className="w-4 h-4 text-amber-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 border border-stone-200">
              <div>
                <h4 className="font-bold text-stone-900">Phone Dialer Access</h4>
                <p className="text-stone-500 text-[11px]">Allow opening native dialer</p>
              </div>
              <input
                type="checkbox"
                checked={permissions.allowPhoneDialer}
                onChange={() => handleTogglePermission('allowPhoneDialer')}
                className="w-4 h-4 text-amber-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 border border-stone-200">
              <div>
                <h4 className="font-bold text-stone-900">External Links & Shortcuts</h4>
                <p className="text-stone-500 text-[11px]">Allow opening YouTube, Maps, etc.</p>
              </div>
              <input
                type="checkbox"
                checked={permissions.allowExternalLinks}
                onChange={() => handleTogglePermission('allowExternalLinks')}
                className="w-4 h-4 text-amber-600 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-emerald-50 border border-emerald-200">
              <div>
                <h4 className="font-bold text-emerald-900">Zero-Click Confirmation Mandatory</h4>
                <p className="text-emerald-700 text-[11px]">Never execute background actions without user review</p>
              </div>
              <span className="text-xs font-bold text-emerald-800 bg-white px-2 py-0.5 rounded-md border border-emerald-300">
                Always Active
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Audit History */}
      {activeSubTab === 'history' && (
        <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-4 shadow-2xs">
          <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider">
            Action Audit Log • कार्य इतिहास
          </h3>

          {actionHistory.length === 0 ? (
            <p className="text-xs text-stone-400 text-center py-6">
              No actions have been prepared or executed yet.
            </p>
          ) : (
            <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
              {actionHistory.map((act) => (
                <div
                  key={act.id}
                  className="p-3 rounded-2xl bg-stone-50 border border-stone-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <h4 className="font-bold text-stone-900">{act.title}</h4>
                    <span className="text-[10px] text-stone-400">
                      {new Date(act.createdAt).toLocaleString()} • Type: {act.type}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      act.status === 'executed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {act.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import Markdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import {
  HelpCircle,
  Lightbulb,
  ListOrdered,
  Sparkles,
  CheckCircle2,
  BookmarkCheck,
  Target,
  Send,
  HelpCircle as HintIcon,
  ChevronDown,
  ChevronUp,
  Layers,
  Copy,
  Check,
} from 'lucide-react';
import { preprocessMathMarkdown } from '../utils/mathHelper';
import { CodeBlock } from './CodeBlock';

const markdownComponents = {
  code({ node, inline, className, children, ...props }: any) {
    const match = /language-(\w+)/.exec(className || '');
    const codeString = String(children).replace(/\n$/, '');
    if (!inline && (match || codeString.includes('\n'))) {
      return <CodeBlock language={match ? match[1] : 'code'} value={codeString} />;
    }
    return (
      <code className="px-1.5 py-0.5 rounded-md bg-stone-100 text-amber-900 font-mono text-xs font-semibold border border-stone-200" {...props}>
        {children}
      </code>
    );
  },
};

interface KajuBoardProps {
  content: string;
  onAnswerChallenge?: (answerText: string) => void;
}

interface ParsedSection {
  id: string;
  title: string;
  cleanTitle: string;
  icon: any;
  colorScheme: {
    border: string;
    bg: string;
    headerBg: string;
    iconColor: string;
    badgeBg: string;
    badgeText: string;
  };
  body: string;
}

export const KajuBoard: React.FC<KajuBoardProps> = ({ content, onAnswerChallenge }) => {
  const [challengeAnswer, setChallengeAnswer] = useState('');
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const [copiedSectionId, setCopiedSectionId] = useState<string | null>(null);

  // Parse the content into Kaju Board sections if section headers exist
  const { hasBoardStructure, sections, preamble, challengeQuestion } = useMemo(() => {
    // Regex matching section headers: ### 📌 ... or ## 📌 ... or ### What is being asked ...
    const headerRegex = /(?:^|\n)(?:#{2,4}\s+([^\n]+)|(?:\*\*|__)(?:[0-9]+\.\s*)?([^\n*:]+):?(?:\*\*|__))/g;
    const matches: { index: number; title: string }[] = [];
    let match;

    while ((match = headerRegex.exec(content)) !== null) {
      const title = (match[1] || match[2] || '').trim();
      if (title.length > 2) {
        matches.push({ index: match.index, title });
      }
    }

    if (matches.length < 2) {
      return { hasBoardStructure: false, sections: [], preamble: content, challengeQuestion: null };
    }

    const preambleText = content.substring(0, matches[0].index).trim();
    const parsedSections: ParsedSection[] = [];
    let challenge: string | null = null;

    for (let i = 0; i < matches.length; i++) {
      const current = matches[i];
      const nextIndex = i + 1 < matches.length ? matches[i + 1].index : content.length;
      const rawBody = content.substring(current.index, nextIndex);
      // Remove header line from body
      const firstNewline = rawBody.indexOf('\n');
      const bodyText = firstNewline !== -1 ? rawBody.substring(firstNewline + 1).trim() : '';

      const lowerTitle = current.title.toLowerCase();

      // Check if this is the Kaju Challenge
      if (
        lowerTitle.includes('challenge') ||
        lowerTitle.includes('चैलेंज') ||
        lowerTitle.includes('practice question')
      ) {
        challenge = bodyText;
        continue;
      }

      let icon = Lightbulb;
      let colorScheme = {
        border: 'border-amber-200/90',
        bg: 'bg-white',
        headerBg: 'hover:bg-amber-50/40',
        iconColor: 'text-amber-700',
        badgeBg: 'bg-amber-100',
        badgeText: 'text-amber-900',
      };

      if (
        lowerTitle.includes('asked') ||
        lowerTitle.includes('पूछा') ||
        lowerTitle.includes('problem') ||
        lowerTitle.includes('given')
      ) {
        icon = HelpCircle;
        colorScheme = {
          border: 'border-blue-200/90',
          bg: 'bg-white',
          headerBg: 'hover:bg-blue-50/40',
          iconColor: 'text-blue-700',
          badgeBg: 'bg-blue-100',
          badgeText: 'text-blue-900',
        };
      } else if (
        lowerTitle.includes('explanation') ||
        lowerTitle.includes('व्याख्या') ||
        lowerTitle.includes('simple') ||
        lowerTitle.includes('concept')
      ) {
        icon = Lightbulb;
        colorScheme = {
          border: 'border-amber-200/90',
          bg: 'bg-white',
          headerBg: 'hover:bg-amber-50/40',
          iconColor: 'text-amber-700',
          badgeBg: 'bg-amber-100',
          badgeText: 'text-amber-900',
        };
      } else if (
        lowerTitle.includes('step') ||
        lowerTitle.includes('चरण') ||
        lowerTitle.includes('solution') ||
        lowerTitle.includes('samadhan') ||
        lowerTitle.includes('derivation') ||
        lowerTitle.includes('calculation')
      ) {
        icon = ListOrdered;
        colorScheme = {
          border: 'border-indigo-200/90',
          bg: 'bg-white',
          headerBg: 'hover:bg-indigo-50/40',
          iconColor: 'text-indigo-700',
          badgeBg: 'bg-indigo-100',
          badgeText: 'text-indigo-900',
        };
      } else if (
        lowerTitle.includes('example') ||
        lowerTitle.includes('उदाहरण') ||
        lowerTitle.includes('analogy')
      ) {
        icon = Sparkles;
        colorScheme = {
          border: 'border-purple-200/90',
          bg: 'bg-white',
          headerBg: 'hover:bg-purple-50/40',
          iconColor: 'text-purple-700',
          badgeBg: 'bg-purple-100',
          badgeText: 'text-purple-900',
        };
      } else if (
        lowerTitle.includes('final') ||
        lowerTitle.includes('उत्तर') ||
        lowerTitle.includes('answer') ||
        lowerTitle.includes('conclusion')
      ) {
        icon = Target;
        colorScheme = {
          border: 'border-emerald-300 ring-1 ring-emerald-300',
          bg: 'bg-emerald-50/30',
          headerBg: 'hover:bg-emerald-50/60',
          iconColor: 'text-emerald-700',
          badgeBg: 'bg-emerald-100',
          badgeText: 'text-emerald-950',
        };
      } else if (
        lowerTitle.includes('recap') ||
        lowerTitle.includes('सारांश') ||
        lowerTitle.includes('summary') ||
        lowerTitle.includes('takeaway')
      ) {
        icon = BookmarkCheck;
        colorScheme = {
          border: 'border-orange-200/90',
          bg: 'bg-white',
          headerBg: 'hover:bg-orange-50/40',
          iconColor: 'text-orange-700',
          badgeBg: 'bg-orange-100',
          badgeText: 'text-orange-900',
        };
      }

      const cleanTitle = current.title.replace(/^[#\s📌💡📝🔍🎯⚡\d.-]+/, '').trim();

      parsedSections.push({
        id: `sec_${i}`,
        title: current.title,
        cleanTitle: cleanTitle || current.title,
        icon,
        colorScheme,
        body: bodyText,
      });
    }

    return {
      hasBoardStructure: parsedSections.length >= 2,
      sections: parsedSections,
      preamble: preambleText,
      challengeQuestion: challenge,
    };
  }, [content]);

  const toggleSection = (id: string) => {
    setCollapsedSections((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopySection = async (id: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSectionId(id);
      setTimeout(() => setCopiedSectionId(null), 2000);
    } catch {}
  };

  const handleChallengeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = challengeAnswer.trim();
    if (!trimmed || !onAnswerChallenge) return;
    onAnswerChallenge(`Kaju Challenge Answer: ${trimmed}`);
    setChallengeAnswer('');
  };

  const handleHintRequest = () => {
    if (!onAnswerChallenge) return;
    onAnswerChallenge('Kaju, is challenge question ka ek chhota hint do please.');
  };

  // If not enough structured sections, return standard clean markdown with KaTeX
  if (!hasBoardStructure) {
    return (
      <div className="prose prose-sm max-w-none text-stone-800 leading-relaxed font-normal">
        <Markdown
          remarkPlugins={[remarkMath]}
          rehypePlugins={[rehypeKatex]}
          components={markdownComponents}
        >
          {preprocessMathMarkdown(content)}
        </Markdown>
      </div>
    );
  }

  return (
    <div className="w-full space-y-3.5 my-1">
      {/* Preamble (if any introductory sentence before the board) */}
      {preamble && (
        <div className="prose prose-sm max-w-none text-stone-800 leading-relaxed mb-2 font-medium">
          <Markdown
            remarkPlugins={[remarkMath]}
            rehypePlugins={[rehypeKatex]}
            components={markdownComponents}
          >
            {preprocessMathMarkdown(preamble)}
          </Markdown>
        </div>
      )}

      {/* Kaju Board Interactive Canvas */}
      <div className="rounded-3xl border-2 border-amber-300/80 bg-linear-to-b from-amber-50/40 via-white to-stone-50/40 p-3 sm:p-4 shadow-sm space-y-3">
        {/* Board Top Banner */}
        <div className="flex items-center justify-between px-2 pb-2 border-b border-amber-200/80">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-500 text-white shadow-2xs">
              <Layers className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs font-extrabold text-stone-900 tracking-tight">
              Interactive Kaju Board • Step-by-Step Clarity
            </span>
          </div>
          <span className="text-[10px] font-bold text-amber-800 bg-amber-100/90 border border-amber-200 px-2 py-0.5 rounded-full">
            All School Subjects
          </span>
        </div>

        {/* Section Cards */}
        <div className="space-y-2.5">
          {sections.map((sec) => {
            const Icon = sec.icon;
            const isCollapsed = collapsedSections[sec.id];
            const isFinalAnswer =
              sec.cleanTitle.toLowerCase().includes('final') ||
              sec.cleanTitle.toLowerCase().includes('उत्तर') ||
              sec.cleanTitle.toLowerCase().includes('answer');

            return (
              <div
                key={sec.id}
                className={`rounded-2xl border transition-all overflow-hidden shadow-2xs ${sec.colorScheme.border} ${sec.colorScheme.bg}`}
              >
                {/* Header button */}
                <div className={`w-full px-3.5 py-2.5 flex items-center justify-between text-left transition-colors ${sec.colorScheme.headerBg}`}>
                  <button
                    type="button"
                    onClick={() => toggleSection(sec.id)}
                    className="flex-1 flex items-center gap-2 min-w-0 cursor-pointer text-left"
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${sec.colorScheme.iconColor}`} />
                    <span
                      className={`text-xs font-bold truncate ${
                        isFinalAnswer ? 'text-emerald-950 font-black' : 'text-stone-900'
                      }`}
                    >
                      {sec.cleanTitle}
                    </span>
                  </button>

                  <div className="flex items-center gap-1 shrink-0 ml-2">
                    {/* Copy snippet button */}
                    <button
                      type="button"
                      onClick={() => handleCopySection(sec.id, sec.body)}
                      className="p-1 text-stone-400 hover:text-stone-700 rounded-md hover:bg-black/5 transition-colors cursor-pointer"
                      title="Copy section text"
                    >
                      {copiedSectionId === sec.id ? (
                        <Check className="w-3 h-3 text-emerald-600" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleSection(sec.id)}
                      className="p-1 text-stone-400 hover:text-stone-700 rounded-md cursor-pointer"
                    >
                      {isCollapsed ? (
                        <ChevronDown className="w-4 h-4" />
                      ) : (
                        <ChevronUp className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Body Content */}
                {!isCollapsed && (
                  <div className="px-3.5 pb-3.5 pt-1.5 text-xs sm:text-sm text-stone-800 leading-relaxed border-t border-stone-100">
                    <div className="prose prose-sm max-w-none">
                      <Markdown
                        remarkPlugins={[remarkMath]}
                        rehypePlugins={[rehypeKatex]}
                        components={markdownComponents}
                      >
                        {preprocessMathMarkdown(sec.body)}
                      </Markdown>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* 🎯 KAJU CHALLENGE INTERACTIVE SECTION */}
        {challengeQuestion && (
          <div className="mt-3.5 rounded-2xl border-2 border-dashed border-amber-400 bg-linear-to-r from-amber-100/70 via-orange-100/60 to-amber-100/70 p-4 space-y-3 animate-in fade-in duration-300 shadow-xs">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-xl bg-amber-600 text-white shadow-2xs">
                  <Target className="w-4 h-4" />
                </span>
                <div>
                  <span className="text-xs font-black text-amber-950 uppercase tracking-wider block">
                    🎯 Kaju Challenge • आपकी बारी!
                  </span>
                  <span className="text-[10px] text-amber-800 font-medium">
                    Try solving this practice question to lock in your understanding
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={handleHintRequest}
                className="text-[11px] font-bold text-amber-900 hover:text-amber-950 bg-white hover:bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-300 shadow-2xs flex items-center gap-1 transition-colors cursor-pointer"
              >
                <HintIcon className="w-3 h-3 text-amber-700" />
                <span>Need a Hint?</span>
              </button>
            </div>

            {/* The Question */}
            <div className="text-xs sm:text-sm font-semibold text-stone-900 leading-relaxed bg-white/95 p-3.5 rounded-xl border border-amber-200/90 shadow-2xs">
              <div className="prose prose-sm max-w-none">
                <Markdown
                  remarkPlugins={[remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  components={markdownComponents}
                >
                  {preprocessMathMarkdown(challengeQuestion)}
                </Markdown>
              </div>
            </div>

            {/* Answer Input */}
            {onAnswerChallenge && (
              <form onSubmit={handleChallengeSubmit} className="flex items-center gap-1.5 pt-0.5">
                <input
                  type="text"
                  value={challengeAnswer}
                  onChange={(e) => setChallengeAnswer(e.target.value)}
                  placeholder="Apna answer yahan likhein aur Kaju se check karwayein..."
                  className="flex-1 py-2 px-3 rounded-xl bg-white border border-amber-300 text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 shadow-inner"
                />
                <button
                  type="submit"
                  disabled={!challengeAnswer.trim()}
                  className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer disabled:cursor-not-allowed shrink-0"
                >
                  <span>Submit</span>
                  <Send className="w-3 h-3" />
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  );
};


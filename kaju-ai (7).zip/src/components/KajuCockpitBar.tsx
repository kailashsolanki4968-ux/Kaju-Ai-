import React, { useState } from 'react';
import {
  Plus,
  History,
  ShieldCheck,
  Globe,
  Trash2,
  Sparkles,
  Zap,
  RotateCcw,
  Target,
  ChevronDown,
  FolderKanban,
  Brain,
  UserCheck,
  Gamepad2,
  User,
  GraduationCap,
} from 'lucide-react';
import { KajuLogo } from './KajuLogo';
import { LanguagePreference, Conversation, Goal, KajuAccount } from '../types';
import { LanguageSelectorModal } from './LanguageSelectorModal';
import { getLanguageInfo } from '../utils/languages';

interface KajuCockpitBarProps {
  language: LanguagePreference;
  onLanguageChange: (lang: LanguagePreference) => void;
  onNewSession: () => void;
  onOpenHistoryDrawer: () => void;
  onOpenActionsDrawer: () => void;
  onClearSession: () => void;
  hasMessages: boolean;
  activeSessionTitle?: string;
  activeGoal?: Goal | null;
  onOpenReplayModal?: (goal: Goal) => void;
  activeProjectName?: string;
  onOpenProjectsModal?: () => void;
  onOpenMemoryModal?: () => void;
  onOpenIdentityModal?: () => void;
  account?: KajuAccount;
  onOpenAccountModal?: () => void;
  onTriggerFun?: () => void;
  onSelectPrompt?: (prompt: string) => void;
  onOpenMediaStudio?: () => void;
}

export const KajuCockpitBar: React.FC<KajuCockpitBarProps> = ({
  language,
  onLanguageChange,
  onNewSession,
  onOpenHistoryDrawer,
  onOpenActionsDrawer,
  onClearSession,
  hasMessages,
  activeSessionTitle,
  activeGoal,
  onOpenReplayModal,
  activeProjectName,
  onOpenProjectsModal,
  onOpenMemoryModal,
  onOpenIdentityModal,
  account,
  onOpenAccountModal,
  onTriggerFun,
  onSelectPrompt,
  onOpenMediaStudio,
}) => {
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const langInfo = getLanguageInfo(language);
  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-amber-200/70 px-3 sm:px-6 py-2.5 shadow-xs">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Left: Brand & Active Workspace / Goal */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <KajuLogo size="md" showText={true} />

          {/* Active Project Workspace Pill */}
          {onOpenProjectsModal && (
            <button
              type="button"
              onClick={onOpenProjectsModal}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-stone-100 hover:bg-stone-200/90 border border-stone-300 text-stone-800 text-xs font-bold max-w-[130px] sm:max-w-[200px] truncate shadow-2xs transition-colors cursor-pointer"
              title={`Active Project: ${activeProjectName || 'General Workspace'} (Click to manage projects)`}
            >
              <FolderKanban className="w-3.5 h-3.5 text-amber-700 shrink-0" />
              <span className="truncate">{activeProjectName || 'Workspace'}</span>
              <ChevronDown className="w-3 h-3 text-stone-400 shrink-0" />
            </button>
          )}

          {/* Active Goal Pill */}
          {activeGoal && activeGoal.status === 'active' ? (
            <button
              type="button"
              onClick={() => onOpenReplayModal?.(activeGoal)}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-100/90 hover:bg-amber-200/90 border border-amber-300/80 text-amber-950 text-xs font-extrabold max-w-[170px] sm:max-w-[220px] truncate shadow-2xs transition-colors cursor-pointer"
              title={`Active Goal: ${activeGoal.title} (Click to see Replay)`}
            >
              <Target className="w-3.5 h-3.5 text-amber-700 shrink-0" />
              <span className="truncate">{activeGoal.title}</span>
              <span className="text-[10px] bg-amber-600 text-white px-1.5 py-0.2 rounded-md font-black shrink-0">
                {activeGoal.currentStage}
              </span>
            </button>
          ) : null}
        </div>

        {/* Right: Controls & Drawers */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Learn Something / Skill Mode Easy Button */}
          <button
            type="button"
            onClick={() => onNewSession ? (onNewSession(), setTimeout(() => onSelectPrompt?.("Kaju mujhe Japanese zero se sikhana."), 100)) : onSelectPrompt?.("Kaju mujhe Japanese zero se sikhana.")}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-950 border border-indigo-200 text-xs font-bold transition-all cursor-pointer shadow-2xs"
            title="Skill Learning: Learn anything zero se"
          >
            <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden sm:inline">Learn something</span>
            <span className="sm:hidden">Learn</span>
          </button>

          {/* New Session Button */}
          <button
            type="button"
            onClick={onNewSession}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 text-xs font-bold transition-all cursor-pointer shadow-2xs"
            title="Start fresh conversation"
          >
            <Plus className="w-3.5 h-3.5 text-amber-700" />
            <span className="hidden sm:inline">Naya Sawal</span>
            <span className="sm:hidden">New</span>
          </button>

          {/* Memory Modal Trigger */}
          {onOpenMemoryModal && (
            <button
              type="button"
              onClick={onOpenMemoryModal}
              className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200/80 text-stone-700 border border-stone-200 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              title="Kaju Memory & Preferences"
              aria-label="Kaju Memory"
            >
              <Brain className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden md:inline">Memory</span>
            </button>
          )}

          {/* Number / ID Check Trigger */}
          {onOpenIdentityModal && (
            <button
              type="button"
              onClick={onOpenIdentityModal}
              className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200/80 text-stone-700 border border-stone-200 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
              title="Kaju Number & Profile Discovery"
              aria-label="Number & ID Check"
            >
              <UserCheck className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden md:inline">ID Check</span>
            </button>
          )}

          {/* History Drawer Trigger */}
          <button
            type="button"
            onClick={onOpenHistoryDrawer}
            className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200/80 text-stone-700 border border-stone-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Past conversations & chat history"
          >
            <History className="w-3.5 h-3.5 text-stone-600" />
            <span className="hidden sm:inline">History</span>
          </button>

          {/* Actions & Safe Control Drawer Trigger */}
          <button
            type="button"
            onClick={onOpenActionsDrawer}
            className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-xl bg-linear-to-r from-amber-500 to-orange-500 text-white text-xs font-bold shadow-xs hover:shadow-md transition-all cursor-pointer"
            title="Safe actions (WhatsApp, Phone, Web Apps, Desktop Blueprint)"
          >
            <Zap className="w-3.5 h-3.5 fill-white" />
            <span className="hidden sm:inline">Actions</span>
            <span className="text-[10px] bg-white/25 px-1 rounded-sm font-semibold">
              Safe
            </span>
          </button>

          {/* Subtle Boredom / Fun Play Trigger */}
          {onTriggerFun && (
            <button
              type="button"
              onClick={onTriggerFun}
              className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-xs font-bold transition-all cursor-pointer shadow-2xs"
              title="Bored? Let's play an interactive game or talk!"
            >
              <Gamepad2 className="w-3.5 h-3.5 text-purple-600" />
              <span className="hidden sm:inline">Play</span>
            </button>
          )}

          {/* AI Media Studio Trigger (Image & Video Generation) */}
          {onOpenMediaStudio && (
            <button
              id="cockpit-media-btn"
              type="button"
              onClick={onOpenMediaStudio}
              className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-xl bg-orange-50 hover:bg-orange-100 text-orange-950 border border-orange-200 text-xs font-bold transition-all cursor-pointer shadow-2xs"
              title="Create Real AI Images & Videos (Gemini 3.1 & Veo 3.1)"
              aria-label="AI Media Studio"
            >
              <Sparkles className="w-3.5 h-3.5 text-orange-600" />
              <span className="hidden sm:inline">Media</span>
            </button>
          )}

          {/* Account Profile / Switcher Trigger */}
          {account && onOpenAccountModal && (
            <button
              id="cockpit-account-btn"
              type="button"
              onClick={onOpenAccountModal}
              className="flex items-center gap-1.5 px-2 sm:px-2.5 py-1 sm:py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100/90 border border-amber-200 text-stone-800 text-xs font-bold transition-all cursor-pointer shadow-2xs group"
              title={`Active Profile: ${account.displayName} (${account.isAnonymous ? 'Guest Local Profile' : 'Dedicated Profile'}). Click to switch or create profiles.`}
              aria-label={`Profile: ${account.displayName}`}
            >
              <div className="w-5 h-5 rounded-lg bg-amber-600 text-white text-[10px] font-extrabold flex items-center justify-center shadow-2xs group-hover:bg-amber-700 transition-colors shrink-0">
                {account.displayName.slice(0, 1).toUpperCase()}
              </div>
              <div className="flex flex-col text-left leading-tight min-w-0">
                <span className="text-[9px] text-stone-500 font-medium">Profile</span>
                <span className="text-[11px] font-bold text-stone-900 truncate max-w-[80px]">
                  {account.displayName}
                </span>
              </div>
              <span className="text-[9px] px-1.5 py-0.5 rounded-md bg-amber-200/80 text-amber-900 font-semibold hidden sm:inline ml-0.5">
                Switch
              </span>
            </button>
          )}

          {/* Global Language Selector Trigger */}
          <button
            type="button"
            onClick={() => setIsLanguageModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100/90 border border-amber-200/90 text-stone-800 text-xs font-semibold shadow-2xs transition-all cursor-pointer group"
            title={`Language: ${langInfo.name} (${langInfo.nativeName}). Click to change.`}
            aria-label={`Language selector: ${langInfo.name}`}
          >
            <Globe className="w-3.5 h-3.5 text-amber-700 shrink-0 group-hover:rotate-12 transition-transform" />
            <span className="text-[11px] sm:text-xs flex items-center gap-1">
              <span className="hidden lg:inline text-stone-500 font-normal">Language:</span>
              <span className="font-bold text-amber-950">
                {langInfo.id === 'auto' ? 'Auto' : langInfo.nativeName.split(' ')[0]}
              </span>
            </span>
            <ChevronDown className="w-3 h-3 text-stone-400 group-hover:text-stone-700 transition-colors shrink-0" />
          </button>

          {/* Searchable Global Language Modal */}
          <LanguageSelectorModal
            isOpen={isLanguageModalOpen}
            onClose={() => setIsLanguageModalOpen(false)}
            selectedLanguage={language}
            onSelectLanguage={onLanguageChange}
          />

          {/* Clear Session Button (if messages exist) */}
          {hasMessages && (
            <button
              type="button"
              onClick={onClearSession}
              className="p-1.5 rounded-xl text-stone-400 hover:text-rose-600 hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors cursor-pointer"
              title="Clear this session's messages"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

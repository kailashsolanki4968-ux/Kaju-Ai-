import React, {
  useState,
  useRef,
  useEffect,
  useImperativeHandle,
  forwardRef,
} from 'react';
import {
  Mic,
  MicOff,
  Camera,
  Image as ImageIcon,
  Send,
  Loader2,
  AlertCircle,
  X,
  ZoomIn,
  RotateCcw,
  Trash2,
  Sparkles,
  Paperclip,
  FileText,
  Palette,
  Video,
} from 'lucide-react';
import { LanguagePreference, Goal, DocumentAttachment } from '../types';
import { CameraCaptureModal } from './CameraCaptureModal';
import { ImagePreviewModal } from './ImagePreviewModal';
import { fastOptimizeImage } from '../utils/imageHelper';
import { speechManager } from '../utils/speech';
import { getSpeechRecognitionLang } from '../utils/languages';
import { NativeActionRouter } from '../utils/nativeActionRouter';

export interface KajuComposerHandle {
  toggleListening: () => void;
  focus: () => void;
  setText: (text: string) => void;
}

interface KajuComposerProps {
  onSendMessage: (text: string, image?: string, fileAttachment?: DocumentAttachment) => void;
  language: LanguagePreference;
  isStreaming: boolean;
  activeGoal?: Goal | null;
  onListeningChange?: (isListening: boolean, transcript: string) => void;
  onInputFocus?: () => void;
  onOpenMediaStudio?: (tab?: 'image' | 'video' | 'setup') => void;
}

export const KajuComposer = forwardRef<KajuComposerHandle, KajuComposerProps>(
  (
    {
      onSendMessage,
      language,
      isStreaming,
      activeGoal,
      onListeningChange,
      onInputFocus,
      onOpenMediaStudio,
    },
    ref
  ) => {
    const [inputText, setInputText] = useState('');
    const [selectedImage, setSelectedImage] = useState<string | null>(null);
    const [selectedFile, setSelectedFile] = useState<DocumentAttachment | null>(null);
    const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
    const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
    const [isProcessingImage, setIsProcessingImage] = useState(false);
    const [cameraErrorMessage, setCameraErrorMessage] = useState<string | null>(null);

    // Speech Recognition state
    const [isListening, setIsListening] = useState(false);
    const [liveTranscript, setLiveTranscript] = useState('');
    const [micErrorMessage, setMicErrorMessage] = useState<string | null>(null);
    const [isSpeechSupported, setIsSpeechSupported] = useState(true);

    const cameraInputRef = useRef<HTMLInputElement>(null);
    const galleryInputRef = useRef<HTMLInputElement>(null);
    const docInputRef = useRef<HTMLInputElement>(null);
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const recognitionRef = useRef<any>(null);

    // Notify parent of listening state
    useEffect(() => {
      onListeningChange?.(isListening, liveTranscript);
    }, [isListening, liveTranscript, onListeningChange]);

    // Check speech recognition support
    useEffect(() => {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (!SpeechRecognition) {
        setIsSpeechSupported(false);
      }
    }, []);

    // Register web action handlers so that voice commands like "camera kholo" / "gallery kholo" activate inputs
    useEffect(() => {
      NativeActionRouter.registerWebHandlers({
        triggerCamera: () => {
          cameraInputRef.current?.click();
        },
        triggerGallery: () => {
          galleryInputRef.current?.click();
        },
      });
    }, []);

    // Auto-resize textarea
    useEffect(() => {
      const textarea = textareaRef.current;
      if (textarea) {
        textarea.style.height = 'auto';
        const newHeight = Math.min(textarea.scrollHeight, 140);
        textarea.style.height = `${Math.max(48, newHeight)}px`;
      }
    }, [inputText, liveTranscript]);

    const stopListening = () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
        recognitionRef.current = null;
      }
      setIsListening(false);
      setLiveTranscript('');
    };

    const startListening = async () => {
      speechManager.stop();
      setMicErrorMessage(null);

      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

      if (!SpeechRecognition) {
        setIsSpeechSupported(false);
        setMicErrorMessage('Speech recognition is not supported in this browser.');
        return;
      }

      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          stream.getTracks().forEach((track) => track.stop());
        } catch (err: any) {
          if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
            setMicErrorMessage('Microphone access denied. Please allow it in browser settings.');
            return;
          }
        }
      }

      stopListening();

      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;
        recognition.lang = getSpeechRecognitionLang(language);

        recognition.onstart = () => {
          setIsListening(true);
          setMicErrorMessage(null);
        };

        recognition.onresult = (event: any) => {
          let finalChunk = '';
          let interimChunk = '';

          for (let i = event.resultIndex; i < event.results.length; ++i) {
            const trans = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalChunk += trans;
            } else {
              interimChunk += trans;
            }
          }

          if (interimChunk) {
            setLiveTranscript(interimChunk);
          }

          if (finalChunk) {
            const combined = (inputText ? `${inputText.trim()} ` : '') + finalChunk.trim();
            setInputText('');
            setLiveTranscript('');
            stopListening();
            onSendMessage(combined, selectedImage || undefined);
            setSelectedImage(null);
          }
        };

        recognition.onerror = (event: any) => {
          if (event.error !== 'no-speech' && event.error !== 'aborted') {
            setMicErrorMessage(`Voice input error: ${event.error}. Please try again.`);
          }
          stopListening();
        };

        recognition.onend = () => {
          stopListening();
        };

        recognitionRef.current = recognition;
        recognition.start();
      } catch (err: any) {
        console.error('Error starting speech recognition:', err);
        setMicErrorMessage('Could not activate microphone.');
        stopListening();
      }
    };

    const toggleListening = () => {
      if (isListening) {
        stopListening();
      } else {
        startListening();
      }
    };

    useImperativeHandle(ref, () => ({
      toggleListening,
      focus: () => {
        textareaRef.current?.focus();
      },
      setText: (text: string) => {
        setInputText(text);
      },
    }));

    // Unified image processing & preview attachment pipeline for both Camera and Gallery (does NOT auto-send)
    const handleProcessImageAttachment = async (file: File) => {
      if (!file) return;

      setIsProcessingImage(true);
      setCameraErrorMessage(null);

      try {
        stopListening();

        // 1. Fast, hardware-accelerated optimization (1280px max, 0.82 quality JPEG)
        const optimized = await fastOptimizeImage(file, 1280, 0.82);

        // 2. Attach image to composer preview tray (Do NOT auto-send)
        setSelectedImage(optimized.dataUrl);

        // 3. Keep composer open and auto-focus textarea so user can enter a question
        setTimeout(() => {
          textareaRef.current?.focus();
        }, 50);
      } catch (err: any) {
        console.error('Failed to process image:', err);
        setCameraErrorMessage(
          language === 'hindi'
            ? 'फ़ोटो लोड करने में त्रुटि हुई। कृपया पुनः प्रयास करें।'
            : "Couldn't process the photo. Please try again."
        );
      } finally {
        setIsProcessingImage(false);
        if (cameraInputRef.current) cameraInputRef.current.value = '';
        if (galleryInputRef.current) galleryInputRef.current.value = '';
      }
    };

    const handleCameraChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return; // user cancelled camera; never crash
      handleProcessImageAttachment(file);
    };

    const handleGalleryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return; // user cancelled gallery picker
      handleProcessImageAttachment(file);
    };

    const handleTriggerCamera = async () => {
      setCameraErrorMessage(null);
      // Check permissions API if available
      if (navigator.permissions && (navigator.permissions as any).query) {
        try {
          const status = await navigator.permissions.query({ name: 'camera' as any });
          if (status.state === 'denied') {
            setCameraErrorMessage(
              language === 'hindi'
                ? 'कैमरा अनुमति बंद है। कृपया ब्राउज़र/फ़ोन सेटिंग्स में जाकर कैमरा अनुमति चालू करें।'
                : 'Camera permission is denied. Please enable camera access in your browser settings to take photos.'
            );
            return;
          }
        } catch {
          // Continue to direct camera trigger
        }
      }

      // Directly trigger device camera
      if (cameraInputRef.current) {
        cameraInputRef.current.value = '';
        cameraInputRef.current.click();
      }
    };

    // Live viewfinder capture fallback (modal)
    const handlePhotoCaptured = (imageDataUrl: string) => {
      stopListening();
      setSelectedImage(imageDataUrl);
      setIsCameraModalOpen(false);
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 50);
    };

    // Explicit "Analyze photo" action: analyzes photo with or without custom question
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const rawContent = (event.target?.result as string) || '';
        setSelectedFile({
          id: `doc_${Date.now()}`,
          name: file.name,
          type: file.type || 'text/plain',
          size: file.size,
          content: rawContent,
          previewSnippet: rawContent.slice(0, 150),
        });
      };
      reader.readAsText(file);
      e.target.value = '';
    };

    const handleAnalyzePhoto = () => {
      if (!selectedImage || isStreaming) return;
      const query = (inputText + (liveTranscript ? ` ${liveTranscript}` : '')).trim();
      stopListening();
      onSendMessage(query, selectedImage, selectedFile || undefined);
      setInputText('');
      setSelectedImage(null);
      setSelectedFile(null);
      setLiveTranscript('');
      if (textareaRef.current) {
        textareaRef.current.style.height = '48px';
      }
    };

    const handleQuickVisionChip = (chipPrompt: string) => {
      setInputText(chipPrompt);
      textareaRef.current?.focus();
    };

    const handleSubmit = (e?: React.FormEvent) => {
      if (e) e.preventDefault();
      const query = (inputText + (liveTranscript ? ` ${liveTranscript}` : '')).trim();
      if ((!query && !selectedImage && !selectedFile) || isStreaming) return;

      stopListening();
      onSendMessage(query, selectedImage || undefined, selectedFile || undefined);
      setInputText('');
      setSelectedImage(null);
      setSelectedFile(null);
      setLiveTranscript('');

      if (textareaRef.current) {
        textareaRef.current.style.height = '48px';
      }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    };

    return (
      <div className="w-full flex flex-col items-center">
        {/* Direct native camera capture input for Android & mobile */}
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={handleCameraChange}
        />

        {/* Gallery selection input */}
        <input
          ref={galleryInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleGalleryChange}
        />

        {/* Document / Code file selection input */}
        <input
          ref={docInputRef}
          type="file"
          accept=".txt,.csv,.json,.md,.js,.ts,.py,.html,.css,.pdf,.docx,.doc"
          className="hidden"
          onChange={handleFileChange}
        />

        {/* Camera Capture Modal (fallback / live viewfinder) */}
        <CameraCaptureModal
          isOpen={isCameraModalOpen}
          onClose={() => setIsCameraModalOpen(false)}
          onCapture={handlePhotoCaptured}
        />

        {/* Image Preview Modal */}
        <ImagePreviewModal
          imageUrl={isPreviewModalOpen ? selectedImage : null}
          onClose={() => setIsPreviewModalOpen(false)}
          title="Attached Question Image"
        />

        {/* 📄 KAJU DOCUMENT PREVIEW & INTELLIGENCE TRAY */}
        {selectedFile && (
          <div className="w-full max-w-3xl mb-2 px-1 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="bg-amber-50/95 border-2 border-amber-300 rounded-2xl p-2.5 sm:p-3 shadow-sm flex flex-col gap-2">
              <div className="flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-12 h-12 rounded-xl bg-amber-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <FileText className="w-6 h-6" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                      <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Document attached ✓</span>
                    </div>
                    <p className="text-xs font-semibold text-stone-800 truncate mt-0.5 max-w-[240px] sm:max-w-md">
                      {selectedFile.name} ({Math.round(selectedFile.size / 1024)} KB)
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0 ml-auto">
                  <button
                    type="button"
                    onClick={() => setSelectedFile(null)}
                    disabled={isStreaming}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-rose-600 text-xs font-semibold border border-rose-200 shadow-2xs transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove</span>
                  </button>
                </div>
              </div>

              {/* Quick Document Question Chips */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1.5 border-t border-amber-200/80">
                <span className="text-[10px] uppercase font-bold text-amber-900/70 tracking-wider shrink-0">
                  Ask about file:
                </span>
                {[
                  'Summarize this file',
                  'Extract key insights',
                  'Explain step-by-step',
                  'Find errors or bugs',
                ].map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => {
                      setInputText(chip);
                      textareaRef.current?.focus();
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      inputText === chip
                        ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                        : 'bg-white hover:bg-amber-100 text-stone-800 border-amber-200 hover:border-amber-300'
                    }`}
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 📷 KAJU PHOTO PREVIEW & COMPOSE TRAY */}
        {selectedImage && (
          <div className="w-full max-w-3xl mb-2 px-1 animate-in fade-in slide-in-from-bottom-2 duration-200">
            <div className="bg-amber-50/95 border-2 border-amber-300 rounded-2xl p-2.5 sm:p-3 shadow-sm flex flex-col gap-2.5">
              {/* Top row: Thumbnail, Info & Action Buttons */}
              <div className="flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap">
                <div className="flex items-center gap-2.5 min-w-0">
                  {/* Thumbnail with zoom */}
                  <div
                    onClick={() => setIsPreviewModalOpen(true)}
                    className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden bg-stone-900 border-2 border-amber-400 shrink-0 cursor-zoom-in group shadow-xs"
                    title="Click to zoom photo"
                  >
                    <img
                      src={selectedImage}
                      alt="Captured preview"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                      <ZoomIn className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Photo Status */}
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                      <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Photo captured ✓</span>
                    </div>
                    <p className="text-[11px] text-stone-600 truncate mt-0.5 max-w-[200px] sm:max-w-xs">
                      {inputText.trim()
                        ? `Question: "${inputText.trim()}"`
                        : 'Sawal likhein ya seedhe "Analyze photo" dabayein'}
                    </p>
                  </div>
                </div>

                {/* Primary Photo Actions: [Retake] [Remove] [Analyze photo] */}
                <div className="flex items-center gap-1.5 shrink-0 ml-auto">
                  <button
                    type="button"
                    onClick={handleTriggerCamera}
                    disabled={isStreaming || isProcessingImage}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white hover:bg-stone-100 text-stone-700 text-xs font-semibold border border-amber-200 shadow-2xs transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                    title="Retake photo using camera"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-stone-500" />
                    <span>Retake</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedImage(null)}
                    disabled={isStreaming}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white hover:bg-rose-50 text-rose-600 text-xs font-semibold border border-rose-200 shadow-2xs transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                    title="Remove attached photo"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleAnalyzePhoto}
                    disabled={isStreaming}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-linear-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white text-xs font-bold shadow-xs hover:shadow transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                    title="Analyze this photo directly"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Analyze photo</span>
                  </button>
                </div>
              </div>

              {/* Quick Question Chips for Fast Mobile Input */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1.5 border-t border-amber-200/80">
                <span className="text-[10px] uppercase font-bold text-amber-900/70 tracking-wider shrink-0">
                  Quick questions:
                </span>
                {[
                  'Isko solve karo',
                  'Iska answer batao',
                  'Isme kya likha hai?',
                  'Explain this',
                ].map((chip) => (
                  <button
                    key={chip}
                    type="button"
                    onClick={() => {
                      setInputText(chip);
                      textareaRef.current?.focus();
                    }}
                    className={`px-2.5 py-1 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      inputText === chip
                        ? 'bg-amber-600 text-white border-amber-600 shadow-2xs'
                        : 'bg-white hover:bg-amber-100 text-stone-800 border-amber-200 hover:border-amber-300'
                    }`}
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Camera Permission / Error Banner */}
        {cameraErrorMessage && (
          <div className="w-full max-w-3xl mb-2 px-1 animate-in fade-in duration-200">
            <div className="flex items-center justify-between p-2.5 rounded-2xl bg-rose-50 border border-rose-300 text-rose-800 text-xs shadow-xs">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{cameraErrorMessage}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleTriggerCamera}
                  className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-[11px] cursor-pointer"
                >
                  Retry
                </button>
                <button
                  type="button"
                  onClick={() => setCameraErrorMessage(null)}
                  className="p-1 rounded-lg text-rose-600 hover:bg-rose-100 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Voice Error Banner */}
        {micErrorMessage && (
          <div className="w-full max-w-3xl px-1 mb-2">
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
              <span className="flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                {micErrorMessage}
              </span>
              <button
                type="button"
                onClick={() => setMicErrorMessage(null)}
                className="text-rose-500 hover:text-rose-800 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* CENTRAL UNIFIED OMNI-INPUT FORM */}
        <div className="w-full max-w-3xl">
          <form
            onSubmit={handleSubmit}
            className="relative bg-white/98 backdrop-blur-md rounded-3xl border-2 border-amber-300/80 shadow-md shadow-amber-900/5 focus-within:border-amber-500 focus-within:ring-4 focus-within:ring-amber-500/15 transition-all p-1.5 sm:p-2 flex items-end gap-1 sm:gap-1.5"
          >
            {/* Quick Camera Action (directly opens native camera on Android) */}
            <button
              type="button"
              onClick={handleTriggerCamera}
              disabled={isStreaming || isProcessingImage}
              className="p-2 sm:p-2.5 rounded-2xl text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 transition-all shrink-0 cursor-pointer disabled:opacity-40"
              title="Snap photo with camera"
              aria-label="Camera"
            >
              {isProcessingImage ? (
                <Loader2 className="w-5 h-5 text-amber-700 animate-spin" />
              ) : (
                <Camera className="w-5 h-5 text-amber-700" />
              )}
            </button>

            {/* Quick Gallery Action */}
            <button
              type="button"
              onClick={() => galleryInputRef.current?.click()}
              disabled={isStreaming || isProcessingImage}
              className="p-2 sm:p-2.5 rounded-2xl text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 transition-all shrink-0 cursor-pointer disabled:opacity-40"
              title="Upload photo from gallery"
              aria-label="Gallery"
            >
              {isProcessingImage ? (
                <Loader2 className="w-5 h-5 text-amber-700 animate-spin" />
              ) : (
                <ImageIcon className="w-5 h-5 text-amber-700" />
              )}
            </button>

            {/* Quick Document / File Action */}
            <button
              type="button"
              onClick={() => docInputRef.current?.click()}
              disabled={isStreaming || isProcessingImage}
              className="p-2 sm:p-2.5 rounded-2xl text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 transition-all shrink-0 cursor-pointer disabled:opacity-40"
              title="Attach document or code file (.txt, .csv, .json, .md, .py, .pdf, etc.)"
              aria-label="Attach File"
            >
              <Paperclip className="w-5 h-5 text-amber-700" />
            </button>

            {/* Create AI Image Button */}
            {onOpenMediaStudio && (
              <button
                type="button"
                onClick={() => onOpenMediaStudio('image')}
                disabled={isStreaming || isProcessingImage}
                className="p-2 sm:p-2.5 rounded-2xl text-stone-500 hover:text-amber-800 hover:bg-amber-100/70 transition-all shrink-0 cursor-pointer disabled:opacity-40"
                title="Create AI Image (Gemini 3.1 Flash Lite Image) / चित्र बनाएं"
                aria-label="Create AI Image"
              >
                <Palette className="w-5 h-5 text-amber-700" />
              </button>
            )}

            {/* Create AI Video Button */}
            {onOpenMediaStudio && (
              <button
                type="button"
                onClick={() => onOpenMediaStudio('video')}
                disabled={isStreaming || isProcessingImage}
                className="p-2 sm:p-2.5 rounded-2xl text-stone-500 hover:text-indigo-800 hover:bg-indigo-100/70 transition-all shrink-0 cursor-pointer disabled:opacity-40"
                title="Create AI Video (Google DeepMind Veo 3.1) / वीडियो बनाएं"
                aria-label="Create AI Video"
              >
                <Video className="w-5 h-5 text-indigo-700" />
              </button>
            )}

            {/* Voice Microphone Toggle in Input Bar */}
            <button
              type="button"
              onClick={toggleListening}
              disabled={isStreaming}
              className={`p-2 sm:p-2.5 rounded-2xl transition-all shrink-0 cursor-pointer ${
                isListening
                  ? 'bg-red-500 text-white shadow-xs shadow-red-500/30 animate-pulse'
                  : 'text-stone-500 hover:text-amber-800 hover:bg-amber-100/70'
              }`}
              title="Speak your query in Hindi, English, or any supported language"
              aria-label={isListening ? 'Stop listening' : 'Start speaking'}
            >
              {isListening ? (
                <MicOff className="w-5 h-5 text-white" />
              ) : (
                <Mic className="w-5 h-5 text-amber-700" />
              )}
            </button>

            {/* Text Area */}
            <div className="flex-1 relative flex flex-col justify-center min-w-0">
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                onFocus={onInputFocus}
                placeholder={
                  selectedImage
                    ? 'Is photo ke baare mein kya puchna hai?'
                    : selectedFile
                    ? `File: "${selectedFile.name}". Is document ke baare mein kya puchna hai?`
                    : activeGoal
                    ? `Goal: "${activeGoal.title}". Agla step likhein ya bolein...`
                    : isListening
                    ? 'Kaju sun raha hai… bolte rahiye…'
                    : 'Bolo ya likho… (e.g. coding, trip plan, maths exam, file summary, WhatsApp)'
                }
                rows={1}
                disabled={isStreaming}
                className="w-full max-h-36 py-2 px-1 bg-transparent text-stone-900 placeholder:text-stone-400 resize-none outline-none text-sm sm:text-base leading-relaxed"
              />
              {liveTranscript && (
                <div className="text-xs text-amber-700/80 italic pb-1 px-1">
                  &ldquo;{liveTranscript}&rdquo;…
                </div>
              )}
            </div>

            {/* Send / Execute Button */}
            <button
              type="submit"
              disabled={(!inputText.trim() && !liveTranscript.trim() && !selectedImage && !selectedFile) || isStreaming}
              className="p-2 sm:p-2.5 rounded-2xl bg-linear-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 disabled:opacity-30 text-white shadow-xs transition-all shrink-0 cursor-pointer disabled:cursor-not-allowed active:scale-95"
              title={
                selectedImage
                  ? inputText.trim()
                    ? 'Send question and photo'
                    : 'Analyze photo / Send'
                  : selectedFile
                  ? 'Analyze document / Send'
                  : 'Ask Kaju or start goal'
              }
              aria-label="Send message"
            >
              {isStreaming ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }
);

KajuComposer.displayName = 'KajuComposer';

import React from 'react';
import {
  Sparkles,
  RotateCcw,
  CheckCircle2,
  ArrowRight,
  Layers,
  Target,
  Award,
  Play,
  Check,
} from 'lucide-react';
import { KajuCoreState, Goal, JourneyStage } from '../types';

export interface KajuHeroProps {
  coreState: KajuCoreState;
  activeGoal?: Goal | null;
  recentlyCompletedGoals?: Goal[];
  onOpenReplayModal?: (goal: Goal) => void;
  onExecutePrimaryAction?: (prompt: string) => void;
  onDismissGoal?: (goalId: string) => void;
  onSelectSuggestion: (text: string) => void;
  isListening?: boolean;
  onToggleListening?: () => void;
  liveTranscript?: string;
}

export const KajuHero: React.FC<KajuHeroProps> = ({
  coreState,
  activeGoal,
  recentlyCompletedGoals = [],
  onOpenReplayModal,
  onExecutePrimaryAction,
  onDismissGoal,
  onSelectSuggestion,
  isListening = false,
  onToggleListening,
  liveTranscript = '',
}) => {
  // Determine active visual state
  const visualState: KajuCoreState = isListening ? 'listening' : coreState;

  // Contextual status text and sub-captions
  const statusMap: Record<KajuCoreState, { title: string; subtitle: string; badge: string }> = {
    idle: {
      title: activeGoal ? `Goal: ${activeGoal.title}` : 'WHAT DO YOU WANT TO GET DONE?',
      subtitle: activeGoal
        ? `Stage ${activeGoal.currentStage}: ${
            activeGoal.steps.find((s) => s.id === activeGoal.currentStepId)?.title ||
            activeGoal.steps.find((s) => s.stage === activeGoal.currentStage)?.title ||
            'In progress'
          }`
        : 'Speak, type, or snap a photo. Kaju detects your goal and guides you to verified completion.',
      badge: activeGoal ? `Goal Active • ${activeGoal.currentStage}` : 'Goal Engine Online • Ready',
    },
    listening: {
      title: 'Kaju sun raha hai…',
      subtitle: liveTranscript ? `"${liveTranscript}"` : 'Bolna shuru karein (Hindi, English, Hinglish)...',
      badge: 'Listening • बोलिए',
    },
    understanding: {
      title: 'Kaju samajh raha hai…',
      subtitle: 'Analyzing your goal, situation, constraints, and required outcome...',
      badge: 'Understanding • सोच रहा है',
    },
    planning: {
      title: 'Kaju journey plan kar raha hai…',
      subtitle: 'Structuring your 5-stage roadmap: GOAL → NOW → NEXT → CHECK → DONE',
      badge: 'Planning • योजना',
    },
    preparing: {
      title: 'Kaju taiyaar kar raha hai…',
      subtitle: 'Structuring step-by-step clarity...',
      badge: 'Preparing • तैयारी',
    },
    doing: {
      title: 'Kaju kaam kar raha hai…',
      subtitle: 'Executing step & generating crystal-clear guidance...',
      badge: 'Doing • प्रगति पर',
    },
    answering: {
      title: 'Kaju samjha raha hai…',
      subtitle: 'Generating complete explanation with formulas & steps...',
      badge: 'Answering • उत्तर',
    },
    checking: {
      title: 'Kaju checkpoint verify kar raha hai…',
      subtitle: 'Checking your concept understanding before advancing...',
      badge: 'Checking • जांच',
    },
    adjusting: {
      title: 'Kaju adaptive replan kar raha hai…',
      subtitle: 'Adapting explanation to your pace & addressing weak areas...',
      badge: 'Adjusting • अनुकूलन',
    },
    completed: {
      title: 'Kaam ho gaya! ✨',
      subtitle: 'Bataiye, ab aage kya karna hai?',
      badge: 'Done • पूर्ण',
    },
    error: {
      title: 'Thoda sa issue hua',
      subtitle: 'Ek baar phir se bolkar ya likhkar try karein.',
      badge: 'Retry • पुनः प्रयास',
    },
  };

  const currentStatusInfo = statusMap[visualState] || statusMap.idle;

  return (
    <div className="w-full flex flex-col items-center select-none animate-in fade-in duration-300 py-2 sm:py-4">
      {/* 1. LIVING KAJU CORE ORB & AURA */}
      <div className="relative my-3 sm:my-5 flex flex-col items-center">
        {/* Multilayered Outer Breathing Halos */}
        <div
          className={`absolute inset-0 rounded-full transition-all duration-700 pointer-events-none ${
            visualState === 'listening'
              ? 'scale-150 sm:scale-175 bg-linear-to-r from-red-500/20 via-amber-500/30 to-orange-500/20 blur-2xl animate-pulse'
              : visualState === 'understanding'
              ? 'scale-140 sm:scale-160 bg-linear-to-r from-amber-400/25 via-purple-500/20 to-orange-500/25 blur-2xl animate-spin'
              : visualState === 'planning' || visualState === 'preparing'
              ? 'scale-140 sm:scale-155 bg-linear-to-r from-orange-500/30 via-amber-400/25 to-indigo-500/20 blur-2xl animate-pulse'
              : visualState === 'doing' || visualState === 'answering'
              ? 'scale-135 sm:scale-150 bg-linear-to-r from-amber-500/30 via-orange-500/30 to-amber-600/30 blur-xl animate-pulse'
              : visualState === 'checking'
              ? 'scale-140 sm:scale-155 bg-linear-to-r from-purple-500/30 via-amber-400/25 to-indigo-500/30 blur-xl animate-spin'
              : visualState === 'adjusting'
              ? 'scale-140 sm:scale-155 bg-linear-to-r from-orange-500/30 via-amber-500/30 to-teal-500/25 blur-xl animate-pulse'
              : visualState === 'completed'
              ? 'scale-130 sm:scale-145 bg-linear-to-r from-emerald-500/30 via-amber-400/20 to-teal-500/30 blur-xl animate-pulse'
              : 'scale-110 sm:scale-125 bg-amber-400/15 blur-xl'
          }`}
        />

        {/* Central Core Sphere */}
        <div
          onClick={onToggleListening}
          className={`relative group cursor-pointer w-26 h-26 sm:w-34 sm:h-34 rounded-full flex items-center justify-center transition-all duration-500 shadow-xl ${
            visualState === 'listening'
              ? 'bg-linear-to-tr from-red-600 via-amber-500 to-orange-500 ring-8 ring-red-400/30 scale-105'
              : visualState === 'understanding'
              ? 'bg-linear-to-tr from-amber-500 via-indigo-600 to-orange-500 ring-6 ring-amber-300/40 animate-pulse'
              : visualState === 'planning' || visualState === 'preparing'
              ? 'bg-linear-to-tr from-orange-500 via-amber-500 to-indigo-600 ring-6 ring-orange-300/40 animate-pulse'
              : visualState === 'doing' || visualState === 'answering'
              ? 'bg-linear-to-tr from-amber-600 via-orange-500 to-amber-500 ring-6 ring-amber-400/30'
              : visualState === 'checking'
              ? 'bg-linear-to-tr from-purple-600 via-indigo-600 to-amber-500 ring-6 ring-purple-300/40 animate-pulse'
              : visualState === 'adjusting'
              ? 'bg-linear-to-tr from-orange-600 via-amber-500 to-teal-500 ring-6 ring-teal-300/40 animate-pulse'
              : visualState === 'completed'
              ? 'bg-linear-to-tr from-emerald-600 via-teal-500 to-amber-500 ring-6 ring-emerald-300/40'
              : 'bg-linear-to-br from-amber-500 via-orange-500 to-amber-600 ring-4 ring-amber-300/30 hover:scale-105 hover:ring-amber-400/50'
          }`}
          title="Click to talk with Kaju"
          role="button"
          tabIndex={0}
        >
          {/* Inner Gloss & Light Reflex */}
          <div className="absolute inset-1 rounded-full bg-linear-to-b from-white/30 to-transparent pointer-events-none" />

          {/* Living State Visualization within Orb */}
          {visualState === 'listening' ? (
            /* Audio Frequency Waveform Bars */
            <div className="flex items-center gap-1.5 z-10">
              <span className="w-1.5 h-6 bg-white rounded-full animate-bounce [animation-delay:-0.3s]" />
              <span className="w-1.5 h-10 bg-white rounded-full animate-bounce [animation-delay:-0.15s]" />
              <span className="w-1.5 h-12 bg-white rounded-full animate-bounce" />
              <span className="w-1.5 h-8 bg-white rounded-full animate-bounce [animation-delay:-0.2s]" />
              <span className="w-1.5 h-5 bg-white rounded-full animate-bounce [animation-delay:-0.35s]" />
            </div>
          ) : visualState === 'understanding' ? (
            /* Rotating Neural Sparkle */
            <div className="z-10 flex flex-col items-center">
              <Sparkles className="w-9 h-9 sm:w-11 sm:h-11 text-white animate-spin" />
            </div>
          ) : visualState === 'planning' || visualState === 'preparing' ? (
            /* Layered Journey Planning Pulse */
            <div className="z-10 flex flex-col items-center">
              <Layers className="w-9 h-9 sm:w-11 sm:h-11 text-white animate-pulse" />
            </div>
          ) : visualState === 'doing' || visualState === 'answering' ? (
            /* Vocalizer Pulse */
            <div className="z-10 flex items-center gap-1">
              <span className="w-1 h-4 bg-white/90 rounded-full animate-pulse" />
              <span className="w-1 h-8 bg-white rounded-full animate-pulse [animation-delay:150ms]" />
              <span className="w-1.5 h-11 bg-white rounded-full animate-pulse [animation-delay:300ms]" />
              <span className="w-1 h-7 bg-white rounded-full animate-pulse [animation-delay:150ms]" />
              <span className="w-1 h-4 bg-white/90 rounded-full animate-pulse" />
            </div>
          ) : visualState === 'checking' ? (
            /* Checkpoint Verification Target */
            <div className="z-10 flex flex-col items-center">
              <Target className="w-9 h-9 sm:w-11 sm:h-11 text-white animate-ping" />
            </div>
          ) : visualState === 'adjusting' ? (
            /* Adaptive Replanning Rotation */
            <div className="z-10 flex flex-col items-center">
              <RotateCcw className="w-9 h-9 sm:w-11 sm:h-11 text-white animate-spin" />
            </div>
          ) : visualState === 'completed' ? (
            /* Done Checkmark Celebration */
            <div className="z-10 flex flex-col items-center">
              <CheckCircle2 className="w-10 h-10 sm:w-12 sm:h-12 text-white drop-shadow-md animate-in zoom-in-75 duration-300" />
            </div>
          ) : (
            /* Idle Signature Orange K Logo */
            <div className="z-10 flex flex-col items-center justify-center group-hover:scale-110 transition-transform">
              <span className="text-4xl sm:text-5xl font-black text-white font-['Plus_Jakarta_Sans',sans-serif] tracking-tight drop-shadow-sm">
                K
              </span>
            </div>
          )}

          {/* Tap-to-Talk subtle micro-tooltip */}
          <span className="absolute -bottom-2 text-[10px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-stone-900/90 text-white shadow-md border border-white/20">
            {visualState === 'listening' ? 'Tap to Stop' : 'Tap to Talk'}
          </span>
        </div>
      </div>

      {/* 2. THE KAJU INVOCATION & SUBTITLE */}
      <div className="text-center px-4 max-w-xl mx-auto space-y-1 mb-3 sm:mb-4">
        <h1 className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight flex items-center justify-center gap-2">
          <span>{currentStatusInfo.title}</span>
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 font-medium line-clamp-2">
          {currentStatusInfo.subtitle}
        </p>
      </div>

      {/* 3. KAJU JOURNEY RAIL: GOAL → NOW → NEXT → CHECK → DONE */}
      <div className="w-full max-w-2xl px-4 mb-3">
        <div className="flex items-center justify-between p-2 rounded-2xl bg-stone-100/95 border border-stone-200/90 shadow-2xs overflow-x-auto">
          {(['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'] as JourneyStage[]).map((stage, idx) => {
            const currentStageIndex = activeGoal
              ? ['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'].indexOf(activeGoal.currentStage)
              : -1;
            const isCompleted = activeGoal
              ? activeGoal.status === 'completed' || currentStageIndex > idx
              : false;
            const isCurrent = activeGoal
              ? activeGoal.status === 'active' && activeGoal.currentStage === stage
              : idx === 0 && !activeGoal;

            return (
              <React.Fragment key={stage}>
                <div
                  className={`flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-xl text-[10px] sm:text-xs font-black tracking-wider transition-all duration-300 ${
                    isCurrent
                      ? 'bg-amber-600 text-white shadow-xs scale-105 ring-2 ring-amber-300/80 animate-pulse'
                      : isCompleted
                      ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                      : 'text-stone-400 bg-white/70 border border-stone-200/60'
                  }`}
                  title={`Stage: ${stage}`}
                >
                  {isCompleted ? (
                    <Check className="w-3 h-3 text-emerald-700 shrink-0" />
                  ) : isCurrent ? (
                    <span className="w-1.5 h-1.5 rounded-full bg-white shrink-0" />
                  ) : null}
                  <span>{stage}</span>
                </div>
                {idx < 4 && (
                  <ArrowRight
                    className={`w-3 h-3 shrink-0 ${
                      isCompleted ? 'text-emerald-500' : 'text-stone-300'
                    }`}
                  />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* 4. ONE PRIMARY ACTION CARD (for Active Journey) */}
      {activeGoal && activeGoal.status === 'active' && (
        <div className="w-full max-w-2xl px-4 mb-4 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="rounded-3xl border-2 border-amber-400 bg-linear-to-r from-amber-500/10 via-orange-500/10 to-amber-500/5 p-4 sm:p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2 min-w-0">
                <span className="p-1.5 rounded-xl bg-amber-600 text-white shadow-2xs">
                  <Target className="w-4 h-4" />
                </span>
                <div className="min-w-0">
                  <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                    Active Journey • Stage: {activeGoal.currentStage}
                  </span>
                  <h3 className="text-sm sm:text-base font-extrabold text-stone-900 truncate mt-0.5">
                    {activeGoal.title}
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                {onOpenReplayModal && (
                  <button
                    type="button"
                    onClick={() => onOpenReplayModal(activeGoal)}
                    className="text-[11px] font-bold text-amber-900 bg-white hover:bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-300 shadow-2xs transition-colors cursor-pointer"
                  >
                    View Replay
                  </button>
                )}
                {onDismissGoal && (
                  <button
                    type="button"
                    onClick={() => onDismissGoal(activeGoal.id)}
                    className="text-[11px] font-medium text-stone-400 hover:text-stone-700 px-1.5 py-1 transition-colors cursor-pointer"
                    title="Dismiss active goal"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            </div>

            {/* Current Step Description */}
            {(() => {
              const currentStep =
                activeGoal.steps.find((s) => s.id === activeGoal.currentStepId) ||
                activeGoal.steps.find((s) => s.stage === activeGoal.currentStage) ||
                activeGoal.steps[1];
              return (
                <div className="space-y-2.5">
                  <div className="p-3 bg-white/90 rounded-2xl border border-amber-200 text-xs sm:text-sm text-stone-800 font-medium leading-relaxed">
                    <span className="font-bold text-amber-950 block mb-0.5">
                      {currentStep.title}
                    </span>
                    {currentStep.description}
                  </div>

                  {/* ONE OBVIOUS PRIMARY ACTION BUTTON */}
                  {onExecutePrimaryAction && (
                    <button
                      type="button"
                      onClick={() => onExecutePrimaryAction(currentStep.primaryAction.prompt)}
                      className="w-full py-3 px-4 rounded-2xl bg-linear-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-700 hover:to-orange-700 text-white font-extrabold text-xs sm:text-sm shadow-md shadow-amber-900/15 flex items-center justify-center gap-2 transition-all cursor-pointer group active:scale-[0.99]"
                    >
                      <Play className="w-4 h-4 fill-white shrink-0 group-hover:translate-x-0.5 transition-transform" />
                      <span>{currentStep.primaryAction.label}</span>
                      <ArrowRight className="w-4 h-4 shrink-0 group-hover:translate-x-1 transition-transform" />
                    </button>
                  )}
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* 5. GOAL-FOCUSED NATURAL SUGGESTIONS */}
      <div className="w-full max-w-2xl px-4 pt-2">
        <div className="flex flex-wrap items-center justify-center gap-1.5 text-xs">
          <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider mr-1">
            Start Goal / Ask:
          </span>
          {[
            { label: 'Japanese zero se', text: 'Kaju mujhe Japanese zero se sikhana.' },
            { label: 'Electric cars research', text: 'Kaju, electric cars par detailed research karo.' },
            { label: 'Next step in Kaju AI', text: 'Kaju, mere Kaju AI project ka next step kya hai?' },
            { label: 'Maths exam in 10 days', text: 'Kaju, I have a maths exam in 10 days. Help me finish preparation.' },
            { label: 'Photosynthesis samjhao', text: 'Kaju, mujhe photosynthesis step by step samjhao' },
            { label: 'YouTube kholo', text: 'Kaju, YouTube kholo' },
          ].map((sugg) => (
            <button
              key={sugg.label}
              type="button"
              onClick={() => onSelectSuggestion(sugg.text)}
              className="px-2.5 py-1 rounded-xl bg-white hover:bg-amber-50 text-stone-700 hover:text-amber-900 text-xs font-medium border border-amber-200/80 shadow-2xs transition-colors cursor-pointer"
            >
              &ldquo;{sugg.label}&rdquo;
            </button>
          ))}
        </div>

        {/* Subtle Boredom & Companion Shortcut */}
        <div className="flex items-center justify-center pt-2.5">
          <button
            type="button"
            onClick={() => onSelectSuggestion("Kaju, bore ho raha hu! Chal koi mast game khelte hain 😄")}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-200 text-xs font-semibold shadow-2xs hover:scale-102 transition-all cursor-pointer group"
          >
            <span className="text-sm">🎮</span>
            <span>Bored? Let&apos;s play or chat</span>
            <ArrowRight className="w-3 h-3 text-purple-600 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      </div>

      {/* 6. RECENTLY COMPLETED GOALS (Kaju Replay Section on Home) */}
      {recentlyCompletedGoals && recentlyCompletedGoals.length > 0 && (
        <div className="w-full max-w-2xl px-4 pt-5 space-y-2.5 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-black uppercase tracking-wider text-stone-600 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-600" />
              Recently Completed • Kaju Replay
            </span>
            <span className="text-[11px] text-stone-400 font-medium">
              {recentlyCompletedGoals.length} Finished
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {recentlyCompletedGoals.slice(0, 4).map((cGoal) => (
              <div
                key={cGoal.id}
                onClick={() => onOpenReplayModal?.(cGoal)}
                className="p-3 bg-white/95 hover:bg-amber-50/80 border border-stone-200/90 hover:border-amber-300 rounded-2xl shadow-2xs transition-all cursor-pointer flex items-center justify-between gap-2 group"
              >
                <div className="min-w-0">
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 inline-block mb-1">
                    Done ✓
                  </span>
                  <h4 className="text-xs font-bold text-stone-900 truncate group-hover:text-amber-900">
                    {cGoal.title}
                  </h4>
                  <p className="text-[11px] text-stone-500 truncate">
                    {cGoal.replayEvents[cGoal.replayEvents.length - 1]?.description || 'Goal completed'}
                  </p>
                </div>
                <ArrowRight className="w-4 h-4 text-stone-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-all shrink-0" />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export interface KajuGoalBannerProps {
  activeGoal: Goal;
  onOpenReplayModal?: (goal: Goal) => void;
  onDismissGoal?: (goalId: string) => void;
  onExecutePrimaryAction?: (prompt: string) => void;
}

export const KajuGoalBanner: React.FC<KajuGoalBannerProps> = ({
  activeGoal,
  onOpenReplayModal,
  onDismissGoal,
  onExecutePrimaryAction,
}) => {
  if (!activeGoal || activeGoal.status !== 'active') return null;

  const currentStep =
    activeGoal.steps.find((s) => s.id === activeGoal.currentStepId) ||
    activeGoal.steps.find((s) => s.stage === activeGoal.currentStage) ||
    activeGoal.steps[1];

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-6 pt-2 pb-1 animate-in fade-in duration-300">
      <div className="rounded-2xl border border-amber-300/80 bg-amber-50/90 p-3 sm:p-4 shadow-xs space-y-2.5">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 min-w-0">
            <span className="p-1 rounded-xl bg-amber-600 text-white shadow-2xs">
              <Target className="w-3.5 h-3.5" />
            </span>
            <div className="min-w-0">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-800 bg-amber-200/80 px-2 py-0.5 rounded-full">
                Active Goal • Stage: {activeGoal.currentStage}
              </span>
              <h3 className="text-xs sm:text-sm font-extrabold text-stone-900 truncate mt-0.5">
                {activeGoal.title}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {onOpenReplayModal && (
              <button
                type="button"
                onClick={() => onOpenReplayModal(activeGoal)}
                className="text-[10px] font-bold text-amber-900 bg-white hover:bg-amber-100 px-2 py-0.5 rounded-lg border border-amber-300 shadow-2xs transition-colors cursor-pointer"
              >
                Replay
              </button>
            )}
            {onDismissGoal && (
              <button
                type="button"
                onClick={() => onDismissGoal(activeGoal.id)}
                className="text-[10px] font-medium text-stone-400 hover:text-stone-700 px-1 py-0.5 transition-colors cursor-pointer"
                title="Dismiss active goal"
              >
                Dismiss
              </button>
            )}
          </div>
        </div>

        {/* 5-stage mini bar */}
        <div className="flex items-center justify-between p-1.5 rounded-xl bg-white/90 border border-amber-200/70 text-[10px] overflow-x-auto">
          {(['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'] as JourneyStage[]).map((stage, idx) => {
            const currentStageIndex = ['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'].indexOf(
              activeGoal.currentStage
            );
            const isCompleted = activeGoal.status === 'completed' || currentStageIndex > idx;
            const isCurrent = activeGoal.status === 'active' && activeGoal.currentStage === stage;

            return (
              <React.Fragment key={stage}>
                <span
                  className={`px-2 py-0.5 rounded-md font-bold tracking-wider ${
                    isCurrent
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : isCompleted
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'text-stone-400'
                  }`}
                >
                  {stage}
                </span>
                {idx < 4 && <ArrowRight className="w-2.5 h-2.5 text-stone-300 shrink-0" />}
              </React.Fragment>
            );
          })}
        </div>

        {/* Step description and execute button */}
        {currentStep && (
          <div className="flex items-center justify-between gap-2 pt-0.5">
            <span className="text-xs text-stone-700 font-medium truncate">
              <strong className="text-amber-950">{currentStep.title}:</strong>{' '}
              {currentStep.description}
            </span>
            {onExecutePrimaryAction && (
              <button
                type="button"
                onClick={() => onExecutePrimaryAction(currentStep.primaryAction.prompt)}
                className="shrink-0 px-3 py-1 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1 shadow-2xs transition-colors cursor-pointer"
              >
                <Play className="w-3 h-3 fill-white" />
                <span>{currentStep.primaryAction.label}</span>
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// Also export KajuHero as default KajuCore for backwards compatibility
export const KajuCore = KajuHero;

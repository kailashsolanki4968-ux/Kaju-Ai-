import React, { useState } from 'react';
import {
  GraduationCap,
  Camera,
  Mic,
  Zap,
  Lightbulb,
  Sparkles,
  ArrowRight,
  MessageSquare,
  BookOpen,
  Atom,
  Languages,
  Clock,
  Compass,
} from 'lucide-react';
import { KajuLogo } from './KajuLogo';
import { Conversation, LanguagePreference } from '../types';

interface KajuHomeProps {
  onStartStudy: (subject?: string, mode?: string) => void;
  onOpenVision: () => void;
  onOpenVoice: () => void;
  onOpenActions: () => void;
  onOpenChats: () => void;
  onSelectPrompt: (prompt: string) => void;
  recentConversations: Conversation[];
  onSelectChat: (id: string) => void;
  language: LanguagePreference;
}

export const KajuHome: React.FC<KajuHomeProps> = ({
  onStartStudy,
  onOpenVision,
  onOpenVoice,
  onOpenActions,
  onOpenChats,
  onSelectPrompt,
  recentConversations,
  onSelectChat,
  language,
}) => {
  const [kajuModeInput, setKajuModeInput] = useState('');

  const handleKajuModeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = kajuModeInput.trim();
    if (!trimmed) return;
    onSelectPrompt(trimmed);
  };

  const sampleCommands = [
    { label: 'YouTube kholo', command: 'Kaju, YouTube kholo' },
    { label: 'Photosynthesis samjhao', command: 'Kaju, mujhe photosynthesis samjhao' },
    { label: 'WhatsApp message', command: 'Kaju, WhatsApp message ready karo' },
    { label: 'Pythagoras theorem', command: 'Kaju, Pythagoras theorem step by step samjhao' },
  ];

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-6 sm:py-8 space-y-8 animate-in fade-in duration-300">
      {/* 1. Kaju AI Welcome Greeting */}
      <section className="text-center space-y-3 pt-2">
        <div className="inline-flex items-center justify-center p-2 rounded-2xl bg-amber-500/10 border border-amber-300/60 shadow-xs mb-1">
          <KajuLogo size="lg" showText={false} />
        </div>
        <div className="flex items-center justify-center gap-2">
          <h1 className="text-2xl sm:text-4xl font-extrabold text-stone-900 tracking-tight">
            Kaju AI
          </h1>
          <span className="text-xs sm:text-sm font-bold px-2.5 py-0.5 rounded-full bg-linear-to-r from-amber-500 to-orange-500 text-white shadow-xs">
            काजू
          </span>
        </div>
        <p className="text-xl sm:text-2xl font-bold text-amber-900/90 tracking-tight">
          Namaste 👋 Main Kaju hoon.
        </p>
        <p className="text-sm sm:text-base text-stone-600 font-medium">
          Batao, aaj kya karna hai?
        </p>
      </section>

      {/* 2. Prominent "⚡ Kaju Mode" Quick Action Bar */}
      <section className="relative overflow-hidden rounded-3xl bg-linear-to-br from-amber-500 via-orange-500 to-amber-600 p-0.5 shadow-md shadow-amber-900/10">
        <div className="rounded-[22px] bg-white/98 backdrop-blur-md p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-amber-500 text-white shadow-2xs">
                <Zap className="w-4 h-4 fill-white" />
              </span>
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-stone-900 flex items-center gap-2">
                  <span>⚡ Kaju Mode</span>
                  <span className="text-[11px] font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                    Smart Intent Router
                  </span>
                </h2>
                <p className="text-xs text-stone-500">
                  Say or type: &ldquo;Kaju, mere liye ye kaam karo...&rdquo;
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onOpenVoice}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-100/80 hover:bg-amber-200/80 text-amber-900 text-xs font-semibold border border-amber-300 transition-colors cursor-pointer self-start sm:self-auto"
            >
              <Mic className="w-3.5 h-3.5 text-amber-700 animate-pulse" />
              <span>Bolkar bolo (Voice)</span>
            </button>
          </div>

          <form onSubmit={handleKajuModeSubmit} className="relative flex items-center gap-2">
            <input
              type="text"
              value={kajuModeInput}
              onChange={(e) => setKajuModeInput(e.target.value)}
              placeholder="Kaju, mere liye ye kaam karo... (e.g. YouTube kholo, question solve karo)"
              className="w-full py-3 pl-4 pr-24 rounded-2xl bg-stone-50 border border-amber-200/90 text-stone-900 placeholder:text-stone-400 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all shadow-inner"
            />
            <button
              type="submit"
              disabled={!kajuModeInput.trim()}
              className="absolute right-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold transition-all shadow-xs cursor-pointer disabled:cursor-not-allowed"
            >
              Start
            </button>
          </form>

          {/* Quick sample chips */}
          <div className="flex items-center gap-1.5 mt-3 overflow-x-auto pb-1 text-xs">
            <span className="text-stone-600 text-[11px] shrink-0 font-medium">Try:</span>
            {sampleCommands.map((cmd) => (
              <button
                key={cmd.label}
                type="button"
                onClick={() => onSelectPrompt(cmd.command)}
                className="shrink-0 px-2.5 py-1 rounded-xl bg-amber-50 hover:bg-amber-100/90 text-amber-900 text-[11px] font-medium border border-amber-200/70 transition-colors cursor-pointer"
              >
                &ldquo;{cmd.label}&rdquo;
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Five Large Interactive Cards */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold uppercase tracking-wider text-stone-600 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            Main Kaju Features
          </h2>
          <span className="text-xs text-stone-600">Select any card to begin</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4">
          {/* Card 1: 🎓 Padhai */}
          <button
            type="button"
            onClick={() => onStartStudy()}
            className="group text-left p-5 rounded-3xl bg-white border border-amber-200/90 hover:border-amber-400 hover:shadow-lg hover:shadow-amber-500/10 transition-all cursor-pointer flex flex-col justify-between min-h-[160px] relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-100/50 rounded-full blur-xl -mr-6 -mt-6 group-hover:scale-125 transition-transform" />
            <div className="space-y-2">
              <div className="w-11 h-11 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <GraduationCap className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>🎓 Padhai</span>
                <span className="text-xs font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  Study Mode
                </span>
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Step-by-step explanations, formulas, exam prep, and solutions for all school subjects.
              </p>
            </div>
            <div className="flex items-center text-xs font-bold text-amber-700 mt-4 group-hover:translate-x-1 transition-transform">
              <span>Open Study Assistant</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </button>

          {/* Card 2: 📷 Photo se samjhao */}
          <button
            type="button"
            onClick={onOpenVision}
            className="group text-left p-5 rounded-3xl bg-white border border-rose-200/80 hover:border-rose-400 hover:shadow-lg hover:shadow-rose-500/10 transition-all cursor-pointer flex flex-col justify-between min-h-[160px] relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-rose-100/50 rounded-full blur-xl -mr-6 -mt-6 group-hover:scale-125 transition-transform" />
            <div className="space-y-2">
              <div className="w-11 h-11 rounded-2xl bg-rose-500 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <Camera className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>📷 Photo se samjhao</span>
                <span className="text-xs font-semibold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full">
                  Kaju Vision
                </span>
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Snap or upload questions, handwritten notes, diagrams, and textbook pages.
              </p>
            </div>
            <div className="flex items-center text-xs font-bold text-rose-700 mt-4 group-hover:translate-x-1 transition-transform">
              <span>Scan & Explain</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </button>

          {/* Card 3: 🎙️ Kaju se baat karo */}
          <button
            type="button"
            onClick={onOpenVoice}
            className="group text-left p-5 rounded-3xl bg-white border border-indigo-200/80 hover:border-indigo-400 hover:shadow-lg hover:shadow-indigo-500/10 transition-all cursor-pointer flex flex-col justify-between min-h-[160px] relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-100/50 rounded-full blur-xl -mr-6 -mt-6 group-hover:scale-125 transition-transform" />
            <div className="space-y-2">
              <div className="w-11 h-11 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <Mic className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>🎙️ Kaju se baat karo</span>
                <span className="text-xs font-semibold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full">
                  Voice Assistant
                </span>
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Hands-free voice assistant. Speak naturally in Hindi, English, or Hinglish with speech replies.
              </p>
            </div>
            <div className="flex items-center text-xs font-bold text-indigo-700 mt-4 group-hover:translate-x-1 transition-transform">
              <span>Start Voice Talk</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </button>

          {/* Card 4: ⚡ Kaju se kaam karwao */}
          <button
            type="button"
            onClick={onOpenActions}
            className="group text-left p-5 rounded-3xl bg-white border border-amber-200/90 hover:border-amber-400 hover:shadow-lg hover:shadow-amber-500/10 transition-all cursor-pointer flex flex-col justify-between min-h-[160px] relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-100/50 rounded-full blur-xl -mr-6 -mt-6 group-hover:scale-125 transition-transform" />
            <div className="space-y-2">
              <div className="w-11 h-11 rounded-2xl bg-amber-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <Zap className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>⚡ Kaju se kaam karwao</span>
                <span className="text-xs font-semibold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                  Safe Actions
                </span>
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed">
                Draft WhatsApp messages, open phone dialer, launch YouTube/Maps with zero-click confirmation safety.
              </p>
            </div>
            <div className="flex items-center text-xs font-bold text-amber-700 mt-4 group-hover:translate-x-1 transition-transform">
              <span>Explore Kaju Actions</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </button>

          {/* Card 5: 💡 Kuch bhi pucho */}
          <button
            type="button"
            onClick={onOpenChats}
            className="group text-left p-5 rounded-3xl bg-white border border-emerald-200/80 hover:border-emerald-400 hover:shadow-lg hover:shadow-emerald-500/10 transition-all cursor-pointer flex flex-col justify-between min-h-[160px] relative overflow-hidden sm:col-span-2 lg:col-span-2"
          >
            <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-100/50 rounded-full blur-xl -mr-6 -mt-6 group-hover:scale-125 transition-transform" />
            <div className="space-y-2">
              <div className="w-11 h-11 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                <Lightbulb className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>💡 Kuch bhi pucho</span>
                <span className="text-xs font-semibold text-stone-600 bg-stone-100 px-2 py-0.5 rounded-full">
                  Direct Chat
                </span>
              </h3>
              <p className="text-xs text-stone-600 leading-relaxed max-w-xl">
                Ask any question, brainstorm ideas, practice languages, or have a warm and polite conversation.
              </p>
            </div>
            <div className="flex items-center text-xs font-bold text-emerald-700 mt-4 group-hover:translate-x-1 transition-transform">
              <span>Go to Chat</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </div>
          </button>
        </div>
      </section>

      {/* 4. Subject Shortcuts & Study Pills */}
      <section className="bg-amber-50/70 border border-amber-200/70 rounded-3xl p-4 sm:p-6 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-amber-700" />
            School Subjects • कक्षा 1 से 12 तक
          </h2>
          <span className="text-[11px] text-amber-800 font-medium">Bilingual Step-by-Step</span>
        </div>

        <div className="flex flex-wrap gap-2">
          {[
            { name: 'Mathematics (गणित)', query: 'Kaju, class 10 math trigonometry formula aur example samjhao' },
            { name: 'Physics (भौतिकी)', query: 'Kaju, Newton ke teeno laws real-life example ke sath samjhao' },
            { name: 'Chemistry (रसायन)', query: 'Kaju, chemical reaction balancing ka simple rule kya hai?' },
            { name: 'Biology (जीव विज्ञान)', query: 'Kaju, human heart circulatory system step by step explain karo' },
            { name: 'English Grammar', query: 'Kaju, active and passive voice rules with examples samjhao' },
            { name: 'Hindi Vyakaran (व्याकरण)', query: 'Kaju, sandhi aur samas mein kya antar hai udaharan sahit batao' },
            { name: 'History & Civics', query: 'Kaju, Indian Constitution ke fundamental rights simple bhasha mein batao' },
          ].map((subj) => (
            <button
              key={subj.name}
              type="button"
              onClick={() => onSelectPrompt(subj.query)}
              className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-100/80 text-stone-800 text-xs font-medium border border-amber-200 shadow-2xs hover:border-amber-300 transition-all cursor-pointer"
            >
              {subj.name}
            </button>
          ))}
        </div>
      </section>

      {/* 5. Recent Conversations (if any) */}
      {recentConversations.filter((c) => c.messages.length > 0).length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-wider text-stone-600 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              Recent Conversations • हाल की बातचीत
            </h2>
            <button
              type="button"
              onClick={onOpenChats}
              className="text-xs text-amber-700 font-bold hover:underline cursor-pointer"
            >
              View all
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {recentConversations
              .filter((c) => c.messages.length > 0)
              .slice(0, 3)
              .map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onSelectChat(c.id)}
                  className="text-left p-3.5 rounded-2xl bg-white border border-stone-200/90 hover:border-amber-300 hover:shadow-xs transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <MessageSquare className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span className="text-xs font-bold text-stone-900 truncate group-hover:text-amber-700">
                      {c.title}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-500 line-clamp-2 leading-relaxed">
                    {c.messages[c.messages.length - 1]?.content.replace(/<!--[\s\S]*?-->/g, '') ||
                      'Open conversation'}
                  </p>
                  <span className="inline-block mt-2 text-[10px] text-stone-600 font-medium">
                    {c.messages.length} messages • {new Date(c.updatedAt).toLocaleDateString()}
                  </span>
                </button>
              ))}
          </div>
        </section>
      )}
    </div>
  );
};

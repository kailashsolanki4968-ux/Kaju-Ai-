import React, { useState } from 'react';
import {
  Search,
  UserCheck,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Building2,
  ExternalLink,
  X,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  User,
  Phone,
} from 'lucide-react';
import { KajuPublicProfile } from '../types';
import {
  loadMyProfile,
  saveMyProfile,
  lookupKajuIdentity,
  LookupResult,
} from '../utils/identityHelper';

interface KajuIdentityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KajuIdentityModal: React.FC<KajuIdentityModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'lookup' | 'settings'>('lookup');
  const [queryInput, setQueryInput] = useState('');
  const [lookupResult, setLookupResult] = useState<LookupResult | null>(null);

  // My Discovery Settings
  const [myProfile, setMyProfile] = useState<KajuPublicProfile>(() => loadMyProfile());
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!queryInput.trim()) return;
    const res = lookupKajuIdentity(queryInput);
    setLookupResult(res);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    saveMyProfile(myProfile);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-amber-200 animate-in zoom-in-95 duration-200 max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200/90 bg-stone-50/80 shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-linear-to-tr from-amber-600 to-orange-600 text-white shadow-2xs">
              <UserCheck className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-stone-900 flex items-center gap-2">
                <span>Kaju Number & ID Check</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  Opt-In Identity
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                Discover registered public profiles or configure your own discoverability.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-200 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-stone-200 px-5 pt-2 bg-stone-50/40">
          <button
            type="button"
            onClick={() => setActiveTab('lookup')}
            className={`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'lookup'
                ? 'border-amber-600 text-amber-900'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            Number / ID Lookup
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('settings')}
            className={`pb-2.5 px-3 text-xs font-bold border-b-2 transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'border-amber-600 text-amber-900'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            My Discovery Settings
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'lookup' ? (
            <div className="space-y-4">
              {/* Privacy Banner */}
              <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200 text-xs text-amber-950 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <p className="text-[11px] leading-relaxed">
                  <strong>Strict Privacy Architecture:</strong> Kaju only displays accounts that have explicitly chosen to make their profile public. We never query telecom carriers, private contacts, or personal data.
                </p>
              </div>

              {/* Search Form */}
              <form onSubmit={handleLookup} className="space-y-2">
                <label className="text-xs font-bold text-stone-700 block">
                  Search Phone Number or @KajuID:
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={queryInput}
                      onChange={(e) => setQueryInput(e.target.value)}
                      placeholder="e.g. +91 98765 43210 or @solanki_labs"
                      className="w-full pl-9 pr-3 py-2 rounded-xl border border-stone-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-xs sm:text-sm outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer shrink-0"
                  >
                    Check
                  </button>
                </div>
              </form>

              {/* Quick Sample Queries */}
              <div className="flex items-center gap-1.5 flex-wrap text-xs text-stone-500 pt-1">
                <span className="text-[10px] font-bold uppercase tracking-wider">Try sample:</span>
                {[
                  { label: 'Official Support', val: '+91 80000 12345' },
                  { label: 'Solanki Labs', val: '+91 98765 43210' },
                  { label: 'Priya (Physics)', val: '@priya_tutor' },
                ].map((s) => (
                  <button
                    key={s.label}
                    type="button"
                    onClick={() => {
                      setQueryInput(s.val);
                      const res = lookupKajuIdentity(s.val);
                      setLookupResult(res);
                    }}
                    className="px-2 py-0.5 rounded-lg bg-stone-100 hover:bg-amber-100 text-stone-700 text-[11px] font-medium border border-stone-200 cursor-pointer"
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              {/* Lookup Result Card */}
              {lookupResult && (
                <div className="pt-2 animate-in fade-in duration-200">
                  {lookupResult.status === 'found' && lookupResult.profile ? (
                    <div className="p-4 rounded-2xl border-2 border-emerald-300 bg-emerald-50/40 space-y-3">
                      <div className="flex items-start justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-2xl bg-amber-600 text-white font-extrabold text-base flex items-center justify-center shadow-xs">
                            {lookupResult.profile.displayName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <h4 className="font-extrabold text-stone-900 text-sm sm:text-base">
                                {lookupResult.profile.displayName}
                              </h4>
                              {lookupResult.profile.verified && (
                                <span title="Verified Account" className="inline-flex items-center">
                                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                                </span>
                              )}
                            </div>
                            <span className="text-xs text-stone-500 font-mono">
                              @{lookupResult.profile.kajuId}
                            </span>
                          </div>
                        </div>

                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
                          Verified Public Profile
                        </span>
                      </div>

                      <p className="text-xs text-stone-700 leading-relaxed bg-white p-3 rounded-xl border border-emerald-100">
                        {lookupResult.profile.bio}
                      </p>

                      <div className="flex items-center gap-3 text-xs text-stone-600 flex-wrap">
                        <span>Account: <strong>{lookupResult.profile.accountType}</strong></span>
                        <span>•</span>
                        <span>Location: <strong>{lookupResult.profile.location || 'India'}</strong></span>
                        <span>•</span>
                        <span>Joined: <strong>{lookupResult.profile.joinedDate}</strong></span>
                      </div>

                      {lookupResult.profile.links && lookupResult.profile.links.length > 0 && (
                        <div className="flex items-center gap-2 pt-1 border-t border-emerald-200/60">
                          {lookupResult.profile.links.map((link, idx) => (
                            <a
                              key={idx}
                              href={link.url}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 hover:text-amber-950 underline"
                            >
                              <span>{link.label}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : lookupResult.status === 'private' ? (
                    <div className="p-4 rounded-2xl border border-amber-300 bg-amber-50/60 space-y-1.5 text-xs text-stone-800">
                      <div className="flex items-center gap-2 text-amber-900 font-bold">
                        <Lock className="w-4 h-4 text-amber-700" />
                        <span>Private Account</span>
                      </div>
                      <p className="text-[11px] text-stone-600 leading-relaxed">
                        {lookupResult.message}
                      </p>
                    </div>
                  ) : (
                    <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50 space-y-1.5 text-xs text-stone-700">
                      <div className="flex items-center gap-2 text-stone-800 font-bold">
                        <ShieldAlert className="w-4 h-4 text-stone-500" />
                        <span>Not Discoverable</span>
                      </div>
                      <p className="text-[11px] text-stone-600 leading-relaxed">
                        {lookupResult.message}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            /* My Discovery Settings Tab */
            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-stone-50 border border-stone-200">
                <div>
                  <span className="text-xs font-bold text-stone-900 block">Make Profile Discoverable</span>
                  <span className="text-[11px] text-stone-500">
                    {myProfile.isPublic
                      ? 'Public • Others can discover your public badge & bio'
                      : 'Private (Default) • Your number is hidden and never discoverable'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setMyProfile((prev) => ({ ...prev, isPublic: !prev.isPublic }))}
                  className="cursor-pointer"
                >
                  {myProfile.isPublic ? (
                    <ToggleRight className="w-8 h-8 text-amber-600" />
                  ) : (
                    <ToggleLeft className="w-8 h-8 text-stone-400" />
                  )}
                </button>
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Display Name</label>
                <input
                  type="text"
                  value={myProfile.displayName}
                  onChange={(e) => setMyProfile((p) => ({ ...p, displayName: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs sm:text-sm outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Kaju ID (@handle)</label>
                <input
                  type="text"
                  value={myProfile.kajuId}
                  onChange={(e) => setMyProfile((p) => ({ ...p, kajuId: e.target.value }))}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs sm:text-sm outline-none focus:border-amber-500 font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Public Bio</label>
                <textarea
                  value={myProfile.bio}
                  onChange={(e) => setMyProfile((p) => ({ ...p, bio: e.target.value }))}
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs sm:text-sm outline-none focus:border-amber-500 resize-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">Account Type</label>
                <select
                  value={myProfile.accountType}
                  onChange={(e) => setMyProfile((p) => ({ ...p, accountType: e.target.value as any }))}
                  className="w-full px-3 py-2 rounded-xl border border-stone-300 text-xs sm:text-sm outline-none focus:border-amber-500 bg-white"
                >
                  <option value="personal">Personal Account</option>
                  <option value="creator">Creator / Educator</option>
                  <option value="business">Business / Organization</option>
                </select>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Save Discovery Settings</span>
                </button>
                {saveSuccess && (
                  <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Saved!</span>
                  </span>
                )}
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';

interface KajuLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
}

export const KajuLogo: React.FC<KajuLogoProps> = ({
  size = 'md',
  className = '',
  showText = false,
}) => {
  const sizeMap = {
    sm: { box: 'w-7 h-7 text-xs', icon: 16 },
    md: { box: 'w-9 h-9 text-sm', icon: 20 },
    lg: { box: 'w-12 h-12 text-base', icon: 26 },
    xl: { box: 'w-16 h-16 text-xl', icon: 34 },
  };

  const { box } = sizeMap[size];

  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      <div
        id="kaju-brand-logo"
        className={`${box} rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 shadow-sm shadow-amber-900/10 flex items-center justify-center font-bold text-white select-none ring-1 ring-white/20`}
        aria-label="Kaju AI Logo"
      >
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-3/5 h-3/5"
        >
          {/* Stylized Modern Letter K */}
          <path
            d="M9 6V26"
            stroke="currentColor"
            strokeWidth="3.4"
            strokeLinecap="round"
          />
          <path
            d="M23 7L11.5 17.5"
            stroke="currentColor"
            strokeWidth="3.4"
            strokeLinecap="round"
          />
          <path
            d="M14 15.5L23.5 26"
            stroke="currentColor"
            strokeWidth="3.4"
            strokeLinecap="round"
          />
          {/* Warm playful dot/accent */}
          <circle cx="23" cy="7" r="1.8" fill="#FEF08A" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-stone-900 tracking-tight text-lg leading-tight">
              Kaju AI
            </span>
            <span className="text-[11px] font-semibold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-200/80">
              काजू
            </span>
          </div>
          <span className="text-[11px] text-stone-500 font-medium leading-none mt-0.5">
            Bilingual Assistant • द्विभाषी साथी
          </span>
        </div>
      )}
    </div>
  );
};

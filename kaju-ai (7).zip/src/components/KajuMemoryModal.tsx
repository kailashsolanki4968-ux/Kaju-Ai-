import React, { useState } from 'react';
import {
  Brain,
  Plus,
  Trash2,
  X,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  Info,
  Check,
  Edit2,
  Search,
  CheckCircle2,
  Tag,
  AlertCircle,
} from 'lucide-react';
import { UserMemory } from '../types';
import {
  addMemory,
  updateMemory,
  deleteMemory,
  clearMemories,
  isMemoryEnabled,
  setMemoryEnabled,
} from '../utils/memoryHelper';

interface KajuMemoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories: UserMemory[];
  onRefreshMemories: () => void;
}

export const KajuMemoryModal: React.FC<KajuMemoryModalProps> = ({
  isOpen,
  onClose,
  memories,
  onRefreshMemories,
}) => {
  const [newMemoryText, setNewMemoryText] = useState('');
  const [newCategory, setNewCategory] = useState<UserMemory['category']>('preference');
  const [memoryEnabledState, setMemoryEnabledState] = useState<boolean>(isMemoryEnabled());
  const [searchQuery, setSearchQuery] = useState('');

  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');
  const [editingCategory, setEditingCategory] = useState<UserMemory['category']>('preference');

  if (!isOpen) return null;

  const handleToggleEnable = () => {
    const next = !memoryEnabledState;
    setMemoryEnabledState(next);
    setMemoryEnabled(next);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    addMemory(newMemoryText.trim(), newCategory, 'user_stated');
    onRefreshMemories();
    setNewMemoryText('');
  };

  const handleStartEdit = (mem: UserMemory) => {
    setEditingId(mem.id);
    setEditingText(mem.content);
    setEditingCategory(mem.category);
  };

  const handleSaveEdit = (id: string) => {
    if (!editingText.trim()) return;
    updateMemory(id, editingText.trim(), editingCategory);
    setEditingId(null);
    onRefreshMemories();
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditingText('');
  };

  const handleDelete = (id: string) => {
    deleteMemory(id);
    if (editingId === id) setEditingId(null);
    onRefreshMemories();
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to delete all saved memories? This action cannot be undone.')) {
      clearMemories();
      setEditingId(null);
      onRefreshMemories();
    }
  };

  const filteredMemories = memories.filter((m) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return m.content.toLowerCase().includes(q) || m.category.toLowerCase().includes(q);
  });

  const getCategoryBadgeClass = (category: UserMemory['category']) => {
    switch (category) {
      case 'fact':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'profile':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'instruction':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'work':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      default:
        return 'bg-stone-100 text-stone-800 border-stone-200';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-amber-200 animate-in zoom-in-95 duration-200 max-h-[88vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200/90 bg-stone-50/80 shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-linear-to-tr from-amber-600 to-orange-600 text-white shadow-2xs">
              <Brain className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-stone-900 flex items-center gap-2">
                <span>Kaju Memory & Preferences</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  {memories.length} Active
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                View, edit, or delete the explicit facts and preferences Kaju remembers.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-200 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Honest Device-Local Notice */}
          <div className="p-3.5 rounded-2xl bg-amber-50/80 border border-amber-200/90 flex items-start gap-2.5 text-xs text-amber-950">
            <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold block">Reliable & Honest Memory Architecture</span>
              <p className="text-amber-900 leading-relaxed text-[11px]">
                Memories are stored locally in your browser storage for your active profile. Kaju only remembers facts you explicitly provide or approve, and never invents personal history.
                <em> Note: Real-time cross-device cloud sync requires configured and tested persistent cloud storage.</em>
              </p>
            </div>
          </div>

          {/* Toggle Enable Memory */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 border border-stone-200">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-stone-500" />
              <div>
                <span className="text-xs font-bold text-stone-900 block">Personalized Memory</span>
                <span className="text-[11px] text-stone-500">
                  {memoryEnabledState ? 'Enabled • Recalls saved preferences and facts' : 'Disabled • Memory inactive'}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleToggleEnable}
              className="text-stone-700 hover:text-amber-700 transition-colors cursor-pointer"
              title={memoryEnabledState ? 'Disable memory' : 'Enable memory'}
            >
              {memoryEnabledState ? (
                <ToggleRight className="w-8 h-8 text-amber-600" />
              ) : (
                <ToggleLeft className="w-8 h-8 text-stone-400" />
              )}
            </button>
          </div>

          {/* Add New Memory Form */}
          <form onSubmit={handleAddSubmit} className="space-y-2 p-3 rounded-2xl bg-stone-50 border border-stone-200/90">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-stone-700 block">
                Add New Explicit Fact or Preference:
              </label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="text-[11px] font-semibold px-2 py-0.5 rounded-lg border border-stone-300 bg-white text-stone-700 outline-none"
              >
                <option value="preference">Preference</option>
                <option value="fact">Fact</option>
                <option value="instruction">Instruction</option>
                <option value="profile">Profile</option>
                <option value="work">Work</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={newMemoryText}
                onChange={(e) => setNewMemoryText(e.target.value)}
                placeholder="e.g., 'Mera favourite subject Physics hai', 'Keep answers concise'"
                className="flex-1 px-3.5 py-2 rounded-xl border border-stone-300 bg-white focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-xs sm:text-sm outline-none"
              />
              <button
                type="submit"
                disabled={!newMemoryText.trim()}
                className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold transition-all cursor-pointer shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>Save</span>
              </button>
            </div>
          </form>

          {/* Search & Filter */}
          {memories.length > 2 && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search saved memories..."
                className="w-full pl-8.5 pr-3 py-1.5 rounded-xl border border-stone-200 bg-white text-xs text-stone-800 placeholder-stone-400 outline-none focus:border-amber-500"
              />
            </div>
          )}

          {/* Saved Memories List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                Saved Memories ({filteredMemories.length})
              </span>
              {memories.length > 0 && (
                <button
                  type="button"
                  onClick={handleClearAll}
                  className="text-[11px] text-rose-600 hover:underline font-medium cursor-pointer"
                >
                  Clear All
                </button>
              )}
            </div>

            {filteredMemories.length === 0 ? (
              <p className="text-xs text-stone-400 italic py-4 text-center bg-stone-50 rounded-2xl border border-stone-200/60">
                {memories.length === 0
                  ? 'No memories saved yet. Add a preference above or share facts in chat.'
                  : 'No memories match your search filter.'}
              </p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-0.5">
                {filteredMemories.map((mem) => {
                  const isEditing = editingId === mem.id;
                  return (
                    <div
                      key={mem.id}
                      className="p-3 rounded-2xl bg-stone-50 border border-stone-200/90 text-xs text-stone-800 space-y-2 transition-all"
                    >
                      {isEditing ? (
                        <div className="space-y-2">
                          <input
                            type="text"
                            value={editingText}
                            onChange={(e) => setEditingText(e.target.value)}
                            className="w-full px-3 py-1.5 rounded-xl border border-amber-400 bg-white text-xs text-stone-900 outline-none focus:ring-2 focus:ring-amber-500/20"
                            autoFocus
                          />
                          <div className="flex items-center justify-between gap-2">
                            <select
                              value={editingCategory}
                              onChange={(e) => setEditingCategory(e.target.value as any)}
                              className="text-[11px] px-2 py-1 rounded-lg border border-stone-300 bg-white text-stone-700 outline-none"
                            >
                              <option value="preference">Preference</option>
                              <option value="fact">Fact</option>
                              <option value="instruction">Instruction</option>
                              <option value="profile">Profile</option>
                              <option value="work">Work</option>
                            </select>
                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={handleCancelEdit}
                                className="px-2.5 py-1 rounded-lg border border-stone-300 text-stone-600 text-[11px] font-semibold hover:bg-stone-100 cursor-pointer"
                              >
                                Cancel
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSaveEdit(mem.id)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 text-white text-[11px] font-bold hover:bg-emerald-700 cursor-pointer"
                              >
                                Update
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-1 flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span
                                className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.2 rounded-md border ${getCategoryBadgeClass(
                                  mem.category
                                )}`}
                              >
                                {mem.category}
                              </span>
                              {mem.source === 'user_stated' && (
                                <span className="text-[10px] text-amber-800 bg-amber-50 px-1.5 py-0.2 rounded-md font-medium border border-amber-200">
                                  User Stated
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-stone-800 leading-relaxed font-medium break-words">
                              {mem.content}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0 mt-0.5">
                            <button
                              type="button"
                              onClick={() => handleStartEdit(mem)}
                              className="p-1 rounded-lg text-stone-400 hover:text-amber-600 hover:bg-amber-50 transition-colors cursor-pointer"
                              title="Edit this memory"
                              aria-label="Edit memory"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDelete(mem.id)}
                              className="p-1 rounded-lg text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                              title="Delete this memory"
                              aria-label="Delete memory"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-stone-200 bg-stone-50 flex items-center justify-between text-xs text-stone-500">
          <span>{memories.length} item{memories.length === 1 ? '' : 's'} stored on this device</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-stone-800 text-white font-bold text-xs hover:bg-stone-900 transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};


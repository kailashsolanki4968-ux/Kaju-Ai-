import React, { useState } from 'react';
import {
  User,
  ShieldCheck,
  Globe,
  Volume2,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Trash2,
  BookOpen,
  Camera,
  MessageSquare,
  Lock,
} from 'lucide-react';
import { KajuLogo } from './KajuLogo';
import { LanguagePreference, ActionPermissions } from '../types';
import { speechManager } from '../utils/speech';
import { LanguageSelectorModal } from './LanguageSelectorModal';
import { getLanguageInfo } from '../utils/languages';

interface KajuProfileViewProps {
  language: LanguagePreference;
  onLanguageChange: (newLang: LanguagePreference) => void;
  permissions: ActionPermissions;
  onOpenActionCenter: () => void;
  onClearAllChats: () => void;
  conversationCount: number;
}

export const KajuProfileView: React.FC<KajuProfileViewProps> = ({
  language,
  onLanguageChange,
  permissions,
  onOpenActionCenter,
  onClearAllChats,
  conversationCount,
}) => {
  const [isLangModalOpen, setIsLangModalOpen] = useState(false);
  const langInfo = getLanguageInfo(language);
  const [testSpeechText, setTestSpeechText] = useState(
    language === 'hindi'
      ? 'नमस्ते! मैं काजू हूँ, आपका पर्सनल एआई साथी।'
      : language === 'hinglish'
      ? 'Namaste! Main Kaju hoon, aapka personal study partner.'
      : 'Hello! I am Kaju, your personal AI companion and study mentor.'
  );
  const [isPlayingTest, setIsPlayingTest] = useState(false);

  React.useEffect(() => {
    const unsub = speechManager.subscribe((state) => {
      if (state.messageId === 'test_profile_speech') {
        setIsPlayingTest(state.status === 'playing');
      }
    });
    return unsub;
  }, []);

  const handleTestSpeech = () => {
    if (isPlayingTest) {
      speechManager.stop();
      setIsPlayingTest(false);
      return;
    }

    setIsPlayingTest(true);
    speechManager.speak('test_profile_speech', testSpeechText, language);
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-6 sm:py-8 space-y-6 animate-in fade-in duration-300">
      {/* 1. Kaju Companion Hero Card */}
      <div className="relative rounded-3xl bg-linear-to-br from-amber-500 via-orange-500 to-amber-600 p-0.5 shadow-md">
        <div className="rounded-[22px] bg-white p-6 sm:p-8 flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
          <div className="relative">
            <div className="w-20 h-20 rounded-3xl bg-linear-to-br from-amber-500 to-orange-600 p-1 shadow-md flex items-center justify-center">
              <span className="text-4xl font-extrabold text-white font-['Plus_Jakarta_Sans',sans-serif]">
                K
              </span>
            </div>
            <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center">
              <CheckCircle2 className="w-3.5 h-3.5 text-white" />
            </span>
          </div>

          <div className="space-y-1.5 flex-1 min-w-0">
            <div className="flex items-center justify-center sm:justify-start gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-extrabold text-stone-900">Kaju AI (काजू)</h2>
              <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                Personal Companion
              </span>
            </div>
            <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
              Your empathetic study mentor for all school subjects, photo solver, and safe action assistant.
            </p>
            <div className="flex items-center justify-center sm:justify-start gap-3 pt-2 text-xs text-stone-500">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Gemini AI Connected
              </span>
              <span>•</span>
              <span>{conversationCount} Conversations stored</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Language Preference */}
      <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-3 shadow-2xs">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
            <Globe className="w-4 h-4 text-amber-600" />
            Language Mode • भाषा चयन
          </h3>
          <button
            type="button"
            onClick={() => setIsLangModalOpen(true)}
            className="text-xs font-bold text-amber-800 bg-amber-100 hover:bg-amber-200 px-3 py-1 rounded-xl transition-colors cursor-pointer"
          >
            All 27+ Languages...
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {(
            [
              { id: 'auto', title: 'Auto (स्वतः)', desc: 'Matches input language' },
              { id: 'hindi', title: 'हिंदी (Hindi)', desc: 'Pure Devanagari script' },
              { id: 'english', title: 'English', desc: 'Modern clear English' },
              { id: 'hinglish', title: 'Hinglish (हिंग्लिश)', desc: 'Natural Hindi in Latin script' },
            ] as const
          ).map((item) => {
            const isSelected = language === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onLanguageChange(item.id)}
                className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-amber-500/10 border-amber-500 text-amber-950 font-bold shadow-2xs ring-1 ring-amber-500'
                    : 'bg-stone-50 hover:bg-stone-100/80 border-stone-200 text-stone-700'
                }`}
              >
                <div className="text-xs font-bold text-stone-900">{item.title}</div>
                <div className="text-[10px] text-stone-500 mt-0.5">{item.desc}</div>
              </button>
            );
          })}
        </div>

        {!['auto', 'hindi', 'english', 'hinglish'].includes(language) && (
          <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between text-xs">
            <span className="font-semibold text-stone-800">
              Active Regional/Global Language: <span className="font-bold text-amber-900">{langInfo.name} ({langInfo.nativeName})</span>
            </span>
            <button
              type="button"
              onClick={() => setIsLangModalOpen(true)}
              className="text-xs font-bold text-amber-700 hover:underline"
            >
              Change
            </button>
          </div>
        )}

        <LanguageSelectorModal
          isOpen={isLangModalOpen}
          onClose={() => setIsLangModalOpen(false)}
          selectedLanguage={language}
          onSelectLanguage={onLanguageChange}
        />
      </div>

      {/* 3. Text-to-Speech (TTS) Voice Test */}
      <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-3 shadow-2xs">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-600" />
            Speech & Audio Playback
          </h3>
          <span className="text-xs text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            Web Speech API
          </span>
        </div>
        <p className="text-xs text-stone-600 leading-relaxed">
          Kaju can speak any explanation out loud in Hindi, English, and Hinglish. Test the speech output below:
        </p>

        <div className="flex flex-col sm:flex-row items-center gap-2">
          <input
            type="text"
            value={testSpeechText}
            onChange={(e) => setTestSpeechText(e.target.value)}
            className="w-full py-2.5 px-3.5 rounded-xl bg-stone-50 border border-stone-200 text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/20"
          />
          <button
            type="button"
            onClick={handleTestSpeech}
            className={`w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              isPlayingTest
                ? 'bg-red-500 hover:bg-red-600 text-white'
                : 'bg-amber-600 hover:bg-amber-700 text-white shadow-xs'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>{isPlayingTest ? 'Stop Voice' : 'Test Speech'}</span>
          </button>
        </div>
      </div>

      {/* 4. Safety & Action Control Guarantees */}
      <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Safety & Boundaries Guarantees
          </h3>
          <button
            type="button"
            onClick={onOpenActionCenter}
            className="text-xs text-amber-700 font-bold hover:underline cursor-pointer"
          >
            Configure in Actions
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
            <span className="font-bold text-stone-900 flex items-center gap-1 text-emerald-800">
              <Lock className="w-3.5 h-3.5 text-emerald-600" />
              Zero-Click Safe Confirmation
            </span>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              Kaju NEVER silently sends WhatsApp messages or dials phone numbers. Everything requires your explicit review and tap.
            </p>
          </div>

          <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 space-y-1">
            <span className="font-bold text-stone-900 flex items-center gap-1 text-amber-800">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              Browser Sandbox Limits
            </span>
            <p className="text-[11px] text-stone-500 leading-relaxed">
              Web browsers cannot access local PC hardware, run scripts, or click mice. Kaju explains this transparently.
            </p>
          </div>
        </div>
      </div>

      {/* 5. Data Management */}
      <div className="bg-stone-50 rounded-3xl border border-stone-200 p-5 flex items-center justify-between gap-4">
        <div>
          <h4 className="text-xs font-bold text-stone-900">Manage Chat History</h4>
          <p className="text-[11px] text-stone-500">
            {conversationCount} conversation{conversationCount === 1 ? '' : 's'} saved locally on your device.
          </p>
        </div>
        <button
          type="button"
          onClick={onClearAllChats}
          className="px-3.5 py-2 rounded-xl bg-white hover:bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear History</span>
        </button>
      </div>
    </div>
  );
};

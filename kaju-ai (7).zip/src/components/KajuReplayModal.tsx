import React from 'react';
import {
  X,
  CheckCircle2,
  Calendar,
  Clock,
  ArrowRight,
  Sparkles,
  Target,
  Layers,
  Award,
  BookOpen,
} from 'lucide-react';
import { Goal, ReplayEvent } from '../types';

interface KajuReplayModalProps {
  goal: Goal | null;
  isOpen: boolean;
  onClose: () => void;
  onRestartGoal?: (goal: Goal) => void;
}

export const KajuReplayModal: React.FC<KajuReplayModalProps> = ({
  goal,
  isOpen,
  onClose,
  onRestartGoal,
}) => {
  if (!isOpen || !goal) return null;

  const formatDate = (ts: number) => {
    return new Date(ts).toLocaleString([], {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getEventIcon = (type: ReplayEvent['type']) => {
    switch (type) {
      case 'started':
        return <Target className="w-4 h-4 text-amber-600" />;
      case 'detected':
        return <Sparkles className="w-4 h-4 text-indigo-600" />;
      case 'practiced':
        return <BookOpen className="w-4 h-4 text-blue-600" />;
      case 'adapted':
        return <Layers className="w-4 h-4 text-orange-600" />;
      case 'checkpoint':
        return <Award className="w-4 h-4 text-purple-600" />;
      case 'completed':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      default:
        return <Sparkles className="w-4 h-4 text-stone-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white rounded-3xl border border-amber-200 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-amber-100 bg-linear-to-r from-amber-500/10 via-orange-500/10 to-amber-500/5">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-2xl bg-amber-500 text-white shadow-xs">
              <Award className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-200">
                  Kaju Replay
                </span>
                {goal.status === 'completed' ? (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Completed
                  </span>
                ) : (
                  <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                    Active • Stage: {goal.currentStage}
                  </span>
                )}
              </div>
              <h2 className="text-base sm:text-lg font-black text-stone-900 tracking-tight mt-0.5 line-clamp-1">
                {goal.title}
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
            title="Close replay"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {/* Journey Overview Bar */}
          <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200/80 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-stone-500">
              <span>Goal Journey Progress</span>
              <span className="text-amber-800">
                {goal.status === 'completed'
                  ? '100% Completed'
                  : `Stage: ${goal.currentStage}`}
              </span>
            </div>
            <div className="grid grid-cols-5 gap-1.5 pt-1">
              {(['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'] as const).map((st, idx) => {
                const isPassed =
                  goal.status === 'completed' ||
                  ['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'].indexOf(goal.currentStage) >= idx;
                const isCurrent = goal.currentStage === st && goal.status === 'active';
                return (
                  <div
                    key={st}
                    className={`py-1.5 px-1 rounded-xl text-center text-[10px] font-black tracking-wider transition-all ${
                      isPassed
                        ? 'bg-amber-600 text-white shadow-2xs'
                        : isCurrent
                        ? 'bg-amber-100 text-amber-900 border border-amber-400 animate-pulse'
                        : 'bg-stone-100 text-stone-400'
                    }`}
                  >
                    {st}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Timeline of Actual Events */}
          <div className="space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-stone-500 px-1">
              Verified Replay Timeline
            </h3>

            <div className="relative pl-6 space-y-4 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
              {goal.replayEvents && goal.replayEvents.length > 0 ? (
                goal.replayEvents.map((ev, i) => (
                  <div key={ev.id || i} className="relative group">
                    {/* Dot / Icon */}
                    <div className="absolute -left-6 mt-0.5 w-5 h-5 rounded-full bg-white border-2 border-amber-500 flex items-center justify-center shadow-xs">
                      <div className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                    </div>

                    {/* Card */}
                    <div className="bg-white rounded-2xl border border-stone-200/90 p-3 shadow-2xs hover:border-amber-300 transition-colors space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-stone-500">
                        <span className="font-bold flex items-center gap-1.5 text-stone-800 capitalize">
                          {getEventIcon(ev.type)}
                          {ev.type}
                        </span>
                        <span>{formatDate(ev.timestamp)}</span>
                      </div>
                      <p className="text-xs sm:text-sm text-stone-700 leading-relaxed font-medium">
                        {ev.description}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-xs text-stone-500 italic py-2">
                  No recorded events yet.
                </div>
              )}
            </div>
          </div>

          {/* Weak areas & adjustments (if any) */}
          {goal.weakAreas && goal.weakAreas.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-1.5">
              <span className="text-[11px] font-bold text-amber-900 block">
                Identified Learning Adjustments:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {goal.weakAreas.map((area, idx) => (
                  <span
                    key={idx}
                    className="px-2.5 py-0.5 rounded-lg bg-white border border-amber-300 text-stone-700 text-xs font-semibold"
                  >
                    {area}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between gap-3">
          <div className="text-xs text-stone-500 font-medium">
            Recorded by Kaju Goal Engine
          </div>

          <div className="flex items-center gap-2">
            {onRestartGoal && goal.status === 'completed' && (
              <button
                type="button"
                onClick={() => {
                  onRestartGoal(goal);
                  onClose();
                }}
                className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                Practice Again
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-700 text-xs font-bold transition-colors cursor-pointer"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

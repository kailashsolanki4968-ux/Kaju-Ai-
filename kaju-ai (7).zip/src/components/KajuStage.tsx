import React, { useRef, useEffect } from 'react';
import {
  Message,
  LanguagePreference,
  ActionPermissions,
  DeviceAction,
} from '../types';
import { ChatMessage } from './ChatMessage';
import { Sparkles, ArrowDown, BookOpen, Layers, ShieldCheck } from 'lucide-react';

interface KajuStageProps {
  messages: Message[];
  isStreaming: boolean;
  streamingMessageId: string | null;
  onRetryMessage: (failedMessageId: string) => void;
  language: LanguagePreference;
  permissions: ActionPermissions;
  onUpdateAction: (messageId: string, updatedAction: DeviceAction) => void;
  onOpenActionCenter: (tab?: 'permissions' | 'desktop') => void;
  onAnswerChallenge?: (answerText: string) => void;
  onSelectFollowUp?: (prompt: string) => void;
  onOpenMediaSetup?: () => void;
  onConfirmImage?: (cardId: string) => void;
  onCancelImage?: (cardId: string) => void;
  onConfirmVideo?: (cardId: string) => void;
  onCancelVideo?: (cardId: string) => void;
  onRegenerateImage?: (prompt: string, aspectRatio: any) => void;
}

export const KajuStage: React.FC<KajuStageProps> = ({
  messages,
  isStreaming,
  streamingMessageId,
  onRetryMessage,
  language,
  permissions,
  onUpdateAction,
  onOpenActionCenter,
  onAnswerChallenge,
  onSelectFollowUp,
  onOpenMediaSetup,
  onConfirmImage,
  onCancelImage,
  onConfirmVideo,
  onCancelVideo,
  onRegenerateImage,
}) => {
  if (messages.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-6 py-4 space-y-4 animate-in fade-in duration-300">
      {/* Stage Header Banner */}
      <div className="flex items-center justify-between px-3 py-1.5 rounded-2xl bg-amber-500/10 border border-amber-300/40 text-xs text-amber-900 font-semibold">
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          <span>Kaju Control Room • Active Response Stage</span>
        </span>
        <span className="text-[10px] text-amber-700 bg-white/80 px-2 py-0.5 rounded-full border border-amber-200">
          {messages.length} Turn{messages.length === 1 ? '' : 's'}
        </span>
      </div>

      {/* Render all turns inside this stage */}
      <div className="space-y-4">
        {messages.map((message, idx) => {
          const prevMessage = idx > 0 ? messages[idx - 1] : undefined;
          const isImageResponse = Boolean(prevMessage?.image);
          return (
            <ChatMessage
              key={message.id}
              message={message}
              isStreaming={message.id === streamingMessageId && isStreaming}
              onRetry={
                message.status === 'error'
                  ? () => onRetryMessage(message.id)
                  : undefined
              }
              userLanguage={language}
              permissions={permissions}
              onUpdateAction={(updatedAct) => onUpdateAction(message.id, updatedAct)}
              onOpenActionCenter={onOpenActionCenter}
              onAnswerChallenge={onAnswerChallenge}
              onSelectFollowUp={onSelectFollowUp}
              hasImage={isImageResponse}
              onOpenMediaSetup={onOpenMediaSetup}
              onConfirmImage={onConfirmImage}
              onCancelImage={onCancelImage}
              onConfirmVideo={onConfirmVideo}
              onCancelVideo={onCancelVideo}
              onRegenerateImage={onRegenerateImage}
            />
          );
        })}

        <div className="h-2" />
      </div>
    </div>
  );
};

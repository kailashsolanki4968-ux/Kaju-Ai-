import React, { useState, useRef } from 'react';
import {
  Camera,
  Image as ImageIcon,
  RotateCcw,
  Sparkles,
  ArrowRight,
  HelpCircle,
  BookOpen,
  ZoomIn,
  X,
  Loader2,
  CheckCircle2,
} from 'lucide-react';
import { CameraCaptureModal } from './CameraCaptureModal';
import { ImagePreviewModal } from './ImagePreviewModal';
import { fastOptimizeImage } from '../utils/imageHelper';
import { LanguagePreference } from '../types';

interface KajuVisionProps {
  onAnalyzeImage: (image: string, promptText: string) => void;
  language: LanguagePreference;
  onClose?: () => void;
}

export const KajuVision: React.FC<KajuVisionProps> = ({
  onAnalyzeImage,
  language,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [isPreviewModalOpen, setIsPreviewModalOpen] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('General / All Subjects');
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const quickChips = [
    { id: 'explain', label: 'Isko samjhao', prompt: 'Kaju, please is photo ko pura detail mein step-by-step samjhao.' },
    { id: 'solve', label: 'Question solve karo', prompt: 'Kaju, is image mein jo question ya equation diya hai, use step by step solve karo aur final answer highlight karo.' },
    { id: 'transcribe', label: 'Isme kya likha hai?', prompt: 'Kaju, is photo mein jitna bhi text, formula ya notes likha hai, use padhkar saf-saf batao.' },
    { id: 'summary', label: 'Iska summary do', prompt: 'Kaju, is page ya diagram ka quick summary aur important points batao.' },
  ];

  const subjects = [
    'General / All Subjects',
    'Mathematics (गणित)',
    'Physics (भौतिक विज्ञान)',
    'Chemistry (रसायन विज्ञान)',
    'Biology (जीव विज्ञान)',
    'English Language & Literature',
    'Hindi Vyakaran & Sahitya',
    'Social Science / History / Civics',
    'Computer Science & Coding',
  ];

  const handleGalleryChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImage(true);
    try {
      const optimized = await fastOptimizeImage(file, 1280, 0.82);
      setSelectedImage(optimized.dataUrl);
    } catch (err) {
      console.error('Failed to process image:', err);
    } finally {
      setIsProcessingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handlePhotoCaptured = (imageDataUrl: string) => {
    setSelectedImage(imageDataUrl);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        setIsProcessingImage(true);
        try {
          const optimized = await fastOptimizeImage(file, 1280, 0.82);
          setSelectedImage(optimized.dataUrl);
        } catch (err) {
          console.error('Failed to process dropped image:', err);
        } finally {
          setIsProcessingImage(false);
        }
      }
    }
  };

  const handleQuickChipClick = (chipPrompt: string) => {
    setCustomPrompt(chipPrompt);
  };

  const handleAnalyze = () => {
    if (!selectedImage) return;

    let finalPrompt = customPrompt.trim();
    if (!finalPrompt) {
      finalPrompt =
        language === 'hindi'
          ? `कृपया इस चित्र को ध्यान से देखकर इसमें दिए गए प्रश्न, डायग्राम या विषय (${selectedSubject}) को 7-चरणीय स्पष्टता विधि से हल और व्याख्या करें।`
          : language === 'hinglish'
          ? `Kaju, please is image ko carefully dekhkar isme diye question/concept (${selectedSubject}) ko step-by-step Hindi/Hinglish mein explain karo.`
          : `Please carefully analyze this image, read all text and equations for ${selectedSubject}, and explain it step by step.`;
    }

    onAnalyzeImage(selectedImage, finalPrompt);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 sm:py-8 space-y-6 animate-in fade-in duration-300">
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleGalleryChange}
      />

      {/* Camera Capture Modal */}
      <CameraCaptureModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        onCapture={handlePhotoCaptured}
      />

      {/* Zoom Modal */}
      <ImagePreviewModal
        imageUrl={isPreviewModalOpen ? selectedImage : null}
        onClose={() => setIsPreviewModalOpen(false)}
        title="Kaju Vision • Full Photo Preview"
      />

      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 text-rose-800 text-xs font-bold border border-rose-200">
          <Camera className="w-3.5 h-3.5" />
          <span>Multimodal Photo Solver</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight flex items-center justify-center gap-2">
          <span>📷 Kaju Vision</span>
          <span className="text-sm font-semibold px-2 py-0.5 rounded-lg bg-amber-100 text-amber-800">
            काजू विज़न
          </span>
        </h1>
        <p className="text-sm text-stone-600 max-w-lg mx-auto">
          Snap or upload questions, handwritten notes, diagrams, and textbook pages. Kaju analyzes and explains them step by step.
        </p>
      </div>

      {/* Subject Selector */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-2xs">
        <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <BookOpen className="w-3.5 h-3.5 text-amber-600" />
          Choose Subject • विषय चुनें
        </label>
        <div className="flex flex-wrap gap-1.5">
          {subjects.map((subj) => (
            <button
              key={subj}
              type="button"
              onClick={() => setSelectedSubject(subj)}
              className={`px-2.5 py-1 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                selectedSubject === subj
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-stone-50 hover:bg-stone-100 text-stone-700 border border-stone-200'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>
      </div>

      {/* Main Image Viewfinder / Upload Zone */}
      {!selectedImage ? (
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="relative rounded-3xl border-2 border-dashed border-amber-300 bg-linear-to-b from-amber-50/50 to-orange-50/30 p-8 sm:p-12 text-center flex flex-col items-center justify-center space-y-4 hover:border-amber-500 transition-colors"
        >
          <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center shadow-xs">
            {isProcessingImage ? (
              <Loader2 className="w-8 h-8 animate-spin" />
            ) : (
              <Camera className="w-8 h-8" />
            )}
          </div>
          <div className="space-y-1">
            <h3 className="text-base sm:text-lg font-bold text-stone-900">
              Take a Photo or Select from Gallery
            </h3>
            <p className="text-xs text-stone-500 max-w-sm mx-auto">
              Textbooks, homework notebook, whiteboard, diagrams, or printed exam sheets.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsCameraModalOpen(true)}
              className="px-5 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm shadow-md shadow-amber-900/10 flex items-center gap-2 transition-all cursor-pointer active:scale-95"
            >
              <Camera className="w-4 h-4" />
              <span>Open Camera</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-5 py-2.5 rounded-2xl bg-white hover:bg-stone-100 text-stone-800 font-bold text-sm border border-stone-300 shadow-2xs flex items-center gap-2 transition-all cursor-pointer active:scale-95"
            >
              <ImageIcon className="w-4 h-4 text-amber-600" />
              <span>Upload from Gallery</span>
            </button>
          </div>
          <p className="text-[11px] text-stone-400">
            Tip: You can also drag & drop image or paste screenshot directly
          </p>
        </div>
      ) : (
        /* Image Loaded & Ready to Analyze */
        <div className="bg-white rounded-3xl border border-amber-300 p-4 sm:p-6 shadow-sm space-y-5 animate-in fade-in duration-200">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            {/* Thumbnail */}
            <div
              onClick={() => setIsPreviewModalOpen(true)}
              className="relative w-full sm:w-48 h-48 rounded-2xl overflow-hidden bg-stone-900 border border-amber-200 cursor-zoom-in group shadow-xs shrink-0"
              title="Click to view full photo"
            >
              <img
                src={selectedImage}
                alt="Selected question"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                <ZoomIn className="w-5 h-5" />
              </div>
            </div>

            {/* Actions for Photo */}
            <div className="flex-1 space-y-3 w-full">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1 rounded-lg bg-emerald-100 text-emerald-800">
                    <CheckCircle2 className="w-4 h-4" />
                  </span>
                  <div>
                    <h4 className="text-sm font-bold text-stone-900">Photo Attached</h4>
                    <p className="text-xs text-stone-500">Subject: {selectedSubject}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setIsCameraModalOpen(true)}
                    className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium flex items-center gap-1 cursor-pointer"
                    title="Retake photo"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Retake</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedImage(null)}
                    className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 cursor-pointer"
                    title="Remove photo"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Quick Action Chips requested by user:
                  - “Isko samjhao”
                  - “Question solve karo”
                  - “Isme kya likha hai?”
                  - “Iska summary do”
              */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  Quick Action Chips:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {quickChips.map((chip) => (
                    <button
                      key={chip.id}
                      type="button"
                      onClick={() => handleQuickChipClick(chip.prompt)}
                      className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                        customPrompt === chip.prompt
                          ? 'bg-amber-100/90 border-amber-400 text-amber-950 font-bold shadow-2xs'
                          : 'bg-stone-50 hover:bg-amber-50/60 border-stone-200 text-stone-800 text-xs'
                      }`}
                    >
                      <span className="block text-xs font-semibold">{chip.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Custom prompt text field */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-stone-700">
              Optional: Specific question or instruction (Hindi or English)
            </label>
            <input
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="e.g. Question number 3 solve karo, ya equation explain karo..."
              className="w-full py-2.5 px-3.5 rounded-xl bg-stone-50 border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
            />
          </div>

          {/* Analyze Button */}
          <button
            type="button"
            onClick={handleAnalyze}
            className="w-full py-3.5 rounded-2xl bg-linear-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-sm shadow-md shadow-amber-900/10 flex items-center justify-center gap-2 transition-all cursor-pointer active:scale-98"
          >
            <Sparkles className="w-4 h-4" />
            <span>Analyze with Kaju Vision & Solve Step-by-Step</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};

import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Globe,
  Search,
  Check,
  X,
  Sparkles,
  Compass,
  Languages,
} from 'lucide-react';
import { LanguagePreference } from '../types';
import {
  SUPPORTED_LANGUAGES,
  LanguageItem,
  getLanguageInfo,
} from '../utils/languages';

interface LanguageSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedLanguage: LanguagePreference;
  onSelectLanguage: (lang: LanguagePreference) => void;
}

export const LanguageSelectorModal: React.FC<LanguageSelectorModalProps> = ({
  isOpen,
  onClose,
  selectedLanguage,
  onSelectLanguage,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'indian' | 'global'>('all');
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setSearchQuery('');
      // Subtle focus after modal open
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const filteredLanguages = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    return SUPPORTED_LANGUAGES.filter((item) => {
      // Exclude 'auto' from the regular list since it's pinned at the top
      if (item.id === 'auto') return false;

      // Filter by tab if not searching
      if (!query && activeTab !== 'all') {
        if (activeTab === 'indian' && item.category !== 'indian' && item.id !== 'hinglish' && item.id !== 'hindi') {
          return false;
        }
        if (activeTab === 'global' && item.category !== 'global' && item.id !== 'english') {
          return false;
        }
      }

      if (!query) return true;

      return (
        item.name.toLowerCase().includes(query) ||
        item.nativeName.toLowerCase().includes(query) ||
        item.id.toLowerCase().includes(query) ||
        item.code.toLowerCase().includes(query)
      );
    });
  }, [searchQuery, activeTab]);

  if (!isOpen) return null;

  const currentInfo = getLanguageInfo(selectedLanguage);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="language-modal-title"
    >
      <div
        className="relative w-full max-w-lg bg-white rounded-3xl border border-amber-200 shadow-2xl overflow-hidden flex flex-col max-h-[88vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-amber-100 bg-linear-to-r from-amber-500/10 via-orange-500/10 to-amber-500/5">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-2xl bg-amber-500 text-white shadow-xs">
              <Globe className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2
                  id="language-modal-title"
                  className="text-base sm:text-lg font-black text-stone-900 tracking-tight"
                >
                  Select Language • भाषा चुनें
                </h2>
              </div>
              <p className="text-xs text-stone-500 font-medium mt-0.5">
                Current: <span className="font-bold text-amber-900">{currentInfo.name} ({currentInfo.nativeName})</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
            title="Close language selector"
            aria-label="Close language selector"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Category Filter */}
        <div className="p-3 sm:p-4 border-b border-stone-100 space-y-2.5 bg-stone-50/70">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search language (e.g. Hindi, Spanish, বাংলা, 日本語...)"
              className="w-full pl-9 pr-9 py-2.5 rounded-2xl bg-white border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-stone-900 text-xs sm:text-sm placeholder:text-stone-400 outline-none transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-600 rounded-lg"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Filter Tabs */}
          {!searchQuery && (
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs pb-0.5">
              {[
                { id: 'all', label: 'All Languages' },
                { id: 'indian', label: 'Indian Regional' },
                { id: 'global', label: 'Global' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-1 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200/80'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Scrollable Language List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-2 max-h-[50vh]">
          {/* 1. Prominent Pinned "Auto Detect" Card */}
          {(!searchQuery ||
            'auto detect स्वतः पहचानें'.toLowerCase().includes(searchQuery.toLowerCase())) && (
            <button
              type="button"
              onClick={() => {
                onSelectLanguage('auto');
                onClose();
              }}
              className={`w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                selectedLanguage === 'auto'
                  ? 'bg-amber-500/10 border-amber-400 ring-2 ring-amber-400/30'
                  : 'bg-stone-50/90 hover:bg-amber-50/50 border-stone-200'
              }`}
            >
              <div className="flex items-center gap-3">
                <span
                  className={`p-2.5 rounded-xl flex items-center justify-center shrink-0 ${
                    selectedLanguage === 'auto'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-white text-amber-700 border border-amber-200'
                  }`}
                >
                  <Sparkles className="w-4 h-4 animate-pulse" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-stone-900 text-sm sm:text-base">
                      Auto Detect
                    </span>
                    <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200">
                      Recommended
                    </span>
                  </div>
                  <p className="text-xs text-stone-500 mt-0.5">
                    Kaju automatically detects text, camera OCR, and spoken voice.
                  </p>
                </div>
              </div>

              {selectedLanguage === 'auto' && (
                <span className="p-1 rounded-full bg-amber-600 text-white shrink-0 shadow-2xs">
                  <Check className="w-4 h-4" />
                </span>
              )}
            </button>
          )}

          {/* Divider */}
          <div className="px-2 pt-2 pb-1 flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-stone-400">
            <span>Supported Languages ({filteredLanguages.length})</span>
            {searchQuery && <span>Search results</span>}
          </div>

          {/* Languages Grid / List */}
          {filteredLanguages.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {filteredLanguages.map((lang) => {
                const isSelected = selectedLanguage === lang.id;
                return (
                  <button
                    key={lang.id}
                    type="button"
                    onClick={() => {
                      onSelectLanguage(lang.id as LanguagePreference);
                      onClose();
                    }}
                    className={`text-left p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-2.5 ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-400 ring-2 ring-amber-400/20'
                        : 'bg-white hover:bg-stone-50 border-stone-200/90 hover:border-amber-200'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-stone-900 text-sm truncate">
                          {lang.name}
                        </span>
                        {lang.popular && (
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800">
                            Popular
                          </span>
                        )}
                      </div>
                      <div className="text-xs font-semibold text-amber-900/80 truncate mt-0.5">
                        {lang.nativeName}
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="text-[10px] text-stone-400 font-mono">
                        {lang.code.split('-')[0]}
                      </span>
                      {isSelected ? (
                        <span className="p-1 rounded-full bg-amber-600 text-white shadow-2xs">
                          <Check className="w-3.5 h-3.5" />
                        </span>
                      ) : (
                        <span className="w-5 h-5 rounded-full border border-stone-200 flex items-center justify-center text-transparent hover:border-amber-400">
                          •
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center text-stone-400 text-xs sm:text-sm space-y-1">
              <p>No matching languages found for &ldquo;{searchQuery}&rdquo;</p>
              <p className="text-stone-400 text-xs">
                Try searching in English, native script, or select Auto Detect.
              </p>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 border-t border-stone-200 bg-stone-50 flex items-center justify-between text-xs">
          <span className="text-stone-500 flex items-center gap-1.5">
            <Languages className="w-3.5 h-3.5 text-amber-600" />
            <span>Kaju Goal Engine works across all 27+ languages</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-white hover:bg-stone-100 border border-stone-300 text-stone-700 font-bold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  Video,
  Image as ImageIcon,
  Info,
  CheckCircle2,
  AlertTriangle,
  Play,
  Download,
  Loader2,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Coins,
} from 'lucide-react';
import { GeneratedImageCard, GeneratedVideoCard } from '../types';

interface MediaStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerateImage: (prompt: string, aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4', style?: string) => Promise<any>;
  onGenerateVideo: (prompt: string, resolution: '720p' | '1080p', aspectRatio: '16:9' | '9:16') => Promise<any>;
  initialTab?: 'image' | 'video' | 'setup';
  initialPrompt?: string;
}

export const MediaStudioModal: React.FC<MediaStudioModalProps> = ({
  isOpen,
  onClose,
  onGenerateImage,
  onGenerateVideo,
  initialTab = 'image',
  initialPrompt = '',
}) => {
  const [activeTab, setActiveTab] = useState<'image' | 'video' | 'setup'>(initialTab);

  // Image Tab States
  const [imagePrompt, setImagePrompt] = useState(initialPrompt);
  const [imageAspectRatio, setImageAspectRatio] = useState<'1:1' | '16:9' | '9:16' | '4:3' | '3:4'>('1:1');
  const [imageStyle, setImageStyle] = useState('Photorealistic');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImageResult, setGeneratedImageResult] = useState<GeneratedImageCard | null>(null);

  // Video Tab States
  const [videoPrompt, setVideoPrompt] = useState(initialPrompt);
  const [videoResolution, setVideoResolution] = useState<'720p' | '1080p'>('720p');
  const [videoAspectRatio, setVideoAspectRatio] = useState<'16:9' | '9:16'>('16:9');
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [videoResult, setVideoResult] = useState<GeneratedVideoCard | null>(null);

  // Capabilities check
  const [capabilities, setCapabilities] = useState<any>(null);
  const [isLoadingCaps, setIsLoadingCaps] = useState(false);

  useEffect(() => {
    if (initialTab) setActiveTab(initialTab);
    if (initialPrompt) {
      setImagePrompt(initialPrompt);
      setVideoPrompt(initialPrompt);
    }
  }, [initialTab, initialPrompt]);

  useEffect(() => {
    if (isOpen) {
      setIsLoadingCaps(true);
      fetch('/api/media/capabilities')
        .then((res) => res.json())
        .then((data) => setCapabilities(data))
        .catch(() => {})
        .finally(() => setIsLoadingCaps(false));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRunImage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imagePrompt.trim() || isGeneratingImage) return;
    setIsGeneratingImage(true);
    setGeneratedImageResult(null);

    try {
      const res = await onGenerateImage(imagePrompt, imageAspectRatio, imageStyle);
      setGeneratedImageResult(res);
    } catch (err: any) {
      setGeneratedImageResult({
        id: `err_${Date.now()}`,
        prompt: imagePrompt,
        aspectRatio: imageAspectRatio,
        model: 'gemini-3.1-flash-lite-image',
        status: 'error',
        error: err.message || 'Image generation failed',
        createdAt: Date.now(),
      });
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleRunVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!videoPrompt.trim() || isGeneratingVideo) return;
    setIsGeneratingVideo(true);
    setVideoResult(null);

    try {
      const res = await onGenerateVideo(videoPrompt, videoResolution, videoAspectRatio);
      setVideoResult(res);
    } catch (err: any) {
      setVideoResult({
        id: `err_${Date.now()}`,
        prompt: videoPrompt,
        resolution: videoResolution,
        aspectRatio: videoAspectRatio,
        model: 'veo-3.1-lite-generate-preview',
        status: 'error',
        error: err.message || 'Video generation failed',
        createdAt: Date.now(),
      });
    } finally {
      setIsGeneratingVideo(false);
    }
  };

  const sampleImagePrompts = [
    { label: 'बनारस घाट दिया', text: 'Varanasi ghats during Diwali illuminated by thousands of floating clay diyas, photorealistic, cinematic golden hour' },
    { label: 'Cute Cartoon Lion', text: 'A friendly cute cartoon baby lion smiling warmly, Disney Pixar 3D animation style, vibrant soft lighting' },
    { label: 'Himalayan Watercolor', text: 'A serene Himalayan snow-capped mountain landscape at dawn with pine trees and alpine lake, delicate watercolor art' },
    { label: 'Cyberpunk Mumbai', text: 'Futuristic cyberpunk auto-rickshaw navigating neon-lit rain-slicked streets of Mumbai, hyperrealistic 4K render' },
  ];

  const sampleVideoPrompts = [
    { label: 'Water Drop Ripple', text: 'A single crystal-clear water drop falling into still turquoise water, ripples expanding outwards in slow motion, photorealistic 4K' },
    { label: 'Robot in Rain', text: 'A small friendly robot walking under a bright yellow umbrella in gentle rain, cinematic lighting, slow camera pan' },
    { label: 'Cosmic Nebula', text: 'Flying through a deep space colorful glowing nebula with swirling stardust and distant galaxies, cinematic 8k' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-stone-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200/80 bg-linear-to-r from-amber-500/10 via-orange-500/10 to-indigo-500/10">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-linear-to-br from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-stone-900 text-base flex items-center gap-2">
                <span>Kaju AI Media Studio</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  Real AI Models
                </span>
              </h3>
              <p className="text-xs text-stone-500">
                Text-to-Image (Gemini 3.1) & Text-to-Video (Google DeepMind Veo 3.1)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 bg-stone-50/70 px-4 pt-2 gap-2 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('image')}
            className={`pb-2.5 px-3 rounded-t-xl transition-all flex items-center gap-1.5 cursor-pointer border-b-2 ${
              activeTab === 'image'
                ? 'border-amber-600 text-amber-900 bg-white shadow-2xs'
                : 'border-transparent text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-amber-600" />
            <span>AI Image (Gemini 3.1)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('video')}
            className={`pb-2.5 px-3 rounded-t-xl transition-all flex items-center gap-1.5 cursor-pointer border-b-2 ${
              activeTab === 'video'
                ? 'border-indigo-600 text-indigo-900 bg-white shadow-2xs'
                : 'border-transparent text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Video className="w-4 h-4 text-indigo-600" />
            <span>AI Video (Veo 3.1)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('setup')}
            className={`pb-2.5 px-3 rounded-t-xl transition-all flex items-center gap-1.5 cursor-pointer border-b-2 ml-auto ${
              activeTab === 'setup'
                ? 'border-purple-600 text-purple-900 bg-white shadow-2xs'
                : 'border-transparent text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <Info className="w-4 h-4 text-purple-600" />
            <span>Setup & Pricing</span>
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* TAB 1: IMAGE GENERATION */}
          {activeTab === 'image' && (
            <form onSubmit={handleRunImage} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1.5">
                  Describe what you want to create (Hindi, Hinglish, or English):
                </label>
                <textarea
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder="e.g. 'Ek pyara sa baby lion', 'A futuristic cybernetic tiger in neon jungle', 'Varanasi ghats during sunset watercolor'..."
                  rows={3}
                  className="w-full px-3.5 py-2.5 text-xs rounded-2xl border border-stone-300 focus:border-amber-500 focus:ring-3 focus:ring-amber-500/15 outline-none resize-none"
                  required
                />
              </div>

              {/* Sample Prompts */}
              <div>
                <span className="text-[11px] font-semibold text-stone-500 block mb-1.5">
                  Quick Prompt Ideas:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {sampleImagePrompts.map((s, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setImagePrompt(s.text)}
                      className="text-[11px] px-2.5 py-1 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-900 font-medium transition-colors cursor-pointer"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Configuration Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Aspect Ratio */}
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1">
                    Aspect Ratio:
                  </label>
                  <select
                    value={imageAspectRatio}
                    onChange={(e) => setImageAspectRatio(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 bg-white font-medium outline-none focus:border-amber-500"
                  >
                    <option value="1:1">1:1 (Square - Instagram/Avatar)</option>
                    <option value="16:9">16:9 (Landscape - Desktop/Hero)</option>
                    <option value="9:16">9:16 (Portrait - Mobile Story)</option>
                    <option value="4:3">4:3 (Standard Photo)</option>
                    <option value="3:4">3:4 (Portrait Photo)</option>
                  </select>
                </div>

                {/* Style */}
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1">
                    Visual Style Preset:
                  </label>
                  <select
                    value={imageStyle}
                    onChange={(e) => setImageStyle(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 bg-white font-medium outline-none focus:border-amber-500"
                  >
                    <option value="Photorealistic">Photorealistic / Real Photo</option>
                    <option value="Digital Art">Digital Art & Illustration</option>
                    <option value="Watercolor">Watercolor Painting</option>
                    <option value="Cinematic 3D">Cinematic 3D Render</option>
                    <option value="Anime">Anime / Manga Style</option>
                    <option value="Minimalist">Minimalist Vector Art</option>
                  </select>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!imagePrompt.trim() || isGeneratingImage}
                  className="w-full py-2.5 px-4 rounded-2xl bg-linear-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 disabled:opacity-40 text-white font-bold text-xs transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isGeneratingImage ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Generating with Gemini Image Model…</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Generate Real Image / इमेज बनाएं</span>
                    </>
                  )}
                </button>
              </div>

              {/* Result Preview inside Modal if already generated */}
              {generatedImageResult && (
                <div className="pt-3 border-t border-stone-200">
                  {generatedImageResult.status === 'completed' && generatedImageResult.imageUrl ? (
                    <div className="rounded-2xl border-2 border-amber-300 overflow-hidden bg-stone-950 p-2 text-center space-y-2">
                      <img
                        src={generatedImageResult.imageUrl}
                        alt={generatedImageResult.prompt}
                        className="max-h-64 mx-auto rounded-xl object-contain"
                      />
                      <div className="flex items-center justify-center gap-2 pt-1">
                        <a
                          href={generatedImageResult.imageUrl}
                          download="kaju_image.png"
                          className="px-3 py-1.5 rounded-xl bg-amber-600 text-white text-xs font-bold inline-flex items-center gap-1.5"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download Image</span>
                        </a>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-orange-50 border border-orange-200 text-xs text-orange-950 space-y-1">
                      <p className="font-bold flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-orange-600" />
                        <span>{generatedImageResult.error || 'Generation Note'}</span>
                      </p>
                      {generatedImageResult.errorDetails?.hindiMessage && (
                        <p className="text-[11px] text-orange-800">
                          {generatedImageResult.errorDetails.hindiMessage}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </form>
          )}

          {/* TAB 2: VIDEO GENERATION (VEO 3.1) */}
          {activeTab === 'video' && (
            <form onSubmit={handleRunVideo} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-800 mb-1.5">
                  Describe the video scene (Veo 3.1 Video Engine):
                </label>
                <textarea
                  value={videoPrompt}
                  onChange={(e) => setVideoPrompt(e.target.value)}
                  placeholder="e.g. 'A crystal water drop falling into still turquoise pool in slow motion', 'A cute robot exploring ancient Indian temple with floating lanterns'..."
                  rows={3}
                  className="w-full px-3.5 py-2.5 text-xs rounded-2xl border border-stone-300 focus:border-indigo-500 focus:ring-3 focus:ring-indigo-500/15 outline-none resize-none"
                  required
                />
              </div>

              {/* Sample Prompts */}
              <div>
                <span className="text-[11px] font-semibold text-stone-500 block mb-1.5">
                  Veo 3.1 Scene Ideas:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {sampleVideoPrompts.map((s, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setVideoPrompt(s.text)}
                      className="text-[11px] px-2.5 py-1 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-900 font-medium transition-colors cursor-pointer"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Configuration Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Resolution */}
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1">
                    Resolution:
                  </label>
                  <select
                    value={videoResolution}
                    onChange={(e) => setVideoResolution(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 bg-white font-medium outline-none focus:border-indigo-500"
                  >
                    <option value="720p">720p HD (~$0.075 / sec - Recommended)</option>
                    <option value="1080p">1080p Full HD (~$0.15 / sec)</option>
                  </select>
                </div>

                {/* Aspect Ratio */}
                <div>
                  <label className="block text-[11px] font-bold text-stone-700 mb-1">
                    Aspect Ratio:
                  </label>
                  <select
                    value={videoAspectRatio}
                    onChange={(e) => setVideoAspectRatio(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 bg-white font-medium outline-none focus:border-indigo-500"
                  >
                    <option value="16:9">16:9 (Landscape - YouTube / TV)</option>
                    <option value="9:16">9:16 (Portrait - Reels / Shorts)</option>
                  </select>
                </div>
              </div>

              {/* Cost Confirmation Notice */}
              <div className="p-3 rounded-2xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-950 space-y-1">
                <div className="flex items-center gap-1.5 font-bold">
                  <Coins className="w-4 h-4 text-indigo-700" />
                  <span>Veo 3.1 Model Billing Disclosure</span>
                </div>
                <p className="text-[11px] text-stone-700 leading-relaxed">
                  Video generation runs on Google DeepMind Veo 3.1. Generating a 5s clip requires ~1–3 minutes of GPU compute and applies Pay-As-You-Go Google Cloud billing.
                </p>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={!videoPrompt.trim() || isGeneratingVideo}
                  className="w-full py-2.5 px-4 rounded-2xl bg-linear-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:opacity-40 text-white font-bold text-xs transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                >
                  {isGeneratingVideo ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Submitting to Veo 3.1 Pipeline…</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-current" />
                      <span>Generate Real Video / वीडियो बनाएं</span>
                    </>
                  )}
                </button>
              </div>

              {/* Result Preview inside Modal if already generated */}
              {videoResult && (
                <div className="pt-3 border-t border-stone-200">
                  {videoResult.status === 'completed' && videoResult.videoUrl ? (
                    <div className="rounded-2xl border-2 border-indigo-300 overflow-hidden bg-stone-950 p-2 text-center space-y-2">
                      <video
                        src={videoResult.videoUrl}
                        controls
                        className="max-h-64 mx-auto rounded-xl"
                      />
                    </div>
                  ) : (
                    <div className="p-3 rounded-xl bg-purple-50 border border-purple-200 text-xs text-purple-950 space-y-1">
                      <p className="font-bold flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-purple-600" />
                        <span>{videoResult.error || 'Video Note'}</span>
                      </p>
                      {videoResult.errorDetails?.hindiMessage && (
                        <p className="text-[11px] text-purple-800">
                          {videoResult.errorDetails.hindiMessage}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}
            </form>
          )}

          {/* TAB 3: SETUP, BILLING & API REQUIREMENTS */}
          {activeTab === 'setup' && (
            <div className="space-y-4 text-xs text-stone-800">
              <div className="p-3.5 rounded-2xl bg-linear-to-r from-amber-50 to-indigo-50 border border-amber-200/80 space-y-2">
                <div className="flex items-center gap-2 font-extrabold text-stone-900">
                  <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span>Real Google AI Studio Model Architecture</span>
                </div>
                <p className="text-stone-700 leading-relaxed text-[11px]">
                  Kaju AI connects directly to official Google GenAI foundation models using the modern <code>@google/genai</code> SDK on the server side. API keys remain strictly on the backend and are never exposed to browser client code.
                </p>
              </div>

              {/* Free-Tier Reality & Protection Policy */}
              <div className="p-3.5 rounded-2xl bg-amber-50/90 border border-amber-300 text-stone-800 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-950 text-xs">
                  <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                  <span>Free-Tier Reality & Protection Policy</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-stone-700 leading-relaxed pl-1">
                  <li><strong>Google AI Studio Limit</strong>: Official Gemini image models (<code>gemini-3.1-flash-lite-image</code>, <code>gemini-nano-banana</code>) and video models (<code>veo-3.1</code>) have a strict 0-request quota on free-tier keys.</li>
                  <li><strong>Zero Automatic Paid Calls</strong>: Kaju will NEVER automatically trigger paid APIs. Both image and video generation require explicit user confirmation before execution.</li>
                  <li><strong>Zero Fake Generation</strong>: Kaju will never return stock photos, search engine links, or simulated text placeholders pretending to be real AI generation.</li>
                  <li><strong>Genuinely Free Features</strong>: Full conversational intelligence, bilingual problem solving, document analysis, camera OCR/vision, Goal Engine, and interactive games remain 100% free.</li>
                </ul>
              </div>

              {/* Pricing & Quota Table */}
              <div className="rounded-2xl border border-stone-200 overflow-hidden">
                <table className="w-full text-left text-[11px]">
                  <thead className="bg-stone-100 border-b border-stone-200 text-stone-700 font-bold">
                    <tr>
                      <th className="p-2.5">Feature</th>
                      <th className="p-2.5">Model</th>
                      <th className="p-2.5">Tier / Quota</th>
                      <th className="p-2.5">Est. Price</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    <tr>
                      <td className="p-2.5 font-bold text-stone-900">AI Image Generation</td>
                      <td className="p-2.5 font-mono text-[10px]">gemini-3.1-flash-lite-image</td>
                      <td className="p-2.5 text-orange-700 font-medium">Paid (0-quota on free key)</td>
                      <td className="p-2.5">~$0.03 / image</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-stone-900">AI Video Generation</td>
                      <td className="p-2.5 font-mono text-[10px]">veo-3.1-lite-generate-preview</td>
                      <td className="p-2.5 text-purple-700 font-medium">Google Cloud Billing required</td>
                      <td className="p-2.5">~$0.075 / sec (720p)</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-stone-900">Vision Analysis (OCR)</td>
                      <td className="p-2.5 font-mono text-[10px]">gemini-3.8-flash</td>
                      <td className="p-2.5 text-emerald-700 font-medium">Free Tier Supported</td>
                      <td className="p-2.5">Included in tier</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold text-stone-900">Bilingual Chat / Goals</td>
                      <td className="p-2.5 font-mono text-[10px]">gemini-3.1-flash-lite</td>
                      <td className="p-2.5 text-emerald-700 font-medium">Free Tier Supported</td>
                      <td className="p-2.5">Included in tier</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Setup Steps */}
              <div className="space-y-2">
                <h4 className="font-extrabold text-stone-900 text-xs">
                  How to Enable Image & Video Generation in Google AI Studio:
                </h4>
                <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-stone-700 pl-1 leading-relaxed">
                  <li>
                    Open <strong>Google AI Studio</strong> (<a href="https://aistudio.google.com" target="_blank" rel="noopener noreferrer" className="text-indigo-600 underline">aistudio.google.com</a>).
                  </li>
                  <li>
                    Go to <strong>Settings → Billing & Cloud Projects</strong>.
                  </li>
                  <li>
                    Link a Google Cloud Billing account (Pay-As-You-Go). Google provides $300 free credits for new cloud accounts.
                  </li>
                  <li>
                    Create or attach your billing-enabled API key in <strong>Settings → Secrets</strong>.
                  </li>
                  <li>
                    Once attached, image generation (<code>gemini-3.1-flash-lite-image</code>) and video generation (<code>veo-3.1</code>) will execute without 429 quota limits!
                  </li>
                </ol>
              </div>

              {/* Security Guarantee */}
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div className="leading-relaxed text-[11px]">
                  <strong>Zero-Secret Guarantee:</strong> Kaju AI handles all media API requests server-side through <code>/api/image/generate</code> and <code>/api/video/generate</code>. Your credentials never touch the browser.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

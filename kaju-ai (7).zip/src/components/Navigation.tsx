import React from 'react';
import { Home, MessageSquare, Zap, Camera, User } from 'lucide-react';
import { NavigationTab } from '../types';

interface NavigationProps {
  activeTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  messageCount?: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  messageCount = 0,
}) => {
  const tabs: { id: NavigationTab; label: string; icon: any; badge?: string }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'chats', label: 'Chats', icon: MessageSquare, badge: messageCount > 0 ? String(messageCount) : undefined },
    { id: 'actions', label: 'Actions', icon: Zap, badge: 'Safe' },
    { id: 'vision', label: 'Vision', icon: Camera },
    { id: 'kaju', label: 'Kaju', icon: User },
  ];

  return (
    <>
      {/* Mobile Bottom Navigation Bar (fixed bottom for thumb reach) */}
      <nav
        id="mobile-bottom-nav"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-amber-200/70 px-2 py-1.5 shadow-lg flex items-center justify-around"
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all cursor-pointer relative ${
                isActive
                  ? 'text-amber-800 font-bold bg-amber-500/15'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'text-amber-700 stroke-[2.5]' : 'stroke-[1.75]'}`} />
                {tab.badge && (
                  <span className="absolute -top-1.5 -right-2 text-[9px] font-bold bg-amber-600 text-white rounded-full px-1 py-0.2 leading-none shadow-2xs">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight font-medium">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Desktop / Tablet Header Nav Pills (embedded into Header) */}
      <div
        id="desktop-nav-pills"
        className="hidden md:flex items-center gap-1 bg-stone-100/80 p-1 rounded-2xl border border-stone-200/70 text-xs font-semibold"
      >
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl transition-all cursor-pointer relative ${
                isActive
                  ? 'bg-white text-stone-900 shadow-2xs font-bold'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-white/50'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-600' : 'text-stone-500'}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full leading-none ${
                    tab.badge === 'Safe'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-900'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </>
  );
};

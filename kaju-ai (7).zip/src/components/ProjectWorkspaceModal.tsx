import React, { useState } from 'react';
import {
  FolderKanban,
  Plus,
  CheckCircle2,
  Circle,
  FileText,
  CheckSquare,
  Sparkles,
  Trash2,
  X,
  Target,
  ArrowRight,
  Code2,
  Compass,
  GraduationCap,
  Briefcase,
  Layers,
  Paperclip,
  Upload,
} from 'lucide-react';
import { ProjectWorkspace, DocumentAttachment } from '../types';
import {
  createProject,
  addProjectNote,
  addProjectTask,
  toggleProjectTask,
  deleteProject,
  addProjectFile,
} from '../utils/projectHelper';

interface ProjectWorkspaceModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: ProjectWorkspace[];
  activeProjectId: string;
  onSelectProject: (projectId: string) => void;
  onRefreshProjects: () => void;
  onStartProjectChat?: (projectName: string) => void;
}

export const ProjectWorkspaceModal: React.FC<ProjectWorkspaceModalProps> = ({
  isOpen,
  onClose,
  projects,
  activeProjectId,
  onSelectProject,
  onRefreshProjects,
  onStartProjectChat,
}) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string>(activeProjectId);
  const [isCreating, setIsCreating] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDesc, setNewProjectDesc] = useState('');
  const [newProjectCategory, setNewProjectCategory] = useState<ProjectWorkspace['category']>('general');

  const [newNoteInput, setNewNoteInput] = useState('');
  const [newTaskInput, setNewTaskInput] = useState('');

  if (!isOpen) return null;

  const currentProject = projects.find((p) => p.id === selectedProjectId) || projects[0];

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName.trim()) return;
    const created = createProject(newProjectName, newProjectDesc, newProjectCategory);
    onRefreshProjects();
    setSelectedProjectId(created.id);
    onSelectProject(created.id);
    setIsCreating(false);
    setNewProjectName('');
    setNewProjectDesc('');
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteInput.trim() || !currentProject) return;
    addProjectNote(currentProject.id, newNoteInput);
    onRefreshProjects();
    setNewNoteInput('');
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskInput.trim() || !currentProject) return;
    addProjectTask(currentProject.id, newTaskInput);
    onRefreshProjects();
    setNewTaskInput('');
  };

  const handleToggleTask = (taskId: string) => {
    if (!currentProject) return;
    toggleProjectTask(currentProject.id, taskId);
    onRefreshProjects();
  };

  const handleDeleteProject = (projId: string) => {
    if (window.confirm('Are you sure you want to delete this project workspace?')) {
      const remaining = deleteProject(projId);
      onRefreshProjects();
      if (remaining.length > 0) {
        setSelectedProjectId(remaining[0].id);
        onSelectProject(remaining[0].id);
      }
    }
  };

  const getCategoryIcon = (category: ProjectWorkspace['category']) => {
    switch (category) {
      case 'coding':
        return <Code2 className="w-4 h-4 text-blue-600" />;
      case 'trip':
        return <Compass className="w-4 h-4 text-emerald-600" />;
      case 'learning':
        return <GraduationCap className="w-4 h-4 text-purple-600" />;
      case 'business':
        return <Briefcase className="w-4 h-4 text-amber-600" />;
      default:
        return <Layers className="w-4 h-4 text-stone-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-4xl h-[90vh] max-h-[720px] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-amber-200 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-200/90 bg-stone-50/80 shrink-0">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-amber-600 text-white shadow-2xs">
              <FolderKanban className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-stone-900 flex items-center gap-2">
                <span>Projects & Workspaces</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  {projects.length} Active
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                Independent context for chats, goals, code, notes, and task roadmaps.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-stone-200 text-stone-500 hover:text-stone-800 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Left Project List & Right Workspace Detail */}
        <div className="flex-1 min-h-0 flex flex-col md:flex-row overflow-hidden">
          {/* Left Sidebar: Projects List */}
          <div className="w-full md:w-72 border-b md:border-b-0 md:border-r border-stone-200/90 bg-stone-50/60 p-3 flex flex-col shrink-0 overflow-y-auto">
            <div className="flex items-center justify-between mb-2 px-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
                Your Workspaces
              </span>
              <button
                type="button"
                onClick={() => setIsCreating(true)}
                className="inline-flex items-center gap-1 text-xs font-bold text-amber-700 hover:text-amber-800 bg-amber-100/80 hover:bg-amber-100 px-2 py-1 rounded-lg transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Project</span>
              </button>
            </div>

            {/* Project List */}
            <div className="space-y-1.5 flex-1 overflow-y-auto">
              {projects.map((proj) => {
                const isCurrent = proj.id === selectedProjectId;
                const isActive = proj.id === activeProjectId;
                return (
                  <button
                    key={proj.id}
                    type="button"
                    onClick={() => {
                      setSelectedProjectId(proj.id);
                      setIsCreating(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-2xl transition-all cursor-pointer flex items-center justify-between gap-2 border ${
                      isCurrent
                        ? 'bg-white border-amber-400 shadow-xs'
                        : 'hover:bg-white/80 border-transparent text-stone-700'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="p-1.5 rounded-xl bg-stone-100 border border-stone-200 shrink-0">
                        {getCategoryIcon(proj.category)}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-xs text-stone-900 truncate">
                            {proj.name}
                          </span>
                          {isActive && (
                            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" title="Active project" />
                          )}
                        </div>
                        <span className="text-[10px] text-stone-500 truncate block">
                          {proj.tasks.filter((t) => t.completed).length}/{proj.tasks.length} tasks • {proj.category}
                        </span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Main Pane: Project Detail or Creation Form */}
          <div className="flex-1 min-h-0 flex flex-col p-4 sm:p-6 overflow-y-auto bg-white">
            {isCreating ? (
              /* Create New Project Form */
              <form onSubmit={handleCreateSubmit} className="space-y-4 max-w-lg">
                <div>
                  <h3 className="text-base font-bold text-stone-900">Create New Project Workspace</h3>
                  <p className="text-xs text-stone-500">
                    Each project keeps its own context, chats, files, goals, notes, and task lists.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Project Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="e.g. School Management App, Japan Trip 2026, Japanese Learning"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Description / Core Objective
                  </label>
                  <textarea
                    value={newProjectDesc}
                    onChange={(e) => setNewProjectDesc(e.target.value)}
                    placeholder="Briefly describe what you are building, learning, or organizing..."
                    rows={2}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 text-sm outline-none resize-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                    Category
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'general', label: 'General', icon: Layers },
                      { id: 'coding', label: 'Coding / App', icon: Code2 },
                      { id: 'learning', label: 'Learning', icon: GraduationCap },
                      { id: 'trip', label: 'Travel / Trip', icon: Compass },
                      { id: 'business', label: 'Business', icon: Briefcase },
                    ].map((cat) => {
                      const Icon = cat.icon;
                      const isSel = newProjectCategory === cat.id;
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setNewProjectCategory(cat.id as any)}
                          className={`p-2 rounded-xl border text-xs font-medium flex items-center gap-2 cursor-pointer transition-all ${
                            isSel
                              ? 'bg-amber-50 border-amber-500 text-amber-950 font-bold'
                              : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                          }`}
                        >
                          <Icon className="w-4 h-4 text-amber-700" />
                          <span>{cat.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
                  >
                    Create Workspace
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsCreating(false)}
                    className="px-3.5 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-medium transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : currentProject ? (
              /* Selected Project View */
              <div className="space-y-5">
                {/* Top Info & Set Active Button */}
                <div className="flex items-start justify-between gap-3 flex-wrap border-b border-stone-100 pb-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 rounded-xl bg-stone-100 border border-stone-200">
                        {getCategoryIcon(currentProject.category)}
                      </span>
                      <h3 className="text-lg font-black text-stone-900">{currentProject.name}</h3>
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-stone-100 text-stone-600 border border-stone-200">
                        {currentProject.category}
                      </span>
                    </div>
                    <p className="text-xs text-stone-600 mt-1 leading-relaxed max-w-xl">
                      {currentProject.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    {currentProject.id === activeProjectId ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Active Workspace</span>
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectProject(currentProject.id);
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer active:scale-95"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Set as Active Project</span>
                      </button>
                    )}

                    {onStartProjectChat && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectProject(currentProject.id);
                          onStartProjectChat(currentProject.name);
                          onClose();
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold transition-all cursor-pointer"
                        title="Start a new chat inside this project workspace"
                      >
                        <span>Chat in Project</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {projects.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleDeleteProject(currentProject.id)}
                        className="p-1.5 rounded-xl text-stone-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Delete project"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Grid: Tasks Checklist & Project Notes */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {/* Tasks Checklist */}
                  <div className="rounded-2xl border border-stone-200 bg-stone-50/50 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
                        <CheckSquare className="w-4 h-4 text-amber-700" />
                        <span>Project Tasks</span>
                      </span>
                      <span className="text-[11px] font-bold text-stone-500">
                        {currentProject.tasks.filter((t) => t.completed).length}/{currentProject.tasks.length}
                      </span>
                    </div>

                    {/* Task input */}
                    <form onSubmit={handleAddTask} className="flex items-center gap-1.5">
                      <input
                        type="text"
                        value={newTaskInput}
                        onChange={(e) => setNewTaskInput(e.target.value)}
                        placeholder="Add a new milestone or task..."
                        className="flex-1 py-1.5 px-3 rounded-xl bg-white border border-stone-300 text-xs text-stone-900 placeholder:text-stone-400 outline-none focus:border-amber-500"
                      />
                      <button
                        type="submit"
                        disabled={!newTaskInput.trim()}
                        className="px-2.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold transition-all cursor-pointer"
                      >
                        Add
                      </button>
                    </form>

                    {/* Task items */}
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {currentProject.tasks.length === 0 ? (
                        <p className="text-xs text-stone-400 italic py-2">No tasks added yet.</p>
                      ) : (
                        currentProject.tasks.map((task) => (
                          <div
                            key={task.id}
                            onClick={() => handleToggleTask(task.id)}
                            className="flex items-center gap-2 p-2 rounded-xl bg-white border border-stone-200/80 hover:border-amber-300 transition-all cursor-pointer group"
                          >
                            {task.completed ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                            ) : (
                              <Circle className="w-4 h-4 text-stone-400 group-hover:text-amber-600 shrink-0" />
                            )}
                            <span
                              className={`text-xs ${
                                task.completed ? 'line-through text-stone-400' : 'text-stone-800 font-medium'
                              }`}
                            >
                              {task.title}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Project Notes & Scratchpad */}
                  <div className="rounded-2xl border border-stone-200 bg-stone-50/50 p-4 space-y-3">
                    <span className="text-xs font-black uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-amber-700" />
                      <span>Project Notes & Specs</span>
                    </span>

                    {/* Add note input */}
                    <form onSubmit={handleAddNote} className="flex items-center gap-1.5">
                      <input
                        type="text"
                        value={newNoteInput}
                        onChange={(e) => setNewNoteInput(e.target.value)}
                        placeholder="Add a quick note or spec..."
                        className="flex-1 py-1.5 px-3 rounded-xl bg-white border border-stone-300 text-xs text-stone-900 placeholder:text-stone-400 outline-none focus:border-amber-500"
                      />
                      <button
                        type="submit"
                        disabled={!newNoteInput.trim()}
                        className="px-2.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-40 text-white text-xs font-bold transition-all cursor-pointer"
                      >
                        Save
                      </button>
                    </form>

                    {/* Notes list */}
                    <div className="space-y-1.5 max-h-48 overflow-y-auto">
                      {currentProject.notes.length === 0 ? (
                        <p className="text-xs text-stone-400 italic py-2">No notes saved yet.</p>
                      ) : (
                        currentProject.notes.map((note, idx) => (
                          <div
                            key={idx}
                            className="p-2.5 rounded-xl bg-white border border-stone-200/80 text-xs text-stone-800 leading-relaxed font-medium"
                          >
                            {note}
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* Project Files, Documents & Code */}
                  <div className="rounded-2xl border border-stone-200 bg-stone-50/50 p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
                        <Paperclip className="w-4 h-4 text-amber-700" />
                        <span>Project Files & Documents</span>
                      </span>

                      <label className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-white hover:bg-stone-100 text-stone-700 border border-stone-300 text-xs font-semibold cursor-pointer shadow-2xs transition-colors">
                        <Upload className="w-3 h-3 text-amber-600" />
                        <span>Add File</span>
                        <input
                          type="file"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file || !currentProject) return;
                            const text = await file.text();
                            const doc: DocumentAttachment = {
                              id: `doc_${Date.now()}`,
                              name: file.name,
                              type: file.type || 'text/plain',
                              size: file.size,
                              content: text,
                              previewSnippet: text.slice(0, 150),
                            };
                            addProjectFile(currentProject.id, doc);
                            onRefreshProjects();
                          }}
                        />
                      </label>
                    </div>

                    <div className="space-y-1.5 max-h-40 overflow-y-auto">
                      {(!currentProject.files || currentProject.files.length === 0) && (!currentProject.documents || currentProject.documents.length === 0) ? (
                        <p className="text-xs text-stone-400 italic py-2">No documents attached to this project yet.</p>
                      ) : (
                        (currentProject.files || currentProject.documents || []).map((file) => (
                          <div
                            key={file.id}
                            className="p-2 rounded-xl bg-white border border-stone-200 flex items-center justify-between gap-2 text-xs"
                          >
                            <div className="flex items-center gap-2 min-w-0">
                              <FileText className="w-4 h-4 text-amber-600 shrink-0" />
                              <span className="font-semibold text-stone-800 truncate">{file.name}</span>
                              <span className="text-[10px] text-stone-400 font-mono">
                                ({Math.round(file.size / 1024)} KB)
                              </span>
                            </div>
                            <span className="text-[10px] bg-amber-50 text-amber-900 border border-amber-200 px-2 py-0.5 rounded-full font-bold shrink-0">
                              Attached
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

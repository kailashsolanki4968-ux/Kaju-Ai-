import React from 'react';
import { BookOpen, MessageCircleHeart, HelpCircle, Sparkles } from 'lucide-react';
import { ConversationTopic } from '../types';

interface QuickPromptsProps {
  onSelectPrompt: (prompt: string) => void;
  activeTopic: ConversationTopic;
  onSelectTopic: (topic: ConversationTopic) => void;
}

interface PromptItem {
  topic: ConversationTopic;
  category: string;
  hindiTitle: string;
  englishTitle: string;
  fullPrompt: string;
  icon: string;
}

const PROMPTS: PromptItem[] = [
  {
    topic: 'study',
    category: 'Science',
    hindiTitle: 'प्रकाश संश्लेषण (Photosynthesis)',
    englishTitle: 'Biology: Sunlight to glucose cycle',
    fullPrompt: 'Please explain the concept of Photosynthesis in both simple Hindi and English with balanced chemical equations, key stages, and an everyday analogy.',
    icon: '🌱',
  },
  {
    topic: 'study',
    category: 'Physics',
    hindiTitle: 'न्यूटन के गति के नियम (Newton\'s Laws)',
    englishTitle: 'Physics: 3 laws with bus & ball analogies',
    fullPrompt: 'Explain Newton\'s three laws of motion with simple real-life everyday examples and formulas in both Hindi and English.',
    icon: '⚡',
  },
  {
    topic: 'study',
    category: 'Chemistry',
    hindiTitle: 'रासायनिक समीकरण संतुलन (Chemical Reactions)',
    englishTitle: 'Chemistry: Balancing & reaction types',
    fullPrompt: 'Explain how to balance a chemical equation step-by-step with an example like Fe + H2O -> Fe3O4 + H2, explaining what reactants, products, and coefficients mean in Hindi and English.',
    icon: '🧪',
  },
  {
    topic: 'study',
    category: 'Geography',
    hindiTitle: 'मानसून और वर्षा चक्र (Monsoon & Rain)',
    englishTitle: 'Geography: Wind systems & water cycle',
    fullPrompt: 'भारत में दक्षिण-पश्चिम मानसून कैसे आता है और वर्षा चक्र कैसे काम करता है? इसे सरल भाषा और मुख्य बिंदुओं के साथ समझाएं।',
    icon: '🌧️',
  },
  {
    topic: 'study',
    category: 'Economics',
    hindiTitle: 'मुद्रास्फीति और महंगाई (Inflation)',
    englishTitle: 'Economics: Supply, demand & money value',
    fullPrompt: 'Explain inflation (महंगाई/मुद्रास्फीति) in simple terms using an everyday household shopping analogy in Hindi and English.',
    icon: '📈',
  },
  {
    topic: 'study',
    category: 'Grammar',
    hindiTitle: 'Active vs Passive Voice',
    englishTitle: 'English Grammar: Rules & clear examples',
    fullPrompt: 'Explain Active and Passive Voice in simple English and Hindi with clear conversion rules, positive examples, and common mistakes to avoid.',
    icon: '📝',
  },
  {
    topic: 'study',
    category: 'Grammar',
    hindiTitle: 'संधि और उसके भेद (Hindi Grammar)',
    englishTitle: 'Hindi Grammar: स्वर, व्यंजन व विसर्ग संधि',
    fullPrompt: 'हिंदी व्याकरण में संधि क्या है? स्वर संधि, व्यंजन संधि और विसर्ग संधि को सरल नियमों और स्पष्ट उदाहरणों के साथ समझाओ।',
    icon: '📖',
  },
  {
    topic: 'study',
    category: 'Social Science',
    hindiTitle: 'सिंधु घाटी सभ्यता (Indus Valley)',
    englishTitle: 'History: Urban planning & drainage system',
    fullPrompt: 'Explain the Indus Valley Civilization (हड़प्पा सभ्यता) focusing on town planning, drainage systems, and historical significance in simple Hindi and English.',
    icon: '🏛️',
  },
  {
    topic: 'study',
    category: 'Civics',
    hindiTitle: 'भारतीय संविधान व मूल अधिकार',
    englishTitle: 'Civics: Fundamental rights & constitution',
    fullPrompt: 'भारतीय संविधान के मुख्य मूल अधिकार (Fundamental Rights) क्या हैं? इन्हें सरल भाषा में समझाएं और बताएं कि ये नागरिकों के लिए क्यों जरूरी हैं।',
    icon: '⚖️',
  },
  {
    topic: 'study',
    category: 'Tech',
    hindiTitle: 'इंटरनेट कैसे काम करता है?',
    englishTitle: 'Computer Science: IP, DNS, & Servers',
    fullPrompt: 'Explain how the Internet works in simple terms using a postal delivery analogy—including IP addresses, DNS, and servers in Hindi & English.',
    icon: '💻',
  },
  {
    topic: 'study',
    category: 'Math',
    hindiTitle: 'द्विघात समीकरण (Quadratic Formula)',
    englishTitle: 'Math: Step-by-step formula & roots',
    fullPrompt: 'Solve the quadratic equation 2x^2 - 7x + 3 = 0 step-by-step using the quadratic formula with all intermediate steps and formulas clearly shown.',
    icon: '🔢',
  },
  {
    topic: 'study',
    category: 'Math',
    hindiTitle: 'निश्चित समाकलन (Definite Integral)',
    englishTitle: 'Math: Integration by parts with KaTeX',
    fullPrompt: 'Please calculate the integral \\int_{0}^{\\pi} x \\sin(x) \\, dx step-by-step using Integration by Parts, explaining each step in simple Hindi & English.',
    icon: '∫',
  },
  {
    topic: 'study',
    category: 'Practical',
    hindiTitle: 'परीक्षा की तैयारी (Exam Revision Tips)',
    englishTitle: 'Everyday: 5 proven study techniques',
    fullPrompt: 'Can you give me 5 practical, scientifically-backed study and revision techniques for upcoming exams in an encouraging way?',
    icon: '📚',
  },
  {
    topic: 'chat',
    category: 'Friendly Chat',
    hindiTitle: 'नमस्ते काजू! आप कैसे हो?',
    englishTitle: 'Say hello and introduce yourself',
    fullPrompt: 'नमस्ते काजू! आप कैसे हो? अपने बारे में कुछ बताओ और आप पढ़ाई व रोजमर्रा की ज़िंदगी में मेरी कैसे मदद कर सकते हो?',
    icon: '👋',
  },
  {
    topic: 'chat',
    category: 'Friendly Chat',
    hindiTitle: 'आज का सुविचार व सकारात्मक सोच',
    englishTitle: 'Daily motivation & positive reflection',
    fullPrompt: 'आज का एक प्यारा सुविचार (daily positive thought) बताओ और थोड़ी सकारात्मक बातचीत करो!',
    icon: '☀️',
  },
  {
    topic: 'chat',
    category: 'Actions',
    hindiTitle: 'व्हाट्सएप संदेश (WhatsApp Draft)',
    englishTitle: 'Draft a WhatsApp message',
    fullPrompt: 'WhatsApp par message draft karo ki "Meeting kal dopahar 3 baje fix hui hai".',
    icon: '💬',
  },
  {
    topic: 'qa',
    category: 'Actions',
    hindiTitle: 'गूगल मैप्स खोज (Google Maps)',
    englishTitle: 'Search nearby places on Maps',
    fullPrompt: 'Mere paas ke hospital aur clinic search karne ke liye Google Maps kholo.',
    icon: '📍',
  },
  {
    topic: 'qa',
    category: 'Actions',
    hindiTitle: 'फ़ोन डायलर (Phone Dialer)',
    englishTitle: 'Open phone dialer',
    fullPrompt: 'Phone dialer kholo.',
    icon: '📞',
  },
  {
    topic: 'qa',
    category: 'Science Q&A',
    hindiTitle: 'आसमान नीला क्यों दिखता है?',
    englishTitle: 'Rayleigh Scattering explained simply',
    fullPrompt: 'आसमान का रंग नीला क्यों दिखाई देता है? Please explain the science of Rayleigh scattering simply in Hindi & English with an everyday example.',
    icon: '🌤️',
  },
];

export const QuickPrompts: React.FC<QuickPromptsProps> = ({
  onSelectPrompt,
  activeTopic,
  onSelectTopic,
}) => {
  const filteredPrompts =
    activeTopic === 'all'
      ? PROMPTS
      : PROMPTS.filter((p) => p.topic === activeTopic);

  const topicTabs: { id: ConversationTopic; labelEn: string; labelHi: string; icon: React.ReactNode }[] = [
    { id: 'all', labelEn: 'All Topics', labelHi: 'सभी', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'study', labelEn: 'Studies', labelHi: 'पढ़ाई व होमवर्क', icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: 'chat', labelEn: 'Friendly Chat', labelHi: 'दोस्ताना बातचीत', icon: <MessageCircleHeart className="w-3.5 h-3.5" /> },
    { id: 'qa', labelEn: 'Q&A', labelHi: 'सवाल-जवाब', icon: <HelpCircle className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="w-full max-w-2xl mx-auto my-4 px-2">
      {/* Category selector pills */}
      <div className="flex items-center justify-start sm:justify-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
        {topicTabs.map((tab) => {
          const isActive = activeTopic === tab.id;
          return (
            <button
              key={tab.id}
              id={`topic-tab-${tab.id}`}
              type="button"
              onClick={() => onSelectTopic(tab.id)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white text-stone-600 hover:bg-amber-50 hover:text-stone-900 border border-stone-200/80'
              }`}
            >
              {tab.icon}
              <span>{tab.labelEn}</span>
              <span className={`text-[10px] ${isActive ? 'text-amber-100' : 'text-stone-500'}`}>
                ({tab.labelHi})
              </span>
            </button>
          );
        })}
      </div>

      {/* Suggestion prompt cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mt-2">
        {filteredPrompts.map((item, idx) => (
          <button
            key={idx}
            id={`suggested-prompt-${idx}`}
            type="button"
            onClick={() => onSelectPrompt(item.fullPrompt)}
            className="flex items-start text-left gap-3 p-3 rounded-xl bg-white/90 hover:bg-amber-50/80 border border-amber-200/70 hover:border-amber-300 transition-all shadow-xs group cursor-pointer"
          >
            <span className="text-xl shrink-0 mt-0.5 group-hover:scale-110 transition-transform">
              {item.icon}
            </span>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-semibold text-stone-900 leading-snug group-hover:text-amber-900 truncate">
                {item.hindiTitle}
              </p>
              <p className="text-[11px] text-stone-500 leading-snug mt-0.5">
                {item.englishTitle}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

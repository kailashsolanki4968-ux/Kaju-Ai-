import React, { useState } from 'react';
import {
  Search,
  Globe,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  FileText,
  Scale,
  Sparkles,
  AlertCircle,
  Copy,
  Check,
} from 'lucide-react';
import { ResearchReport } from '../types';

interface ResearchReportCardProps {
  report: ResearchReport;
}

export const ResearchReportCard: React.FC<ResearchReportCardProps> = ({ report }) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const textToCopy = `# Research Report: ${report.query}
    
## Quick Answer:
${report.quickAnswer}

## Important Findings:
${report.importantFindings.map((f) => `- ${f}`).join('\n')}

${report.comparisonOrPerspectives ? `## Comparison & Perspectives:\n${report.comparisonOrPerspectives.map((c) => `- ${c}`).join('\n')}\n` : ''}
## Details:
${report.details}

## Sources:
${report.sources.map((s) => `- [${s.title}](${s.url})`).join('\n')}`;

    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full my-3.5 rounded-3xl bg-linear-to-br from-blue-500/10 via-amber-500/5 to-cyan-500/10 border-2 border-blue-200/90 p-4 sm:p-5 shadow-sm space-y-4 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-blue-100 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Search className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-extrabold text-stone-900 text-sm sm:text-base flex items-center gap-1.5">
              Verified Research Report
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-900 border border-blue-300">
                Multi-Source
              </span>
            </h4>
            <p className="text-xs text-stone-500 font-mono line-clamp-1">&ldquo;{report.query}&rdquo;</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleCopy}
            className="p-1.5 rounded-xl bg-white hover:bg-stone-50 text-stone-600 border border-stone-200 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
            title="Copy research summary"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span className="text-[11px] hidden sm:inline">{copied ? 'Copied' : 'Copy'}</span>
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-xl bg-white hover:bg-stone-50 text-stone-600 border border-stone-200 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            <span className="text-[11px] hidden sm:inline">{isExpanded ? 'Collapse' : 'Expand'}</span>
          </button>
        </div>
      </div>

      {/* 1. Quick Answer */}
      <div className="p-3.5 rounded-2xl bg-white border border-blue-100 shadow-2xs space-y-1.5">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-blue-950 uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Quick Answer</span>
        </div>
        <p className="text-xs text-stone-800 leading-relaxed font-medium">
          {report.quickAnswer}
        </p>
      </div>

      {isExpanded && (
        <div className="space-y-3.5 animate-in fade-in duration-200">
          {/* 2. Important Findings */}
          {report.importantFindings && report.importantFindings.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-extrabold text-stone-800 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Key Verified Findings:
              </span>
              <ul className="grid grid-cols-1 gap-1.5 text-xs text-stone-700">
                {report.importantFindings.map((finding, idx) => (
                  <li key={idx} className="p-2.5 rounded-xl bg-white/90 border border-stone-200/90 flex items-start gap-2 shadow-2xs">
                    <span className="w-5 h-5 rounded-lg bg-blue-100 text-blue-900 font-bold flex items-center justify-center shrink-0 text-[10px]">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{finding}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* 3. Comparison / Multiple Perspectives */}
          {report.comparisonOrPerspectives && report.comparisonOrPerspectives.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-extrabold text-stone-800 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-amber-600" />
                Comparison & Diverse Perspectives:
              </span>
              <div className="p-3 rounded-2xl bg-amber-50/60 border border-amber-200 space-y-1.5 text-xs text-stone-800">
                {report.comparisonOrPerspectives.map((comp, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="text-amber-700 font-black">•</span>
                    <span>{comp}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 4. Uncertainty & Source Consistency */}
          {report.uncertaintyNotes && (
            <div className="p-3 rounded-2xl bg-stone-50 border border-stone-200 flex items-start gap-2 text-xs text-stone-600">
              <AlertCircle className="w-4 h-4 text-stone-500 shrink-0 mt-0.5" />
              <div>
                <strong className="text-stone-900">Source Consensus Note: </strong>
                {report.uncertaintyNotes}
              </div>
            </div>
          )}

          {/* 5. In-depth Details */}
          {report.details && (
            <div className="p-3.5 rounded-2xl bg-white border border-stone-200 space-y-1 text-xs text-stone-700 leading-relaxed">
              <div className="font-extrabold text-stone-900 flex items-center gap-1.5 mb-1">
                <FileText className="w-3.5 h-3.5 text-stone-600" />
                Comprehensive Details:
              </div>
              <div className="whitespace-pre-line">{report.details}</div>
            </div>
          )}

          {/* 6. Citations & Real Web Sources */}
          {report.sources && report.sources.length > 0 && (
            <div className="space-y-1.5 pt-1">
              <span className="text-xs font-extrabold text-stone-800 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-600" />
                Verified Sources & Citations ({report.sources.length}):
              </span>
              <div className="flex flex-wrap gap-1.5">
                {report.sources.map((src, i) => (
                  <a
                    key={i}
                    href={src.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-white hover:bg-blue-50 text-blue-800 border border-blue-200 text-xs font-semibold shadow-2xs transition-colors cursor-pointer group"
                  >
                    <span className="truncate max-w-[200px]">{src.title}</span>
                    <ExternalLink className="w-3 h-3 text-blue-500 group-hover:translate-x-0.5 transition-transform shrink-0" />
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

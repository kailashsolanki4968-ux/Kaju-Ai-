import React, { useState, useRef, useEffect } from 'react';
import {
  Plus,
  MessageSquare,
  Trash2,
  Edit2,
  Check,
  X,
  Search,
  PanelLeftClose,
  Sparkles,
  Clock,
  ChevronRight,
  AlertTriangle,
  FolderKanban,
} from 'lucide-react';
import { Conversation } from '../types';
import { KajuLogo } from './KajuLogo';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  activeChatId: string;
  onSelectChat: (id: string) => void;
  onNewChat: () => void;
  onRenameChat: (id: string, newTitle: string) => void;
  onDeleteChat: (id: string) => void;
  onOpenProjectsModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  conversations,
  activeChatId,
  onSelectChat,
  onNewChat,
  onRenameChat,
  onDeleteChat,
  onOpenProjectsModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const editInputRef = useRef<HTMLInputElement>(null);

  // Focus input on rename
  useEffect(() => {
    if (editingChatId && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [editingChatId]);

  const handleStartRename = (conv: Conversation, e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDeleteId(null);
    setEditingChatId(conv.id);
    setEditTitle(conv.title);
  };

  const handleSaveRename = (chatId: string) => {
    const trimmed = editTitle.trim();
    if (trimmed) {
      onRenameChat(chatId, trimmed);
    }
    setEditingChatId(null);
  };

  const handleCancelRename = () => {
    setEditingChatId(null);
    setEditTitle('');
  };

  const handleStartDelete = (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingChatId(null);
    setConfirmDeleteId(chatId);
  };

  const handleConfirmDelete = (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    onDeleteChat(chatId);
    setConfirmDeleteId(null);
  };

  const handleCancelDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setConfirmDeleteId(null);
  };

  // Filter conversations
  const filteredConversations = conversations.filter((c) => {
    if (!searchQuery.trim()) return true;
    const query = searchQuery.toLowerCase();
    const titleMatch = c.title.toLowerCase().includes(query);
    const messageMatch = c.messages.some((m) => m.content.toLowerCase().includes(query));
    return titleMatch || messageMatch;
  });

  // Group conversations by date
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
  const startOf7Days = startOfToday - 7 * 24 * 60 * 60 * 1000;

  const groups: {
    id: string;
    label: string;
    sublabel: string;
    items: Conversation[];
  }[] = [
    { id: 'today', label: 'Today', sublabel: 'आज', items: [] },
    { id: 'yesterday', label: 'Yesterday', sublabel: 'कल', items: [] },
    { id: 'week', label: 'Previous 7 Days', sublabel: 'पिछले 7 दिन', items: [] },
    { id: 'older', label: 'Older', sublabel: 'पुराने', items: [] },
  ];

  filteredConversations.forEach((conv) => {
    const time = conv.updatedAt || conv.createdAt || Date.now();
    if (time >= startOfToday) {
      groups[0].items.push(conv);
    } else if (time >= startOfYesterday) {
      groups[1].items.push(conv);
    } else if (time >= startOf7Days) {
      groups[2].items.push(conv);
    } else {
      groups[3].items.push(conv);
    }
  });

  const activeGroups = groups.filter((g) => g.items.length > 0);

  return (
    <>
      {/* Mobile Backdrop overlay */}
      {isOpen && (
        <div
          id="sidebar-backdrop"
          onClick={onClose}
          className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs z-40 md:hidden transition-opacity"
          aria-hidden="true"
        />
      )}

      {/* Sidebar container */}
      <aside
        id="kaju-sidebar"
        className={`fixed md:static inset-y-0 left-0 z-50 flex flex-col w-72 sm:w-80 bg-stone-900 text-stone-200 border-r border-stone-800 transition-transform duration-300 ease-in-out shrink-0 select-none ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:-translate-x-full md:hidden'
        }`}
        aria-label="Chat History Sidebar"
      >
        {/* Top Header of Sidebar */}
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-stone-800/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-white font-bold text-sm shadow-xs">
              K
            </div>
            <div>
              <span className="font-semibold text-stone-100 text-sm tracking-tight block">
                Kaju AI
              </span>
              <span className="text-[10px] text-amber-400 font-medium">
                चैट इतिहास • History
              </span>
            </div>
          </div>

          <button
            id="close-sidebar-button"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-100 hover:bg-stone-800 transition-colors cursor-pointer"
            title="Close sidebar / बंद करें"
            aria-label="Close sidebar"
          >
            <PanelLeftClose className="w-5 h-5" />
          </button>
        </div>

        {/* Action: New Chat Button (Prominent & Primary) */}
        <div className="p-3 border-b border-stone-800/60">
          <button
            id="new-chat-sidebar-button"
            type="button"
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 768) {
                onClose();
              }
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-medium text-sm shadow-sm hover:shadow transition-all cursor-pointer group"
            title="Start a new conversation / नई बातचीत शुरू करें"
          >
            <div className="flex items-center gap-2">
              <Plus className="w-4 h-4 transition-transform group-hover:rotate-90 duration-200" />
              <span>New Chat</span>
            </div>
            <span className="text-[11px] bg-amber-700/60 text-amber-100 px-2 py-0.5 rounded-md font-normal">
              + नई बातचीत
            </span>
          </button>

          {/* Quick Access to Projects & Workspaces */}
          {onOpenProjectsModal && (
            <button
              type="button"
              onClick={() => {
                onOpenProjectsModal();
                if (window.innerWidth < 768) {
                  onClose();
                }
              }}
              className="w-full mt-2 flex items-center justify-between px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700/80 text-stone-200 hover:text-white font-medium text-xs border border-stone-700/70 transition-all cursor-pointer group"
              title="Open Universal Project Workspaces"
            >
              <div className="flex items-center gap-2">
                <FolderKanban className="w-3.5 h-3.5 text-amber-400" />
                <span>Projects Workspace</span>
              </div>
              <span className="text-[10px] bg-stone-700 text-stone-300 px-1.5 py-0.5 rounded font-mono">
                Workspaces
              </span>
            </button>
          )}

          {/* Search bar inside history (visible if at least 2 chats) */}
          {conversations.length > 1 && (
            <div className="mt-2.5 relative">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="search-chats-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search chats / खोजें..."
                className="w-full bg-stone-800/80 text-stone-200 placeholder-stone-400 text-xs pl-8 pr-7 py-1.5 rounded-lg border border-stone-700/60 focus:outline-hidden focus:border-amber-500 transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-200 p-0.5"
                  title="Clear search"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Middle: Chat History List */}
        <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4 text-xs">
          {conversations.length === 0 ? (
            <div className="px-4 py-8 text-center text-stone-400 space-y-2">
              <MessageSquare className="w-8 h-8 mx-auto text-stone-600 opacity-60" />
              <p className="text-xs font-medium text-stone-300">No conversations yet</p>
              <p className="text-[11px] text-stone-500">
                Start a new chat to ask questions or study with Kaju.
              </p>
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="px-4 py-8 text-center text-stone-400">
              <p className="text-xs">No matching conversations found.</p>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="mt-2 text-[11px] text-amber-400 hover:underline cursor-pointer"
              >
                Clear filter
              </button>
            </div>
          ) : (
            activeGroups.map((group) => (
              <div key={group.id} className="space-y-1">
                {/* Section Header */}
                <div className="px-3 py-1 flex items-center justify-between text-[11px] font-semibold text-stone-400 tracking-wider">
                  <span>{group.label}</span>
                  <span className="text-[10px] text-stone-400 font-normal">{group.sublabel}</span>
                </div>

                {/* Section Items */}
                <div className="space-y-0.5">
                  {group.items.map((conv) => {
                    const isActive = conv.id === activeChatId;
                    const isEditing = editingChatId === conv.id;
                    const isConfirmingDelete = confirmDeleteId === conv.id;

                    return (
                      <div
                        key={conv.id}
                        id={`chat-item-${conv.id}`}
                        onClick={() => {
                          if (!isEditing && !isConfirmingDelete) {
                            onSelectChat(conv.id);
                            if (window.innerWidth < 768) {
                              onClose();
                            }
                          }
                        }}
                        className={`group relative flex items-center justify-between px-3 py-2 rounded-xl transition-all cursor-pointer ${
                          isActive
                            ? 'bg-amber-500/20 text-amber-200 font-medium border border-amber-500/30'
                            : 'text-stone-300 hover:bg-stone-800/80 hover:text-stone-100'
                        }`}
                        title={conv.title}
                      >
                        {/* If in Rename Mode */}
                        {isEditing ? (
                          <div
                            className="flex items-center gap-1.5 w-full"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <input
                              ref={editInputRef}
                              type="text"
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSaveRename(conv.id);
                                if (e.key === 'Escape') handleCancelRename();
                              }}
                              className="flex-1 bg-stone-950 text-stone-100 text-xs px-2 py-1 rounded border border-amber-500 focus:outline-hidden"
                              placeholder="Chat title..."
                            />
                            <button
                              id={`save-rename-${conv.id}`}
                              type="button"
                              onClick={() => handleSaveRename(conv.id)}
                              className="p-1 rounded bg-amber-600 hover:bg-amber-500 text-white cursor-pointer"
                              title="Save title / सुरक्षित करें"
                              aria-label="Save title"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              id={`cancel-rename-${conv.id}`}
                              type="button"
                              onClick={handleCancelRename}
                              className="p-1 rounded bg-stone-700 hover:bg-stone-600 text-stone-300 cursor-pointer"
                              title="Cancel / रद्द करें"
                              aria-label="Cancel rename"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : isConfirmingDelete ? (
                          /* If in Delete Confirmation Mode */
                          <div
                            className="flex items-center justify-between w-full bg-rose-950/60 border border-rose-800/80 rounded-lg px-2 py-1 text-rose-200"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <span className="text-[11px] font-medium flex items-center gap-1 text-rose-300">
                              <AlertTriangle className="w-3 h-3 text-rose-400" />
                              Delete chat?
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                id={`confirm-delete-${conv.id}`}
                                type="button"
                                onClick={(e) => handleConfirmDelete(conv.id, e)}
                                className="px-1.5 py-0.5 rounded bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-semibold cursor-pointer"
                                title="Confirm delete / हटाएं"
                              >
                                Yes
                              </button>
                              <button
                                id={`cancel-delete-${conv.id}`}
                                type="button"
                                onClick={handleCancelDelete}
                                className="px-1.5 py-0.5 rounded bg-stone-700 hover:bg-stone-600 text-stone-200 text-[10px] cursor-pointer"
                                title="Cancel / रद्द करें"
                              >
                                No
                              </button>
                            </div>
                          </div>
                        ) : (
                          /* Normal View */
                          <>
                            <div className="flex items-center gap-2.5 min-w-0 pr-2">
                              <MessageSquare
                                className={`w-3.5 h-3.5 shrink-0 ${
                                  isActive ? 'text-amber-400' : 'text-stone-400 group-hover:text-stone-300'
                                }`}
                              />
                              <span className="truncate text-xs text-left">{conv.title || 'Untitled Chat'}</span>
                            </div>

                            {/* Actions on hover/active (Rename & Delete) */}
                            <div
                              className={`flex items-center gap-1 shrink-0 ${
                                isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                              } transition-opacity`}
                            >
                              <button
                                id={`rename-chat-btn-${conv.id}`}
                                type="button"
                                onClick={(e) => handleStartRename(conv, e)}
                                className="p-1 rounded text-stone-400 hover:text-amber-300 hover:bg-stone-700/60 transition-colors cursor-pointer"
                                title="Rename conversation / नाम बदलें"
                                aria-label="Rename chat"
                              >
                                <Edit2 className="w-3 h-3" />
                              </button>
                              <button
                                id={`delete-chat-btn-${conv.id}`}
                                type="button"
                                onClick={(e) => handleStartDelete(conv.id, e)}
                                className="p-1 rounded text-stone-400 hover:text-rose-400 hover:bg-stone-700/60 transition-colors cursor-pointer"
                                title="Delete conversation / हटाएं"
                                aria-label="Delete chat"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Bottom footer in sidebar */}
        <div className="p-3 border-t border-stone-800/80 bg-stone-950/40 text-[11px] text-stone-400 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Kaju AI v2.0</span>
          </div>
          <span className="text-stone-400 font-mono">
            {conversations.length} {conversations.length === 1 ? 'chat' : 'chats'}
          </span>
        </div>
      </aside>
    </>
  );
};

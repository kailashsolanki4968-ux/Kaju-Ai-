import React, { useState } from 'react';
import {
  GraduationCap,
  Sparkles,
  Trophy,
  Flame,
  CheckCircle2,
  ChevronRight,
  BookOpen,
  ArrowRight,
  RotateCcw,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';
import { SkillJourney, SkillStage } from '../types';

interface SkillJourneyCardProps {
  journey: SkillJourney;
  onSendAction?: (actionText: string) => void;
  onRestartDiagnostic?: () => void;
}

export const SkillJourneyCard: React.FC<SkillJourneyCardProps> = ({
  journey,
  onSendAction,
  onRestartDiagnostic,
}) => {
  const [showMistakes, setShowMistakes] = useState(false);
  const currentLesson = journey.lessons[journey.currentLessonIndex] || journey.lessons[0];

  const stages: { stage: SkillStage; label: string }[] = [
    { stage: 'GOAL', label: 'Goal' },
    { stage: 'LEVEL_CHECK', label: 'Level' },
    { stage: 'PLAN', label: 'Plan' },
    { stage: 'LESSON', label: 'Lesson' },
    { stage: 'PRACTICE', label: 'Practice' },
    { stage: 'FEEDBACK', label: 'Feedback' },
    { stage: 'PROGRESS', label: 'Progress' },
  ];

  const currentStageIndex = stages.findIndex((s) => s.stage === journey.stage);

  return (
    <div className="w-full my-3.5 rounded-3xl bg-linear-to-br from-indigo-500/10 via-amber-500/5 to-rose-500/10 border-2 border-indigo-200/90 p-4 sm:p-5 shadow-sm space-y-4 animate-in fade-in duration-200">
      {/* Top Header */}
      <div className="flex items-center justify-between border-b border-indigo-100 pb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-extrabold text-stone-900 text-sm sm:text-base">
                {journey.skillName} Mastery
              </h4>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-900 border border-indigo-300 uppercase tracking-wider">
                {journey.level}
              </span>
            </div>
            <p className="text-xs text-stone-500 line-clamp-1">{journey.targetGoal}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Streak indicator */}
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300 shadow-2xs">
            <Flame className="w-3.5 h-3.5 text-amber-600 fill-amber-500" />
            <span>{journey.streakDays} Day Streak</span>
          </div>

          <span className="text-xs font-extrabold text-indigo-900 bg-white px-2.5 py-1 rounded-xl border border-indigo-200 shadow-2xs">
            {journey.percentProgress}% Done
          </span>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full space-y-1.5">
        <div className="flex items-center justify-between text-[11px] font-bold text-stone-600">
          <span>Lesson {journey.currentLessonIndex + 1} of {journey.lessons.length}</span>
          <span className="text-indigo-700">{currentLesson?.title}</span>
        </div>
        <div className="w-full h-2 rounded-full bg-stone-200 overflow-hidden">
          <div
            className="h-full bg-linear-to-r from-indigo-500 via-amber-500 to-emerald-500 transition-all duration-300"
            style={{ width: `${journey.percentProgress}%` }}
          />
        </div>
      </div>

      {/* Visual Journey Rail */}
      <div className="flex items-center justify-between p-1.5 rounded-2xl bg-white border border-indigo-100 overflow-x-auto gap-1">
        {stages.map((st, idx) => {
          const isDone = currentStageIndex > idx;
          const isCurrent = currentStageIndex === idx || (currentStageIndex === -1 && idx === 3);

          return (
            <div
              key={st.stage}
              className={`flex items-center gap-1 px-2 py-1 rounded-xl text-[10px] font-bold tracking-tight whitespace-nowrap transition-all ${
                isCurrent
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : isDone
                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                  : 'text-stone-400 bg-stone-50'
              }`}
            >
              {isDone ? (
                <CheckCircle2 className="w-3 h-3 text-emerald-700" />
              ) : (
                <span>{idx + 1}.</span>
              )}
              <span>{st.label}</span>
            </div>
          );
        })}
      </div>

      {/* Active Lesson Card */}
      <div className="p-3.5 rounded-2xl bg-white border border-indigo-100 shadow-2xs space-y-2">
        <div className="flex items-center gap-1.5 text-xs font-extrabold text-indigo-950">
          <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
          <span>{currentLesson?.title}</span>
        </div>
        <p className="text-xs text-stone-600 leading-relaxed font-medium">
          {currentLesson?.objective}
        </p>

        {/* Vocabulary or Key Terms if present */}
        {currentLesson?.keyVocabularyOrFormulas && currentLesson.keyVocabularyOrFormulas.length > 0 && (
          <div className="pt-2 border-t border-stone-100 space-y-1.5">
            <span className="text-[10px] font-extrabold text-stone-500 uppercase tracking-wider">
              Key Vocabulary / Formulae:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {currentLesson.keyVocabularyOrFormulas.map((item, i) => (
                <div key={i} className="p-2 rounded-xl bg-stone-50 border border-stone-200 text-xs">
                  <strong className="text-indigo-900">{item.term}</strong>
                  <span className="text-stone-500 text-[11px] block">{item.meaning}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Action / Practice Trigger */}
      <div className="flex items-center justify-between gap-2 flex-wrap pt-1">
        <div className="flex items-center gap-2">
          {journey.mistakesLog.length > 0 && (
            <button
              type="button"
              onClick={() => setShowMistakes(!showMistakes)}
              className="text-xs font-bold text-amber-800 hover:text-amber-950 bg-amber-100/80 hover:bg-amber-200 px-3 py-1.5 rounded-xl border border-amber-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <AlertTriangle className="w-3 h-3 text-amber-700" />
              <span>{showMistakes ? 'Hide Mistakes' : `Review Mistakes (${journey.mistakesLog.length})`}</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onSendAction?.(`Kaju, let's practice Lesson ${journey.currentLessonIndex + 1} for ${journey.skillName}!`)}
            className="text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-1.5 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>Start Practice</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          type="button"
          onClick={() => onSendAction?.(`Kaju, next lesson shuru karo for ${journey.skillName}`)}
          className="text-xs font-bold text-stone-700 hover:text-indigo-700 hover:underline cursor-pointer"
        >
          Next Lesson →
        </button>
      </div>

      {/* Mistakes Log Drawer */}
      {showMistakes && journey.mistakesLog.length > 0 && (
        <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-2xl space-y-2 animate-in fade-in duration-200">
          <span className="text-xs font-extrabold text-rose-900 flex items-center gap-1">
            <Lightbulb className="w-3.5 h-3.5 text-rose-600" />
            Revision Notes & Personalized Correction:
          </span>
          <div className="space-y-1.5 text-xs text-stone-700 max-h-48 overflow-y-auto">
            {journey.mistakesLog.map((m) => (
              <div key={m.id} className="p-2.5 bg-white rounded-xl border border-rose-100 space-y-1">
                <div className="font-semibold text-stone-800">Q: {m.question}</div>
                <div className="text-rose-700 text-[11px]">Your Answer: {m.userAnswer}</div>
                <div className="text-emerald-800 text-[11px] font-bold">Correction: {m.correction}</div>
                <div className="text-stone-500 text-[10px] italic">💡 Tip: {m.advice}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

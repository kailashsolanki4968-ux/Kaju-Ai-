import React, { useState } from 'react';
import {
  X,
  GraduationCap,
  HelpCircle,
  Calculator,
  BookOpen,
  Camera,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  BookmarkCheck,
} from 'lucide-react';
import { LanguagePreference, StudyOption, StudySubject } from '../types';

interface StudyModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartStudyPrompt: (prompt: string, subject?: string) => void;
  onOpenVision: () => void;
  language: LanguagePreference;
}

export const StudyModeModal: React.FC<StudyModeModalProps> = ({
  isOpen,
  onClose,
  onStartStudyPrompt,
  onOpenVision,
  language,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<StudySubject>('math');
  const [selectedOption, setSelectedOption] = useState<StudyOption>('solve');
  const [questionInput, setQuestionInput] = useState('');

  if (!isOpen) return null;

  const subjects: { id: StudySubject; label: string; icon: string }[] = [
    { id: 'math', label: 'Mathematics (गणित)', icon: '📐' },
    { id: 'physics', label: 'Physics (भौतिकी)', icon: '⚡' },
    { id: 'chemistry', label: 'Chemistry (रसायन)', icon: '🧪' },
    { id: 'biology', label: 'Biology (जीव विज्ञान)', icon: '🧬' },
    { id: 'english', label: 'English Grammar & Lit', icon: '📖' },
    { id: 'hindi', label: 'Hindi Vyakaran (हिंदी व्याकरण)', icon: '🇮🇳' },
    { id: 'social_science', label: 'Social Science / History / Civics', icon: '🌍' },
    { id: 'computer_science', label: 'Computer Science & Coding', icon: '💻' },
  ];

  const options: {
    id: StudyOption;
    title: string;
    sub: string;
    description: string;
    icon: any;
    defaultTemplate: string;
  }[] = [
    {
      id: 'ask',
      title: 'Ask a Question',
      sub: 'सवाल पूछें',
      description: 'Ask any doubt or curiosity about your syllabus or homework.',
      icon: HelpCircle,
      defaultTemplate: 'Kaju, mujhe is concept ke bare mein ek basic doubt clear karna hai: ',
    },
    {
      id: 'solve',
      title: 'Solve a Question',
      sub: 'प्रश्न हल करें',
      description: 'Get full step-by-step mathematical or numerical solution with formulas.',
      icon: Calculator,
      defaultTemplate: 'Kaju, please is question ko step-by-step solve karo: ',
    },
    {
      id: 'explain',
      title: 'Explain a Topic',
      sub: 'विषय विस्तार से समझें',
      description: 'Deep conceptual explanation with real-life analogies and definitions.',
      icon: BookOpen,
      defaultTemplate: 'Kaju, please mujhe ye topic shuru se end tak aasan bhasha mein samjhao: ',
    },
    {
      id: 'photo',
      title: 'Photo Question',
      sub: 'फोटो से प्रश्न',
      description: 'Scan your notebook or textbook page directly with camera.',
      icon: Camera,
      defaultTemplate: '',
    },
    {
      id: 'exam',
      title: 'Exam Preparation',
      sub: 'परीक्षा की तैयारी',
      description: 'Important questions, formulas revision, and key summary takeaways.',
      icon: BookmarkCheck,
      defaultTemplate: 'Kaju, meri upcoming exam ke liye is chapter ke important questions aur formulas revise karwa do: ',
    },
  ];

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (selectedOption === 'photo') {
      onClose();
      onOpenVision();
      return;
    }

    const trimmed = questionInput.trim();
    const currentOpt = options.find((o) => o.id === selectedOption);
    const subjectName = subjects.find((s) => s.id === selectedSubject)?.label || 'General';

    let prompt = '';
    if (trimmed) {
      prompt = `[Subject: ${subjectName}] ${currentOpt?.defaultTemplate || ''}${trimmed}`;
    } else {
      prompt = `Kaju, mujhe ${subjectName} mein [${currentOpt?.title}] mein guide karo aur basic revision shuru karo.`;
    }

    onClose();
    onStartStudyPrompt(prompt, subjectName);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl shadow-2xl border border-amber-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-stone-200 bg-linear-to-r from-amber-50 to-orange-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-stone-900 flex items-center gap-2">
                <span>🎓 Padhai • Study Mode</span>
                <span className="text-[11px] font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                  All School Subjects
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                Structured 5-step clarity: Concepts, Steps, Formulas, Final Answer & Recap
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-white/80 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Step 1: Select Subject */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-stone-600 block">
              1. Select Subject • विषय चुनें
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {subjects.map((subj) => (
                <button
                  key={subj.id}
                  type="button"
                  onClick={() => setSelectedSubject(subj.id)}
                  className={`p-2.5 rounded-2xl text-left border text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                    selectedSubject === subj.id
                      ? 'bg-amber-100/90 border-amber-400 text-amber-950 shadow-2xs'
                      : 'bg-stone-50 hover:bg-stone-100/80 border-stone-200 text-stone-700'
                  }`}
                >
                  <span className="text-base">{subj.icon}</span>
                  <span className="truncate">{subj.label.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: Choose Study Experience (5 required options) */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-stone-600 block">
              2. Choose Study Goal • पढ़ाई का लक्ष्य
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {options.map((opt) => {
                const IconComponent = opt.icon;
                const isSelected = selectedOption === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setSelectedOption(opt.id);
                      if (opt.id === 'photo') {
                        onClose();
                        onOpenVision();
                      }
                    }}
                    className={`p-3.5 rounded-2xl text-left border transition-all cursor-pointer flex items-start gap-3 ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-400 text-stone-900 shadow-xs ring-1 ring-amber-400'
                        : 'bg-white hover:bg-stone-50 border-stone-200 text-stone-700'
                    }`}
                  >
                    <div
                      className={`p-2 rounded-xl shrink-0 ${
                        isSelected ? 'bg-amber-500 text-white' : 'bg-stone-100 text-stone-600'
                      }`}
                    >
                      <IconComponent className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-bold text-xs text-stone-900">{opt.title}</span>
                        <span className="text-[10px] text-amber-700 font-medium">({opt.sub})</span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5 leading-snug">
                        {opt.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 3: Question or Topic description input */}
          {selectedOption !== 'photo' && (
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-stone-600 block">
                3. Enter your Question or Topic (Hindi, English or Hinglish)
              </label>
              <textarea
                value={questionInput}
                onChange={(e) => setQuestionInput(e.target.value)}
                placeholder="Type question, equation, or topic here... (e.g. Find the roots of 2x^2 + 5x - 3 = 0 or Photosynthesis process in plants)"
                rows={3}
                className="w-full p-3 rounded-2xl bg-stone-50 border border-stone-200 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500"
              />
            </div>
          )}

          {/* Educational Clarity Structure Preview */}
          <div className="bg-amber-50/80 rounded-2xl p-3 border border-amber-200/80 text-[11px] text-amber-900 space-y-1">
            <span className="font-bold flex items-center gap-1 text-amber-800">
              <Sparkles className="w-3.5 h-3.5" />
              Kaju's 5-Step Solution Structure:
            </span>
            <p className="text-stone-600">
              1. What is being asked • 2. Concept Explanation • 3. Steps & Examples • 4. Final Answer • 5. Short Recap
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-stone-600 hover:text-stone-900 text-xs font-medium cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => handleSubmit()}
            className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <span>Start Study with Kaju</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

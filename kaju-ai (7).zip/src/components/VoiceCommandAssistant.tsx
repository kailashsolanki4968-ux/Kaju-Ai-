import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  X,
  Sparkles,
  Volume2,
  VolumeX,
  CheckCircle2,
  AlertTriangle,
  Send,
  Phone,
  MessageCircle,
  ExternalLink,
  ShieldCheck,
  RotateCcw,
  ArrowRight,
  HelpCircle,
  Laptop,
} from 'lucide-react';
import {
  VoiceAssistantStatus,
  VoiceCommandResult,
  LanguagePreference,
  DeviceAction,
  ActionPermissions,
} from '../types';
import { speechManager } from '../utils/speech';
import { getSpeechRecognitionLang } from '../utils/languages';
import {
  parseVoiceCommandLocally,
  parseVoiceCommandWithAI,
  detectTranscriptLanguage,
} from '../utils/voiceCommandParser';
import {
  executeDeviceAction,
  executeDeviceActionAsync,
  isActionPermitted,
  sanitizePhoneNumber,
} from '../utils/actionHelper';
import { NativeActionRouter } from '../utils/nativeActionRouter';

interface VoiceCommandAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  languagePreference: LanguagePreference;
  permissions: ActionPermissions;
  onActionExecuted: (action: DeviceAction) => void;
  onSendToChat: (text: string) => void;
  onOpenActionCenter: (tab?: 'overview' | 'quick_actions' | 'permissions' | 'desktop' | 'history') => void;
}

export const VoiceCommandAssistant: React.FC<VoiceCommandAssistantProps> = ({
  isOpen,
  onClose,
  languagePreference,
  permissions,
  onActionExecuted,
  onSendToChat,
  onOpenActionCenter,
}) => {
  const [status, setStatus] = useState<VoiceAssistantStatus>('idle');
  const [transcript, setTranscript] = useState('');
  const [interimText, setInterimText] = useState('');
  const [result, setResult] = useState<VoiceCommandResult | null>(null);
  const [isVoiceFeedbackEnabled, setIsVoiceFeedbackEnabled] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Editable fields for WhatsApp / Phone before confirming
  const [editedPhone, setEditedPhone] = useState('');
  const [editedMessage, setEditedMessage] = useState('');

  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef(false);

  // Handle Voice Recognition Language
  const getRecognitionLang = (pref: LanguagePreference): string => {
    return getSpeechRecognitionLang(pref);
  };

  // Start Voice Listening
  const startListening = async () => {
    speechManager.stop();
    setErrorMessage(null);
    setResult(null);
    setTranscript('');
    setInterimText('');

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setStatus('error');
      setErrorMessage(
        'Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.'
      );
      return;
    }

    // Check mic permission via getUserMedia
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch (err: any) {
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          setStatus('error');
          setErrorMessage(
            'Microphone access was denied. Please allow microphone permissions in your browser address bar.'
          );
          return;
        }
      }
    }

    stopListening();

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = getRecognitionLang(languagePreference);

      recognition.onstart = () => {
        isListeningRef.current = true;
        setStatus('listening');
      };

      recognition.onresult = (event: any) => {
        let finalStr = '';
        let interimStr = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const trans = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalStr += trans;
          } else {
            interimStr += trans;
          }
        }
        if (finalStr) {
          setTranscript(finalStr);
          processSpokenCommand(finalStr);
        } else {
          setInterimText(interimStr);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Voice Assistant recognition error:', event.error);
        if (event.error === 'no-speech') {
          setStatus('idle');
          return;
        }
        if (event.error === 'not-allowed') {
          setStatus('error');
          setErrorMessage('Microphone access was blocked. Please enable it in browser settings.');
          return;
        }
        setStatus('error');
        setErrorMessage(`Voice recognition error: ${event.error}`);
      };

      recognition.onend = () => {
        isListeningRef.current = false;
        if (status === 'listening') {
          setStatus('idle');
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Failed to start speech recognition:', err);
      setStatus('error');
      setErrorMessage(err?.message || 'Could not start microphone.');
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {}
      recognitionRef.current = null;
    }
    isListeningRef.current = false;
  };

  // Process the recognized spoken command
  const processSpokenCommand = async (spokenText: string) => {
    stopListening();
    setStatus('processing');

    try {
      // Step 1: Check fast local heuristics
      let parsed = parseVoiceCommandLocally(spokenText, languagePreference);

      // Step 2: If no local pattern matched, fall back to AI endpoint
      if (!parsed) {
        parsed = await parseVoiceCommandWithAI(spokenText, languagePreference);
      }

      setResult(parsed);

      // Check for direct safe app launch (Requirement 5: explicit app launch commands can happen directly)
      if (parsed.action?.type === 'launch_app') {
        const payload = parsed.action.payload.launch_app;
        if (payload?.appId) {
          const launchResult = await NativeActionRouter.launchApp(payload.appId);
          parsed.action.status = launchResult.success ? 'executed' : (launchResult.status === 'not_installed' ? 'blocked' : 'error');
          parsed.action.executedAt = Date.now();
          parsed.action.error = launchResult.success ? undefined : launchResult.message;
          onActionExecuted(parsed.action);

          const isHindi = parsed.detectedLanguage === 'hindi';
          const spokenMsg = isHindi ? launchResult.hindiMessage : launchResult.message;
          parsed.feedbackSpoken = spokenMsg;

          if (launchResult.success) {
            setStatus('executed');
          } else {
            setStatus('error');
            setErrorMessage(spokenMsg);
          }

          if (isVoiceFeedbackEnabled && spokenMsg) {
            speechManager.speak(`voice_cmd_${Date.now()}`, spokenMsg, isHindi ? 'hindi' : 'english');
          }
          return;
        }
      }

      // Populate editable fields if action payload exists
      const p = parsed.action?.payload as any;
      if (parsed.action?.type === 'whatsapp' && p) {
        const waPhone = p.whatsapp?.phone || p.phone || p.recipient || '';
        const waMsg = p.whatsapp?.message || p.message || '';
        setEditedPhone(waPhone);
        setEditedMessage(waMsg);
      } else if (parsed.action?.type === 'call' && p) {
        const callPhone = p.call?.phone || p.phone || '';
        setEditedPhone(callPhone);
      }

      // Determine next status
      if (parsed.clarificationNeeded) {
        setStatus('clarifying');
      } else if (parsed.action) {
        setStatus('action_ready');
      } else {
        setStatus('idle');
      }

      // Speak feedback if voice enabled
      if (isVoiceFeedbackEnabled && parsed.feedbackSpoken) {
        const langPref: LanguagePreference =
          parsed.detectedLanguage === 'hindi' ? 'hindi' : 'english';
        speechManager.speak(`voice_cmd_${Date.now()}`, parsed.feedbackSpoken, langPref);
      }
    } catch (err: any) {
      console.error('Error processing voice command:', err);
      setStatus('error');
      setErrorMessage('Failed to understand voice command. Please try again.');
    }
  };

  // Handle explicit confirmation of action
  const handleConfirmAction = async () => {
    if (!result || !result.action) return;

    let actionToExecute: DeviceAction = { ...result.action };

    // Update with any user edits
    if (actionToExecute.type === 'whatsapp') {
      actionToExecute.payload = {
        ...actionToExecute.payload,
        whatsapp: {
          phone: editedPhone ? sanitizePhoneNumber(editedPhone) : '',
          recipientName: editedPhone ? '' : 'Recipient',
          message: editedMessage,
        },
      };
    } else if (actionToExecute.type === 'call') {
      actionToExecute.payload = {
        ...actionToExecute.payload,
        call: {
          phone: sanitizePhoneNumber(editedPhone),
        },
      };
    }

    // Check permissions
    const permCheck = isActionPermitted(actionToExecute, permissions);
    if (!permCheck.allowed) {
      setStatus('error');
      setErrorMessage(permCheck.reason || 'Action blocked by settings.');
      return;
    }

    // Execute safely (opens WhatsApp or Phone Dialer or URL)
    const execResult = await executeDeviceActionAsync(actionToExecute);
    actionToExecute.status = execResult.success ? 'executed' : 'blocked';
    actionToExecute.executedAt = Date.now();
    if (!execResult.success && execResult.message) {
      actionToExecute.error = execResult.message;
    }

    onActionExecuted(actionToExecute);
    setStatus(execResult.success ? 'executed' : 'error');

    if (isVoiceFeedbackEnabled) {
      const lang = result.detectedLanguage || 'english';
      let msg = 'Confirmed! The action has been opened.';
      if (execResult.success) {
        if (lang === 'hindi') {
          msg = 'कन्फर्म हो गया! एक्शन खोल दिया गया है।';
        } else if (lang === 'hinglish') {
          msg = 'Confirm ho gaya! Action open kar diya gaya hai.';
        }
      } else {
        if (lang === 'hindi') {
          msg = 'एक्शन पूरा नहीं हो सका: ' + execResult.message;
        } else if (lang === 'hinglish') {
          msg = 'Action complete nahi ho saka: ' + execResult.message;
        } else {
          msg = 'Could not complete action: ' + execResult.message;
        }
      }
      speechManager.speak(`exec_${Date.now()}`, msg, lang as any);
    }
  };

  const handleCancelAction = () => {
    if (result && result.action) {
      const cancelled: DeviceAction = {
        ...result.action,
        status: 'cancelled',
        executedAt: Date.now(),
      };
      onActionExecuted(cancelled);
    }
    setStatus('idle');
    setResult(null);
  };

  const handleSelectClarification = (cmd: string) => {
    setTranscript(cmd);
    processSpokenCommand(cmd);
  };

  // When modal opens, auto-start listening
  useEffect(() => {
    if (isOpen) {
      startListening();
    } else {
      stopListening();
      speechManager.stop();
      setStatus('idle');
      setResult(null);
      setTranscript('');
      setInterimText('');
      setErrorMessage(null);
    }
    return () => {
      stopListening();
      speechManager.stop();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="voice-command-assistant-modal"
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-amber-200/80 overflow-hidden flex flex-col max-h-[90vh] transition-all"
      >
        {/* Top bar with Siri-inspired aesthetic */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-amber-100 bg-linear-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-linear-to-tr from-amber-500 via-rose-500 to-indigo-500 p-0.5 shadow-xs">
              <div className="w-full h-full bg-white rounded-full flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-amber-600 animate-pulse" />
              </div>
            </div>
            <div>
              <h2 className="text-sm font-bold text-stone-900 leading-tight">
                Kaju Voice Assistant
              </h2>
              <p className="text-[11px] text-stone-500">
                Siri-like Voice Commands • हिंदी, English, Hinglish
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Toggle voice response */}
            <button
              id="voice-feedback-toggle"
              type="button"
              onClick={() => {
                const next = !isVoiceFeedbackEnabled;
                setIsVoiceFeedbackEnabled(next);
                if (!next) speechManager.stop();
              }}
              className={`p-2 rounded-full transition-colors cursor-pointer ${
                isVoiceFeedbackEnabled
                  ? 'text-amber-700 bg-amber-100 hover:bg-amber-200'
                  : 'text-stone-400 hover:text-stone-600 hover:bg-stone-100'
              }`}
              title={isVoiceFeedbackEnabled ? 'Voice feedback ON' : 'Voice feedback muted'}
            >
              {isVoiceFeedbackEnabled ? (
                <Volume2 className="w-4 h-4" />
              ) : (
                <VolumeX className="w-4 h-4" />
              )}
            </button>

            {/* Close button */}
            <button
              id="close-voice-assistant-btn"
              type="button"
              onClick={onClose}
              className="p-2 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer"
              title="Close Voice Assistant"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dynamic Center Area: Orb & Listening Animation */}
        <div className="px-6 py-6 flex flex-col items-center justify-center text-center bg-radial from-amber-500/5 to-transparent">
          {/* Pulsing Acoustic Visualizer Orb */}
          <div className="relative my-2 flex items-center justify-center">
            {status === 'listening' && (
              <>
                <div className="absolute w-28 h-28 rounded-full bg-amber-400/20 animate-ping duration-1000" />
                <div className="absolute w-24 h-24 rounded-full bg-rose-400/20 animate-pulse" />
              </>
            )}

            <button
              id="voice-mic-main-button"
              type="button"
              onClick={status === 'listening' ? stopListening : startListening}
              className={`relative z-10 w-20 h-20 rounded-full flex items-center justify-center shadow-lg transition-all transform active:scale-95 cursor-pointer ${
                status === 'listening'
                  ? 'bg-linear-to-tr from-amber-500 via-rose-500 to-indigo-600 text-white ring-4 ring-amber-300 animate-pulse'
                  : status === 'processing'
                  ? 'bg-amber-600 text-white animate-spin'
                  : 'bg-white text-stone-700 border-2 border-amber-300 hover:border-amber-500 hover:bg-amber-50'
              }`}
            >
              {status === 'listening' ? (
                <Mic className="w-8 h-8 animate-bounce" />
              ) : status === 'processing' ? (
                <Sparkles className="w-8 h-8" />
              ) : (
                <Mic className="w-8 h-8 text-amber-600" />
              )}
            </button>
          </div>

          {/* Assistant Status Text */}
          <div className="mt-3">
            {status === 'listening' && (
              <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-amber-800">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span>सुन रहा हूँ... / Listening (Hindi, English, Hinglish)...</span>
              </div>
            )}
            {status === 'processing' && (
              <p className="text-xs font-semibold text-stone-600 animate-pulse">
                आदेश समझ रहा हूँ... / Processing your command...
              </p>
            )}
            {status === 'idle' && (
              <p className="text-xs text-stone-500">
                माइक पर टैप करके बोलें (Tap mic to speak a command)
              </p>
            )}
            {status === 'executed' && (
              <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>एक्शन सफलतापूर्वक खोल दिया गया / Action Opened</span>
              </div>
            )}
          </div>

          {/* Real-time Spoken Transcript */}
          {(transcript || interimText) && (
            <div className="w-full mt-4 p-3 bg-amber-50/70 border border-amber-200/80 rounded-2xl text-left">
              <span className="text-[10px] uppercase font-bold tracking-wider text-amber-800 block mb-0.5">
                Recognized Voice:
              </span>
              <p className="text-sm font-medium text-stone-900 leading-snug">
                "{transcript || interimText}"
              </p>
            </div>
          )}

          {/* Error Banner */}
          {errorMessage && (
            <div className="w-full mt-3 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-left text-xs text-rose-800">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">{errorMessage}</p>
                <button
                  type="button"
                  onClick={startListening}
                  className="mt-1.5 text-rose-700 underline font-medium hover:text-rose-900 cursor-pointer"
                >
                  Try Again / पुनः प्रयास करें
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Scrollable Result / Confirmation Area */}
        <div className="flex-1 overflow-y-auto px-5 pb-5 space-y-4">
          {/* Clarification prompt if command was incomplete */}
          {status === 'clarifying' && result?.clarificationPrompt && (
            <div className="p-4 bg-amber-50/90 border border-amber-300 rounded-2xl text-left space-y-2.5">
              <div className="flex items-center gap-2 text-amber-900 font-semibold text-xs">
                <HelpCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>स्पष्टीकरण आवश्यक / Clarification Needed</span>
              </div>
              <p className="text-sm text-stone-800 font-medium">
                {result.clarificationPrompt}
              </p>

              {/* Suggestions chips */}
              {result.clarificationOptions && result.clarificationOptions.length > 0 && (
                <div className="pt-2 flex flex-wrap gap-1.5">
                  {result.clarificationOptions.map((opt, i) => (
                    <button
                      key={i}
                      id={`clarify-option-${i}`}
                      type="button"
                      onClick={() => handleSelectClarification(opt.command)}
                      className="px-3 py-1.5 rounded-full bg-white border border-amber-300 hover:bg-amber-100 text-stone-800 text-xs font-medium transition-colors cursor-pointer flex items-center gap-1.5 shadow-2xs"
                    >
                      <span>{opt.label}</span>
                      <ArrowRight className="w-3 h-3 text-amber-600" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Unsupported Desktop Control boundary explanation */}
          {result?.recognizedIntent === 'unsupported' && (
            <div className="p-4 bg-stone-50 border border-stone-300 rounded-2xl text-left space-y-2.5">
              <div className="flex items-center gap-2 text-stone-800 font-bold text-xs">
                <Laptop className="w-4 h-4 text-amber-600 shrink-0" />
                <span>ब्राउज़र सुरक्षा सीमा / Browser Sandbox Boundary</span>
              </div>
              <p className="text-xs text-stone-700 leading-relaxed">
                {result.explanation ||
                  'Web browsers operate in an isolated sandbox and cannot directly control computer hardware, shutdown the PC, or run local scripts.'}
              </p>
              <button
                id="view-desktop-plan-btn"
                type="button"
                onClick={() => {
                  onClose();
                  onOpenActionCenter('desktop');
                }}
                className="w-full py-2 px-3 rounded-xl bg-stone-800 hover:bg-stone-900 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>View Desktop Companion Blueprint</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Conversational & Study Query recognized */}
          {result?.recognizedIntent === 'chat' && (
            <div className="p-4 bg-amber-50/80 border border-amber-300 rounded-2xl text-left space-y-3">
              <div className="flex items-center gap-2 text-stone-900 font-bold text-xs">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>{result.title || 'Kaju AI Study Query'}</span>
              </div>
              <p className="text-xs text-stone-700 leading-relaxed font-medium">
                &ldquo;{result.rawTranscript}&rdquo;
              </p>
              <button
                id="voice-send-study-btn"
                type="button"
                onClick={() => {
                  onSendToChat(result.rawTranscript);
                  onClose();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <span>Ask Kaju & Get Step-by-Step Explanation</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Action Confirmation Card (WhatsApp / Phone / Apps) */}
          {status === 'action_ready' && result?.action && (
            <div className="p-4 bg-white border-2 border-amber-300/90 rounded-2xl shadow-xs text-left space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {result.action.type === 'whatsapp' && (
                    <MessageCircle className="w-5 h-5 text-emerald-600" />
                  )}
                  {result.action.type === 'call' && (
                    <Phone className="w-5 h-5 text-indigo-600" />
                  )}
                  {result.action.type === 'launch_app' && (
                    <ExternalLink className="w-5 h-5 text-orange-600" />
                  )}
                  {result.action.type === 'open_url' && (
                    <ExternalLink className="w-5 h-5 text-amber-600" />
                  )}
                  {result.action.type === 'search' && (
                    <Sparkles className="w-5 h-5 text-amber-600" />
                  )}
                  <h3 className="text-sm font-bold text-stone-900">
                    {result.action.title}
                  </h3>
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                  {result.action.type === 'launch_app' ? 'Direct Launch' : 'Confirmation Required'}
                </span>
              </div>

              {/* Editable Fields for WhatsApp */}
              {result.action.type === 'whatsapp' && (
                <div className="space-y-2">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                      Recipient Phone (Optional - leaves empty to pick in WhatsApp):
                    </label>
                    <input
                      id="voice-edit-whatsapp-phone"
                      type="text"
                      value={editedPhone}
                      onChange={(e) => setEditedPhone(e.target.value)}
                      placeholder="Enter phone number (or leave blank)"
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-stone-300 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                      Prepared Message (संदेश):
                    </label>
                    <textarea
                      id="voice-edit-whatsapp-msg"
                      value={editedMessage}
                      onChange={(e) => setEditedMessage(e.target.value)}
                      rows={3}
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-stone-300 focus:outline-none focus:border-amber-500 resize-none"
                    />
                  </div>
                </div>
              )}

              {/* Editable Fields for Call */}
              {result.action.type === 'call' && (
                <div>
                  <label className="block text-[11px] font-semibold text-stone-600 mb-1">
                    Phone Number (फ़ोन नंबर):
                  </label>
                  <input
                    id="voice-edit-call-phone"
                    type="text"
                    value={editedPhone}
                    onChange={(e) => setEditedPhone(e.target.value)}
                    placeholder="Enter phone number to call"
                    className="w-full px-3 py-1.5 text-xs font-mono font-medium rounded-lg border border-stone-300 focus:outline-none focus:border-amber-500"
                  />
                </div>
              )}

              {/* Launch App Details */}
              {result.action.type === 'launch_app' && result.action.payload.launch_app && (
                <div className="text-xs text-stone-600 bg-orange-50/70 p-2.5 rounded-lg border border-orange-200">
                  <div className="flex items-center justify-between">
                    <p className="font-bold text-stone-900">
                      {result.action.payload.launch_app.appName} ({result.action.payload.launch_app.hindiName})
                    </p>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-orange-100 text-orange-800">
                      {NativeActionRouter.isNativeAndroid() ? 'Android Native Intent' : 'Browser Preview • Website'}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-600 mt-1">
                    {NativeActionRouter.isNativeAndroid()
                      ? 'Launches installed Android application directly via Android Intent.'
                      : 'Opens website in browser preview (installed app launches on Android APK).'}
                  </p>
                </div>
              )}

              {/* URL / Search Details */}
              {result.action.type === 'open_url' && result.action.payload.open_url && (
                <div className="text-xs text-stone-600 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                  <p className="font-semibold text-stone-800">
                    {result.action.payload.open_url.appName}
                  </p>
                  <p className="text-[11px] text-stone-500 truncate mt-0.5">
                    {result.action.payload.open_url.url}
                  </p>
                </div>
              )}

              {result.action.type === 'search' && result.action.payload.search && (
                <div className="text-xs text-stone-600 bg-stone-50 p-2.5 rounded-lg border border-stone-200">
                  <p className="font-semibold text-stone-800">
                    Engine: {result.action.payload.search.engine.toUpperCase()}
                  </p>
                  <p className="text-stone-700 mt-0.5 font-medium">
                    Query: "{result.action.payload.search.query}"
                  </p>
                </div>
              )}

              {/* Zero-click Safety Guarantee Notice */}
              <div className="flex items-center gap-1.5 text-[11px] text-stone-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>
                  Zero-Click Safety: Never sends or calls automatically. It opens for your final review.
                </span>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                <button
                  id="voice-confirm-action-btn"
                  type="button"
                  onClick={handleConfirmAction}
                  className="flex-1 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    {result.action.type === 'whatsapp'
                      ? 'Open WhatsApp'
                      : result.action.type === 'call'
                      ? 'Open Dialer'
                      : result.action.type === 'launch_app'
                      ? `Open ${result.action.payload.launch_app?.appName || 'App'}`
                      : 'Open Now'}
                  </span>
                </button>

                <button
                  id="voice-cancel-action-btn"
                  type="button"
                  onClick={handleCancelAction}
                  className="py-2 px-3 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-medium transition-colors cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Quick Voice Command Ideas / Hints */}
          {status === 'idle' && (
            <div className="border-t border-amber-100 pt-3 text-left">
              <span className="text-[11px] font-bold text-stone-600 uppercase tracking-wider block mb-2">
                Sample Voice Commands (उदाहरण):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setTranscript('WhatsApp message draft karo');
                    processSpokenCommand('WhatsApp message draft karo ki hum kal milenge');
                  }}
                  className="p-2.5 rounded-xl bg-white hover:bg-amber-50 border border-stone-200 text-left transition-colors cursor-pointer group"
                >
                  <p className="font-semibold text-stone-800 group-hover:text-amber-900">
                    💬 "WhatsApp message bhejo..."
                  </p>
                  <p className="text-[11px] text-stone-500">Drafts message for confirmation</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTranscript('Phone dialer kholo');
                    processSpokenCommand('Phone dialer kholo');
                  }}
                  className="p-2.5 rounded-xl bg-white hover:bg-amber-50 border border-stone-200 text-left transition-colors cursor-pointer group"
                >
                  <p className="font-semibold text-stone-800 group-hover:text-amber-900">
                    📞 "Phone dialer kholo"
                  </p>
                  <p className="text-[11px] text-stone-500">Prepares phone dialer safely</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTranscript('YouTube kholo');
                    processSpokenCommand('YouTube kholo');
                  }}
                  className="p-2.5 rounded-xl bg-white hover:bg-amber-50 border border-stone-200 text-left transition-colors cursor-pointer group"
                >
                  <p className="font-semibold text-stone-800 group-hover:text-amber-900">
                    ▶️ "YouTube kholo"
                  </p>
                  <p className="text-[11px] text-stone-500">Opens educational video portal</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setTranscript('Nearby hospital maps par dhundo');
                    processSpokenCommand('Nearby hospital maps par dhundo');
                  }}
                  className="p-2.5 rounded-xl bg-white hover:bg-amber-50 border border-stone-200 text-left transition-colors cursor-pointer group"
                >
                  <p className="font-semibold text-stone-800 group-hover:text-amber-900">
                    📍 "Hospital maps par dhundo"
                  </p>
                  <p className="text-[11px] text-stone-500">Searches on Google Maps</p>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Bar: Send to regular chat option */}
        {transcript && (
          <div className="px-5 py-3 border-t border-stone-200 bg-stone-50 flex items-center justify-between gap-3 text-xs">
            <span className="text-stone-500 truncate">
              Want to keep this in conversation history?
            </span>
            <button
              id="send-voice-to-chat-btn"
              type="button"
              onClick={() => {
                onSendToChat(transcript);
                onClose();
              }}
              className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-medium flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send to Chat</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

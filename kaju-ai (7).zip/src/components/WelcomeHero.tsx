import React from 'react';
import { BookOpen, Sparkles, MessageCircle, HelpCircle, Camera } from 'lucide-react';
import { KajuLogo } from './KajuLogo';
import { QuickPrompts } from './QuickPrompts';
import { ConversationTopic } from '../types';

interface WelcomeHeroProps {
  onSelectPrompt: (prompt: string) => void;
  activeTopic: ConversationTopic;
  onSelectTopic: (topic: ConversationTopic) => void;
}

export const WelcomeHero: React.FC<WelcomeHeroProps> = ({
  onSelectPrompt,
  activeTopic,
  onSelectTopic,
}) => {
  return (
    <div className="flex flex-col items-center text-center px-4 py-6 sm:py-10 max-w-4xl mx-auto">
      {/* Brand Icon */}
      <div className="mb-4">
        <KajuLogo size="xl" />
      </div>

      {/* Main Title */}
      <h1 className="text-2xl sm:text-3xl font-bold text-stone-900 tracking-tight flex items-center justify-center gap-2 flex-wrap">
        <span>Meet Kaju AI</span>
        <span className="text-amber-700 bg-amber-100/90 text-sm font-semibold px-2.5 py-0.5 rounded-lg border border-amber-200">
          काजू एआई
        </span>
      </h1>

      {/* Bilingual Subtitle */}
      <p className="mt-2 text-stone-600 text-sm sm:text-base max-w-lg leading-relaxed">
        नमस्ते! I am your friendly bilingual study mentor. Ask questions, scan textbook pages and handwritten formulas with camera, or chat in Hindi & English!
      </p>

      {/* Feature Highlights */}
      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 w-full my-6 text-left">
        <div className="bg-white p-3.5 rounded-xl border border-amber-200/70 shadow-2xs">
          <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center mb-2">
            <BookOpen className="w-4 h-4" />
          </div>
          <h2 className="text-xs font-bold text-stone-900">Study Help • पढ़ाई</h2>
          <p className="text-[11px] text-stone-500 mt-1 leading-snug">
            Math, science, exam prep, formulas, and step-by-step clarity.
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-amber-200/70 shadow-2xs">
          <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-800 flex items-center justify-center mb-2">
            <Camera className="w-4 h-4" />
          </div>
          <h2 className="text-xs font-bold text-stone-900">Camera Scan • फोटो प्रश्न</h2>
          <p className="text-[11px] text-stone-500 mt-1 leading-snug">
            Snap textbook pages, diagrams, or handwritten notes for instant solution.
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-amber-200/70 shadow-2xs">
          <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-800 flex items-center justify-center mb-2">
            <MessageCircle className="w-4 h-4" />
          </div>
          <h2 className="text-xs font-bold text-stone-900">Friendly Chat • बातचीत</h2>
          <p className="text-[11px] text-stone-500 mt-1 leading-snug">
            Warm, polite, encouraging companion in Hindi, English & Hinglish.
          </p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-amber-200/70 shadow-2xs">
          <div className="w-8 h-8 rounded-lg bg-yellow-100 text-yellow-800 flex items-center justify-center mb-2">
            <HelpCircle className="w-4 h-4" />
          </div>
          <h2 className="text-xs font-bold text-stone-900">Any Question • सवाल</h2>
          <p className="text-[11px] text-stone-500 mt-1 leading-snug">
            Instant accurate answers powered by Google's Gemini AI.
          </p>
        </div>
      </div>

      {/* Suggested Starters */}
      <div className="w-full">
        <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2 flex items-center justify-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          Try asking one of these to get started
        </p>
        <QuickPrompts
          onSelectPrompt={onSelectPrompt}
          activeTopic={activeTopic}
          onSelectTopic={onSelectTopic}
        />
      </div>
    </div>
  );
};

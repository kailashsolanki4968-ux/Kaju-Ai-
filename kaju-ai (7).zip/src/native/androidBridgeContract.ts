/**
 * Android Native Bridge Interface & Intent Contract for Kaju AI.
 * 
 * Defines the bidirectional communication contract between the Kaju web application
 * and the Android native host layer (e.g., Android WebView via @JavascriptInterface or Capacitor/Cordova wrapper).
 */

export interface NativeIntentParams {
  action?: string;
  category?: string;
  packageName?: string;
  dataUri?: string;
  type?: string;
  extras?: Record<string, string | number | boolean>;
  flags?: number;
}

export interface NativeLaunchResponse {
  success: boolean;
  code: 'OK' | 'APP_NOT_INSTALLED' | 'NO_RESOLVING_ACTIVITY' | 'PERMISSION_DENIED' | 'BRIDGE_ERROR';
  message: string;
  packageName?: string;
  appId?: string;
}

export interface KajuNativeBridge {
  /**
   * Returns true if running inside the official Kaju Android native APK / WebView.
   */
  isAndroidNative: () => boolean;

  /**
   * Queries Android PackageManager to verify if an application is installed.
   * @param packageName e.g. "com.google.android.youtube", "com.whatsapp"
   */
  isAppInstalled: (packageName: string) => boolean | Promise<boolean>;

  /**
   * Launches an installed application by package name or specific Intent parameters.
   */
  launchApp: (appId: string, intentParams: NativeIntentParams) => Promise<NativeLaunchResponse>;

  /**
   * Launches a raw Android intent URI string (e.g. intent://...#Intent;...).
   */
  launchIntentUri: (intentUri: string) => Promise<NativeLaunchResponse>;

  /**
   * Opens Android phone dialer with phone number pre-filled.
   */
  openDialer?: (phoneNumber: string) => Promise<NativeLaunchResponse>;

  /**
   * Launches native camera capture activity.
   */
  openCamera?: () => Promise<NativeLaunchResponse>;

  /**
   * Launches native gallery / image picker activity.
   */
  openGallery?: () => Promise<NativeLaunchResponse>;

  /**
   * Opens system Settings.
   */
  openSettings?: (settingsAction?: string) => Promise<NativeLaunchResponse>;
}

declare global {
  interface Window {
    KajuNative?: KajuNativeBridge;
    AndroidBridge?: any;
  }
}

/**
 * Standard Android Intent Action & Category Constants
 */
export const ANDROID_INTENT_CONSTANTS = {
  // Common Actions
  ACTION_VIEW: 'android.intent.action.VIEW',
  ACTION_MAIN: 'android.intent.action.MAIN',
  ACTION_DIAL: 'android.intent.action.DIAL',
  ACTION_SEND: 'android.intent.action.SEND',
  ACTION_IMAGE_CAPTURE: 'android.media.action.IMAGE_CAPTURE',
  ACTION_SETTINGS: 'android.settings.SETTINGS',
  
  // App Categories (Android 4.0+)
  CATEGORY_APP_CALCULATOR: 'android.intent.category.APP_CALCULATOR',
  CATEGORY_APP_MAPS: 'android.intent.category.APP_MAPS',
  CATEGORY_APP_GALLERY: 'android.intent.category.APP_GALLERY',
  CATEGORY_LAUNCHER: 'android.intent.category.LAUNCHER',

  // Well-known Android Package IDs
  PACKAGES: {
    YOUTUBE: 'com.google.android.youtube',
    WHATSAPP: 'com.whatsapp',
    CALCULATOR_GOOGLE: 'com.google.android.calculator',
    CALCULATOR_AOSP: 'com.android.calculator2',
    CALCULATOR_SAMSUNG: 'com.sec.android.app.popupcalculator',
    CALCULATOR_MIUI: 'com.miui.calculator',
    MAPS: 'com.google.android.apps.maps',
    GMAIL: 'com.google.android.gm',
  }
} as const;

export type Role = 'user' | 'assistant';

export type ActionType = 'whatsapp' | 'call' | 'open_url' | 'launch_app' | 'search' | 'unsupported';
export type ActionStatus = 'draft' | 'ready' | 'executed' | 'cancelled' | 'blocked' | 'error';

export type SupportedAppId =
  | 'youtube'
  | 'whatsapp'
  | 'calculator'
  | 'camera'
  | 'gallery'
  | 'settings'
  | 'maps'
  | 'gmail';

export interface WhatsAppPayload {
  phone?: string;
  recipientName?: string;
  message: string;
}

export interface CallPayload {
  phone: string;
  contactName?: string;
}

export interface OpenUrlPayload {
  url: string;
  appName?: string;
  description?: string;
}

export interface LaunchAppPayload {
  appId: SupportedAppId;
  appName: string;
  hindiName: string;
  packageName?: string;
  intentAction?: string;
  intentUri?: string;
  fallbackWebUrl?: string;
  requiresConfirmation?: boolean;
}

export interface SearchPayload {
  query: string;
  engine: 'google' | 'youtube' | 'maps' | 'wikipedia';
}

export interface UnsupportedPayload {
  requestedAction: string;
  reason: string;
  requiredTier: 'android' | 'desktop';
  safeAlternative?: string;
}

export interface DeviceAction {
  id: string;
  type: ActionType;
  status: ActionStatus;
  title: string;
  payload: {
    whatsapp?: WhatsAppPayload;
    call?: CallPayload;
    open_url?: OpenUrlPayload;
    launch_app?: LaunchAppPayload;
    search?: SearchPayload;
    unsupported?: UnsupportedPayload;
  };
  createdAt: number;
  executedAt?: number;
  error?: string;
}

export interface ActionPermissions {
  allowWhatsApp: boolean;
  allowPhoneDialer: boolean;
  allowExternalLinks: boolean;
  requireConfirmationAlways: boolean;
}

export interface DocumentAttachment {
  id: string;
  name: string;
  type: string;
  size: number;
  content: string; // extracted text content
  previewSnippet?: string;
}

export interface WebCitation {
  title: string;
  url: string;
  snippet?: string;
}

export interface GeneratedImageCard {
  id: string;
  prompt: string;
  englishPrompt?: string;
  imageUrl?: string;
  aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4';
  style?: string;
  model: string;
  status: 'pending_confirmation' | 'generating' | 'completed' | 'error' | 'quota_restricted';
  costEstimate?: string;
  error?: string;
  errorDetails?: {
    code?: number;
    requiresPaidPlan?: boolean;
    setupGuideUrl?: string;
    message?: string;
    hindiMessage?: string;
    pricingInfo?: string;
  };
  createdAt: number;
}

export interface GeneratedVideoCard {
  id: string;
  operationName?: string;
  prompt: string;
  videoUrl?: string;
  status: 'pending_confirmation' | 'submitting' | 'processing' | 'completed' | 'error' | 'quota_restricted';
  progress?: number;
  model: string;
  resolution: '720p' | '1080p';
  aspectRatio: '16:9' | '9:16';
  costEstimate?: string;
  error?: string;
  errorDetails?: {
    code?: number;
    requiresPaidPlan?: boolean;
    setupGuideUrl?: string;
    message?: string;
    hindiMessage?: string;
    costEstimate?: string;
  };
  createdAt: number;
}

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: string;
  status?: 'sending' | 'complete' | 'error';
  action?: DeviceAction;
  image?: string;
  fileAttachment?: DocumentAttachment;
  citations?: WebCitation[];
  suggestedFollowUps?: string[];
  gameCard?: GameState;
  skillCard?: SkillJourney;
  researchReport?: ResearchReport;
  generatedImage?: GeneratedImageCard;
  generatedVideo?: GeneratedVideoCard;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
  topic?: ConversationTopic;
}

export type LanguagePreference =
  | 'auto'
  | 'hindi'
  | 'english'
  | 'hinglish'
  | 'spanish'
  | 'french'
  | 'german'
  | 'portuguese'
  | 'italian'
  | 'japanese'
  | 'korean'
  | 'chinese'
  | 'arabic'
  | 'russian'
  | 'indonesian'
  | 'turkish'
  | 'vietnamese'
  | 'thai'
  | 'bengali'
  | 'marathi'
  | 'telugu'
  | 'tamil'
  | 'gujarati'
  | 'kannada'
  | 'malayalam'
  | 'punjabi'
  | 'urdu'
  | (string & {});
export type ConversationTopic = 'all' | 'study' | 'chat' | 'qa';
export type NavigationTab = 'home' | 'chats' | 'actions' | 'vision' | 'kaju';

export type KajuCoreState =
  | 'idle'
  | 'listening'
  | 'understanding'
  | 'planning'
  | 'preparing'
  | 'doing'
  | 'answering'
  | 'checking'
  | 'adjusting'
  | 'completed'
  | 'error';

// Kaju Goal Engine & Journey types
export type GoalType =
  | 'general'
  | 'study'
  | 'task'
  | 'exam'
  | 'skill'
  | 'problem'
  | 'coding'
  | 'project'
  | 'language'
  | 'travel'
  | 'business';
export type GoalStatus = 'active' | 'completed' | 'abandoned';
export type JourneyStage = 'GOAL' | 'NOW' | 'NEXT' | 'CHECK' | 'DONE';
export type StepStatus = 'pending' | 'in_progress' | 'completed' | 'skipped';

export interface Checkpoint {
  id: string;
  stepId: string;
  question: string;
  expectedConcept?: string;
  userAnswer?: string;
  result?: 'passed' | 'failed' | 'pending';
  attempts: number;
  feedback?: string;
}

export interface ReplayEvent {
  id: string;
  goalId: string;
  type: 'started' | 'detected' | 'practiced' | 'adapted' | 'checkpoint' | 'completed';
  description: string;
  timestamp: number;
}

export interface JourneyStep {
  id: string;
  goalId: string;
  stage: JourneyStage; // 'GOAL' | 'NOW' | 'NEXT' | 'CHECK' | 'DONE'
  title: string;
  description: string;
  status: StepStatus;
  order: number;
  primaryAction: {
    label: string;
    prompt: string;
  };
  evidence?: string;
  completedAt?: number;
  checkpoint?: Checkpoint;
}

export interface Goal {
  id: string;
  title: string;
  originalInput: string;
  type: GoalType;
  status: GoalStatus;
  createdAt: number;
  deadline?: string;
  currentStepId: string;
  currentStage: JourneyStage;
  completionCondition: string;
  steps: JourneyStep[];
  replayEvents: ReplayEvent[];
  weakAreas?: string[];
  completedAt?: number;
}

export type IntentCategory =
  | 'CONVERSATION'
  | 'STUDY'
  | 'VISION'
  | 'ACTION'
  | 'GOAL'
  | 'CODING'
  | 'RESEARCH'
  | 'CREATE'
  | 'FUN'
  | 'GAME'
  | 'SKILL';

// ==========================================
// 👤 KAJU ACCOUNT & AUTH SYSTEM
// ==========================================
export type AccountProvider = 'guest' | 'email' | 'google' | 'local';

export interface KajuAccount {
  uid: string;
  provider: AccountProvider;
  email?: string;
  displayName: string;
  photoURL?: string;
  createdAt: number;
  lastLoginAt: number;
  isAnonymous: boolean;
  migratedFromGuestUid?: string;
}

export interface CloudSyncStatus {
  status: 'local' | 'synced' | 'syncing' | 'error';
  lastSyncedAt?: number;
  pendingItemsCount: number;
  message?: string;
}

// ==========================================
// 🎮 KAJU INTERACTIVE GAMES & FUN COMPANION
// ==========================================
export type GameType =
  | 'number_guess'
  | 'twenty_questions'
  | 'word_guess'
  | 'riddle'
  | 'quiz'
  | 'memory'
  | 'math'
  | 'emoji_guess'
  | 'tic_tac_toe';

export type GameStatus = 'active' | 'won' | 'lost' | 'abandoned';

export interface GameState {
  gameId: string;
  type: GameType;
  title: string;
  status: GameStatus;
  startedAt: number;
  turnCount: number;
  score: number;
  streak?: number;
  // Specific game payload
  data: {
    // Number guess
    targetNumber?: number;
    minRange?: number;
    maxRange?: number;
    attemptsLeft?: number;
    guesses?: number[];
    // 20 Questions
    secretSubject?: string;
    questionsAsked?: { question: string; answer: 'Yes' | 'No' | 'Partially' | 'Irrelevant' }[];
    maxQuestions?: number;
    // Word Guess
    word?: string;
    category?: string;
    guessedLetters?: string[];
    revealedPattern?: string;
    wrongGuessesCount?: number;
    // Riddle
    riddleQuestion?: string;
    riddleAnswer?: string;
    hint?: string;
    hintUsed?: boolean;
    // Quiz
    quizTopic?: string;
    currentQuestionIndex?: number;
    totalQuestions?: number;
    questionText?: string;
    options?: string[];
    correctIndex?: number;
    userAnswers?: number[];
    // Memory
    sequence?: number[];
    displayDurationMs?: number;
    phase?: 'memorize' | 'recall';
    // Math
    problemText?: string;
    solutionValue?: number;
    timeRemainingSeconds?: number;
    // Emoji Guess
    emojiPrompt?: string;
    targetTitle?: string;
    hintClue?: string;
    // Tic-Tac-Toe
    board?: (string | null)[]; // 9 cells: 'X' | 'O' | null
    playerSymbol?: 'X' | 'O';
    aiSymbol?: 'X' | 'O';
    turn?: 'player' | 'ai';
    winner?: 'player' | 'ai' | 'tie' | null;
    winningLine?: number[];
  };
  lastMessage?: string;
  feedbackText?: string;
}

export interface GameProgress {
  totalGamesPlayed: number;
  gamesWon: number;
  currentStreak: number;
  bestStreak: number;
  highScores: Partial<Record<GameType, number>>;
  lastPlayedAt?: number;
}

// ==========================================
// 📁 UNIVERSAL PROJECTS & WORKSPACES ARCHITECTURE
// ==========================================
export interface ProjectImageAttachment {
  id: string;
  name: string;
  dataUrl: string;
  timestamp: number;
}

export interface ProjectWorkspace {
  id: string;
  name: string;
  description: string;
  category: 'general' | 'coding' | 'learning' | 'trip' | 'business' | 'creative';
  createdAt: number;
  updatedAt: number;
  notes: string[];
  tasks: { id: string; title: string; completed: boolean; dueDate?: string }[];
  activeGoalId?: string;
  associatedChatIds: string[];
  documents?: DocumentAttachment[];
  files?: DocumentAttachment[];
  images?: ProjectImageAttachment[];
  goals?: string[];
}

// ==========================================
// 🎓 KAJU SKILL MODE
// ==========================================
export type SkillLevel = 'beginner' | 'intermediate' | 'advanced';

export type SkillStage =
  | 'GOAL'
  | 'LEVEL_CHECK'
  | 'PLAN'
  | 'LESSON'
  | 'PRACTICE'
  | 'CHECK'
  | 'FEEDBACK'
  | 'PROGRESS'
  | 'NEXT_LESSON';

export interface SkillPracticeQuestion {
  id: string;
  question: string;
  type: 'text' | 'choice';
  options?: string[];
  sampleAnswer: string;
}

export interface SkillLesson {
  id: string;
  order: number;
  title: string;
  objective: string;
  content: string; // Explanations, rules, formulas, pronunciations
  keyVocabularyOrFormulas?: { term: string; meaning: string; example?: string }[];
  practicePrompt: string;
  practiceQuestions: SkillPracticeQuestion[];
  completed: boolean;
  score?: number;
}

export interface SkillMistakeRecord {
  id: string;
  timestamp: number;
  question: string;
  userAnswer: string;
  correction: string;
  advice: string;
}

export interface SkillJourney {
  id: string;
  skillName: string; // e.g. "Japanese", "English", "Python Coding", "Calculus"
  targetGoal: string;
  level: SkillLevel;
  stage: SkillStage;
  diagnosticDone: boolean;
  diagnosticScore?: number;
  currentLessonIndex: number;
  lessons: SkillLesson[];
  mistakesLog: SkillMistakeRecord[];
  streakDays: number;
  totalPracticeCompleted: number;
  percentProgress: number;
  createdAt: number;
  updatedAt: number;
}

// ==========================================
// 🔬 KAJU RESEARCH MODE
// ==========================================
export interface ResearchReport {
  id: string;
  query: string;
  quickAnswer: string;
  importantFindings: string[];
  comparisonOrPerspectives?: string[];
  details: string;
  sources: { title: string; url: string; snippet?: string }[];
  uncertaintyNotes?: string;
  generatedAt: number;
}

// ==========================================
// 🧠 MEMORY & TRANSPARENCY
// ==========================================
export interface UserMemory {
  id: string;
  content: string;
  category: 'preference' | 'profile' | 'fact' | 'work' | 'instruction';
  createdAt: number;
  updatedAt: number;
  source?: 'user_stated' | 'user_approved' | 'system_default';
  isVerified?: boolean;
}

export interface MemoryOperation {
  action: 'add' | 'update' | 'delete';
  content: string;
  oldContent?: string;
  category?: UserMemory['category'];
}

// ==========================================
// 🆔 KAJU NUMBER / ID IDENTITY DISCOVERY
// ==========================================
export interface KajuPublicProfile {
  kajuId: string;
  phoneNumber?: string;
  displayName: string;
  bio: string;
  accountType: 'personal' | 'creator' | 'business';
  verified: boolean;
  avatarSeed: string;
  joinedDate: string;
  isPublic: boolean;
  location?: string;
  links?: { label: string; url: string }[];
}

export type StudyOption = 'ask' | 'solve' | 'explain' | 'photo' | 'exam';
export type StudySubject =
  | 'all'
  | 'math'
  | 'physics'
  | 'chemistry'
  | 'biology'
  | 'english'
  | 'hindi'
  | 'social_science'
  | 'computer_science';

export type VoiceAssistantStatus =
  | 'idle'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'clarifying'
  | 'action_ready'
  | 'executed'
  | 'error';

export interface VoiceCommandClarificationOption {
  label: string;
  command: string;
}

export interface VoiceCommandResult {
  rawTranscript: string;
  recognizedIntent: 'open_url' | 'launch_app' | 'search' | 'whatsapp' | 'call' | 'unsupported' | 'chat' | 'clarify';
  detectedLanguage: 'hindi' | 'english' | 'hinglish';
  title: string;
  action?: DeviceAction;
  clarificationNeeded?: boolean;
  clarificationPrompt?: string;
  clarificationOptions?: VoiceCommandClarificationOption[];
  feedbackSpoken: string;
  explanation?: string;
}

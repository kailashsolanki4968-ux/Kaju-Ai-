import { KajuAccount, CloudSyncStatus } from '../types';

export const ACCOUNT_STORAGE_KEY = 'kaju_active_account_v1';
export const ACCOUNTS_DB_KEY = 'kaju_registered_accounts_v1';
export const SYNC_STATUS_KEY = 'kaju_sync_status_v1';

// In-memory fallback cache for Node test environments or private browsing
let accountStorageCache: Record<string, string> = {};

function safeGetItem(key: string): string | null {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key);
    }
    return accountStorageCache[key] ?? null;
  } catch {
    return accountStorageCache[key] ?? null;
  }
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
    accountStorageCache[key] = value;
  } catch {
    accountStorageCache[key] = value;
  }
}

function safeRemoveItem(key: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(key);
    }
    delete accountStorageCache[key];
  } catch {
    delete accountStorageCache[key];
  }
}

export function getScopedKey(uid: string, keyName: string): string {
  return `kaju_user_${uid}_${keyName}`;
}

/**
 * Generate a random unique ID
 */
function generateUid(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 8)}`;
}

/**
 * Get or initialize current account (defaults to Guest)
 */
export function getCurrentAccount(): KajuAccount {
  try {
    const raw = safeGetItem(ACCOUNT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.uid) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error loading account:', e);
  }

  // Create initial anonymous Guest account
  const guestAccount: KajuAccount = {
    uid: generateUid('guest'),
    provider: 'guest',
    displayName: 'Guest Explorer',
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    isAnonymous: true,
  };

  saveCurrentAccount(guestAccount);
  return guestAccount;
}

/**
 * Save current active account
 */
export function saveCurrentAccount(account: KajuAccount): void {
  try {
    safeSetItem(ACCOUNT_STORAGE_KEY, JSON.stringify(account));
  } catch (e) {
    console.error('Error saving account:', e);
  }
}

/**
 * Get all registered accounts (mock database in localStorage)
 */
export function getRegisteredAccounts(): Record<string, { account: KajuAccount; passwordHash?: string }> {
  try {
    const raw = safeGetItem(ACCOUNTS_DB_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveRegisteredAccounts(db: Record<string, { account: KajuAccount; passwordHash?: string }>): void {
  try {
    safeSetItem(ACCOUNTS_DB_KEY, JSON.stringify(db));
  } catch (e) {
    console.error('Error saving registered accounts:', e);
  }
}

/**
 * Guest to Permanent Account Migration
 * Safely copies all chats, goals, projects, memories, and game progress
 */
export function migrateGuestData(guestUid: string, permanentUid: string): {
  chatsMigrated: number;
  goalsMigrated: number;
  projectsMigrated: number;
  memoriesMigrated: number;
} {
  let chatsMigrated = 0;
  let goalsMigrated = 0;
  let projectsMigrated = 0;
  let memoriesMigrated = 0;

  try {
    // 1. Migrate Conversations
    const guestChatKey = getScopedKey(guestUid, 'conversations');
    const permChatKey = getScopedKey(permanentUid, 'conversations');
    const guestChatsRaw = localStorage.getItem(guestChatKey) || localStorage.getItem('kaju_ai_conversations_v2');
    if (guestChatsRaw) {
      const guestChats = JSON.parse(guestChatsRaw);
      if (Array.isArray(guestChats) && guestChats.length > 0) {
        const permChatsRaw = localStorage.getItem(permChatKey);
        const permChats = permChatsRaw ? JSON.parse(permChatsRaw) : [];
        const mergedChats = [...permChats, ...guestChats.filter(gc => !permChats.some((pc: any) => pc.id === gc.id))];
        localStorage.setItem(permChatKey, JSON.stringify(mergedChats));
        localStorage.setItem('kaju_ai_conversations_v2', JSON.stringify(mergedChats));
        chatsMigrated = guestChats.length;
      }
    }

    // 2. Migrate Goals
    const guestGoalsKey = getScopedKey(guestUid, 'goals');
    const permGoalsKey = getScopedKey(permanentUid, 'goals');
    const guestGoalsRaw = localStorage.getItem(guestGoalsKey) || localStorage.getItem('kaju_ai_goals_v1');
    if (guestGoalsRaw) {
      const guestGoals = JSON.parse(guestGoalsRaw);
      if (Array.isArray(guestGoals) && guestGoals.length > 0) {
        const permGoalsRaw = localStorage.getItem(permGoalsKey);
        const permGoals = permGoalsRaw ? JSON.parse(permGoalsRaw) : [];
        const mergedGoals = [...permGoals, ...guestGoals.filter(gg => !permGoals.some((pg: any) => pg.id === gg.id))];
        localStorage.setItem(permGoalsKey, JSON.stringify(mergedGoals));
        localStorage.setItem('kaju_ai_goals_v1', JSON.stringify(mergedGoals));
        goalsMigrated = guestGoals.length;
      }
    }

    // 3. Migrate Projects
    const guestProjKey = getScopedKey(guestUid, 'projects');
    const permProjKey = getScopedKey(permanentUid, 'projects');
    const guestProjRaw = localStorage.getItem(guestProjKey) || localStorage.getItem('kaju_projects_v1');
    if (guestProjRaw) {
      const guestProjs = JSON.parse(guestProjRaw);
      if (Array.isArray(guestProjs) && guestProjs.length > 0) {
        const permProjRaw = localStorage.getItem(permProjKey);
        const permProjs = permProjRaw ? JSON.parse(permProjRaw) : [];
        const mergedProjs = [...permProjs, ...guestProjs.filter(gp => !permProjs.some((pp: any) => pp.id === gp.id))];
        localStorage.setItem(permProjKey, JSON.stringify(mergedProjs));
        localStorage.setItem('kaju_projects_v1', JSON.stringify(mergedProjs));
        projectsMigrated = guestProjs.length;
      }
    }

    // 4. Migrate Memories
    const guestMemKey = getScopedKey(guestUid, 'memories');
    const permMemKey = getScopedKey(permanentUid, 'memories');
    const guestMemRaw = localStorage.getItem(guestMemKey) || localStorage.getItem('kaju_ai_user_memories_v1') || localStorage.getItem('kaju_user_memories_v1');
    if (guestMemRaw) {
      const guestMems = JSON.parse(guestMemRaw);
      if (Array.isArray(guestMems) && guestMems.length > 0) {
        const permMemRaw = localStorage.getItem(permMemKey);
        const permMems = permMemRaw ? JSON.parse(permMemRaw) : [];
        const mergedMems = [...permMems, ...guestMems.filter(gm => !permMems.some((pm: any) => pm.id === gm.id))];
        localStorage.setItem(permMemKey, JSON.stringify(mergedMems));
        localStorage.setItem('kaju_ai_user_memories_v1', JSON.stringify(mergedMems));
        memoriesMigrated = guestMems.length;
      }
    }

    // 5. Migrate Skills
    const guestSkillKey = getScopedKey(guestUid, 'skills');
    const permSkillKey = getScopedKey(permanentUid, 'skills');
    const guestSkillRaw = localStorage.getItem(guestSkillKey) || localStorage.getItem('kaju_skill_journeys_v1');
    if (guestSkillRaw) {
      const guestSkills = JSON.parse(guestSkillRaw);
      if (Array.isArray(guestSkills) && guestSkills.length > 0) {
        const permSkillRaw = localStorage.getItem(permSkillKey);
        const permSkills = permSkillRaw ? JSON.parse(permSkillRaw) : [];
        const mergedSkills = [...permSkills, ...guestSkills.filter(gs => !permSkills.some((ps: any) => ps.id === gs.id))];
        localStorage.setItem(permSkillKey, JSON.stringify(mergedSkills));
        localStorage.setItem('kaju_skill_journeys_v1', JSON.stringify(mergedSkills));
      }
    }

    // 6. Migrate Game Progress
    const guestGameKey = getScopedKey(guestUid, 'game_progress');
    const permGameKey = getScopedKey(permanentUid, 'game_progress');
    const guestGameRaw = localStorage.getItem(guestGameKey) || localStorage.getItem('kaju_game_progress_v1');
    if (guestGameRaw) {
      localStorage.setItem(permGameKey, guestGameRaw);
      localStorage.setItem('kaju_game_progress_v1', guestGameRaw);
    }
  } catch (err) {
    console.error('Migration error:', err);
  }

  return { chatsMigrated, goalsMigrated, projectsMigrated, memoriesMigrated };
}

/**
 * Sign In / Connect with Google
 */
export function signInWithGoogle(customEmail?: string, customName?: string): {
  account: KajuAccount;
  migrationReport?: ReturnType<typeof migrateGuestData>;
} {
  const current = getCurrentAccount();
  const db = getRegisteredAccounts();

  const googleEmail = (customEmail || `user_${Date.now().toString(36).substring(2, 7)}@gmail.com`).toLowerCase().trim();
  const displayName = customName || (customEmail ? customEmail.split('@')[0] : 'User');

  // Check if account already exists
  const existingKey = Object.keys(db).find(k => db[k].account.email === googleEmail);

  let targetAccount: KajuAccount;
  let migrationReport;

  if (existingKey) {
    targetAccount = {
      ...db[existingKey].account,
      lastLoginAt: Date.now(),
      provider: 'google',
    };
  } else {
    const newUid = `google_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
    targetAccount = {
      uid: newUid,
      provider: 'google',
      email: googleEmail,
      displayName,
      photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(googleEmail)}`,
      createdAt: Date.now(),
      lastLoginAt: Date.now(),
      isAnonymous: false,
    };
  }

  // If current was guest, perform data migration
  if (current.isAnonymous && current.uid !== targetAccount.uid) {
    migrationReport = migrateGuestData(current.uid, targetAccount.uid);
    targetAccount.migratedFromGuestUid = current.uid;
  }

  db[targetAccount.uid] = { account: targetAccount };
  saveRegisteredAccounts(db);
  saveCurrentAccount(targetAccount);

  // Restore user-scoped data into active session
  restoreUserScopedData(targetAccount.uid);

  return { account: targetAccount, migrationReport };
}

/**
 * Sign Up with Email & Password
 */
export function signUpWithEmail(email: string, password: string, displayName: string): {
  success: boolean;
  error?: string;
  account?: KajuAccount;
  migrationReport?: ReturnType<typeof migrateGuestData>;
} {
  const cleanEmail = email.toLowerCase().trim();
  if (!cleanEmail || !cleanEmail.includes('@')) {
    return { success: false, error: 'Please enter a valid email address.' };
  }
  if (!password || password.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters.' };
  }

  const db = getRegisteredAccounts();
  const existingKey = Object.keys(db).find(k => db[k].account.email === cleanEmail);
  if (existingKey) {
    return { success: false, error: 'An account with this email already exists. Please login instead.' };
  }

  const current = getCurrentAccount();
  const newUid = `email_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 7)}`;
  const newAccount: KajuAccount = {
    uid: newUid,
    provider: 'email',
    email: cleanEmail,
    displayName: displayName.trim() || cleanEmail.split('@')[0],
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    isAnonymous: false,
  };

  let migrationReport;
  if (current.isAnonymous) {
    migrationReport = migrateGuestData(current.uid, newUid);
    newAccount.migratedFromGuestUid = current.uid;
  }

  db[newUid] = { account: newAccount, passwordHash: btoa(password) };
  saveRegisteredAccounts(db);
  saveCurrentAccount(newAccount);

  // Restore user-scoped data into active session
  restoreUserScopedData(newUid);

  return { success: true, account: newAccount, migrationReport };
}

/**
 * Log In with Email & Password
 */
export function loginWithEmail(email: string, password: string): {
  success: boolean;
  error?: string;
  account?: KajuAccount;
  migrationReport?: ReturnType<typeof migrateGuestData>;
} {
  const cleanEmail = email.toLowerCase().trim();
  const db = getRegisteredAccounts();
  const existingKey = Object.keys(db).find(k => db[k].account.email === cleanEmail);

  if (!existingKey) {
    return { success: false, error: 'No account found with this email. Please check or sign up.' };
  }

  const record = db[existingKey];
  if (record.passwordHash && record.passwordHash !== btoa(password)) {
    return { success: false, error: 'Incorrect password. Try again or reset password.' };
  }

  const current = getCurrentAccount();
  let migrationReport;
  const updatedAccount: KajuAccount = {
    ...record.account,
    lastLoginAt: Date.now(),
  };

  if (current.isAnonymous && current.uid !== updatedAccount.uid) {
    migrationReport = migrateGuestData(current.uid, updatedAccount.uid);
    updatedAccount.migratedFromGuestUid = current.uid;
  }

  db[existingKey].account = updatedAccount;
  saveRegisteredAccounts(db);
  saveCurrentAccount(updatedAccount);

  // Restore user-scoped data to active keys
  restoreUserScopedData(updatedAccount.uid);

  return { success: true, account: updatedAccount, migrationReport };
}

/**
 * Log out and return to a fresh Guest account
 */
export function logoutAccount(): KajuAccount {
  const freshGuest: KajuAccount = {
    uid: generateUid('guest'),
    provider: 'guest',
    displayName: 'Guest Explorer',
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    isAnonymous: true,
  };

  saveCurrentAccount(freshGuest);
  // Reset active session storage so previous user's sensitive data doesn't leak into guest
  restoreUserScopedData(freshGuest.uid);
  return freshGuest;
}

/**
 * Persist current active session data to user-scoped storage before switching
 */
export function persistCurrentSessionToScope(uid: string): void {
  try {
    const conv = safeGetItem('kaju_ai_conversations_v2');
    if (conv) safeSetItem(getScopedKey(uid, 'conversations'), conv);

    const goals = safeGetItem('kaju_ai_goals_v1');
    if (goals) safeSetItem(getScopedKey(uid, 'goals'), goals);

    const mems = safeGetItem('kaju_ai_user_memories_v1');
    if (mems) safeSetItem(getScopedKey(uid, 'memories'), mems);

    const projs = safeGetItem('kaju_projects_v1');
    if (projs) safeSetItem(getScopedKey(uid, 'projects'), projs);
  } catch (e) {
    console.error('Error persisting current session to scope:', e);
  }
}

/**
 * List all available profiles on this device
 */
export function listProfiles(): KajuAccount[] {
  const current = getCurrentAccount();
  const db = getRegisteredAccounts();
  const accounts = Object.values(db).map((r) => r.account);
  if (!accounts.some((a) => a.uid === current.uid)) {
    accounts.unshift(current);
  }
  return accounts;
}

/**
 * Create a new separate user profile
 */
export function createSeparateProfile(displayName: string): KajuAccount {
  const current = getCurrentAccount();
  persistCurrentSessionToScope(current.uid);

  const cleanName = displayName.trim() || 'New User';
  const newUid = generateUid('profile');
  const newAccount: KajuAccount = {
    uid: newUid,
    provider: 'local',
    displayName: cleanName,
    createdAt: Date.now(),
    lastLoginAt: Date.now(),
    isAnonymous: false,
    photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanName)}`,
  };

  const db = getRegisteredAccounts();
  db[newUid] = { account: newAccount };
  saveRegisteredAccounts(db);

  saveCurrentAccount(newAccount);
  restoreUserScopedData(newUid);
  return newAccount;
}

/**
 * Switch to a different user profile
 */
export function switchProfile(uid: string): KajuAccount | null {
  const current = getCurrentAccount();
  if (current.uid === uid) return current;

  persistCurrentSessionToScope(current.uid);

  const db = getRegisteredAccounts();
  const record = db[uid];
  if (!record && !uid.startsWith('guest_')) {
    return null;
  }

  const targetAccount: KajuAccount = record
    ? { ...record.account, lastLoginAt: Date.now() }
    : {
        uid,
        provider: 'guest',
        displayName: 'Guest Explorer',
        createdAt: Date.now(),
        lastLoginAt: Date.now(),
        isAnonymous: true,
      };

  if (record) {
    db[uid].account = targetAccount;
    saveRegisteredAccounts(db);
  }

  saveCurrentAccount(targetAccount);
  restoreUserScopedData(targetAccount.uid);
  return targetAccount;
}

/**
 * Restore user-scoped data into active session localStorage
 */
export function restoreUserScopedData(uid: string): void {
  try {
    const convKey = getScopedKey(uid, 'conversations');
    const goalsKey = getScopedKey(uid, 'goals');
    const projKey = getScopedKey(uid, 'projects');
    const memKey = getScopedKey(uid, 'memories');
    const gameKey = getScopedKey(uid, 'game_progress');

    const conv = safeGetItem(convKey);
    if (conv) {
      safeSetItem('kaju_ai_conversations_v2', conv);
    } else {
      safeRemoveItem('kaju_ai_conversations_v2');
      safeRemoveItem('kaju_ai_active_chat_id_v2');
    }

    const goals = safeGetItem(goalsKey);
    if (goals) {
      safeSetItem('kaju_ai_goals_v1', goals);
    } else {
      safeRemoveItem('kaju_ai_goals_v1');
      safeRemoveItem('kaju_ai_active_goal_id_v1');
    }

    const projs = safeGetItem(projKey);
    if (projs) {
      safeSetItem('kaju_projects_v1', projs);
    } else {
      safeRemoveItem('kaju_projects_v1');
      safeRemoveItem('kaju_active_project_id_v1');
    }

    const skillKey = getScopedKey(uid, 'skills');
    const skills = safeGetItem(skillKey);
    if (skills) {
      safeSetItem('kaju_skill_journeys_v1', skills);
    } else {
      safeRemoveItem('kaju_skill_journeys_v1');
      safeRemoveItem('kaju_active_skill_id_v1');
    }

    const mems = safeGetItem(memKey);
    if (mems) {
      safeSetItem('kaju_ai_user_memories_v1', mems);
    } else {
      safeRemoveItem('kaju_ai_user_memories_v1');
    }

    const game = safeGetItem(gameKey);
    if (game) {
      safeSetItem('kaju_game_progress_v1', game);
    } else {
      safeRemoveItem('kaju_game_progress_v1');
    }
  } catch (e) {
    console.error('Error restoring scoped data:', e);
  }
}

/**
 * Save user data into scoped keys
 */
export function persistUserDataToScope(
  uid: string,
  category: 'conversations' | 'goals' | 'projects' | 'skills' | 'memories' | 'game_progress',
  data: any
): void {
  try {
    const key = getScopedKey(uid, category);
    safeSetItem(key, typeof data === 'string' ? data : JSON.stringify(data));
  } catch (e) {
    console.error(`Failed to persist scoped data for ${category}:`, e);
  }
}

/**
 * Reset password mock
 */
export function requestPasswordReset(email: string): { success: boolean; message: string } {
  const cleanEmail = email.toLowerCase().trim();
  const db = getRegisteredAccounts();
  const existingKey = Object.keys(db).find(k => db[k].account.email === cleanEmail);

  if (!existingKey) {
    return { success: false, message: 'No registered user found with this email.' };
  }

  return {
    success: true,
    message: `Password reset instructions have been sent to ${cleanEmail}. Check your inbox!`,
  };
}

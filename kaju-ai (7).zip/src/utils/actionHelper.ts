import { DeviceAction, ActionPermissions, ActionType, SupportedAppId } from '../types';
import { NativeActionRouter, LaunchResult } from './nativeActionRouter';

export const DEFAULT_PERMISSIONS: ActionPermissions = {
  allowWhatsApp: true,
  allowPhoneDialer: true,
  allowExternalLinks: true,
  requireConfirmationAlways: true,
};

export const PERMISSIONS_STORAGE_KEY = 'kaju_ai_action_permissions_v1';
export const AUDIT_LOG_STORAGE_KEY = 'kaju_ai_action_audit_v1';

/**
 * Clean and format a phone number for tel: and WhatsApp
 */
export function sanitizePhoneNumber(input: string): string {
  // Remove spaces, hyphens, parentheses, etc.
  const cleaned = input.replace(/[\s\-()]/g, '');
  
  // If it starts with + leave as is, if it starts with 00 replace with +
  if (cleaned.startsWith('00')) {
    return '+' + cleaned.slice(2);
  }
  
  // If it's a 10-digit Indian number without country code, add +91 for WhatsApp
  if (/^\d{10}$/.test(cleaned)) {
    return '+91' + cleaned;
  }
  
  return cleaned;
}

/**
 * Format phone for display (e.g. +91 XXXXX XXXXX -> formatted chunks)
 */
export function formatPhoneDisplay(phone: string): string {
  const clean = phone.trim();
  if (clean.startsWith('+91') && clean.length === 13) {
    return `+91 ${clean.slice(3, 8)} ${clean.slice(8)}`;
  }
  return clean;
}

/**
 * Build safe WhatsApp Web / Mobile redirect URL
 */
export function buildWhatsAppUrl(phone?: string, message: string = ''): string {
  const encodedText = encodeURIComponent(message.trim());
  if (phone && phone.trim()) {
    // wa.me requires digits only, with country code, no + or symbols
    const digitsOnly = phone.replace(/\D/g, '');
    if (digitsOnly) {
      return `https://wa.me/${digitsOnly}?text=${encodedText}`;
    }
  }
  // Generic WhatsApp share link (allows user to select any contact in WhatsApp)
  return `https://wa.me/?text=${encodedText}`;
}

/**
 * Build phone dialer URL
 */
export function buildDialerUrl(phone: string): string {
  const clean = phone.replace(/[^\d+]/g, '');
  return `tel:${clean}`;
}

/**
 * Predefined supported popular apps / services
 */
export const POPULAR_APP_SHORTCUTS: {
  id: string;
  appId?: SupportedAppId;
  name: string;
  hindiName: string;
  category: 'search' | 'tools' | 'communication' | 'media' | 'system';
  url: string;
  iconName: string;
  description: string;
}[] = [
  {
    id: 'youtube',
    appId: 'youtube',
    name: 'YouTube',
    hindiName: 'यूट्यूब',
    category: 'media',
    url: 'https://www.youtube.com',
    iconName: 'Youtube',
    description: 'Educational videos, music & lectures',
  },
  {
    id: 'whatsapp',
    appId: 'whatsapp',
    name: 'WhatsApp',
    hindiName: 'व्हाट्सएप',
    category: 'communication',
    url: 'https://web.whatsapp.com',
    iconName: 'MessageCircle',
    description: 'Bilingual messaging & chat',
  },
  {
    id: 'calculator',
    appId: 'calculator',
    name: 'Calculator',
    hindiName: 'कैलकुलेटर',
    category: 'tools',
    url: 'https://www.google.com/search?q=calculator',
    iconName: 'Calculator',
    description: 'Scientific and standard calculator',
  },
  {
    id: 'camera',
    appId: 'camera',
    name: 'Camera',
    hindiName: 'कैमरा',
    category: 'tools',
    url: '',
    iconName: 'Camera',
    description: 'Take photo for instant study analysis',
  },
  {
    id: 'gallery',
    appId: 'gallery',
    name: 'Photos / Gallery',
    hindiName: 'फ़ोटो गैलरी',
    category: 'tools',
    url: '',
    iconName: 'Image',
    description: 'Browse photos and study documents',
  },
  {
    id: 'settings',
    appId: 'settings',
    name: 'Settings',
    hindiName: 'सेटिंग्स',
    category: 'system',
    url: '',
    iconName: 'Settings',
    description: 'Permissions and system configuration',
  },
  {
    id: 'google_maps',
    appId: 'maps',
    name: 'Google Maps',
    hindiName: 'गूगल मैप्स',
    category: 'tools',
    url: 'https://maps.google.com',
    iconName: 'MapPin',
    description: 'Navigation, routes & nearby places',
  },
  {
    id: 'google_search',
    name: 'Google Search',
    hindiName: 'गूगल खोज',
    category: 'search',
    url: 'https://www.google.com',
    iconName: 'Search',
    description: 'Web search & answers',
  },
  {
    id: 'wikipedia',
    name: 'Wikipedia',
    hindiName: 'विकिपीडिया',
    category: 'tools',
    url: 'https://hi.wikipedia.org',
    iconName: 'BookOpen',
    description: 'Free encyclopedia in Hindi & English',
  },
  {
    id: 'gmail',
    appId: 'gmail',
    name: 'Gmail',
    hindiName: 'जीमेल',
    category: 'communication',
    url: 'https://mail.google.com',
    iconName: 'Mail',
    description: 'Draft or check email',
  },
  {
    id: 'translate',
    name: 'Google Translate',
    hindiName: 'गूगल अनुवाद',
    category: 'tools',
    url: 'https://translate.google.com/?sl=hi&tl=en',
    iconName: 'Languages',
    description: 'Hindi <-> English instant translation',
  },
];

/**
 * Extract structured action from assistant output text (looking for <!--ACTION: {...}-->)
 */
export function extractActionFromText(text: string): { cleanText: string; action?: DeviceAction } {
  // Strip any internal Goal Engine or Checkpoint comment tags from chat text
  let strippedText = text
    .replace(/<!--GOAL_DETECTED:[\s\S]*?-->/g, '')
    .replace(/<!--CHECKPOINT_RESULT:[\s\S]*?-->/g, '')
    .replace(/<!--GOAL_COMPLETE:[\s\S]*?-->/g, '')
    .trim();

  const actionRegex = /<!--ACTION:\s*({[\s\S]*?})\s*-->/;
  const match = strippedText.match(actionRegex);

  if (!match) {
    return { cleanText: strippedText };
  }

  try {
    const rawAction = JSON.parse(match[1]);
    const cleanText = strippedText.replace(actionRegex, '').trim();

    const action: DeviceAction = {
      id: rawAction.id || `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: rawAction.type as ActionType,
      status: 'ready',
      title: rawAction.title || 'Action Request',
      payload: rawAction.payload || {},
      createdAt: Date.now(),
    };

    return { cleanText, action };
  } catch (err) {
    console.error('Failed to parse embedded action JSON:', err);
    return { cleanText: strippedText.replace(actionRegex, '').trim() };
  }
}

/**
 * Check if an action is permitted according to user settings
 */
export function isActionPermitted(action: DeviceAction, permissions: ActionPermissions): { allowed: boolean; reason?: string } {
  if (action.type === 'whatsapp' && !permissions.allowWhatsApp) {
    return { allowed: false, reason: 'WhatsApp actions are currently disabled in Action Center settings.' };
  }
  if (action.type === 'call' && !permissions.allowPhoneDialer) {
    return { allowed: false, reason: 'Phone dialer integration is currently disabled in Action Center settings.' };
  }
  if (action.type === 'open_url' && !permissions.allowExternalLinks) {
    return { allowed: false, reason: 'External link opening is currently disabled in Action Center settings.' };
  }
  if (action.type === 'launch_app' && !permissions.allowExternalLinks) {
    return { allowed: false, reason: 'Application launching is currently disabled in Action Center settings.' };
  }
  return { allowed: true };
}

/**
 * Safely execute an action after user confirmation or direct invocation
 */
export function executeDeviceAction(action: DeviceAction): { success: boolean; message: string; launchResult?: LaunchResult } {
  try {
    if (action.type === 'launch_app') {
      const payload = action.payload.launch_app;
      if (!payload || !payload.appId) return { success: false, message: 'Missing launch_app payload' };
      
      // Trigger platform launch via NativeActionRouter
      NativeActionRouter.launchApp(payload.appId);

      const isNative = NativeActionRouter.isNativeAndroid();
      return {
        success: true,
        message: isNative
          ? `Launching ${payload.appName} on Android...`
          : `Opening ${payload.appName} in web browser...`,
      };
    }

    if (action.type === 'whatsapp') {
      const payload = action.payload.whatsapp;
      if (!payload) return { success: false, message: 'Missing WhatsApp payload' };
      const url = buildWhatsAppUrl(payload.phone, payload.message);
      if (NativeActionRouter.isNativeAndroid() && window.KajuNative) {
        window.KajuNative.launchApp('whatsapp', {
          action: 'android.intent.action.VIEW',
          packageName: 'com.whatsapp',
          dataUri: url,
        });
        return { success: true, message: 'Opened WhatsApp on Android with prepared message.' };
      }
      window.open(url, '_blank', 'noopener,noreferrer');
      return {
        success: true,
        message: 'Opened WhatsApp Web with prepared message (Note: In browser preview, web WhatsApp is opened; on Android device, the native WhatsApp app will launch directly).',
      };
    }

    if (action.type === 'call') {
      const payload = action.payload.call;
      if (!payload || !payload.phone) return { success: false, message: 'Missing phone number' };
      if (NativeActionRouter.isNativeAndroid() && typeof window.KajuNative?.openDialer === 'function') {
        window.KajuNative.openDialer(payload.phone);
        return { success: true, message: 'Opened Android phone dialer.' };
      }
      const url = buildDialerUrl(payload.phone);
      window.location.href = url;
      return {
        success: true,
        message: 'Phone dialer triggered in browser (Note: Running in browser preview; actual phone dialer intent launches in the Kaju Android APK).',
      };
    }

    if (action.type === 'open_url') {
      const payload = action.payload.open_url;
      if (!payload || !payload.url) return { success: false, message: 'Missing URL' };
      window.open(payload.url, '_blank', 'noopener,noreferrer');
      return { success: true, message: `Opened ${payload.appName || payload.url}` };
    }

    if (action.type === 'search') {
      const payload = action.payload.search;
      if (!payload || !payload.query) return { success: false, message: 'Missing search query' };
      const query = encodeURIComponent(payload.query);
      let url = `https://www.google.com/search?q=${query}`;
      if (payload.engine === 'youtube') {
        url = `https://www.youtube.com/results?search_query=${query}`;
      } else if (payload.engine === 'maps') {
        url = `https://www.google.com/maps/search/${query}`;
      } else if (payload.engine === 'wikipedia') {
        url = `https://en.wikipedia.org/wiki/Special:Search?search=${query}`;
      }
      window.open(url, '_blank', 'noopener,noreferrer');
      return { success: true, message: `Searching on ${payload.engine}` };
    }

    return { success: false, message: 'Unsupported action type.' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Failed to trigger action.' };
  }
}

/**
 * Async execution returning full platform launch diagnostic result
 */
export async function executeDeviceActionAsync(action: DeviceAction): Promise<{ success: boolean; message: string; launchResult?: LaunchResult }> {
  try {
    if (action.type === 'launch_app') {
      const payload = action.payload.launch_app;
      if (!payload || !payload.appId) return { success: false, message: 'Missing launch_app payload' };

      const result = await NativeActionRouter.launchApp(payload.appId);
      return {
        success: result.success,
        message: result.message,
        launchResult: result,
      };
    }

    if (action.type === 'call') {
      const payload = action.payload.call;
      if (!payload || !payload.phone) return { success: false, message: 'Missing phone number' };
      if (NativeActionRouter.isNativeAndroid() && typeof window.KajuNative?.openDialer === 'function') {
        const raw = await Promise.resolve(window.KajuNative.openDialer(payload.phone));
        const resp = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
        return {
          success: Boolean(resp.success ?? true),
          message: resp.message || 'Opened Android phone dialer.',
        };
      }
      const url = buildDialerUrl(payload.phone);
      window.location.href = url;
      return {
        success: true,
        message: 'Phone dialer triggered in browser (Note: Running in browser preview; actual phone dialer intent launches in the Kaju Android APK).',
      };
    }

    if (action.type === 'whatsapp') {
      const payload = action.payload.whatsapp;
      if (!payload) return { success: false, message: 'Missing WhatsApp payload' };
      const url = buildWhatsAppUrl(payload.phone, payload.message);
      if (NativeActionRouter.isNativeAndroid() && window.KajuNative) {
        const raw = await Promise.resolve(window.KajuNative.launchApp('whatsapp', {
          action: 'android.intent.action.VIEW',
          packageName: 'com.whatsapp',
          dataUri: url,
        }));
        const resp = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
        return {
          success: Boolean(resp.success ?? true),
          message: resp.message || 'Opened WhatsApp on Android with prepared message.',
        };
      }
      window.open(url, '_blank', 'noopener,noreferrer');
      return {
        success: true,
        message: 'Opened WhatsApp Web with prepared message (Note: In browser preview, web WhatsApp is opened; on Android device, the native WhatsApp app will launch directly).',
      };
    }

    return executeDeviceAction(action);
  } catch (err: any) {
    return { success: false, message: err?.message || 'Failed to execute action.' };
  }
}

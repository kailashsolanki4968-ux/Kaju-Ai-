import { GameType, GameState } from '../types';
import { startNewGame, loadActiveGame } from './gameEngine';

export interface CompanionResponse {
  isHandled: boolean;
  type?: 'boredom_prompt' | 'start_game' | 'return_to_work' | 'joke' | 'shayari' | 'story' | 'casual_talk';
  replyText?: string;
  gameCard?: GameState;
  suggestedFollowUps?: string[];
}

export const FUN_OPTIONS = [
  { id: 'game', label: '🎮 Play a Game', prompt: 'Kaju, chal koi mast game khelte hain!' },
  { id: 'talk', label: '💬 Just Chat', prompt: 'Kaju, aao aapas me thodi casual baat karte hain.' },
  { id: 'joke', label: '😂 Tell a Joke', prompt: 'Kaju, ek ekdum funny joke sunao!' },
  { id: 'shayari', label: '✍️ Ek Shayari', prompt: 'Kaju, dil ko chhu lene wali shayari sunao!' },
  { id: 'riddle', label: '🧩 Ek Paheli', prompt: 'Kaju, ek dimaag hilane wali paheli pucho!' },
  { id: 'quiz', label: '🧠 Rapid Quiz', prompt: 'Kaju, ek interesting GK quiz pucho!' },
  { id: 'tic_tac_toe', label: '❌ Tic-Tac-Toe', prompt: 'Kaju, Tic-Tac-Toe khelte hain!' },
];

export const FUN_JOKES = [
  "टीचर: बताओ पिज्जा और जिंदगी में क्या समानता है?\nपप्पू: सर, दोनों ही ठंडी होने पर बिल्कुल बेस्वाद हो जाती हैं! 😂🍕",
  "मरीज: डॉक्टर साहब, मुझे नींद में चलने की बीमारी है!\nडॉक्टर: तो रात को ताले की चाबी कहाँ रखते हो?\nमरीज: अलमारी में, और अलमारी की चाबी तकिये के नीचे! 🤣",
  "Interview Tip from Kaju:\nInterviewer: What is your biggest weakness?\nCandidate: I get easily attached to Wi-Fi without a password! 📶😂",
  "Son: Dad, can you do my Math homework for me?\nDad: No son, it wouldn't be right.\nSon: That's okay, you can at least try! 😆"
];

export const FUN_SHAYARI = [
  "मंजिलें भी जिद्दी हैं, रास्ते भी जिद्दी हैं,\nदेखते हैं कल क्या होगा, हौसले भी तो जिद्दी हैं! ✨",
  "चाय की चुस्की में भी एक अलग ही सुकून है,\nसपनों को सच करने का दिल में एक जुनून है! ☕❤️",
  "ना थके कभी पैर, ना कभी हिम्मत हारी है,\nजज्बा है कुछ नया सीखने का, इसलिए सफर जारी है! 🚀",
  "Life is a canvas, draw it with pride,\nWith Kaju always standing right by your side! 🌟"
];

export const FUN_STORIES = [
  "**The Two Woodcutters (दो लकड़हारे)**\n\nदो लकड़हारे एक जंगल में पेड़ काटते थे। पहला लकड़हारा बिना रुके लगातार 8 घंटे कुल्हाड़ी चलाता रहा, जबकि दूसरा हर घंटे 10 मिनट का ब्रेक लेता था।\n\nशाम को देखा गया कि दूसरे लकड़हारे ने पहले से दुगनी लकड़ियां काटी थीं!\nपहला हैरान होकर बोला: *'तुम तो बार-बार आराम कर रहे थे, फिर इतनी लकड़ियां कैसे काटीं?'*\nदूसरे ने मुस्कुराकर कहा: *'दोस्त, जब मैं ब्रेक ले रहा था, तब मैं अपनी कुल्हाड़ी की धार तेज कर रहा था!'*\n\n💡 **Kaju's Lesson:** स्मार्ट वर्क और समय पर दिमाग को रिफ्रेश करना हमेशा लगातार बिना सोचे मेहनत करने से बेहतर परिणाम देता है! 💪"
];

/**
 * Route boredom, casual, and fun inputs
 */
export function routeCompanionInput(text: string): CompanionResponse {
  const clean = text.trim();
  const lower = clean.toLowerCase();

  // 1. Returning to work / study
  if (
    lower.includes('bas ab kaam') ||
    lower.includes('ab kaam karte') ||
    lower.includes('wapas padhai') ||
    lower.includes('back to work') ||
    lower.includes('study mode') ||
    lower.includes('goal pe wapas') ||
    lower.includes('stop fun') ||
    lower.includes('chalo padhte hain')
  ) {
    return {
      isHandled: true,
      type: 'return_to_work',
      replyText: `Chalo wapas focus mode me aate hain! 🎯\n\nAapka active goal aur project ready hai. Bataiye agla step kya solve karein?`,
      suggestedFollowUps: ['Show my active goal', 'Next step of project', 'Help me solve problem'],
    };
  }

  // 2. Direct Game Triggers
  if (lower.includes('tic tac toe') || lower.includes('tictactoe') || lower.includes('zero kata')) {
    const game = startNewGame('tic_tac_toe');
    return {
      isHandled: true,
      type: 'start_game',
      replyText: `Chalo Tic-Tac-Toe ka match shuru karte hain! ❌ vs ⭕\n\nAap **X** ho aur main **O**. Board me 1 se 9 tak koi bhi khaali square chuno!`,
      gameCard: game,
      suggestedFollowUps: ['1', '5', '9', 'Exit game'],
    };
  }

  if (lower.includes('number guess') || lower.includes('guess number') || lower.includes('number game')) {
    const game = startNewGame('number_guess');
    return {
      isHandled: true,
      type: 'start_game',
      replyText: `Maine 1 se 50 ke beech ek secret number socha hai! 🔢\n\nAapke paas 7 attempts hain. Pehla guess kya hai?`,
      gameCard: game,
      suggestedFollowUps: ['25', '10', '40', 'Exit game'],
    };
  }

  if (lower.includes('riddle') || lower.includes('paheli') || lower.includes('puzzle')) {
    const game = startNewGame('riddle');
    return {
      isHandled: true,
      type: 'start_game',
      replyText: `Chalo dimaag ki koshish karte hain! Ek mazedaar paheli:\n\n**${game.data.riddleQuestion}**\n\nKya answer ho sakta hai?`,
      gameCard: game,
      suggestedFollowUps: ['Give me a hint', 'Show answer', 'Exit game'],
    };
  }

  if (lower.includes('emoji guess') || lower.includes('movie guess') || lower.includes('emoji puzzle')) {
    const game = startNewGame('emoji_guess');
    return {
      isHandled: true,
      type: 'start_game',
      replyText: `Emojis dekhkar movie/phrase guess karo:\n\n# ${game.data.emojiPrompt}\n\n*Clue: ${game.data.hintClue}*\n\nBatao kya naam hai?`,
      gameCard: game,
      suggestedFollowUps: ['Give me a hint', 'Exit game'],
    };
  }

  if (lower.includes('speed math') || lower.includes('math challenge')) {
    const game = startNewGame('math');
    return {
      isHandled: true,
      type: 'start_game',
      replyText: `⚡ Speed Math Challenge!\n\n**${game.data.problemText}** = ?\n\nJaldi answer type karo!`,
      gameCard: game,
      suggestedFollowUps: ['Exit game'],
    };
  }

  if (lower.includes('gk quiz') || lower.includes('rapid quiz') || lower.includes('quiz khelo')) {
    const game = startNewGame('quiz');
    return {
      isHandled: true,
      type: 'start_game',
      replyText: `🧠 Kaju Rapid Quiz:\n\n**${game.data.questionText}**\n\n${game.data.options?.map((o, idx) => `**${String.fromCharCode(65 + idx)}.** ${o}`).join('\n')}`,
      gameCard: game,
      suggestedFollowUps: ['A', 'B', 'C', 'D'],
    };
  }

  // 3. Boredom Triggers: explicit boredom expressions
  if (
    lower.includes('bore ho raha') ||
    lower.includes('boring lag raha') ||
    lower.includes("i'm bored") ||
    lower.includes('im bored') ||
    lower.includes('bored hu') ||
    lower.includes('kuch mazedaar batao') ||
    lower.includes('timepass karo') ||
    lower.includes('boredom')
  ) {
    return {
      isHandled: true,
      type: 'boredom_prompt',
      replyText: `Chal boredom bhagate hain 😄!\n\nMain aapka personal AI companion hoon. Bataiye kya man kar raha hai:\n\n🎮 **Play a Game** (Tic-Tac-Toe, Number Guess, Riddles, Emoji Guess)\n💬 **Baat karte hain** (Dil khol ke baat karo)\n😂 **Funny Joke**\n📖 **Ek Inspirational Short Story**\n✍️ **Ek mast Shayari**\n🧩 **Dimaagi Paheli**`,
      suggestedFollowUps: [
        '🎮 Tic-Tac-Toe khelo',
        '🔢 Number guessing game',
        '🧩 Ek dimaagi paheli',
        '😂 Ek funny joke sunao',
        '✍️ Ek achhi shayari sunao',
        '💬 Chalo thodi baat karte hain',
      ],
    };
  }

  // 4. Joke Request
  if (lower.includes('joke sunao') || lower.includes('tell me a joke') || lower.includes('hasao') || lower.includes('funny joke')) {
    const randomJoke = FUN_JOKES[Math.floor(Math.random() * FUN_JOKES.length)];
    return {
      isHandled: true,
      type: 'joke',
      replyText: `Lo suno ye wala 😂:\n\n${randomJoke}\n\nKaisa laga? Aur ek sunna hai ya koi game khelein?`,
      suggestedFollowUps: ['Aur ek joke sunao 😂', '🎮 Koi game khelein', '✍️ Ek shayari sunao', 'Bas ab kaam karte hain 🎯'],
    };
  }

  // 5. Shayari Request
  if (lower.includes('shayari sunao') || lower.includes('poetry') || lower.includes('kavita')) {
    const randomShayari = FUN_SHAYARI[Math.floor(Math.random() * FUN_SHAYARI.length)];
    return {
      isHandled: true,
      type: 'shayari',
      replyText: `Yeh khass aapke liye ✨:\n\n${randomShayari}\n\nKaise lagi? Aur kuch sunna hai ya thodi baat karein?`,
      suggestedFollowUps: ['Aur ek shayari sunao ✨', '🎮 Chal Tic-Tac-Toe khelte hain', '😂 Koi joke sunao', 'Bas ab wapas padhte hain 📚'],
    };
  }

  // 6. Story Request
  if (lower.includes('kahani sunao') || lower.includes('story sunao') || lower.includes('tell a story')) {
    const story = FUN_STORIES[Math.floor(Math.random() * FUN_STORIES.length)];
    return {
      isHandled: true,
      type: 'story',
      replyText: `${story}\n\nKaisi lagi ye kahani? Chahein to thoda relax karke wapas kaam par laut sakte hain!`,
      suggestedFollowUps: ['🎮 Koi game khelo', 'Bas ab kaam karte hain 🎯', '💬 Thodi baat karte hain'],
    };
  }

  // 7. General "game khelo" prompt
  if (lower === 'game' || lower === 'game khelo' || lower === 'khelte hain' || lower === 'play game') {
    return {
      isHandled: true,
      type: 'boredom_prompt',
      replyText: `Konsa game khelna pasand karenge? Choose kijiye:\n\n1. ❌ **Tic-Tac-Toe** (Kaju vs You)\n2. 🔢 **Number Guessing** (1 to 50 challenge)\n3. 🧩 **Paheliyan / Riddles** (Dimaagi kasrat)\n4. 🎭 **Emoji Guess** (Movie aur phrase pehchano)\n5. ⚡ **Speed Math** (Mental arithmetic challenge)\n6. 🧠 **Rapid GK Quiz**`,
      suggestedFollowUps: [
        '❌ Tic-Tac-Toe',
        '🔢 Number Guess',
        '🧩 Riddles & Paheli',
        '🎭 Emoji Guess',
        '⚡ Speed Math',
      ],
    };
  }

  return { isHandled: false };
}

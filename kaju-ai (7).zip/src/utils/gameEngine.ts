import { GameType, GameState, GameProgress, GameStatus } from '../types';

export const GAME_PROGRESS_STORAGE_KEY = 'kaju_game_progress_v1';
export const ACTIVE_GAME_STORAGE_KEY = 'kaju_active_game_v1';

export function loadGameProgress(): GameProgress {
  try {
    const raw = localStorage.getItem(GAME_PROGRESS_STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load game progress:', e);
  }
  return {
    totalGamesPlayed: 0,
    gamesWon: 0,
    currentStreak: 0,
    bestStreak: 0,
    highScores: {},
  };
}

export function saveGameProgress(progress: GameProgress): void {
  try {
    localStorage.setItem(GAME_PROGRESS_STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.error('Failed to save game progress:', e);
  }
}

export function recordGameResult(type: GameType, won: boolean, points: number): GameProgress {
  const current = loadGameProgress();
  const total = current.totalGamesPlayed + 1;
  const wins = won ? current.gamesWon + 1 : current.gamesWon;
  const streak = won ? current.currentStreak + 1 : 0;
  const best = Math.max(streak, current.bestStreak);
  const currentHigh = current.highScores[type] || 0;
  const highScores = {
    ...current.highScores,
    [type]: Math.max(currentHigh, points),
  };

  const updated: GameProgress = {
    totalGamesPlayed: total,
    gamesWon: wins,
    currentStreak: streak,
    bestStreak: best,
    highScores,
    lastPlayedAt: Date.now(),
  };

  saveGameProgress(updated);
  return updated;
}

export function loadActiveGame(): GameState | null {
  try {
    const raw = localStorage.getItem(ACTIVE_GAME_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.status === 'active') return parsed;
    }
  } catch (e) {
    console.error('Failed to load active game:', e);
  }
  return null;
}

export function saveActiveGame(game: GameState | null): void {
  try {
    if (!game || game.status !== 'active') {
      localStorage.removeItem(ACTIVE_GAME_STORAGE_KEY);
    } else {
      localStorage.setItem(ACTIVE_GAME_STORAGE_KEY, JSON.stringify(game));
    }
  } catch (e) {
    console.error('Failed to save active game:', e);
  }
}

// ==========================================
// PRESET CURATED CONTENT FOR COMPANION GAMES
// ==========================================

export const RIDDLES_PRESET = [
  {
    question: "ऐसी कौन सी चीज़ है जो जितनी ज़्यादा सूखी होती है, उतनी ही ज़्यादा भीगती जाती है? (What gets wetter the more it dries?)",
    answer: "तौलिया (Towel)",
    hint: "हम इसे नहाने के बाद रोज़ इस्तेमाल करते हैं!",
    keywords: ["towel", "tauliya", "तौलिया", "gamcha"]
  },
  {
    question: "वो क्या है जिसके पास गला तो है पर सिर नहीं, और दो हाथ हैं पर उंगलियां नहीं? (What has a neck but no head, and two arms but no fingers?)",
    answer: "शर्ट / कमीज़ (Shirt)",
    hint: "कपड़े की अलमारी में ढूँढो!",
    keywords: ["shirt", "t-shirt", "kameez", "kurta", "शर्ट", "कमीज़"]
  },
  {
    question: "ऐसी कौन सी चीज़ है जिसे हम खा भी सकते हैं और फेंक भी देते हैं, और वो कभी खत्म नहीं होती?",
    answer: "कसम / गुस्सा / गेंद (Ball / Oath)",
    hint: "लोग दोस्तों से बात करते हुए अक्सर इसे 'खाते' हैं!",
    keywords: ["kasam", "कसम", "promise"]
  },
  {
    question: "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I?",
    answer: "Echo (गूंज)",
    hint: "पहाड़ों में आवाज़ लगाओगे तो वापस आएगी!",
    keywords: ["echo", "goonj", "गूंज", "sound"]
  },
  {
    question: "ऐसी कौन सी चीज़ है जो रात को पैदा होती है और सुबह मर जाती है?",
    answer: "ओस की बूंद (Dew drop)",
    hint: "सुबह-सुबह हरी घास पर मोतियों जैसी चमकती है!",
    keywords: ["dew", "os", "ओस", "shabnam"]
  }
];

export const EMOJI_PUZZLES_PRESET = [
  { prompt: "🦁 👑 🌅", answer: "The Lion King", clue: "Famous animation and Disney blockbuster movie", keywords: ["lion king", "the lion king"] },
  { prompt: "☕ 🌧️ 🎶", answer: "Chai aur Barish (Chai Lover)", clue: "Monsoon favorite Indian emotion", keywords: ["chai", "barish", "chai barish", "tea and rain"] },
  { prompt: "🕷️ 🕸️ 🦸‍♂️", answer: "Spider-Man", clue: "Peter Parker Marvel superhero", keywords: ["spiderman", "spider man", "spider-man"] },
  { prompt: "🚂 💨 🧳 💘", answer: "Dilwale Dulhania Le Jayenge (DDLJ) / Jab We Met", clue: "Iconic train catching scene in Bollywood", keywords: ["ddlj", "jab we met", "train"] },
  { prompt: "🏏 🏆 🇮🇳", answer: "Cricket World Cup Champions India", clue: "Team India sports victory", keywords: ["cricket", "world cup", "india"] },
  { prompt: "🧊 🚢 💔 🌊", answer: "Titanic", clue: "Jack & Rose legendary romantic film", keywords: ["titanic"] }
];

export const WORD_GUESS_PRESET = [
  { word: "GALAXY", category: "Space & Astronomy", hint: "Milky Way is an example of this vast celestial system." },
  { word: "PYTHON", category: "Coding & Nature", hint: "Both a mighty serpent and a beloved programming language." },
  { word: "QUANTUM", category: "Physics", hint: "The subatomic scale where particles can be in multiple states." },
  { word: "CRICKET", category: "Sports", hint: "A game of 22 yards, bat, and ball cherished by billions." },
  { word: "SAMOSA", category: "Delicious Indian Food", hint: "Crispy triangular pastry filled with spiced potatoes." },
  { word: "CHAI", category: "Beverage", hint: "Spiced milk tea that fuels conversations across India." }
];

export const QUIZ_PRESET = [
  {
    topic: "Science & Wonders",
    question: "What gives human blood its distinct red color?",
    options: ["Chlorophyll", "Hemoglobin", "Carotene", "Melanin"],
    correctIndex: 1,
    explanation: "Hemoglobin is an iron-rich protein in red blood cells that transports oxygen and imparts the red color."
  },
  {
    topic: "Space Explorations",
    question: "Which Indian lunar mission successfully made a soft landing near the south pole of the Moon?",
    options: ["Chandrayaan-1", "Mangalyaan", "Chandrayaan-3", "Aditya-L1"],
    correctIndex: 2,
    explanation: "ISRO's Chandrayaan-3 achieved historical soft-landing near the Moon's South Pole in August 2023!"
  },
  {
    topic: "Computer Science",
    question: "Who is widely acknowledged as the world's very first computer programmer?",
    options: ["Alan Turing", "Ada Lovelace", "Charles Babbage", "Grace Hopper"],
    correctIndex: 1,
    explanation: "Ada Lovelace wrote the first algorithm for Charles Babbage's mechanical Analytical Engine."
  }
];

export const TWENTY_QUESTIONS_SECRET_POOL = [
  { subject: "Smart Phone", category: "Everyday Gadget", hints: ["Can connect to internet", "Has a touchscreen", "Fits in your pocket"] },
  { subject: "Elephant", category: "Animal Kingdom", hints: ["Largest land mammal", "Has a long trunk", "Loves water"] },
  { subject: "Taj Mahal", category: "Historical Monument", hints: ["Made of white marble", "Located in Agra, India", "One of world wonders"] },
  { subject: "Guitar", category: "Musical Instrument", hints: ["Has six strings", "Can be acoustic or electric", "Makes melodious music"] },
  { subject: "Pizza", category: "Food & Snacks", hints: ["Round in shape, sliced into triangles", "Has cheese and tomato sauce", "Baked in an oven"] }
];

// ==========================================
// GAME FACTORY & STATE TRANSITIONS
// ==========================================

export function startNewGame(type: GameType): GameState {
  const gameId = `game_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

  switch (type) {
    case 'number_guess': {
      const targetNumber = Math.floor(Math.random() * 50) + 1; // 1 to 50
      const game: GameState = {
        gameId,
        type: 'number_guess',
        title: '🔢 Number Guessing Challenge',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 100,
        data: {
          targetNumber,
          minRange: 1,
          maxRange: 50,
          attemptsLeft: 7,
          guesses: [],
        },
        lastMessage: "I've chosen a secret number between 1 and 50. You have 7 attempts! What's your first guess?",
        feedbackText: "Guess any number between 1 and 50!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'tic_tac_toe': {
      const game: GameState = {
        gameId,
        type: 'tic_tac_toe',
        title: '❌ Tic-Tac-Toe Showdown ⭕',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 50,
        data: {
          board: Array(9).fill(null),
          playerSymbol: 'X',
          aiSymbol: 'O',
          turn: 'player',
          winner: null,
        },
        lastMessage: "You are 'X' and I am 'O'. Your turn! Pick a square (1-9) or tap directly on the board.",
        feedbackText: "Your move! Tap square 1-9 to place your X.",
      };
      saveActiveGame(game);
      return game;
    }

    case 'riddle': {
      const selected = RIDDLES_PRESET[Math.floor(Math.random() * RIDDLES_PRESET.length)];
      const game: GameState = {
        gameId,
        type: 'riddle',
        title: '🧩 Paheli / Riddle Challenge',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 50,
        data: {
          riddleQuestion: selected.question,
          riddleAnswer: selected.answer,
          hint: selected.hint,
          hintUsed: false,
        },
        lastMessage: `Here is your riddle:\n\n**"${selected.question}"**\n\nWhat is your answer? (You can also ask for a Hint!)`,
        feedbackText: "Type your answer or say 'Give me a hint'!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'emoji_guess': {
      const selected = EMOJI_PUZZLES_PRESET[Math.floor(Math.random() * EMOJI_PUZZLES_PRESET.length)];
      const game: GameState = {
        gameId,
        type: 'emoji_guess',
        title: '🎭 Emoji Movie/Phrase Guess',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 50,
        data: {
          emojiPrompt: selected.prompt,
          targetTitle: selected.answer,
          hintClue: selected.clue,
        },
        lastMessage: `Guess the movie/phrase from these emojis:\n\n# ${selected.prompt}\n\nClue: *${selected.clue}*\n\nCan you name it?`,
        feedbackText: "Guess the title or phrase represented by the emojis!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'word_guess': {
      const selected = WORD_GUESS_PRESET[Math.floor(Math.random() * WORD_GUESS_PRESET.length)];
      const pattern = selected.word.split('').map(() => '_').join(' ');
      const game: GameState = {
        gameId,
        type: 'word_guess',
        title: '🔤 Word Guess Mystery',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 80,
        data: {
          word: selected.word,
          category: selected.category,
          guessedLetters: [],
          revealedPattern: pattern,
          wrongGuessesCount: 0,
          hint: selected.hint,
        },
        lastMessage: `Category: **${selected.category}**\nWord: \`${pattern}\` (${selected.word.length} letters)\nHint: *${selected.hint}*\n\nGuess a letter or the whole word!`,
        feedbackText: "Guess a letter (A-Z) or write the full word!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'twenty_questions': {
      const selected = TWENTY_QUESTIONS_SECRET_POOL[Math.floor(Math.random() * TWENTY_QUESTIONS_SECRET_POOL.length)];
      const game: GameState = {
        gameId,
        type: 'twenty_questions',
        title: '❓ 20 Questions Game',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 100,
        data: {
          secretSubject: selected.subject,
          category: selected.category,
          questionsAsked: [],
          maxQuestions: 20,
        },
        lastMessage: `I have picked a secret **${selected.category}**! You have 20 Yes/No questions to guess what it is. Ask your first question! (e.g., "Is it alive?", "Is it man-made?")`,
        feedbackText: "Ask any Yes/No question to narrow down the secret!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'quiz': {
      const selected = QUIZ_PRESET[Math.floor(Math.random() * QUIZ_PRESET.length)];
      const optionsText = selected.options.map((opt, idx) => `**${String.fromCharCode(65 + idx)}.** ${opt}`).join('\n');
      const game: GameState = {
        gameId,
        type: 'quiz',
        title: '🧠 Kaju Rapid Quiz',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 100,
        data: {
          quizTopic: selected.topic,
          currentQuestionIndex: 0,
          totalQuestions: 1,
          questionText: selected.question,
          options: selected.options,
          correctIndex: selected.correctIndex,
        },
        lastMessage: `Topic: **${selected.topic}**\n\n**${selected.question}**\n\n${optionsText}\n\nType A, B, C, or D!`,
        feedbackText: "Reply with A, B, C, or D!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'math': {
      const a = Math.floor(Math.random() * 20) + 5;
      const b = Math.floor(Math.random() * 15) + 3;
      const op = Math.random() > 0.5 ? '+' : '×';
      const solution = op === '+' ? a + b : a * b;
      const game: GameState = {
        gameId,
        type: 'math',
        title: '⚡ Speed Math Challenge',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 50,
        data: {
          problemText: `${a} ${op} ${b}`,
          solutionValue: solution,
        },
        lastMessage: `Quick! What is **${a} ${op} ${b}**? Solve as fast as you can!`,
        feedbackText: "Calculate the answer and send it!",
      };
      saveActiveGame(game);
      return game;
    }

    case 'memory': {
      const seq = [
        Math.floor(Math.random() * 9) + 1,
        Math.floor(Math.random() * 9) + 1,
        Math.floor(Math.random() * 9) + 1,
        Math.floor(Math.random() * 9) + 1,
      ];
      const game: GameState = {
        gameId,
        type: 'memory',
        title: '🧠 Memory Sequence Test',
        status: 'active',
        startedAt: Date.now(),
        turnCount: 0,
        score: 60,
        data: {
          sequence: seq,
          phase: 'recall',
        },
        lastMessage: `Memorize this 4-digit sequence:\n\n# ${seq.join(' - ')}\n\nNow repeat it back in order! (e.g. "${seq.join('')}")`,
        feedbackText: `Enter the 4 numbers you just saw!`,
      };
      saveActiveGame(game);
      return game;
    }

    default:
      return startNewGame('number_guess');
  }
}

// ==========================================
// TIC TAC TOE LOGIC
// ==========================================
export const WINNING_COMBOS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
  [0, 4, 8], [2, 4, 6]             // Diagonals
];

export function checkTicTacToeWinner(board: (string | null)[]): { winner: 'X' | 'O' | 'tie' | null; line?: number[] } {
  for (const combo of WINNING_COMBOS) {
    const [a, b, c] = combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a] as 'X' | 'O', line: combo };
    }
  }
  if (board.every(cell => cell !== null)) {
    return { winner: 'tie' };
  }
  return { winner: null };
}

export function computeAiMoveTicTacToe(board: (string | null)[], aiSymbol: 'X' | 'O', playerSymbol: 'X' | 'O'): number {
  // 1. Can AI win in 1 move?
  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      const copy = [...board];
      copy[i] = aiSymbol;
      if (checkTicTacToeWinner(copy).winner === aiSymbol) return i;
    }
  }
  // 2. Can player win in 1 move? Block them!
  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      const copy = [...board];
      copy[i] = playerSymbol;
      if (checkTicTacToeWinner(copy).winner === playerSymbol) return i;
    }
  }
  // 3. Take center if free
  if (!board[4]) return 4;
  // 4. Take corners
  const corners = [0, 2, 6, 8].filter(c => !board[c]);
  if (corners.length > 0) {
    return corners[Math.floor(Math.random() * corners.length)];
  }
  // 5. Take any remaining empty cell
  const empty = board.map((c, idx) => c === null ? idx : -1).filter(idx => idx !== -1);
  return empty[Math.floor(Math.random() * empty.length)];
}

/**
 * Handle turn for active game
 */
export function handleGameTurn(game: GameState, userInput: string): {
  updatedGame: GameState;
  responseMessage: string;
  gameCompleted: boolean;
} {
  const cleanInput = userInput.trim();
  const lowerInput = cleanInput.toLowerCase();

  // Check for resignation or exit
  if (lowerInput === 'exit' || lowerInput === 'quit' || lowerInput === 'chhoro' || lowerInput.includes('stop game') || lowerInput.includes('band karo')) {
    const abandoned: GameState = {
      ...game,
      status: 'abandoned',
      lastMessage: "Game paused. You can start a new game anytime or get back to work/study!",
    };
    saveActiveGame(null);
    return {
      updatedGame: abandoned,
      responseMessage: "Game stopped! Jab bhi man kare, dobara khelenge 😄",
      gameCompleted: true,
    };
  }

  // 1. Number Guessing
  if (game.type === 'number_guess') {
    const target = game.data.targetNumber || 25;
    const guessNum = parseInt(cleanInput.replace(/[^0-9]/g, ''), 10);

    if (isNaN(guessNum)) {
      return {
        updatedGame: game,
        responseMessage: "Please enter a valid number between 1 and 50! (e.g. 25)",
        gameCompleted: false,
      };
    }

    const attemptsLeft = (game.data.attemptsLeft ?? 7) - 1;
    const guesses = [...(game.data.guesses || []), guessNum];
    const turns = game.turnCount + 1;

    if (guessNum === target) {
      const wonGame: GameState = {
        ...game,
        status: 'won',
        turnCount: turns,
        score: Math.max(10, attemptsLeft * 20),
        data: { ...game.data, attemptsLeft, guesses },
        lastMessage: `🎉 **BOOM! BINGO!** You guessed it! The number was **${target}**! Solved in ${turns} ${turns === 1 ? 'attempt' : 'attempts'}.`,
      };
      recordGameResult('number_guess', true, wonGame.score);
      saveActiveGame(null);
      return {
        updatedGame: wonGame,
        responseMessage: `🎉 **Wah shabash!** Bilkul sahi pakde hain! The secret number was **${target}**! Points earned: +${wonGame.score} ⭐\n\nAur ek round khelein ya kuch aur?`,
        gameCompleted: true,
      };
    }

    if (attemptsLeft <= 0) {
      const lostGame: GameState = {
        ...game,
        status: 'lost',
        turnCount: turns,
        data: { ...game.data, attemptsLeft: 0, guesses },
        lastMessage: `Oh no! Out of attempts. The secret number was **${target}**. Better luck next time!`,
      };
      recordGameResult('number_guess', false, 0);
      saveActiveGame(null);
      return {
        updatedGame: lostGame,
        responseMessage: `Aww, attempts khatam ho gaye! The secret number was **${target}**. Koi baat nahi, ek aur game try karte hain?`,
        gameCompleted: true,
      };
    }

    const hint = guessNum < target ? "Higher! 📈 (Thoda bada number guess karo)" : "Lower! 📉 (Thoda chhota number try karo)";
    const updated: GameState = {
      ...game,
      turnCount: turns,
      data: { ...game.data, attemptsLeft, guesses },
      lastMessage: `${hint}\nAttempts remaining: **${attemptsLeft}**`,
      feedbackText: `${hint} (${attemptsLeft} left)`,
    };
    saveActiveGame(updated);
    return {
      updatedGame: updated,
      responseMessage: `${hint}\nAttempts left: **${attemptsLeft}**. Next guess?`,
      gameCompleted: false,
    };
  }

  // 2. Tic-Tac-Toe
  if (game.type === 'tic_tac_toe') {
    const board = [...(game.data.board || Array(9).fill(null))];
    const playerSymbol = game.data.playerSymbol || 'X';
    const aiSymbol = game.data.aiSymbol || 'O';

    let moveIndex = -1;
    // Check if input is a number 1-9
    const cellMatch = cleanInput.match(/[1-9]/);
    if (cellMatch) {
      moveIndex = parseInt(cellMatch[0], 10) - 1;
    }

    if (moveIndex < 0 || moveIndex > 8 || board[moveIndex] !== null) {
      return {
        updatedGame: game,
        responseMessage: "That cell is not available! Pick an empty cell from 1 to 9.",
        gameCompleted: false,
      };
    }

    // Apply player move
    board[moveIndex] = playerSymbol;
    const playerWinCheck = checkTicTacToeWinner(board);

    if (playerWinCheck.winner === playerSymbol) {
      const wonGame: GameState = {
        ...game,
        status: 'won',
        score: 60,
        data: { ...game.data, board, winner: 'player', winningLine: playerWinCheck.line },
        lastMessage: "🏆 **VICTORY!** You won the Tic-Tac-Toe match!",
      };
      recordGameResult('tic_tac_toe', true, 60);
      saveActiveGame(null);
      return {
        updatedGame: wonGame,
        responseMessage: "🎉 **Shandar!** You got 3 in a row and won! Mazaa aa gaya! Ek aur match?",
        gameCompleted: true,
      };
    }

    if (playerWinCheck.winner === 'tie') {
      const tieGame: GameState = {
        ...game,
        status: 'won', // tie counts as draw/completed
        score: 25,
        data: { ...game.data, board, winner: 'tie' },
        lastMessage: "🤝 It's a draw! Well played on both sides.",
      };
      recordGameResult('tic_tac_toe', true, 25);
      saveActiveGame(null);
      return {
        updatedGame: tieGame,
        responseMessage: "🤝 **Tie Game!** Barabari ka mukabla raha! Dobara challenge karein?",
        gameCompleted: true,
      };
    }

    // AI's turn
    const aiMove = computeAiMoveTicTacToe(board, aiSymbol, playerSymbol);
    board[aiMove] = aiSymbol;
    const aiWinCheck = checkTicTacToeWinner(board);

    if (aiWinCheck.winner === aiSymbol) {
      const lostGame: GameState = {
        ...game,
        status: 'lost',
        data: { ...game.data, board, winner: 'ai', winningLine: aiWinCheck.line },
        lastMessage: "🤖 Kaju got 3 in a row! Nice try, let's rematch!",
      };
      recordGameResult('tic_tac_toe', false, 0);
      saveActiveGame(null);
      return {
        updatedGame: lostGame,
        responseMessage: `Maine square ${aiMove + 1} par 'O' rakha aur 3-in-a-row ban gaya! 😄 Great match! Rematch?`,
        gameCompleted: true,
      };
    }

    if (aiWinCheck.winner === 'tie') {
      const tieGame: GameState = {
        ...game,
        status: 'won',
        score: 25,
        data: { ...game.data, board, winner: 'tie' },
        lastMessage: "🤝 It's a tie match!",
      };
      recordGameResult('tic_tac_toe', true, 25);
      saveActiveGame(null);
      return {
        updatedGame: tieGame,
        responseMessage: `Maine square ${aiMove + 1} par 'O' rakha. Match Draw ho gaya! Well played!`,
        gameCompleted: true,
      };
    }

    const updated: GameState = {
      ...game,
      turnCount: game.turnCount + 1,
      data: { ...game.data, board, turn: 'player' },
      lastMessage: `I picked square **${aiMove + 1}**. Your turn! Choose 1-9.`,
    };
    saveActiveGame(updated);
    return {
      updatedGame: updated,
      responseMessage: `Maine square ${aiMove + 1} par 'O' rakha. Ab aapki baari (1-9)!`,
      gameCompleted: false,
    };
  }

  // 3. Riddle / Paheli
  if (game.type === 'riddle') {
    if (lowerInput.includes('hint') || lowerInput.includes('ishaara') || lowerInput.includes('clue')) {
      const updated: GameState = {
        ...game,
        data: { ...game.data, hintUsed: true },
        lastMessage: `💡 **Hint:** ${game.data.hint}\n\nNow, what is your answer?`,
      };
      saveActiveGame(updated);
      return {
        updatedGame: updated,
        responseMessage: `💡 **Hint:** ${game.data.hint}\n\nAb batao, kya answer hai?`,
        gameCompleted: false,
      };
    }

    const ans = (game.data.riddleAnswer || '').toLowerCase();
    const isCorrect = lowerInput.length > 2 && (ans.includes(lowerInput) || lowerInput.includes('towel') || lowerInput.includes('shirt') || lowerInput.includes('echo') || lowerInput.includes('tauliya') || lowerInput.includes('kameez') || lowerInput.includes('goonj') || lowerInput.includes('dew') || lowerInput.includes('os'));

    if (isCorrect) {
      const wonGame: GameState = {
        ...game,
        status: 'won',
        score: game.data.hintUsed ? 30 : 50,
        lastMessage: `🎉 **Correct!** The answer is indeed **${game.data.riddleAnswer}**!`,
      };
      recordGameResult('riddle', true, wonGame.score);
      saveActiveGame(null);
      return {
        updatedGame: wonGame,
        responseMessage: `🎉 **Kya baat hai! Ekdum sahi jawab:** ${game.data.riddleAnswer}! Dimaag tez hai aapka 😄! Aur ek paheli sunoge?`,
        gameCompleted: true,
      };
    }

    return {
      updatedGame: game,
      responseMessage: `Hmm, thoda kareeb ho lekin bilkul ye nahi hai! Dobara socho, ya phir bolo 'Hint do'!`,
      gameCompleted: false,
    };
  }

  // 4. Emoji Movie/Phrase Guess
  if (game.type === 'emoji_guess') {
    const target = (game.data.targetTitle || '').toLowerCase();
    const isCorrect = lowerInput.length > 2 && (target.includes(lowerInput) || lowerInput.includes(target.split(' ')[0]));

    if (isCorrect) {
      const wonGame: GameState = {
        ...game,
        status: 'won',
        score: 50,
        lastMessage: `🎉 **Sahi pakde hain!** The title is **${game.data.targetTitle}**!`,
      };
      recordGameResult('emoji_guess', true, 50);
      saveActiveGame(null);
      return {
        updatedGame: wonGame,
        responseMessage: `🎉 **Brilliant!** Bilkul sahi: **${game.data.targetTitle}**! Bollywood/Cinema ke expert nikle aap! Next challenge?`,
        gameCompleted: true,
      };
    }

    return {
      updatedGame: game,
      responseMessage: `Nahin, ye wala nahi hai! Emojis ko dhyan se dekho: ${game.data.emojiPrompt}\nClue: ${game.data.hintClue}\n\nTry again!`,
      gameCompleted: false,
    };
  }

  // 5. Speed Math Challenge
  if (game.type === 'math') {
    const solution = game.data.solutionValue;
    const userVal = parseInt(cleanInput.replace(/[^0-9-]/g, ''), 10);

    if (userVal === solution) {
      const wonGame: GameState = {
        ...game,
        status: 'won',
        score: 50,
        lastMessage: `⚡ **Lightning Fast!** Correct answer is **${solution}**!`,
      };
      recordGameResult('math', true, 50);
      saveActiveGame(null);
      return {
        updatedGame: wonGame,
        responseMessage: `⚡ **Superfast!** Sahi jawab: **${solution}**! Calculation ekdum solid hai. Agla sawal?`,
        gameCompleted: true,
      };
    }

    return {
      updatedGame: game,
      responseMessage: `Oops, ${userVal} nahi hai! Sahi calculation karke dobara batao: **${game.data.problemText}** = ?`,
      gameCompleted: false,
    };
  }

  // Fallback
  return {
    updatedGame: game,
    responseMessage: `Aapne kaha: "${userInput}". Game continue karte hain!`,
    gameCompleted: false,
  };
}

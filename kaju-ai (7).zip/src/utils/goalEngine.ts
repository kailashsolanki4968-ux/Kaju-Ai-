import { Goal, GoalType, JourneyStep, JourneyStage, Checkpoint, ReplayEvent, IntentCategory } from '../types';

export const GOALS_STORAGE_KEY = 'kaju_ai_goals_v1';
export const ACTIVE_GOAL_KEY = 'kaju_ai_active_goal_id_v1';

/**
 * Load goals from localStorage
 */
export function loadGoals(): Goal[] {
  try {
    const raw = localStorage.getItem(GOALS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to load goals:', err);
    return [];
  }
}

/**
 * Save goals to localStorage
 */
export function saveGoals(goals: Goal[]): void {
  try {
    localStorage.setItem(GOALS_STORAGE_KEY, JSON.stringify(goals));
  } catch (err) {
    console.error('Failed to save goals:', err);
  }
}

/**
 * Load active goal ID
 */
export function loadActiveGoalId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_GOAL_KEY);
  } catch {
    return null;
  }
}

/**
 * Save active goal ID
 */
export function saveActiveGoalId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_GOAL_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_GOAL_KEY);
    }
  } catch {}
}

/**
 * Load active goal object
 */
export function loadActiveGoal(): Goal | null {
  const goals = loadGoals();
  const activeId = loadActiveGoalId();
  if (activeId) {
    const found = goals.find((g) => g.id === activeId && g.status === 'active');
    if (found) return found;
  }
  // Fallback to first active goal
  return goals.find((g) => g.status === 'active') || null;
}

/**
 * Fast client-side Intent Classifier for Kaju AI
 * Central intelligent orchestration layer:
 * Routes input into: VISION, ACTION, CODING, RESEARCH, CREATE, GOAL, STUDY, or CONVERSATION
 */
export function classifyIntent(text: string, hasImage?: boolean, hasFile?: boolean): IntentCategory {
  const lower = text.toLowerCase().trim();

  // 1. VISION intent
  if (hasImage) {
    if (
      lower.includes('finish') ||
      lower.includes('chapter') ||
      lower.includes('exam') ||
      lower.includes('tayyari') ||
      lower.includes('khatam')
    ) {
      return 'GOAL';
    }
    return 'VISION';
  }

  // 2. ACTION intent (Native app launching, WhatsApp, Call, Settings, Calculator, Camera, Gallery)
  if (
    lower.includes('whatsapp') ||
    lower.includes('phone') ||
    lower.includes('call') ||
    lower.includes('dial') ||
    lower.includes('youtube kholo') ||
    lower.includes('kholo') ||
    lower.includes('open karo') ||
    lower.includes('calculator') ||
    lower.includes('camera kholo') ||
    lower.includes('gallery kholo') ||
    lower.includes('settings kholo')
  ) {
    return 'ACTION';
  }

  // 3. CODING intent
  if (
    lower.includes('python') ||
    lower.includes('react') ||
    lower.includes('javascript') ||
    lower.includes('typescript') ||
    lower.includes('bug') ||
    lower.includes('error fix') ||
    lower.includes('coding') ||
    lower.includes('function') ||
    lower.includes('component') ||
    lower.includes('database') ||
    lower.includes('sql') ||
    lower.includes('api endpoint') ||
    lower.includes('git')
  ) {
    return 'CODING';
  }

  // 4. CREATE intent (emails, presentations, scripts, pitches)
  if (
    lower.includes('presentation') ||
    lower.includes('slide deck') ||
    lower.includes('draft email') ||
    lower.includes('write email') ||
    lower.includes('script likho') ||
    lower.includes('pitch deck') ||
    lower.includes('creative writing') ||
    lower.includes('resume')
  ) {
    return 'CREATE';
  }

  // 5. RESEARCH intent (travel planning, current info, comparisons)
  if (
    lower.includes('trip plan') ||
    lower.includes('japan trip') ||
    lower.includes('travel to') ||
    lower.includes('compare ') ||
    lower.includes('difference between') ||
    lower.includes('latest news') ||
    lower.includes('research')
  ) {
    return 'RESEARCH';
  }

  // 6. GOAL intent (multi-step objectives across all domains)
  const goalKeywords = [
    'exam in', 'days me', 'din me', 'din mein', 'finish karna', 'complete karna',
    'khatam karna', 'learn english', 'learn math', 'learn japanese', 'seekhni hai',
    'tayyari karni', 'syllabus', 'ye chapter', 'chapter samajhna', 'solve karke finish',
    'form fill karna', 'master ', 'study plan', 'goal hai', 'target hai', '10 days',
    '5 days', '30 days', 'board exam', 'revision plan', 'full marks', 'build an app',
    'app banani hai', 'startup shuru', 'launch business', 'habit banani'
  ];

  if (goalKeywords.some((kw) => lower.includes(kw))) {
    return 'GOAL';
  }

  // 7. STUDY intent (academic / homework / concepts)
  const studyKeywords = [
    'samjhao', 'solve karo', 'kya hota hai', 'kya hai', 'formula',
    'definition', 'photosynthesis', 'law', 'theorem', 'derivation',
    'equation', 'question', 'calculate', 'prove', 'cbse'
  ];

  if (studyKeywords.some((kw) => lower.includes(kw))) {
    return 'STUDY';
  }

  // 8. Default to General CONVERSATION
  return 'CONVERSATION';
}

/**
 * Generate 5-stage Journey steps for any goal: GOAL -> NOW -> NEXT -> CHECK -> DONE
 */
export function generateJourneySteps(goalId: string, goalTitle: string, input: string): JourneyStep[] {
  const lower = input.toLowerCase();

  // Detect goal category
  let category: 'coding' | 'language' | 'travel' | 'business' | 'study' = 'study';
  if (lower.includes('app') || lower.includes('python') || lower.includes('code') || lower.includes('build')) {
    category = 'coding';
  } else if (lower.includes('japanese') || lower.includes('english') || lower.includes('language') || lower.includes('seekh')) {
    category = 'language';
  } else if (lower.includes('trip') || lower.includes('travel') || lower.includes('japan') || lower.includes('ghoom')) {
    category = 'travel';
  } else if (lower.includes('business') || lower.includes('startup') || lower.includes('project')) {
    category = 'business';
  }

  if (category === 'coding') {
    return [
      {
        id: `${goalId}_step_goal`,
        goalId,
        stage: 'GOAL',
        title: 'Define Project Architecture & Tech Stack',
        description: `Architecture set: ${goalTitle}. Target components, state, and libraries established.`,
        status: 'completed',
        order: 0,
        primaryAction: {
          label: 'Proceed to Setup (NOW)',
          prompt: `Kaju, I'm ready to begin: "${goalTitle}". Let's start with NOW (Environment & Scaffolding).`,
        },
        completedAt: Date.now(),
      },
      {
        id: `${goalId}_step_now`,
        goalId,
        stage: 'NOW',
        title: 'Project Scaffold & Core Setup',
        description: 'Verify project repository, dependencies, and baseline components.',
        status: 'in_progress',
        order: 1,
        primaryAction: {
          label: 'Scaffold Project Structure',
          prompt: `Kaju, let's start the NOW step for "${goalTitle}". Show me the initial architecture, file tree, and packages needed.`,
        },
      },
      {
        id: `${goalId}_step_next`,
        goalId,
        stage: 'NEXT',
        title: 'Implement Core Logic & Features',
        description: 'Build core business logic, UI components, state management, and edge-case handling.',
        status: 'pending',
        order: 2,
        primaryAction: {
          label: 'Build Core Features',
          prompt: `Kaju, I'm ready for the NEXT step in "${goalTitle}". Let's implement the core functions and features.`,
        },
      },
      {
        id: `${goalId}_step_check`,
        goalId,
        stage: 'CHECK',
        title: 'Verify Code Quality & Testing',
        description: 'Run tests, audit error boundaries, test edge cases, and ensure clean types.',
        status: 'pending',
        order: 3,
        primaryAction: {
          label: 'Run Quality & Edge-Case Check',
          prompt: `Kaju, give me the CHECK audit for "${goalTitle}". What are the edge cases and tests to verify?`,
        },
        checkpoint: {
          id: `${goalId}_cp_1`,
          stepId: `${goalId}_step_check`,
          question: `Code verification test for ${goalTitle}`,
          attempts: 0,
          result: 'pending',
        },
      },
      {
        id: `${goalId}_step_done`,
        goalId,
        stage: 'DONE',
        title: 'Deployment & Project Launch',
        description: 'Final build verification, production deployment, and project milestone summary.',
        status: 'pending',
        order: 4,
        primaryAction: {
          label: 'Finalize & View Project Replay',
          prompt: `Kaju, I have completed all steps for "${goalTitle}". Let's finish and verify final completion!`,
        },
      },
    ];
  }

  if (category === 'language') {
    return [
      {
        id: `${goalId}_step_goal`,
        goalId,
        stage: 'GOAL',
        title: 'Define Fluency Milestones',
        description: `Fluency target set: ${goalTitle}. Core vocabulary, grammar rules, and conversational targets.`,
        status: 'completed',
        order: 0,
        primaryAction: {
          label: 'Proceed to Baseline (NOW)',
          prompt: `Kaju, I'm ready to learn: "${goalTitle}". Let's start with NOW.`,
        },
        completedAt: Date.now(),
      },
      {
        id: `${goalId}_step_now`,
        goalId,
        stage: 'NOW',
        title: 'Diagnostic & Common Survival Phrases',
        description: 'Assess current familiarity and master top 20 everyday conversational phrases.',
        status: 'in_progress',
        order: 1,
        primaryAction: {
          label: 'Start 5-min Phrase Practice',
          prompt: `Kaju, start the NOW step for "${goalTitle}". Teach me the 10 most essential everyday phrases with pronunciation.`,
        },
      },
      {
        id: `${goalId}_step_next`,
        goalId,
        stage: 'NEXT',
        title: 'Core Grammar & High-Frequency Patterns',
        description: 'Sentence structures, verb forms, and natural sentence formation patterns.',
        status: 'pending',
        order: 2,
        primaryAction: {
          label: 'Master Grammar & Sentence Making',
          prompt: `Kaju, NEXT step for "${goalTitle}". Explain the primary sentence structure with everyday examples.`,
        },
      },
      {
        id: `${goalId}_step_check`,
        goalId,
        stage: 'CHECK',
        title: 'Interactive Conversation Test',
        description: 'Simulate a real dialogue and test comprehension under natural scenarios.',
        status: 'pending',
        order: 3,
        primaryAction: {
          label: 'Take Conversation Checkpoint',
          prompt: `Kaju, give me the CHECK test for "${goalTitle}". Speak a dialogue and test my reply!`,
        },
        checkpoint: {
          id: `${goalId}_cp_1`,
          stepId: `${goalId}_step_check`,
          question: `Interactive dialogue test for ${goalTitle}`,
          attempts: 0,
          result: 'pending',
        },
      },
      {
        id: `${goalId}_step_done`,
        goalId,
        stage: 'DONE',
        title: 'Fluency Verification & Replay',
        description: 'Review achievements, mastery roadmap, and unlock next level.',
        status: 'pending',
        order: 4,
        primaryAction: {
          label: 'Complete & Unlock Replay',
          prompt: `Kaju, let's complete the final verification for "${goalTitle}".`,
        },
      },
    ];
  }

  if (category === 'travel') {
    return [
      {
        id: `${goalId}_step_goal`,
        goalId,
        stage: 'GOAL',
        title: 'Set Destination, Budget & Dates',
        description: `Travel target: ${goalTitle}. Trip duration, budget category, and must-see spots.`,
        status: 'completed',
        order: 0,
        primaryAction: {
          label: 'Proceed to Essentials (NOW)',
          prompt: `Kaju, let's plan "${goalTitle}". Start with NOW.`,
        },
        completedAt: Date.now(),
      },
      {
        id: `${goalId}_step_now`,
        goalId,
        stage: 'NOW',
        title: 'Season, Visas, Currency & Best Routes',
        description: 'Check visa requirements, seasonal weather, flights, and optimal routes.',
        status: 'in_progress',
        order: 1,
        primaryAction: {
          label: 'Check Travel Essentials',
          prompt: `Kaju, what are the seasonal tips, visa needs, and flight options for "${goalTitle}"?`,
        },
      },
      {
        id: `${goalId}_step_next`,
        goalId,
        stage: 'NEXT',
        title: 'Day-by-Day Itinerary & Booking Plan',
        description: 'Hour-by-hour itinerary, hotel areas, dining, transport passes, and local highlights.',
        status: 'pending',
        order: 2,
        primaryAction: {
          label: 'Generate Complete Itinerary',
          prompt: `Kaju, NEXT step for "${goalTitle}". Generate a realistic, day-by-day itinerary with budget estimates.`,
        },
      },
      {
        id: `${goalId}_step_check`,
        goalId,
        stage: 'CHECK',
        title: 'Packing Checklist & Safety Review',
        description: 'Verify bookings, emergency numbers, packing list, and travel insurance.',
        status: 'pending',
        order: 3,
        primaryAction: {
          label: 'Review Checklist & Passes',
          prompt: `Kaju, give me the CHECK list for "${goalTitle}". What are the essential things to pack and book in advance?`,
        },
        checkpoint: {
          id: `${goalId}_cp_1`,
          stepId: `${goalId}_step_check`,
          question: `Pre-departure readiness audit for ${goalTitle}`,
          attempts: 0,
          result: 'pending',
        },
      },
      {
        id: `${goalId}_step_done`,
        goalId,
        stage: 'DONE',
        title: 'Ready for Takeoff & Trip Replay',
        description: 'Complete digital itinerary and quick reference cards for the trip.',
        status: 'pending',
        order: 4,
        primaryAction: {
          label: 'Finalize Trip Plan & Replay',
          prompt: `Kaju, let's finalize the trip plan for "${goalTitle}"!`,
        },
      },
    ];
  }

  // Standard Academic / Study / Task Goal
  let subject = 'topic';
  if (lower.includes('math')) subject = 'Maths';
  else if (lower.includes('physics')) subject = 'Physics';
  else if (lower.includes('chem')) subject = 'Chemistry';
  else if (lower.includes('bio')) subject = 'Biology';
  else if (lower.includes('english')) subject = 'English';
  else if (lower.includes('integration')) subject = 'Integration';
  else if (lower.includes('form')) subject = 'Form Filling';

  const stepGoal: JourneyStep = {
    id: `${goalId}_step_goal`,
    goalId,
    stage: 'GOAL',
    title: 'Define Target & Milestones',
    description: `Target set: ${goalTitle}. Kaju will guide you step-by-step through execution.`,
    status: 'completed',
    order: 0,
    primaryAction: {
      label: 'Proceed to Step 1 (NOW)',
      prompt: `Kaju, I'm ready to begin the goal: "${goalTitle}". Let's start with NOW.`,
    },
    completedAt: Date.now(),
  };

  const stepNow: JourneyStep = {
    id: `${goalId}_step_now`,
    goalId,
    stage: 'NOW',
    title: 'Check Current Level & Essentials',
    description: `Understand core foundation of ${subject} and identify your baseline.`,
    status: 'in_progress',
    order: 1,
    primaryAction: {
      label: 'Start 5-minute Diagnostic',
      prompt: `Kaju, let's start the NOW step for "${goalTitle}". Give me a quick diagnostic check on what I already know.`,
    },
  };

  const stepNext: JourneyStep = {
    id: `${goalId}_step_next`,
    goalId,
    stage: 'NEXT',
    title: 'Revise Core Rules & High-Yield Points',
    description: `Focus on the most important rules, formulas, and key concepts.`,
    status: 'pending',
    order: 2,
    primaryAction: {
      label: 'Learn Key Formulas & Concepts',
      prompt: `Kaju, I am ready for the NEXT step in "${goalTitle}". Teach me the high-yield rules with clear examples.`,
    },
  };

  const stepCheck: JourneyStep = {
    id: `${goalId}_step_check`,
    goalId,
    stage: 'CHECK',
    title: 'Verify Progress with Practice Questions',
    description: `Test understanding with targeted checkpoint questions before moving to completion.`,
    status: 'pending',
    order: 3,
    primaryAction: {
      label: 'Attempt Checkpoint Questions',
      prompt: `Kaju, give me the CHECK question for "${goalTitle}". I want to verify if my concept is solid.`,
    },
    checkpoint: {
      id: `${goalId}_cp_1`,
      stepId: `${goalId}_step_check`,
      question: `Practice Checkpoint for ${subject}`,
      attempts: 0,
      result: 'pending',
    },
  };

  const stepDone: JourneyStep = {
    id: `${goalId}_step_done`,
    goalId,
    stage: 'DONE',
    title: 'Complete Final Mini-Test & Replay',
    description: `Final assessment checklist and review timeline of what was achieved.`,
    status: 'pending',
    order: 4,
    primaryAction: {
      label: 'Finish Goal & See Replay',
      prompt: `Kaju, I've finished the checklist for "${goalTitle}". Let's finish the goal and see the verified Replay!`,
    },
  };

  return [stepGoal, stepNow, stepNext, stepCheck, stepDone];
}

/**
 * Create a new persistent Goal from user input
 */
export function createGoal(input: string, detectedTitle?: string, deadline?: string): Goal {
  const id = `goal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const title =
    detectedTitle ||
    input.replace(/^(i have a|i want to|mujhe|mera)\s+/i, '').slice(0, 48) ||
    'Academic Goal';

  const steps = generateJourneySteps(id, title, input);

  const initialReplay: ReplayEvent = {
    id: `ev_${Date.now()}_1`,
    goalId: id,
    type: 'started',
    description: `Started: ${title}`,
    timestamp: Date.now(),
  };

  const detectedReplay: ReplayEvent = {
    id: `ev_${Date.now()}_2`,
    goalId: id,
    type: 'detected',
    description: `Kaju detected target${deadline ? ` with deadline (${deadline})` : ''}`,
    timestamp: Date.now() + 50,
  };

  let goalType: GoalType = 'study';
  const low = input.toLowerCase();
  if (low.includes('app') || low.includes('python') || low.includes('code') || low.includes('build')) goalType = 'coding';
  else if (low.includes('japanese') || low.includes('language') || low.includes('english') || low.includes('seekh')) goalType = 'language';
  else if (low.includes('trip') || low.includes('travel') || low.includes('japan')) goalType = 'travel';
  else if (low.includes('business') || low.includes('startup') || low.includes('launch')) goalType = 'business';
  else if (low.includes('form') || low.includes('task')) goalType = 'task';
  else if (low.includes('exam') || low.includes('board') || low.includes('paper')) goalType = 'exam';

  const newGoal: Goal = {
    id,
    title,
    originalInput: input,
    type: goalType,
    status: 'active',
    createdAt: Date.now(),
    deadline,
    currentStepId: steps[1].id, // Start at NOW
    currentStage: 'NOW',
    completionCondition: 'Complete checkpoint question and verify final mastery test',
    steps,
    replayEvents: [initialReplay, detectedReplay],
    weakAreas: [],
  };

  // Persist
  const existing = loadGoals();
  const updated = [newGoal, ...existing.filter((g) => g.id !== id)];
  saveGoals(updated);
  saveActiveGoalId(id);

  return newGoal;
}

/**
 * Advance an active goal to the next journey stage:
 * GOAL -> NOW -> NEXT -> CHECK -> DONE
 */
export function advanceGoalStage(goal: Goal, stepEvidence?: string): Goal {
  const stageOrder: JourneyStage[] = ['GOAL', 'NOW', 'NEXT', 'CHECK', 'DONE'];
  const currentIndex = stageOrder.indexOf(goal.currentStage);

  if (currentIndex === -1 || currentIndex >= stageOrder.length - 1) {
    // Already at DONE or completed
    return markGoalCompleted(goal);
  }

  const nextStage = stageOrder[currentIndex + 1];

  // Update current step to completed
  const updatedSteps = goal.steps.map((st) => {
    if (st.stage === goal.currentStage) {
      return {
        ...st,
        status: 'completed' as const,
        completedAt: Date.now(),
        evidence: stepEvidence || st.evidence,
      };
    }
    if (st.stage === nextStage) {
      return {
        ...st,
        status: 'in_progress' as const,
      };
    }
    return st;
  });

  const nextStep = updatedSteps.find((s) => s.stage === nextStage) || updatedSteps[updatedSteps.length - 1];

  // Add replay event
  const newReplayEvent: ReplayEvent = {
    id: `ev_${Date.now()}`,
    goalId: goal.id,
    type: 'practiced',
    description: `Completed stage ${goal.currentStage}: ${stepEvidence || 'Advancement achieved'}`,
    timestamp: Date.now(),
  };

  const updatedGoal: Goal = {
    ...goal,
    currentStage: nextStage,
    currentStepId: nextStep.id,
    steps: updatedSteps,
    replayEvents: [...goal.replayEvents, newReplayEvent],
  };

  if (nextStage === 'DONE') {
    return markGoalCompleted(updatedGoal);
  }

  // Save
  const allGoals = loadGoals();
  const savedList = allGoals.map((g) => (g.id === goal.id ? updatedGoal : g));
  saveGoals(savedList);

  return updatedGoal;
}

/**
 * Adaptive replanning: modify the active journey based on user struggle, ease, or style request
 */
export function adaptGoalJourney(
  goal: Goal,
  reason: 'struggle' | 'easy' | 'short' | 'checkpoint_failed',
  details?: string
): Goal {
  let description = '';
  let updatedWeakAreas = goal.weakAreas || [];

  if (reason === 'struggle' || reason === 'checkpoint_failed') {
    description = `Needed help with: ${details || 'core concept'}. Kaju simplified next task.`;
    if (details && !updatedWeakAreas.includes(details)) {
      updatedWeakAreas = [...updatedWeakAreas, details];
    }
  } else if (reason === 'easy') {
    description = 'Concept mastered quickly. Accelerated to checkpoint.';
  } else if (reason === 'short') {
    description = 'Switched to concise summary mode.';
  }

  const adaptEvent: ReplayEvent = {
    id: `ev_adapt_${Date.now()}`,
    goalId: goal.id,
    type: 'adapted',
    description,
    timestamp: Date.now(),
  };

  // Adjust current step action
  const updatedSteps = goal.steps.map((st) => {
    if (st.id === goal.currentStepId) {
      if (reason === 'struggle' || reason === 'checkpoint_failed') {
        return {
          ...st,
          primaryAction: {
            label: 'Review Simpler Example First',
            prompt: `Kaju, give me an everyday simple example for "${goal.title}" to make this click.`,
          },
        };
      }
      if (reason === 'easy') {
        return {
          ...st,
          primaryAction: {
            label: 'Jump Directly to Challenge',
            prompt: `Kaju, this is easy for me! Give me a real exam question for "${goal.title}".`,
          },
        };
      }
    }
    return st;
  });

  const adaptedGoal: Goal = {
    ...goal,
    weakAreas: updatedWeakAreas,
    steps: updatedSteps,
    replayEvents: [...goal.replayEvents, adaptEvent],
  };

  const allGoals = loadGoals();
  const savedList = allGoals.map((g) => (g.id === goal.id ? adaptedGoal : g));
  saveGoals(savedList);

  return adaptedGoal;
}

/**
 * Mark goal as completed with honest Replay record
 */
export function markGoalCompleted(goal: Goal): Goal {
  const completedSteps = goal.steps.map((st) => ({
    ...st,
    status: 'completed' as const,
    completedAt: st.completedAt || Date.now(),
  }));

  const completionEvent: ReplayEvent = {
    id: `ev_comp_${Date.now()}`,
    goalId: goal.id,
    type: 'completed',
    description: `Goal completed: ${goal.title}`,
    timestamp: Date.now(),
  };

  const completedGoal: Goal = {
    ...goal,
    status: 'completed',
    currentStage: 'DONE',
    completedAt: Date.now(),
    steps: completedSteps,
    replayEvents: [...goal.replayEvents, completionEvent],
  };

  const allGoals = loadGoals();
  const savedList = allGoals.map((g) => (g.id === goal.id ? completedGoal : g));
  saveGoals(savedList);

  // Clear active goal ID
  saveActiveGoalId(null);

  return completedGoal;
}

/**
 * Abandon/dismiss a goal
 */
export function abandonGoal(goalId: string): void {
  const allGoals = loadGoals();
  const savedList = allGoals.map((g) => (g.id === goalId ? { ...g, status: 'abandoned' as const } : g));
  saveGoals(savedList);
  if (loadActiveGoalId() === goalId) {
    saveActiveGoalId(null);
  }
}

import { KajuPublicProfile } from '../types';

export const MY_PROFILE_STORAGE_KEY = 'kaju_ai_my_public_profile_v1';

const DEFAULT_MY_PROFILE: KajuPublicProfile = {
  kajuId: 'kaju_explorer',
  displayName: 'Kaju Explorer',
  bio: 'Exploring AI productivity, learning, and safe assistant actions.',
  accountType: 'personal',
  verified: false,
  avatarSeed: 'KajuExplorer',
  joinedDate: '2026',
  isPublic: false, // Default is private / opt-in
  location: 'India',
};

// Verified Directory for discoverable public profiles (only explicitly verified accounts)
const PUBLIC_DIRECTORY: KajuPublicProfile[] = [
  {
    kajuId: 'kaju_official',
    displayName: 'Kaju AI Official Support',
    bio: 'Official verification & assistance channel for Kaju AI platform. Built and developed by Kailash.',
    accountType: 'business',
    verified: true,
    avatarSeed: 'KajuOfficial',
    joinedDate: '2026',
    isPublic: true,
    location: 'India',
    links: [
      { label: 'Documentation', url: 'https://kaju.ai/docs' },
    ],
  },
];

// In-memory fallback cache for Node test environments or private browsing
let identityStorageCache: Record<string, string> = {};

function safeGetItem(key: string): string | null {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key);
    }
    return identityStorageCache[key] ?? null;
  } catch {
    return identityStorageCache[key] ?? null;
  }
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
    identityStorageCache[key] = value;
  } catch {
    identityStorageCache[key] = value;
  }
}

export function loadMyProfile(): KajuPublicProfile {
  try {
    const raw = safeGetItem(MY_PROFILE_STORAGE_KEY);
    if (!raw) {
      saveMyProfile(DEFAULT_MY_PROFILE);
      return DEFAULT_MY_PROFILE;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load my profile:', e);
    return DEFAULT_MY_PROFILE;
  }
}

export function saveMyProfile(profile: KajuPublicProfile): void {
  try {
    safeSetItem(MY_PROFILE_STORAGE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed to save my profile:', e);
  }
}

export interface LookupResult {
  status: 'found' | 'private' | 'not_registered' | 'invalid_input';
  profile?: KajuPublicProfile;
  message: string;
}

/**
 * Privacy-respecting Kaju Identity Lookup
 * Checks only explicitly opt-in registered accounts.
 * Never accesses external telecom records or reveals private information.
 */
export function lookupKajuIdentity(query: string): LookupResult {
  const clean = query.trim();
  if (!clean || clean.length < 3) {
    return {
      status: 'invalid_input',
      message: 'Please enter a valid 10-digit phone number or @KajuID to look up.',
    };
  }

  // Normalize phone digits
  const digitsOnly = clean.replace(/[^0-9]/g, '');
  const isPhone = digitsOnly.length >= 10;
  const normalizedHandle = clean.startsWith('@') ? clean.slice(1).toLowerCase() : clean.toLowerCase();

  // Check current user's profile if public
  const myProfile = loadMyProfile();
  if (myProfile.isPublic) {
    const myDigits = (myProfile.phoneNumber || '').replace(/[^0-9]/g, '');
    if (
      (isPhone && digitsOnly.slice(-10) === myDigits.slice(-10)) ||
      normalizedHandle === myProfile.kajuId.toLowerCase()
    ) {
      return {
        status: 'found',
        profile: myProfile,
        message: 'Public profile verified on Kaju AI.',
      };
    }
  }

  // Check public verified directory
  for (const pub of PUBLIC_DIRECTORY) {
    const pubDigits = (pub.phoneNumber || '').replace(/[^0-9]/g, '');
    if (
      (isPhone && digitsOnly.slice(-10) === pubDigits.slice(-10)) ||
      normalizedHandle === pub.kajuId.toLowerCase()
    ) {
      return {
        status: 'found',
        profile: pub,
        message: 'Verified discoverable account found on Kaju AI.',
      };
    }
  }

  // If phone matches a simulated private pattern (e.g. ends with '99')
  if (isPhone && digitsOnly.endsWith('99')) {
    return {
      status: 'private',
      message: 'This user is registered on Kaju AI, but their profile is private and not discoverable. Kaju strictly respects user privacy.',
    };
  }

  // Not registered / no public account found
  return {
    status: 'not_registered',
    message: isPhone
      ? `No public Kaju AI profile is associated with ${clean}. Kaju respects user privacy and never searches private telecom carrier databases.`
      : `No public Kaju ID found for "@${normalizedHandle}".`,
  };
}

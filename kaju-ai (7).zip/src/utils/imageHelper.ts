/**
 * Ultra-fast, hardware-accelerated image preprocessing pipeline for Kaju AI.
 * Handles Camera capture & Gallery selection with zero artificial delay.
 * - Hardware-accelerated decoding via createImageBitmap where supported
 * - Automatic EXIF orientation normalization
 * - Optimal resolution (1280px max dimension) and compression (0.82 JPEG) for crystal-clear OCR and fast upload
 * - Avoids duplicate base64 conversions and memory bloat
 */

export interface ProcessedImage {
  dataUrl: string;
  width: number;
  height: number;
  sizeBytes: number;
}

/**
 * Creates a zero-delay instant preview object URL for immediate display
 */
export function createInstantPreview(source: File | Blob): string {
  try {
    return URL.createObjectURL(source);
  } catch {
    return '';
  }
}

/**
 * Revokes an object URL cleanly when no longer needed
 */
export function revokeInstantPreview(url: string): void {
  if (url && url.startsWith('blob:')) {
    try {
      URL.revokeObjectURL(url);
    } catch {}
  }
}

/**
 * Fast, optimized image pipeline for both Camera and Gallery.
 * Resizes and compresses images appropriately for fast mobile transmission while
 * preserving high contrast & resolution for textbook OCR, formulas, and diagrams.
 */
export async function fastOptimizeImage(
  source: File | Blob | string,
  maxDimension: number = 1280,
  quality: number = 0.82
): Promise<ProcessedImage> {
  // 1. If createImageBitmap is available and source is a Blob/File, use the fast path
  if (typeof window !== 'undefined' && 'createImageBitmap' in window && typeof source !== 'string') {
    try {
      // imageOrientation: 'from-image' automatically corrects mobile camera orientation (EXIF)
      const bitmap = await createImageBitmap(source, {
        imageOrientation: 'from-image',
      } as ImageBitmapOptions).catch(() => createImageBitmap(source));

      let width = bitmap.width;
      let height = bitmap.height;

      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d', { alpha: false });

      if (ctx) {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(bitmap, 0, 0, width, height);
        bitmap.close();

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const sizeBytes = Math.round((dataUrl.length * 3) / 4);

        return {
          dataUrl,
          width,
          height,
          sizeBytes,
        };
      }
      bitmap.close();
    } catch (e) {
      console.warn('createImageBitmap fast path failed, falling back to standard Image:', e);
    }
  }

  // 2. Fallback using HTMLImageElement
  return new Promise((resolve, reject) => {
    const img = new Image();

    const handleLoad = () => {
      let { width, height } = img;

      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d', { alpha: false });

      if (!ctx) {
        reject(new Error('Could not create canvas context'));
        return;
      }

      // Draw with white background in case of transparent PNG/scan
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      const sizeBytes = Math.round((dataUrl.length * 3) / 4);

      resolve({
        dataUrl,
        width,
        height,
        sizeBytes,
      });
    };

    img.onerror = () => {
      reject(new Error('Failed to load image for processing'));
    };

    if (typeof source === 'string') {
      img.src = source;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          img.src = e.target.result as string;
        } else {
          reject(new Error('Failed to read image file'));
        }
      };
      reader.onerror = () => reject(new Error('FileReader error'));
      reader.readAsDataURL(source);
    }
  });
}

/**
 * Backward-compatible wrapper
 */
export async function optimizeImage(
  source: File | Blob | string,
  maxDimension: number = 1280,
  quality: number = 0.82
): Promise<ProcessedImage> {
  return fastOptimizeImage(source, maxDimension, quality);
}

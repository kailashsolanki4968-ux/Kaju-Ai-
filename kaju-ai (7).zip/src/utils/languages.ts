export interface LanguageItem {
  id: string;
  name: string;
  nativeName: string;
  code: string; // BCP 47 tag for Web Speech API & TTS
  category: 'primary' | 'indian' | 'global';
  popular?: boolean;
}

export const SUPPORTED_LANGUAGES: LanguageItem[] = [
  {
    id: 'auto',
    name: 'Auto Detect',
    nativeName: 'स्वतः पहचानें',
    code: 'auto',
    category: 'primary',
    popular: true,
  },
  {
    id: 'hinglish',
    name: 'Hinglish',
    nativeName: 'हिंग्लिश (Roman Hindi)',
    code: 'hi-IN',
    category: 'primary',
    popular: true,
  },
  {
    id: 'hindi',
    name: 'Hindi',
    nativeName: 'हिन्दी',
    code: 'hi-IN',
    category: 'primary',
    popular: true,
  },
  {
    id: 'english',
    name: 'English',
    nativeName: 'English',
    code: 'en-US',
    category: 'primary',
    popular: true,
  },
  // Major Indian Regional Languages
  {
    id: 'bengali',
    name: 'Bengali',
    nativeName: 'বাংলা',
    code: 'bn-IN',
    category: 'indian',
    popular: true,
  },
  {
    id: 'marathi',
    name: 'Marathi',
    nativeName: 'मराठी',
    code: 'mr-IN',
    category: 'indian',
    popular: true,
  },
  {
    id: 'telugu',
    name: 'Telugu',
    nativeName: 'తెలుగు',
    code: 'te-IN',
    category: 'indian',
    popular: true,
  },
  {
    id: 'tamil',
    name: 'Tamil',
    nativeName: 'தமிழ்',
    code: 'ta-IN',
    category: 'indian',
    popular: true,
  },
  {
    id: 'gujarati',
    name: 'Gujarati',
    nativeName: 'ગુજરાતી',
    code: 'gu-IN',
    category: 'indian',
  },
  {
    id: 'kannada',
    name: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    code: 'kn-IN',
    category: 'indian',
  },
  {
    id: 'malayalam',
    name: 'Malayalam',
    nativeName: 'മലയാളം',
    code: 'ml-IN',
    category: 'indian',
  },
  {
    id: 'punjabi',
    name: 'Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    code: 'pa-IN',
    category: 'indian',
  },
  {
    id: 'urdu',
    name: 'Urdu',
    nativeName: 'اردو',
    code: 'ur-PK',
    category: 'indian',
  },
  // Major Global Languages
  {
    id: 'spanish',
    name: 'Spanish',
    nativeName: 'Español',
    code: 'es-ES',
    category: 'global',
    popular: true,
  },
  {
    id: 'french',
    name: 'French',
    nativeName: 'Français',
    code: 'fr-FR',
    category: 'global',
    popular: true,
  },
  {
    id: 'german',
    name: 'German',
    nativeName: 'Deutsch',
    code: 'de-DE',
    category: 'global',
  },
  {
    id: 'portuguese',
    name: 'Portuguese',
    nativeName: 'Português',
    code: 'pt-BR',
    category: 'global',
  },
  {
    id: 'italian',
    name: 'Italian',
    nativeName: 'Italiano',
    code: 'it-IT',
    category: 'global',
  },
  {
    id: 'japanese',
    name: 'Japanese',
    nativeName: '日本語',
    code: 'ja-JP',
    category: 'global',
    popular: true,
  },
  {
    id: 'korean',
    name: 'Korean',
    nativeName: '한국어',
    code: 'ko-KR',
    category: 'global',
  },
  {
    id: 'chinese',
    name: 'Chinese',
    nativeName: '中文',
    code: 'zh-CN',
    category: 'global',
    popular: true,
  },
  {
    id: 'arabic',
    name: 'Arabic',
    nativeName: 'العربية',
    code: 'ar-SA',
    category: 'global',
    popular: true,
  },
  {
    id: 'russian',
    name: 'Russian',
    nativeName: 'Русский',
    code: 'ru-RU',
    category: 'global',
  },
  {
    id: 'indonesian',
    name: 'Indonesian',
    nativeName: 'Bahasa Indonesia',
    code: 'id-ID',
    category: 'global',
  },
  {
    id: 'turkish',
    name: 'Turkish',
    nativeName: 'Türkçe',
    code: 'tr-TR',
    category: 'global',
  },
  {
    id: 'vietnamese',
    name: 'Vietnamese',
    nativeName: 'Tiếng Việt',
    code: 'vi-VN',
    category: 'global',
  },
  {
    id: 'thai',
    name: 'Thai',
    nativeName: 'ไทย',
    code: 'th-TH',
    category: 'global',
  },
];

/**
 * Get item by id or fallback to auto
 */
export function getLanguageInfo(id?: string): LanguageItem {
  if (!id) return SUPPORTED_LANGUAGES[0];
  const found = SUPPORTED_LANGUAGES.find((lang) => lang.id.toLowerCase() === id.toLowerCase());
  return found || SUPPORTED_LANGUAGES[0];
}

/**
 * Get short display name for the language pill
 */
export function getLanguageShortLabel(id?: string): string {
  const item = getLanguageInfo(id);
  if (item.id === 'auto') return 'Auto';
  if (item.id === 'hindi') return 'हिंदी';
  if (item.id === 'english') return 'English';
  if (item.id === 'hinglish') return 'Hinglish';
  return item.nativeName.split(' ')[0] || item.name;
}

/**
 * Map language ID to speech recognition BCP-47 tag
 */
export function getSpeechRecognitionLang(pref?: string): string {
  if (!pref || pref === 'auto') {
    // If browser navigator language is available and not generic, prefer it or default to hi-IN / en-US
    const nav = typeof navigator !== 'undefined' ? navigator.language : 'hi-IN';
    return nav || 'hi-IN';
  }
  const item = getLanguageInfo(pref);
  return item.code || 'hi-IN';
}

/**
 * Detect language script from text input
 */
export function detectScriptFromText(text: string): string {
  if (/[\u0900-\u097F]/.test(text)) return 'hindi'; // Devanagari (Hindi, Marathi)
  if (/[\u0980-\u09FF]/.test(text)) return 'bengali';
  if (/[\u0C00-\u0C7F]/.test(text)) return 'telugu';
  if (/[\u0B80-\u0BFF]/.test(text)) return 'tamil';
  if (/[\u0A80-\u0AFF]/.test(text)) return 'gujarati';
  if (/[\u0C80-\u0CFF]/.test(text)) return 'kannada';
  if (/[\u0D00-\u0D7F]/.test(text)) return 'malayalam';
  if (/[\u0A00-\u0A7F]/.test(text)) return 'punjabi';
  if (/[\u0600-\u06FF]/.test(text)) return 'arabic'; // Arabic / Urdu
  if (/[\u3040-\u30FF\u4E00-\u9FAF]/.test(text)) return 'japanese';
  if (/[\uAC00-\uD7AF]/.test(text)) return 'korean';
  if (/[\u0E00-\u0E7F]/.test(text)) return 'thai';
  if (/[\u0400-\u04FF]/.test(text)) return 'russian';
  if (/[a-zA-Z]/.test(text)) {
    // Check common Hinglish markers
    const lower = text.toLowerCase();
    const hinglishMarkers = ['kya', 'hai', 'kaise', 'batao', 'samjhao', 'karo', 'mujhe', 'aaj', 'padhai', 'chahiye', 'mera', 'meri', 'haan', 'nahi'];
    if (hinglishMarkers.some((w) => new RegExp(`\\b${w}\\b`, 'i').test(lower))) {
      return 'hinglish';
    }
    return 'english';
  }
  return 'auto';
}

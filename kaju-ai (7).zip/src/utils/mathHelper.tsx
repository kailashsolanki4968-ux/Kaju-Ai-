import React, { Component, ReactNode, ErrorInfo } from 'react';
import { LanguagePreference } from '../types';

interface MathErrorBoundaryProps {
  children: ReactNode;
  fallbackText?: string;
}

interface MathErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

/**
 * MathErrorBoundary prevents any malformed LaTeX, unexpected tokens, or KaTeX
 * rendering anomalies from crashing the chat message bubble or application.
 */
export class MathErrorBoundary extends Component<
  MathErrorBoundaryProps,
  MathErrorBoundaryState
> {
  constructor(props: MathErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): MathErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.warn('MathErrorBoundary caught an error during rendering:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="math-fallback-container text-stone-800 whitespace-pre-wrap font-sans text-[14px] leading-relaxed p-2 bg-amber-50/60 rounded-lg border border-amber-200/60">
          {this.props.fallbackText || (this.props.children as any)}
        </div>
      );
    }
    return this.props.children;
  }
}

/**
 * Normalizes and formats mathematical LaTeX notation inside Markdown strings:
 * 1. Normalizes double backslashes before LaTeX keywords and brackets
 * 2. Protects code blocks (``` and `)
 * 3. Converts & protects standard LaTeX display \[ ... \] and inline \( ... \) delimiters
 * 4. Protects existing display math $$ ... $$ ensuring clean padding (WITHOUT breaking on numbers e.g. $$49 - 24 = 25$$)
 * 5. Standalone LaTeX matrix and align environments
 * 6. Protects and normalizes inline math $ ... $ (trimming accidental internal whitespace)
 * 7. Protects standalone currency figures (e.g. $15, $3.50, $1,000) so they are never mistaken for math
 * 8. Safely auto-wraps bare mathematical equations on full lines
 * 9. Supports nested curly braces for fractions and square roots
 * 10. Restores tokens safely using replacer functions to prevent $$ string replacement bugs
 * 11. Leaves Hindi, English, and Hinglish prose completely intact
 */
export function preprocessMathMarkdown(rawText: string): string {
  if (!rawText) return '';

  const tokens: string[] = [];

  function addToken(content: string): string {
    const id = `__MATH_TOK_${tokens.length}__`;
    tokens.push(content);
    return id;
  }

  let s = rawText;

  // Phase 0: Normalize double backslashes before LaTeX keywords and brackets (e.g. \\frac -> \frac)
  s = s.replace(/\\\\([a-zA-Z]+|\[|\]|\(|\))/g, '\\$1');

  // Phase 1: Protect code blocks (``` and `) so math inside code is untouched
  s = s.replace(/(`{1,3}[\s\S]*?`{1,3})/g, (match) => addToken(match));

  // Phase 2: Convert & protect LaTeX display \[ ... \]
  s = s.replace(/\\\[([\s\S]*?)\\\]/g, (_, formula) => {
    return addToken(`\n\n$$\n${formula.trim()}\n$$\n\n`);
  });

  // Phase 3: Convert & protect LaTeX inline \( ... \)
  s = s.replace(/\\\(([\s\S]*?)\\\)/g, (_, formula) => {
    return addToken(`$${formula.trim()}$`);
  });

  // Phase 4: Protect existing display math $$ ... $$ BEFORE any currency matching!
  // This ensures equations starting with numbers like $$49 - 24 = 25$$ are never corrupted.
  s = s.replace(/\$\$([\s\S]*?)\$\$/g, (_, formula) => {
    return addToken(`\n\n$$\n${formula.trim()}\n$$\n\n`);
  });

  // Phase 5: Standalone LaTeX environments: \begin{matrix} ... \end{matrix}, align, etc.
  s = s.replace(
    /(\\begin\{(?:pmatrix|bmatrix|vmatrix|Vmatrix|matrix|align\*?|aligned|equation\*?|gather\*?)\}[\s\S]*?\\end\{(?:pmatrix|bmatrix|vmatrix|Vmatrix|matrix|align\*?|aligned|equation\*?|gather\*?)\})/g,
    (match) => addToken(`\n\n$$\n${match.trim()}\n$$\n\n`)
  );

  // Phase 6: Protect existing inline math $ ... $
  // Trim spaces inside dollars so remark-math and KaTeX parse it reliably (e.g. $ 2x + 3 = 7 $ -> $2x + 3 = 7$)
  s = s.replace(/(^|[^\$])\$([^\$\n]+?)\$(?!\$)/g, (match, prefix, mathContent) => {
    const trimmed = mathContent.trim();
    // Exclude two adjacent currency amounts on same line like "$10 and $20"
    if (/^\d+(?:,\d{3})*(?:\.\d+)?\s*(?:and|to|or|,|-)\s*\d+(?:,\d{3})*(?:\.\d+)?$/i.test(trimmed)) {
      return match;
    }
    // Exclude standalone single dollar number with no operators
    if (/^\d+(?:,\d{3})*(?:\.\d+)?$/.test(trimmed)) {
      return match;
    }
    return `${prefix}${addToken(`$${trimmed}$`)}`;
  });

  // Phase 7: Protect remaining standalone currency amounts (e.g. $50, $1,000, $25.50)
  s = s.replace(/(^|\s)\$(\d+(?:,\d{3})*(?:\.\d+)?)(?=[\s\.,।\?!]|$)/g, (m, p, num) => {
    return `${p}${addToken(`$${num}`)}`;
  });

  // Phase 8: Full-line bare mathematical equations
  // Matches lines that contain LaTeX commands or formulas without prose text
  const lines = s.split('\n');
  s = lines
    .map((line) => {
      const trimmed = line.trim();
      if (
        !trimmed ||
        trimmed.startsWith('#') ||
        trimmed.startsWith('|') ||
        trimmed.startsWith('---') ||
        line.includes('__MATH_TOK_')
      ) {
        return line;
      }
      const listMatch = line.match(/^(\s*(?:\d+\.|\*|-)\s*)(.*)$/);
      const prefix = listMatch ? listMatch[1] : '';
      const content = listMatch ? listMatch[2].trim() : trimmed;

      const hasLatex = /\\[a-zA-Z]+/.test(content);
      const hasHindi = /[\u0900-\u097F]/.test(content);
      const englishWords: string[] = content.replace(/\\[a-zA-Z]+/g, '').match(/[a-zA-Z]{3,}/g) || [];
      const knownMathWords = [
        'sin', 'cos', 'tan', 'sec', 'csc', 'cot', 'log', 'lim', 'max', 'min',
        'det', 'dim', 'ker', 'exp', 'deg', 'gcd', 'mod', 'sup', 'inf',
      ];
      const nonMathWords = englishWords.filter((w: string) => !knownMathWords.includes(w.toLowerCase()));

      if (hasLatex && !hasHindi && nonMathWords.length === 0) {
        if (prefix) {
          return `${prefix}${addToken(`$${content}$`)}`;
        } else {
          return addToken(`\n\n$$\n${content}\n$$\n\n`);
        }
      }
      return line;
    })
    .join('\n');

  // Phase 9: Bracketed expressions with \left and \right and sub/superscripts
  s = s.replace(
    /(\\left[\(\[\{\|\.][^\n]*?\\right[\)\]\}\|\.](?:_\{?[^}\s]+\}?|\^\{?[^}\s]+\}?)*)/g,
    (match) => addToken(`$${match.trim()}$`)
  );

  // Phase 10: Integrals, summations, products, and limits
  s = s.replace(
    /(\\int(?:_\{?[^}\s]+\}?)?(?:\^\{?[^}\s]+\}?)?\s+[a-zA-Z0-9\(\)\s\+\-\*\/\^\\]*?d[a-zA-Z])(?=[\s\.,।\?!]|$)/g,
    (match) => addToken(`$${match.trim()}$`)
  );
  s = s.replace(
    /(\\(?:sum|prod|lim)(?:_\{?[^}]+\}?)?(?:\^\{?[^}]+\}?)?\s*[a-zA-Z0-9\(\)\s\+\-\*\/\=\\]+?)(?=[\s\.,।\?!]|$)/g,
    (match) => addToken(`$${match.trim()}$`)
  );

  // Phase 11: Fractions, roots, and vectors with support for nested curly braces (up to 3 levels)
  const b0 = '[^{}]*';
  const b1 = `(?:[^{}]|\\{${b0}\\})*`;
  const b2 = `(?:[^{}]|\\{${b1}\\})*`;
  const b3 = `(?:[^{}]|\\{${b2}\\})*`;
  const eqPrefix = '(?:[a-zA-Z](?:\\([a-zA-Z0-9,\\s]+\\))?(?:_[a-zA-Z0-9]+)?\\s*=\\s*)?';

  const fracRegex = new RegExp(`(${eqPrefix}\\\\frac\\{${b3}\\}\\{${b3}\\})`, 'g');
  s = s.replace(fracRegex, (match) => addToken(`$${match.trim()}$`));

  const sqrtRegex = new RegExp(`(${eqPrefix}\\\\sqrt(?:\\[[^\\]]*\\])?\\{${b3}\\})`, 'g');
  s = s.replace(sqrtRegex, (match) => addToken(`$${match.trim()}$`));

  s = s.replace(/(\\\\vec\{[^{}]+\})/g, (match) => addToken(`$${match.trim()}$`));

  // Phase 12: Trigonometric, logarithmic, and calculus functions with arguments
  s = s.replace(
    /(\\(?:sin|cos|tan|sec|csc|cot|ln|log|exp|arcsin|arccos|arctan)(?:\^[0-9]+)?(?:\([^\)]+\)|[a-zA-Z0-9\\]+)?)/g,
    (match) => addToken(`$${match.trim()}$`)
  );

  // Phase 13: Greek letters and standard math symbols
  const greekAndSymbols =
    'pi|alpha|beta|gamma|delta|epsilon|varepsilon|zeta|eta|theta|vartheta|iota|kappa|lambda|mu|nu|xi|rho|varrho|sigma|tau|upsilon|phi|varphi|chi|psi|omega|Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega|infty|pm|mp|times|div|cdot|approx|neq|leq|geq|forall|exists|partial|nabla|to|rightarrow|leftarrow|implies|iff';
  const symRegex = new RegExp(`(\\\\(${greekAndSymbols})\\b(?:\\^[0-9]+|_[0-9]+)?)`, 'g');
  s = s.replace(symRegex, (match) => addToken(`$${match.trim()}$`));

  // Phase 14: Clean excessive consecutive newlines
  s = s.replace(/\n{3,}/g, '\n\n');

  // Phase 15: Safely restore all tokens using replacer functions
  // IMPORTANT: Using `() => tokens[i]` prevents JavaScript String.replace
  // from interpreting `$$` as an escaped literal dollar sign!
  for (let i = 0; i < tokens.length; i++) {
    s = s.replace(`__MATH_TOK_${i}__`, () => tokens[i]);
  }

  return s;
}

/**
 * Converts mathematical formulas and scientific symbols into natural, readable words
 * for speech synthesis (TTS) in Hindi, English, and Hinglish.
 * Prevents the speech engine from reading confusing raw backslashes and LaTeX tags like "frac" or "sqrt".
 */
export function cleanMathForSpeech(
  text: string,
  langPrefOrIsHindi: LanguagePreference | boolean = 'english'
): string {
  if (!text) return '';

  let isHindi = false;
  let isHinglish = false;

  if (typeof langPrefOrIsHindi === 'boolean') {
    isHindi = langPrefOrIsHindi;
  } else if (langPrefOrIsHindi === 'hindi') {
    isHindi = true;
  } else if (langPrefOrIsHindi === 'hinglish') {
    isHinglish = true;
  } else if (langPrefOrIsHindi === 'auto') {
    isHindi = /[\u0900-\u097F]/.test(text);
  }

  let s = text;

  // 1. Remove LaTeX text wrappers: \text{...}, \mathrm{...}, etc.
  s = s.replace(/\\(?:text|mathbf|mathrm|mathit|textbf|textrm)\{([^{}]+)\}/g, '$1');

  // 2. Remove layout/structural commands with word boundaries
  s = s.replace(/\\(?:left|right|quad|qquad|limits|displaystyle|nolimits)\b/g, ' ');
  s = s.replace(
    /\\(?:begin|end)\{(?:matrix|pmatrix|bmatrix|vmatrix|Vmatrix|align\*?|aligned|equation\*?|gather\*?)\}/g,
    ' '
  );

  // 3. Remove dollar signs early
  s = s.replace(/\${1,2}/g, ' ');

  // 4. Handle chemical formulas e.g. H_2O, CO_2, H_2SO_4, CaCO_3
  s = s.replace(/\b([A-Z][a-z]?)_\{?([0-9]+)\}?/g, '$1 $2 ');

  // 5. Physics and math units
  if (isHindi) {
    s = s.replace(/m\/s\^2\b/g, ' मीटर प्रति सेकंड वर्ग ');
    s = s.replace(/m\/s\b/g, ' मीटर प्रति सेकंड ');
    s = s.replace(/km\/h\b/g, ' किलोमीटर प्रति घंटा ');
    s = s.replace(/kg\\cdot m\/s\^2\b/g, ' न्यूटन ');
  } else if (isHinglish) {
    s = s.replace(/m\/s\^2\b/g, ' meter per second square ');
    s = s.replace(/m\/s\b/g, ' meter per second ');
    s = s.replace(/km\/h\b/g, ' kilometer per hour ');
    s = s.replace(/kg\\cdot m\/s\^2\b/g, ' newton ');
  } else {
    s = s.replace(/m\/s\^2\b/g, ' meters per second squared ');
    s = s.replace(/m\/s\b/g, ' meters per second ');
    s = s.replace(/km\/h\b/g, ' kilometers per hour ');
    s = s.replace(/kg\\cdot m\/s\^2\b/g, ' newtons ');
  }

  // 6. Limits and integrals
  if (isHindi) {
    s = s.replace(/\\int_(?:\{([^}]+)\}|([a-zA-Z0-9]+))\^(?:\{([^}]+)\}|([a-zA-Z0-9]+))/g, ' सीमा $1$2 से $3$4 तक समाकलन ');
    s = s.replace(/\\int\b/g, ' समाकलन ');
  } else if (isHinglish) {
    s = s.replace(/\\int_(?:\{([^}]+)\}|([a-zA-Z0-9]+))\^(?:\{([^}]+)\}|([a-zA-Z0-9]+))/g, ' integral from $1$2 to $3$4 ');
    s = s.replace(/\\int\b/g, ' integral ');
  } else {
    s = s.replace(/\\int_(?:\{([^}]+)\}|([a-zA-Z0-9]+))\^(?:\{([^}]+)\}|([a-zA-Z0-9]+))/g, ' integral from $1$2 to $3$4 of ');
    s = s.replace(/\\int\b/g, ' integral of ');
  }

  // 7. Recursive handling for square roots and fractions (up to 4 levels)
  const replaceRoots = (str: string): string => {
    let prev = str;
    for (let iter = 0; iter < 4; iter++) {
      let next = prev.replace(/\\sqrt\[3\]\{([^{}]+)\}/g, (_, inner) => {
        if (isHindi) return `(${inner.trim()} का घनमूल)`;
        if (isHinglish) return `cube root of (${inner.trim()})`;
        return `cube root of (${inner.trim()})`;
      });
      next = next.replace(/\\sqrt\{([^{}]+)\}/g, (_, inner) => {
        if (isHindi) return `(${inner.trim()} का वर्गमूल)`;
        if (isHinglish) return `square root of (${inner.trim()})`;
        return `square root of (${inner.trim()})`;
      });
      if (next === prev) break;
      prev = next;
    }
    return prev;
  };

  const replaceFractions = (str: string): string => {
    let prev = str;
    for (let iter = 0; iter < 4; iter++) {
      const next = prev.replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, (_, num, den) => {
        if (isHindi) {
          return `(${num.trim()}) बटे (${den.trim()})`;
        } else if (isHinglish) {
          return `(${num.trim()}) divided by (${den.trim()})`;
        } else {
          return `(${num.trim()}) divided by (${den.trim()})`;
        }
      });
      if (next === prev) break;
      prev = next;
    }
    return prev;
  };

  s = replaceRoots(s);
  s = replaceFractions(s);

  // 8. Greek letters, trigonometric functions, and operators
  if (isHindi) {
    s = s.replace(/\\pi\b/g, ' पाई ');
    s = s.replace(/\\theta\b/g, ' थीटा ');
    s = s.replace(/\\alpha\b/g, ' अल्फा ');
    s = s.replace(/\\beta\b/g, ' बीटा ');
    s = s.replace(/\\gamma\b/g, ' गामा ');
    s = s.replace(/\\delta\b|\\Delta\b/g, ' डेल्टा ');
    s = s.replace(/\\lambda\b/g, ' लैम्ब्डा ');
    s = s.replace(/\\sigma\b|\\Sigma\b/g, ' सिग्मा ');
    s = s.replace(/\\omega\b|\\Omega\b/g, ' ओमेगा ');

    s = s.replace(/\\sin\b/g, ' साइन ');
    s = s.replace(/\\cos\b/g, ' कॉस ');
    s = s.replace(/\\tan\b/g, ' टैन ');

    s = s.replace(/\\pm\b/g, ' प्लस या माइनस ');
    s = s.replace(/\\times\b/g, ' गुणा ');
    s = s.replace(/\\div\b/g, ' भाग ');
    s = s.replace(/\\cdot\b/g, ' गुणा ');
    s = s.replace(/\\sum\b/g, ' कुल योग ');
    s = s.replace(/\\infty\b/g, ' अनंत ');
    s = s.replace(/\\implies\b/g, ' जिसका अर्थ है ');
    s = s.replace(/\\to\b|\\rightarrow\b/g, ' की ओर ');
    s = s.replace(/\\le\b|\\leq\b/g, ' से कम या बराबर ');
    s = s.replace(/\\ge\b|\\geq\b/g, ' से बड़ा या बराबर ');
    s = s.replace(/\\neq\b/g, ' बराबर नहीं ');
    s = s.replace(/\\approx\b/g, ' लगभग ');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^2\b/g, '$1 का वर्ग');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^3\b/g, '$1 का घन');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^\{?([a-zA-Z0-9\+\-]+)\}?/g, '$1 की घात $2');
  } else if (isHinglish) {
    s = s.replace(/\\pi\b/g, ' pi ');
    s = s.replace(/\\theta\b/g, ' theta ');
    s = s.replace(/\\alpha\b/g, ' alpha ');
    s = s.replace(/\\beta\b/g, ' beta ');
    s = s.replace(/\\gamma\b/g, ' gamma ');
    s = s.replace(/\\delta\b|\\Delta\b/g, ' delta ');
    s = s.replace(/\\lambda\b/g, ' lambda ');
    s = s.replace(/\\sigma\b|\\Sigma\b/g, ' sigma ');
    s = s.replace(/\\omega\b|\\Omega\b/g, ' omega ');

    s = s.replace(/\\sin\b/g, ' sin ');
    s = s.replace(/\\cos\b/g, ' cos ');
    s = s.replace(/\\tan\b/g, ' tan ');

    s = s.replace(/\\pm\b/g, ' plus minus ');
    s = s.replace(/\\times\b/g, ' into ');
    s = s.replace(/\\div\b/g, ' divided by ');
    s = s.replace(/\\cdot\b/g, ' into ');
    s = s.replace(/\\sum\b/g, ' sum of ');
    s = s.replace(/\\infty\b/g, ' infinity ');
    s = s.replace(/\\implies\b/g, ' implies ');
    s = s.replace(/\\to\b|\\rightarrow\b/g, ' gives ');
    s = s.replace(/\\le\b|\\leq\b/g, ' less than or equal to ');
    s = s.replace(/\\ge\b|\\geq\b/g, ' greater than or equal to ');
    s = s.replace(/\\neq\b/g, ' not equal to ');
    s = s.replace(/\\approx\b/g, ' approximately ');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^2\b/g, '$1 square');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^3\b/g, '$1 cube');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^\{?([a-zA-Z0-9\+\-]+)\}?/g, '$1 ki power $2');
  } else {
    s = s.replace(/\\pi\b/g, ' pi ');
    s = s.replace(/\\theta\b/g, ' theta ');
    s = s.replace(/\\alpha\b/g, ' alpha ');
    s = s.replace(/\\beta\b/g, ' beta ');
    s = s.replace(/\\gamma\b/g, ' gamma ');
    s = s.replace(/\\delta\b|\\Delta\b/g, ' delta ');
    s = s.replace(/\\lambda\b/g, ' lambda ');
    s = s.replace(/\\sigma\b|\\Sigma\b/g, ' sigma ');
    s = s.replace(/\\omega\b|\\Omega\b/g, ' omega ');

    s = s.replace(/\\sin\b/g, ' sine ');
    s = s.replace(/\\cos\b/g, ' cosine ');
    s = s.replace(/\\tan\b/g, ' tangent ');

    s = s.replace(/\\pm\b/g, ' plus or minus ');
    s = s.replace(/\\times\b/g, ' times ');
    s = s.replace(/\\div\b/g, ' divided by ');
    s = s.replace(/\\cdot\b/g, ' times ');
    s = s.replace(/\\int\b/g, ' integral of ');
    s = s.replace(/\\sum\b/g, ' sum of ');
    s = s.replace(/\\infty\b/g, ' infinity ');
    s = s.replace(/\\implies\b/g, ' implies ');
    s = s.replace(/\\to\b|\\rightarrow\b/g, ' approaches ');
    s = s.replace(/\\le\b|\\leq\b/g, ' less than or equal to ');
    s = s.replace(/\\ge\b|\\geq\b/g, ' greater than or equal to ');
    s = s.replace(/\\neq\b/g, ' not equal to ');
    s = s.replace(/\\approx\b/g, ' approximately ');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^2\b/g, '$1 squared');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^3\b/g, '$1 cubed');
    s = s.replace(/([a-zA-Z0-9\(\)]+)\^\{?([a-zA-Z0-9\+\-]+)\}?/g, '$1 to the power $2');
  }

  // 9. Clean reaction arrows
  s = s.replace(/\\xrightarrow\{[^}]*\}/g, ' reacts to form ');
  s = s.replace(/\\rightarrow\b|\\to\b/g, ' gives ');

  // 10. Remove spacing and remaining raw backslash LaTeX words
  s = s.replace(/\\,\s*/g, ' ');
  s = s.replace(/\\([a-zA-Z]+)/g, '$1');

  // 11. Remove curly braces
  s = s.replace(/[\{\}]/g, ' ');

  // 12. Normalize whitespace
  s = s.replace(/[ \t]+/g, ' ').trim();

  return s;
}

/**
 * Natural Language Image & Video Generation Intent Router for Kaju AI.
 * Accurately detects when the user requests generating a real AI image or video
 * in natural Hindi, Hinglish, or English, while strictly distinguishing from:
 * - Image understanding / Vision (e.g., analyzing an uploaded photo)
 * - Ordinary conversational chit-chat
 */

export interface DetectedMediaIntent {
  type: 'image' | 'video';
  prompt: string;
  originalQuery: string;
  aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4';
  resolution?: '720p' | '1080p';
  style?: string;
}

/**
 * Checks if a user message is asking to generate a real AI image or video.
 * Returns the detected intent and cleaned prompt, or null if it's normal chat/vision.
 */
export function detectMediaIntent(
  query: string,
  hasAttachment: boolean = false
): DetectedMediaIntent | null {
  if (!query || typeof query !== 'string') return null;

  // Never hijack vision / photo analysis questions when a user has attached an image
  if (hasAttachment) return null;

  const trimmed = query.trim();
  const lower = trimmed.toLowerCase();

  // If query is too short or is asking about Kaju identity, skip
  if (trimmed.length < 4) return null;

  // Guard against Vision questions without attachments (e.g., "photo me kya tha", "kal ki photo")
  if (
    lower.includes('photo solve') ||
    lower.includes('photo explain') ||
    lower.includes('photo me kya') ||
    lower.includes('image me kya') ||
    lower.includes('ye photo kiski hai') ||
    lower.includes('image solve karo')
  ) {
    return null;
  }

  // 1. VIDEO GENERATION INTENT DETECTION
  // Patterns: "video banao", "video generate karo", "create a video", "generate video", "veo video"
  const isVideoKeyword =
    /\b(video banao|video bana do|video banayein|video generate|generate a video|create a video|make a video|video create|veo video|ai video)\b/i.test(
      lower
    ) ||
    (lower.includes('video') &&
      (lower.includes('banao') ||
        lower.includes('generate') ||
        lower.includes('create') ||
        lower.includes('bana do')));

  if (isVideoKeyword) {
    // Determine aspect ratio
    let aspectRatio: '16:9' | '9:16' = '16:9';
    if (lower.includes('9:16') || lower.includes('portrait') || lower.includes('reel') || lower.includes('short')) {
      aspectRatio = '9:16';
    }

    // Determine resolution
    let resolution: '720p' | '1080p' = '720p';
    if (lower.includes('1080p') || lower.includes('full hd') || lower.includes('1080')) {
      resolution = '1080p';
    }

    // Extract prompt
    let cleanPrompt = trimmed;
    // Strip leading trigger prefixes
    cleanPrompt = cleanPrompt
      .replace(/^(?:kaju\s*,?\s*)?(?:please\s*)?(?:ek\s*)?(?:mujhe\s*)?(?:ai\s*)?video\s*(?:banao|bana\s*do|generate\s*karo|create\s*karo)?\s*(?:jisme|of|for|about|ke\s*liye|par)?\s*/i, '')
      .replace(/^(?:create|generate|make)\s*(?:a\s*)?(?:short\s*)?(?:cinematic\s*)?video\s*(?:of|about|showing|with)?\s*/i, '')
      .replace(/\s*(?:banao|bana\s*do|generate\s*karo|create\s*karo)\s*$/i, '')
      .trim();

    if (!cleanPrompt || cleanPrompt.length < 3) {
      cleanPrompt = trimmed;
    }

    return {
      type: 'video',
      prompt: cleanPrompt,
      originalQuery: trimmed,
      aspectRatio,
      resolution,
    };
  }

  // 2. IMAGE GENERATION INTENT DETECTION
  // Patterns: "photo banao", "image banao", "image generate karo", "create an image", "generate image",
  // "draw an image", "tasveer banao", "chitra banao", "picture draw karo"
  const isImageKeyword =
    /\b(image banao|image bana do|photo banao|photo bana do|tasveer banao|tasvir banao|chitra banao|image generate|generate an image|create an image|draw an image|draw a picture|picture draw|ai photo banao|ai image|ai picture)\b/i.test(
      lower
    ) ||
    ((lower.includes('image') || lower.includes('photo') || lower.includes('tasveer') || lower.includes('chitra') || lower.includes('picture')) &&
      (lower.includes('banao') ||
        lower.includes('bana do') ||
        lower.includes('generate karo') ||
        lower.includes('generate an image') ||
        lower.includes('create an image') ||
        lower.includes('draw karo') ||
        lower.includes('draw an')));

  // Direct trigger phrases in English like "draw a cat", "generate an image of a sunset"
  const isEnglishImageRequest =
    /^(?:draw|generate|create|paint)\s+(?:an?\s+)?(?:image|photo|picture|illustration|painting)\s+(?:of|showing|with)?/i.test(
      lower
    ) ||
    /^(?:draw|paint)\s+(?:me\s+)?(?:an?\s+)?(?:cute\s+|futuristic\s+|beautiful\s+|cartoon\s+|realistic\s+)?/i.test(
      lower
    );

  if (isImageKeyword || isEnglishImageRequest) {
    // Determine aspect ratio
    let aspectRatio: '1:1' | '16:9' | '9:16' | '4:3' | '3:4' = '1:1';
    if (lower.includes('16:9') || lower.includes('landscape') || lower.includes('wallpaper')) {
      aspectRatio = '16:9';
    } else if (lower.includes('9:16') || lower.includes('portrait') || lower.includes('story') || lower.includes('phone wallpaper')) {
      aspectRatio = '9:16';
    } else if (lower.includes('4:3')) {
      aspectRatio = '4:3';
    } else if (lower.includes('3:4')) {
      aspectRatio = '3:4';
    }

    // Determine style
    let style = 'Photorealistic';
    if (lower.includes('watercolor') || lower.includes('water color')) {
      style = 'Watercolor';
    } else if (lower.includes('cartoon') || lower.includes('anime') || lower.includes('disney') || lower.includes('pixar')) {
      style = 'Digital Art / Cartoon';
    } else if (lower.includes('3d') || lower.includes('render')) {
      style = '3D Render';
    } else if (lower.includes('sketch') || lower.includes('pencil')) {
      style = 'Sketch';
    }

    // Clean prompt
    let cleanPrompt = trimmed;
    cleanPrompt = cleanPrompt
      .replace(/^(?:kaju\s*,?\s*)?(?:please\s*)?(?:ek\s*)?(?:mujhe\s*)?(?:ai\s*)?(?:photo|image|tasveer|tasvir|chitra|picture)\s*(?:banao|bana\s*do|generate\s*karo|create\s*karo|draw\s*karo)?\s*(?:jisme|of|for|about|ke\s*liye|par)?\s*/i, '')
      .replace(/^(?:create|generate|draw|paint|make)\s*(?:me\s+)?(?:an?\s+)?(?:image|photo|picture|tasveer|illustration)?\s*(?:of|showing|with)?\s*/i, '')
      .replace(/\s*(?:ki\s*photo|ki\s*image|ki\s*tasveer|banao|bana\s*do|generate\s*karo|create\s*karo|draw\s*karo)\s*$/i, '')
      .trim();

    if (!cleanPrompt || cleanPrompt.length < 3) {
      cleanPrompt = trimmed;
    }

    return {
      type: 'image',
      prompt: cleanPrompt,
      originalQuery: trimmed,
      aspectRatio,
      style,
    };
  }

  return null;
}

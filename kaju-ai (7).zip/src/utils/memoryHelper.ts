import { UserMemory, MemoryOperation } from '../types';

export const MEMORIES_STORAGE_KEY = 'kaju_ai_user_memories_v1';
export const MEMORY_ENABLED_STORAGE_KEY = 'kaju_ai_memory_enabled_v1';

// In-memory fallback cache for Node test environments or private browsing
let memoryStorageCache: Record<string, string> = {};

function safeGetItem(key: string): string | null {
  try {
    if (typeof localStorage !== 'undefined') {
      return localStorage.getItem(key);
    }
    return memoryStorageCache[key] ?? null;
  } catch {
    return memoryStorageCache[key] ?? null;
  }
}

function safeSetItem(key: string, value: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem(key, value);
    }
    memoryStorageCache[key] = value;
  } catch {
    memoryStorageCache[key] = value;
  }
}

function safeRemoveItem(key: string): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem(key);
    }
    delete memoryStorageCache[key];
  } catch {
    delete memoryStorageCache[key];
  }
}

export const DEFAULT_MEMORIES: UserMemory[] = [
  {
    id: 'mem_1',
    content: 'User communicates comfortably in Hindi, English, and Hinglish.',
    category: 'preference',
    createdAt: 1760000000000,
    updatedAt: 1760000000000,
    source: 'system_default',
    isVerified: true,
  },
  {
    id: 'mem_2',
    content: 'Prefers clear, intuitive real-world analogies when complex concepts are introduced.',
    category: 'instruction',
    createdAt: 1760100000000,
    updatedAt: 1760100000000,
    source: 'system_default',
    isVerified: true,
  },
];

export function loadMemories(): UserMemory[] {
  try {
    const raw = safeGetItem(MEMORIES_STORAGE_KEY);
    if (!raw) {
      saveMemories(DEFAULT_MEMORIES);
      return DEFAULT_MEMORIES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_MEMORIES;
  } catch (e) {
    console.error('Failed to load memories:', e);
    return DEFAULT_MEMORIES;
  }
}

export function saveMemories(memories: UserMemory[]): void {
  try {
    safeSetItem(MEMORIES_STORAGE_KEY, JSON.stringify(memories));
  } catch (e) {
    console.error('Failed to save memories:', e);
  }
}

export function isMemoryEnabled(): boolean {
  try {
    const raw = safeGetItem(MEMORY_ENABLED_STORAGE_KEY);
    return raw === null ? true : raw === 'true';
  } catch {
    return true;
  }
}

export function setMemoryEnabled(enabled: boolean): void {
  try {
    safeSetItem(MEMORY_ENABLED_STORAGE_KEY, String(enabled));
  } catch {}
}

export function addMemory(
  content: string,
  category: UserMemory['category'] = 'preference',
  source: UserMemory['source'] = 'user_stated'
): UserMemory | null {
  const trimmed = content.trim();
  if (!trimmed) return null;

  const current = loadMemories();

  // If a similar or conflicting fact exists (e.g. updating name or favorite subject), update it instead of duplicating
  const existing = findSimilarMemory(trimmed, current);
  if (existing) {
    return updateMemory(existing.id, trimmed, category);
  }

  const newMemory: UserMemory = {
    id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    content: trimmed,
    category,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    source,
    isVerified: true,
  };

  const updated = [newMemory, ...current];
  saveMemories(updated);
  return newMemory;
}

export function updateMemory(
  id: string,
  newContent: string,
  newCategory?: UserMemory['category']
): UserMemory | null {
  const trimmed = newContent.trim();
  if (!trimmed) return null;

  const current = loadMemories();
  const index = current.findIndex((m) => m.id === id);
  if (index === -1) return null;

  const updatedItem: UserMemory = {
    ...current[index],
    content: trimmed,
    category: newCategory || current[index].category,
    updatedAt: Date.now(),
    isVerified: true,
  };

  const next = [...current];
  next[index] = updatedItem;
  saveMemories(next);
  return updatedItem;
}

export function deleteMemory(id: string): UserMemory[] {
  const current = loadMemories();
  const filtered = current.filter((m) => m.id !== id);
  saveMemories(filtered);
  return filtered;
}

export function clearMemories(): void {
  try {
    safeRemoveItem(MEMORIES_STORAGE_KEY);
  } catch {}
}

/**
 * Extract topic keywords to detect same-subject memories (e.g. name, subject, language, city)
 */
function extractKeyTopic(text: string): string {
  const lower = text.toLowerCase();
  if (lower.includes('name is') || lower.includes('naam hai') || lower.includes('called ')) return 'user_name';
  if (lower.includes('subject') || lower.includes('padhta hoon') || lower.includes('studying')) return 'study_topic';
  if (lower.includes('language') || lower.includes('bhasha') || lower.includes('hinglish') || lower.includes('hindi')) return 'language_pref';
  if (lower.includes('city') || lower.includes('location') || lower.includes('rehta hoon') || lower.includes('lives in')) return 'location';
  if (lower.includes('creator') || lower.includes('banaya') || lower.includes('builder')) return 'creator_info';
  return '';
}

/**
 * Find similar memory by key topic or content match
 */
export function findSimilarMemory(query: string, list?: UserMemory[]): UserMemory | null {
  const memories = list || loadMemories();
  const queryTopic = extractKeyTopic(query);
  const qLower = query.toLowerCase();

  for (const m of memories) {
    if (m.content.toLowerCase() === qLower) return m;

    if (queryTopic) {
      const mTopic = extractKeyTopic(m.content);
      if (mTopic && mTopic === queryTopic) {
        return m;
      }
    }
  }

  return null;
}

/**
 * Apply memory operation from conversation or AI extraction
 * Handles add, update, delete with explicit fact replacement to prevent repeating incorrect facts
 */
export function applyMemoryOperation(op: MemoryOperation): {
  success: boolean;
  memory?: UserMemory;
  actionTaken: 'added' | 'updated' | 'deleted' | 'ignored';
} {
  if (!op || !op.action || !op.content) {
    return { success: false, actionTaken: 'ignored' };
  }

  const current = loadMemories();
  const content = op.content.trim();
  const oldContent = (op.oldContent || '').trim().toLowerCase();

  if (op.action === 'delete') {
    const toDelete = current.find(
      (m) =>
        m.content.toLowerCase().includes(content.toLowerCase()) ||
        (oldContent && m.content.toLowerCase().includes(oldContent))
    );
    if (toDelete) {
      deleteMemory(toDelete.id);
      return { success: true, memory: toDelete, actionTaken: 'deleted' };
    }
    return { success: false, actionTaken: 'ignored' };
  }

  if (op.action === 'update' || oldContent) {
    // Locate the old memory to replace
    let target = current.find(
      (m) =>
        (oldContent && m.content.toLowerCase().includes(oldContent)) ||
        (oldContent && oldContent.includes(m.content.toLowerCase()))
    );

    if (!target) {
      target = findSimilarMemory(content, current) || undefined;
    }

    if (target) {
      const updated = updateMemory(target.id, content, op.category);
      if (updated) {
        return { success: true, memory: updated, actionTaken: 'updated' };
      }
    }
  }

  // Action is 'add' or update target wasn't found - check if topic already exists to prevent contradictions
  const existing = findSimilarMemory(content, current);
  if (existing) {
    const updated = updateMemory(existing.id, content, op.category);
    return { success: true, memory: updated || undefined, actionTaken: 'updated' };
  }

  const added = addMemory(content, op.category || 'fact', 'user_stated');
  return { success: Boolean(added), memory: added || undefined, actionTaken: 'added' };
}

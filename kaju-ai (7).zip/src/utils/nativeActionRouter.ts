/**
 * NativeActionRouter - Platform Abstraction Layer for Kaju AI.
 * 
 * Routes device and application actions according to the runtime platform:
 * 1. Android Native Environment (APK / WebView with KajuNativeBridge):
 *    - Queries Android PackageManager for installed apps
 *    - Dispatches explicit Android Intents for YouTube, WhatsApp, Calculator, Camera, Gallery, Settings
 *    - Clearly informs the user if an app is NOT installed (never pretends it opened)
 * 
 * 2. Web Browser / AI Studio Preview Environment:
 *    - Executes safe web fallbacks (wa.me, youtube.com, online calculator, in-app camera)
 *    - Never claims a native Android app was opened when running in browser
 * 
 * 3. Zero-Click Safety Standard:
 *    - Direct app opening from explicit user commands is permitted directly
 *    - Actions with side-effects (WhatsApp message sending, phone calls, delete, purchase) MUST require confirmation
 */

import { SupportedAppId, LaunchAppPayload, DeviceAction } from '../types';
import { ANDROID_INTENT_CONSTANTS, NativeIntentParams, NativeLaunchResponse } from '../native/androidBridgeContract';

export interface LaunchResult {
  success: boolean;
  status: 'native_launched' | 'not_installed' | 'web_fallback' | 'in_app_handled' | 'failed';
  environment: 'android_native' | 'web_browser';
  message: string;
  hindiMessage: string;
  appId: SupportedAppId;
  appName: string;
}

export interface AppDefinition {
  id: SupportedAppId;
  name: string;
  hindiName: string;
  category: 'media' | 'communication' | 'tools' | 'system';
  iconName: string;
  description: string;
  packageName: string;
  fallbackPackageNames?: string[];
  intentParams: NativeIntentParams;
  fallbackWebUrl?: string;
}

export interface WebActionHandlers {
  triggerCamera?: () => void;
  triggerGallery?: () => void;
  openSettingsModal?: () => void;
}

export const SUPPORTED_APP_REGISTRY: Record<SupportedAppId, AppDefinition> = {
  youtube: {
    id: 'youtube',
    name: 'YouTube',
    hindiName: 'यूट्यूब',
    category: 'media',
    iconName: 'Youtube',
    description: 'Educational videos, lectures, and music',
    packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.YOUTUBE,
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_VIEW,
      packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.YOUTUBE,
      dataUri: 'https://www.youtube.com',
    },
    fallbackWebUrl: 'https://www.youtube.com',
  },
  whatsapp: {
    id: 'whatsapp',
    name: 'WhatsApp',
    hindiName: 'व्हाट्सएप',
    category: 'communication',
    iconName: 'MessageCircle',
    description: 'Bilingual messaging & chat',
    packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.WHATSAPP,
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_MAIN,
      packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.WHATSAPP,
    },
    fallbackWebUrl: 'https://web.whatsapp.com',
  },
  calculator: {
    id: 'calculator',
    name: 'Calculator',
    hindiName: 'कैलकुलेटर',
    category: 'tools',
    iconName: 'Calculator',
    description: 'Standard & scientific calculator',
    packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.CALCULATOR_GOOGLE,
    fallbackPackageNames: [
      ANDROID_INTENT_CONSTANTS.PACKAGES.CALCULATOR_AOSP,
      ANDROID_INTENT_CONSTANTS.PACKAGES.CALCULATOR_SAMSUNG,
      ANDROID_INTENT_CONSTANTS.PACKAGES.CALCULATOR_MIUI,
    ],
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_MAIN,
      category: ANDROID_INTENT_CONSTANTS.CATEGORY_APP_CALCULATOR,
    },
    fallbackWebUrl: 'https://www.google.com/search?q=calculator',
  },
  camera: {
    id: 'camera',
    name: 'Camera',
    hindiName: 'कैमरा',
    category: 'tools',
    iconName: 'Camera',
    description: 'Device camera for photo capture and study questions',
    packageName: 'android.hardware.camera',
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_IMAGE_CAPTURE,
    },
  },
  gallery: {
    id: 'gallery',
    name: 'Gallery / Photos',
    hindiName: 'फ़ोटो गैलरी',
    category: 'tools',
    iconName: 'Image',
    description: 'Photo gallery and image picker',
    packageName: 'com.google.android.apps.photos',
    fallbackPackageNames: ['com.android.gallery3d', 'com.sec.android.gallery3d'],
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_VIEW,
      type: 'image/*',
      category: ANDROID_INTENT_CONSTANTS.CATEGORY_APP_GALLERY,
    },
  },
  settings: {
    id: 'settings',
    name: 'Settings',
    hindiName: 'सेटिंग्स',
    category: 'system',
    iconName: 'Settings',
    description: 'Device & application settings',
    packageName: 'com.android.settings',
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_SETTINGS,
    },
  },
  maps: {
    id: 'maps',
    name: 'Google Maps',
    hindiName: 'गूगल मैप्स',
    category: 'tools',
    iconName: 'MapPin',
    description: 'Navigation, directions & nearby places',
    packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.MAPS,
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_VIEW,
      packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.MAPS,
      dataUri: 'geo:0,0?q=',
    },
    fallbackWebUrl: 'https://maps.google.com',
  },
  gmail: {
    id: 'gmail',
    name: 'Gmail',
    hindiName: 'जीमेल',
    category: 'communication',
    iconName: 'Mail',
    description: 'Email messaging & drafts',
    packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.GMAIL,
    intentParams: {
      action: ANDROID_INTENT_CONSTANTS.ACTION_MAIN,
      packageName: ANDROID_INTENT_CONSTANTS.PACKAGES.GMAIL,
    },
    fallbackWebUrl: 'https://mail.google.com',
  },
};

class NativeActionRouterService {
  private webHandlers: WebActionHandlers = {};

  /**
   * Register in-app callbacks for browser / web fallback mode
   */
  public registerWebHandlers(handlers: WebActionHandlers): void {
    this.webHandlers = { ...this.webHandlers, ...handlers };
  }

  /**
   * Determines whether Kaju is executing inside a real Android native wrapper / WebView.
   */
  public isNativeAndroid(): boolean {
    if (typeof window === 'undefined') return false;

    // Check custom Kaju Android Native Bridge
    if (window.KajuNative && typeof window.KajuNative.isAndroidNative === 'function') {
      try {
        return window.KajuNative.isAndroidNative() === true;
      } catch {
        return false;
      }
    }

    // Check generic AndroidBridge JavascriptInterface
    if (window.AndroidBridge && typeof window.AndroidBridge.isAndroidNative === 'function') {
      try {
        return window.AndroidBridge.isAndroidNative() === true;
      } catch {
        return false;
      }
    }

    return false;
  }

  /**
   * Diagnostic runtime environment info
   */
  public getRuntimeInfo(): {
    isAndroidNative: boolean;
    runtimeName: string;
    hasBridge: boolean;
    description: string;
  } {
    const isNative = this.isNativeAndroid();
    if (isNative) {
      return {
        isAndroidNative: true,
        runtimeName: 'Android Native Host (APK / WebView)',
        hasBridge: true,
        description: 'Running with real Android Intent & PackageManager bridge.',
      };
    }
    return {
      isAndroidNative: false,
      runtimeName: 'Web Browser / AI Studio Preview',
      hasBridge: false,
      description: 'Running in browser sandbox. Safe web fallbacks active; Android Intent bridge ready.',
    };
  }

  /**
   * Checks whether the target app is installed.
   * - In Android Native: checks via PackageManager bridge
   * - In Browser: returns true if web fallback is available
   */
  public async isAppInstalled(appId: SupportedAppId): Promise<boolean> {
    const appDef = SUPPORTED_APP_REGISTRY[appId];
    if (!appDef) return false;

    if (this.isNativeAndroid() && window.KajuNative?.isAppInstalled) {
      try {
        // Check primary package
        const primaryCheck = await Promise.resolve(window.KajuNative.isAppInstalled(appDef.packageName));
        if (primaryCheck) return true;

        // Check fallback packages (e.g. OEM calculators)
        if (appDef.fallbackPackageNames && appDef.fallbackPackageNames.length > 0) {
          for (const pkg of appDef.fallbackPackageNames) {
            const fbCheck = await Promise.resolve(window.KajuNative.isAppInstalled(pkg));
            if (fbCheck) return true;
          }
        }
        return false;
      } catch (err) {
        console.warn(`Bridge error checking isAppInstalled for ${appId}:`, err);
        return false;
      }
    }

    // In web browser: app is available via web fallback or in-app handler
    return Boolean(appDef.fallbackWebUrl || appId === 'camera' || appId === 'gallery' || appId === 'settings');
  }

  /**
   * Launch target app with appropriate platform routing
   */
  public async launchApp(appId: SupportedAppId, options?: { query?: string; phone?: string }): Promise<LaunchResult> {
    const appDef = SUPPORTED_APP_REGISTRY[appId];
    if (!appDef) {
      return {
        success: false,
        status: 'failed',
        environment: this.isNativeAndroid() ? 'android_native' : 'web_browser',
        message: `Unknown application: ${appId}`,
        hindiMessage: `अज्ञात एप्लिकेशन: ${appId}`,
        appId,
        appName: appId,
      };
    }

    // ==========================================
    // 1. ANDROID NATIVE EXECUTION PATH
    // ==========================================
    if (this.isNativeAndroid() && window.KajuNative) {
      try {
        // Step 1: Verify installed status
        const installed = await this.isAppInstalled(appId);
        if (!installed) {
          return {
            success: false,
            status: 'not_installed',
            environment: 'android_native',
            message: `${appDef.name} is not installed on this Android device.`,
            hindiMessage: `${appDef.hindiName} आपके इस एंड्रॉइड फोन में इंस्टॉल नहीं है।`,
            appId,
            appName: appDef.name,
          };
        }

        // Step 2: Handle special native activities if dedicated methods exist
        if (appId === 'camera' && typeof window.KajuNative.openCamera === 'function') {
          const raw = await window.KajuNative.openCamera();
          const resp = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
          return {
            success: Boolean(resp.success),
            status: resp.success ? 'native_launched' : 'failed',
            environment: 'android_native',
            message: resp.message || `Opened Camera on Android.`,
            hindiMessage: resp.success ? `कैमरा खोल दिया गया है।` : `कैमरा नहीं खुल सका: ${resp.message || 'त्रुटि'}`,
            appId,
            appName: appDef.name,
          };
        }

        if (appId === 'gallery' && typeof window.KajuNative.openGallery === 'function') {
          const raw = await window.KajuNative.openGallery();
          const resp = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
          return {
            success: Boolean(resp.success),
            status: resp.success ? 'native_launched' : 'failed',
            environment: 'android_native',
            message: resp.message || `Opened Photo Gallery on Android.`,
            hindiMessage: resp.success ? `फ़ोटो गैलरी खोल दी गई है।` : `गैलरी नहीं खुल सकी: ${resp.message || 'त्रुटि'}`,
            appId,
            appName: appDef.name,
          };
        }

        if (appId === 'settings' && typeof window.KajuNative.openSettings === 'function') {
          const raw = await window.KajuNative.openSettings();
          const resp = typeof raw === 'string' ? JSON.parse(raw) : (raw || {});
          return {
            success: Boolean(resp.success),
            status: resp.success ? 'native_launched' : 'failed',
            environment: 'android_native',
            message: resp.message || `Opened Android Settings.`,
            hindiMessage: resp.success ? `एंड्रॉइड सेटिंग्स खोल दी गई है।` : `सेटिंग्स नहीं खुल सकी: ${resp.message || 'त्रुटि'}`,
            appId,
            appName: appDef.name,
          };
        }

        // Step 3: Generic Native Intent Launch
        const intentParams: NativeIntentParams = { ...appDef.intentParams };
        if (options?.query && appId === 'youtube') {
          intentParams.dataUri = `https://www.youtube.com/results?search_query=${encodeURIComponent(options.query)}`;
        } else if (options?.query && appId === 'maps') {
          intentParams.dataUri = `geo:0,0?q=${encodeURIComponent(options.query)}`;
        }

        const rawParams = typeof intentParams === 'string' ? intentParams : JSON.stringify(intentParams);
        const rawResp = await Promise.resolve(window.KajuNative.launchApp(appId, rawParams as any));
        const launchResp: NativeLaunchResponse =
          typeof rawResp === 'string'
            ? JSON.parse(rawResp)
            : (rawResp || { success: false, code: 'BRIDGE_ERROR', message: 'No response from bridge' });

        if (launchResp.code === 'APP_NOT_INSTALLED') {
          return {
            success: false,
            status: 'not_installed',
            environment: 'android_native',
            message: `${appDef.name} is not installed on this Android device.`,
            hindiMessage: `${appDef.hindiName} आपके इस एंड्रॉइड फोन में इंस्टॉल नहीं है।`,
            appId,
            appName: appDef.name,
          };
        }

        return {
          success: Boolean(launchResp.success),
          status: launchResp.success ? 'native_launched' : 'failed',
          environment: 'android_native',
          message: launchResp.message || `Launched ${appDef.name} on Android.`,
          hindiMessage: `${appDef.hindiName} खोल दिया गया है।`,
          appId,
          appName: appDef.name,
        };
      } catch (err: any) {
        console.error(`Native Intent dispatch error for ${appId}:`, err);
        return {
          success: false,
          status: 'failed',
          environment: 'android_native',
          message: `Could not launch ${appDef.name}: ${err?.message || 'Native error'}`,
          hindiMessage: `${appDef.hindiName} नहीं खुल सका: ${err?.message || 'सिस्टम त्रुटि'}`,
          appId,
          appName: appDef.name,
        };
      }
    }

    // ==========================================
    // 2. BROWSER / AI STUDIO PREVIEW FALLBACK
    // ==========================================

    // Handle Camera in Web: trigger in-app camera capture
    if (appId === 'camera') {
      if (this.webHandlers.triggerCamera) {
        this.webHandlers.triggerCamera();
        return {
          success: true,
          status: 'in_app_handled',
          environment: 'web_browser',
          message: 'Opened camera in web browser. (Android Camera Activity will launch in native Android app).',
          hindiMessage: 'वेब ब्राउज़र में कैमरा चालू किया गया (एंड्रॉइड ऐप में यह सीधे कैमरा ऐप खोलेगा)।',
          appId,
          appName: appDef.name,
        };
      }

      // Safe fallback if composer handler is not yet registered
      try {
        const tmpInput = document.createElement('input');
        tmpInput.type = 'file';
        tmpInput.accept = 'image/*';
        tmpInput.capture = 'environment';
        tmpInput.style.display = 'none';
        document.body.appendChild(tmpInput);
        tmpInput.click();
        setTimeout(() => document.body.removeChild(tmpInput), 1000);
        return {
          success: true,
          status: 'in_app_handled',
          environment: 'web_browser',
          message: 'Opened camera capture in web browser. (Android Camera Activity will launch in native Android app).',
          hindiMessage: 'वेब ब्राउज़र में कैमरा चालू किया गया (एंड्रॉइड ऐप में यह सीधे कैमरा ऐप खोलेगा)।',
          appId,
          appName: appDef.name,
        };
      } catch (err: any) {
        return {
          success: false,
          status: 'failed',
          environment: 'web_browser',
          message: `Camera unavailable: ${err?.message || 'Access error'}`,
          hindiMessage: `कैमरा चालू नहीं हो सका: ${err?.message || 'त्रुटि'}`,
          appId,
          appName: appDef.name,
        };
      }
    }

    // Handle Gallery in Web: trigger in-app gallery picker
    if (appId === 'gallery') {
      if (this.webHandlers.triggerGallery) {
        this.webHandlers.triggerGallery();
        return {
          success: true,
          status: 'in_app_handled',
          environment: 'web_browser',
          message: 'Opened photo picker in web browser. (Android Gallery will launch in native Android app).',
          hindiMessage: 'वेब ब्राउज़र में फ़ोटो चयन खोला गया (एंड्रॉइड ऐप में यह सीधे गैलरी ऐप खोलेगा)।',
          appId,
          appName: appDef.name,
        };
      }

      try {
        const tmpInput = document.createElement('input');
        tmpInput.type = 'file';
        tmpInput.accept = 'image/*';
        tmpInput.style.display = 'none';
        document.body.appendChild(tmpInput);
        tmpInput.click();
        setTimeout(() => document.body.removeChild(tmpInput), 1000);
        return {
          success: true,
          status: 'in_app_handled',
          environment: 'web_browser',
          message: 'Opened photo picker in web browser. (Android Gallery will launch in native Android app).',
          hindiMessage: 'वेब ब्राउज़र में फ़ोटो चयन खोला गया (एंड्रॉइड ऐप में यह सीधे गैलरी ऐप खोलेगा)।',
          appId,
          appName: appDef.name,
        };
      } catch (err: any) {
        return {
          success: false,
          status: 'failed',
          environment: 'web_browser',
          message: `Photo picker unavailable: ${err?.message || 'Access error'}`,
          hindiMessage: `फ़ोटो गैलरी नहीं खुल सकी: ${err?.message || 'त्रुटि'}`,
          appId,
          appName: appDef.name,
        };
      }
    }

    // Handle Settings in Web: open Kaju Action Center Settings
    if (appId === 'settings') {
      if (this.webHandlers.openSettingsModal) {
        this.webHandlers.openSettingsModal();
        return {
          success: true,
          status: 'in_app_handled',
          environment: 'web_browser',
          message: 'Opened Kaju Settings. (Android OS Settings will open via Intent in native Android app).',
          hindiMessage: 'काजू सेटिंग्स खोल दी गई है (एंड्रॉइड ऐप में यह सिस्टम सेटिंग्स खोलेगा)।',
          appId,
          appName: appDef.name,
        };
      }
    }

    // Standard web URL fallback
    if (appDef.fallbackWebUrl) {
      let targetUrl = appDef.fallbackWebUrl;
      if (options?.query && appId === 'youtube') {
        targetUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(options.query)}`;
      } else if (options?.query && appId === 'maps') {
        targetUrl = `https://www.google.com/maps/search/${encodeURIComponent(options.query)}`;
      }

      let wasBlocked = false;
      if (typeof window !== 'undefined' && typeof window.open === 'function') {
        try {
          const popup = window.open(targetUrl, '_blank', 'noopener,noreferrer');
          if (popup === null && typeof document !== 'undefined') {
            try {
              const link = document.createElement('a');
              link.href = targetUrl;
              link.target = '_blank';
              link.rel = 'noopener noreferrer';
              document.body.appendChild(link);
              link.click();
              document.body.removeChild(link);
            } catch {
              wasBlocked = true;
            }
          }
        } catch {
          wasBlocked = true;
        }
      }

      if (wasBlocked) {
        return {
          success: false,
          status: 'failed',
          environment: 'web_browser',
          message: `Could not open ${appDef.name} website: Browser popup was blocked. Please allow popups in your browser settings. (Note: In browser preview, web links are opened; launching the installed Android app directly requires running the Kaju Android APK with window.KajuNative bridge).`,
          hindiMessage: `${appDef.hindiName} वेबसाइट नहीं खुल सकी: ब्राउज़र पॉपअप ब्लॉकर ने विंडो रोक दी। कृपया ब्राउज़र में पॉपअप अनुमति दें। (सीधे इंस्टॉल किया हुआ एंड्रॉइड ऐप खोलने के लिए Kaju Android APK और वर्किंग KajuNative ब्रिज की आवश्यकता होती है)।`,
          appId,
          appName: appDef.name,
        };
      }

      return {
        success: true,
        status: 'web_fallback',
        environment: 'web_browser',
        message: `Opened ${appDef.name} website in browser preview. (Note: Running in web browser, so the website was opened; launching the installed Android app directly requires the Kaju Android APK with window.KajuNative bridge).`,
        hindiMessage: `ब्राउज़र प्रीव्यू में ${appDef.hindiName} वेबसाइट खोल दी गई है (ध्यान दें: यह वेब ब्राउज़र है, इसलिए वेबसाइट खुली है; सीधे इंस्टॉल किया हुआ एंड्रॉइड ऐप खोलने के लिए Kaju Android APK और KajuNative ब्रिज की आवश्यकता होती है)।`,
        appId,
        appName: appDef.name,
      };
    }

    return {
      success: false,
      status: 'failed',
      environment: 'web_browser',
      message: `Cannot launch ${appDef.name}: Web fallback unavailable and window.KajuNative bridge is unavailable in browser preview (requires Kaju Android APK).`,
      hindiMessage: `${appDef.hindiName} नहीं खुल सका: वेब फ़ॉलबैक उपलब्ध नहीं है और ब्राउज़र में KajuNative ब्रिज अनुपलब्ध है (इसके लिए Kaju Android APK की आवश्यकता होती है)।`,
      appId,
      appName: appDef.name,
    };
  }

  /**
   * Helper to build a standard DeviceAction object for app launching
   */
  public createLaunchAppAction(appId: SupportedAppId, customTitle?: string): DeviceAction {
    const appDef = SUPPORTED_APP_REGISTRY[appId];
    const payload: LaunchAppPayload = {
      appId,
      appName: appDef?.name || appId,
      hindiName: appDef?.hindiName || appId,
      packageName: appDef?.packageName,
      intentAction: appDef?.intentParams.action,
      intentUri: appDef?.intentParams.dataUri,
      fallbackWebUrl: appDef?.fallbackWebUrl,
      requiresConfirmation: false, // Explicit app opening from user command can launch directly
    };

    return {
      id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type: 'launch_app',
      status: 'ready',
      title: customTitle || `Open ${appDef?.name || appId}`,
      payload: {
        launch_app: payload,
      },
      createdAt: Date.now(),
    };
  }
}

export const NativeActionRouter = new NativeActionRouterService();

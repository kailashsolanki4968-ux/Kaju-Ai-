import { ProjectWorkspace, DocumentAttachment, ProjectImageAttachment } from '../types';

export const PROJECTS_STORAGE_KEY = 'kaju_ai_projects_v1';
export const ACTIVE_PROJECT_STORAGE_KEY = 'kaju_ai_active_project_id_v1';

const DEFAULT_PROJECTS: ProjectWorkspace[] = [
  {
    id: 'proj_kaju_ai',
    name: 'Kaju AI',
    description: 'General-purpose AI assistant platform with multi-modal vision, action routing, and companion intelligence.',
    category: 'coding',
    createdAt: Date.now() - 86400000 * 6,
    updatedAt: Date.now() - 86400000 * 1,
    notes: [
      'Core pillars: Kaju Core, Skill Mode, Research Mode, and Universal Workspaces.',
      'Android Native Action Router ready with intent boundary.',
      'Cloud sync and multi-device persistence established.',
    ],
    tasks: [
      { id: 't_kaju_1', title: 'Implement Kaju Skill Mode with diagnostics and lesson flow', completed: true },
      { id: 't_kaju_2', title: 'Build verified multi-source Research Mode', completed: true },
      { id: 't_kaju_3', title: 'Enhance Universal Project Workspace with files and image attachments', completed: false },
      { id: 't_kaju_4', title: 'Test user-scoped sync across secondary devices', completed: false },
    ],
    associatedChatIds: [],
    files: [
      {
        id: 'doc_kaju_arch',
        name: 'architecture_blueprint.txt',
        type: 'text/plain',
        size: 2048,
        content: 'Kaju AI architecture: Central Orchestration Layer + Multi-Modal Vision + Native Action Router + Universal Projects.',
      },
    ],
  },
  {
    id: 'proj_default_general',
    name: 'General Assistant',
    description: 'Everyday conversations, quick questions, research, and general tasks.',
    category: 'general',
    createdAt: Date.now() - 86400000 * 5,
    updatedAt: Date.now() - 86400000 * 5,
    notes: [
      'Welcome to Kaju AI Projects!',
      'Each project retains its own distinct workspace, chats, notes, and task lists.',
    ],
    tasks: [
      { id: 't_gen_1', title: 'Explore Kaju multi-modal vision and camera', completed: true },
      { id: 't_gen_2', title: 'Try asking a coding or translation question', completed: false },
    ],
    associatedChatIds: [],
  },
  {
    id: 'proj_school_mgmt',
    name: 'School Management App',
    description: 'Full-stack application for student records, attendance, and exam marks.',
    category: 'coding',
    createdAt: Date.now() - 86400000 * 3,
    updatedAt: Date.now() - 86400000 * 3,
    notes: [
      'Tech stack: React, TypeScript, Tailwind CSS, Express backend.',
      'Core modules: Student Directory, Gradebook, Attendance Tracker.',
    ],
    tasks: [
      { id: 't_app_1', title: 'Define TypeScript schema for Student and Grade records', completed: true },
      { id: 't_app_2', title: 'Build interactive student dashboard view', completed: false },
      { id: 't_app_3', title: 'Add export to CSV / PDF report feature', completed: false },
    ],
    associatedChatIds: [],
  },
  {
    id: 'proj_japan_trip',
    name: 'Japan Trip 2026',
    description: '7-day itinerary covering Tokyo, Kyoto, Mount Fuji, and Osaka.',
    category: 'trip',
    createdAt: Date.now() - 86400000 * 2,
    updatedAt: Date.now() - 86400000 * 2,
    notes: [
      'Travel dates: Spring cherry blossom season (April).',
      'Target budget: Mid-range with JR Rail Pass and local ryokan stay.',
    ],
    tasks: [
      { id: 't_trip_1', title: 'Check passport validity and e-Visa requirements', completed: true },
      { id: 't_trip_2', title: 'Finalize Tokyo 3-day neighborhood itinerary', completed: false },
      { id: 't_trip_3', title: 'Compare Shinkansen bullet train vs domestic flight options', completed: false },
    ],
    associatedChatIds: [],
  },
];

export function loadProjects(): ProjectWorkspace[] {
  try {
    const raw = localStorage.getItem(PROJECTS_STORAGE_KEY);
    if (!raw) {
      saveProjects(DEFAULT_PROJECTS);
      return DEFAULT_PROJECTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_PROJECTS;
  } catch (e) {
    console.error('Failed to load projects:', e);
    return DEFAULT_PROJECTS;
  }
}

export function saveProjects(projects: ProjectWorkspace[]): void {
  try {
    localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(projects));
  } catch (e) {
    console.error('Failed to save projects:', e);
  }
}

export function loadActiveProjectId(): string {
  try {
    const saved = localStorage.getItem(ACTIVE_PROJECT_STORAGE_KEY);
    if (saved) return saved;
  } catch {}
  return DEFAULT_PROJECTS[0].id;
}

export function saveActiveProjectId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_PROJECT_STORAGE_KEY, id);
  } catch {}
}

export function createProject(
  name: string,
  description: string,
  category: ProjectWorkspace['category'] = 'general'
): ProjectWorkspace {
  const newProj: ProjectWorkspace = {
    id: `proj_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    name: name.trim() || 'New Project',
    description: description.trim() || 'Custom project workspace',
    category,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    notes: [],
    tasks: [],
    associatedChatIds: [],
  };

  const current = loadProjects();
  const updated = [newProj, ...current];
  saveProjects(updated);
  saveActiveProjectId(newProj.id);
  return newProj;
}

export function addProjectNote(projectId: string, noteText: string): ProjectWorkspace | null {
  const trimmed = noteText.trim();
  if (!trimmed) return null;

  const projects = loadProjects();
  let updatedProject: ProjectWorkspace | null = null;

  const updatedList = projects.map((p) => {
    if (p.id === projectId) {
      updatedProject = {
        ...p,
        notes: [trimmed, ...p.notes],
        updatedAt: Date.now(),
      };
      return updatedProject;
    }
    return p;
  });

  if (updatedProject) {
    saveProjects(updatedList);
  }
  return updatedProject;
}

export function addProjectTask(projectId: string, taskTitle: string): ProjectWorkspace | null {
  const trimmed = taskTitle.trim();
  if (!trimmed) return null;

  const projects = loadProjects();
  let updatedProject: ProjectWorkspace | null = null;

  const updatedList = projects.map((p) => {
    if (p.id === projectId) {
      const newTask = {
        id: `t_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
        title: trimmed,
        completed: false,
      };
      updatedProject = {
        ...p,
        tasks: [...p.tasks, newTask],
        updatedAt: Date.now(),
      };
      return updatedProject;
    }
    return p;
  });

  if (updatedProject) {
    saveProjects(updatedList);
  }
  return updatedProject;
}

export function toggleProjectTask(projectId: string, taskId: string): ProjectWorkspace | null {
  const projects = loadProjects();
  let updatedProject: ProjectWorkspace | null = null;

  const updatedList = projects.map((p) => {
    if (p.id === projectId) {
      updatedProject = {
        ...p,
        tasks: p.tasks.map((t) => (t.id === taskId ? { ...t, completed: !t.completed } : t)),
        updatedAt: Date.now(),
      };
      return updatedProject;
    }
    return p;
  });

  if (updatedProject) {
    saveProjects(updatedList);
  }
  return updatedProject;
}

export function deleteProject(projectId: string): ProjectWorkspace[] {
  const current = loadProjects();
  const filtered = current.filter((p) => p.id !== projectId);
  const remaining = filtered.length > 0 ? filtered : DEFAULT_PROJECTS;
  saveProjects(remaining);

  const activeId = loadActiveProjectId();
  if (activeId === projectId) {
    saveActiveProjectId(remaining[0].id);
  }
  return remaining;
}

export function addProjectFile(projectId: string, file: DocumentAttachment): ProjectWorkspace | null {
  const projects = loadProjects();
  let updatedProject: ProjectWorkspace | null = null;

  const updatedList = projects.map((p) => {
    if (p.id === projectId) {
      const existingFiles = p.files || p.documents || [];
      const updatedFiles = [file, ...existingFiles.filter((f) => f.id !== file.id)];
      updatedProject = {
        ...p,
        files: updatedFiles,
        documents: updatedFiles,
        updatedAt: Date.now(),
      };
      return updatedProject;
    }
    return p;
  });

  if (updatedProject) {
    saveProjects(updatedList);
  }
  return updatedProject;
}

export function addProjectImage(projectId: string, image: ProjectImageAttachment): ProjectWorkspace | null {
  const projects = loadProjects();
  let updatedProject: ProjectWorkspace | null = null;

  const updatedList = projects.map((p) => {
    if (p.id === projectId) {
      const existingImages = p.images || [];
      updatedProject = {
        ...p,
        images: [image, ...existingImages],
        updatedAt: Date.now(),
      };
      return updatedProject;
    }
    return p;
  });

  if (updatedProject) {
    saveProjects(updatedList);
  }
  return updatedProject;
}

/**
 * Find project if user explicitly asks about one (e.g. "Kaju AI project ka next step", "Japan trip project")
 */
export function findProjectByNameOrKeyword(text: string): ProjectWorkspace | null {
  const lower = text.toLowerCase();
  const projects = loadProjects();

  for (const p of projects) {
    const nameLower = p.name.toLowerCase();
    if (lower.includes(nameLower) || (nameLower.includes('kaju') && lower.includes('kaju ai project')) || (nameLower.includes('japan') && lower.includes('japan'))) {
      return p;
    }
  }

  // Return currently active project if user says "mera project", "is project", "project ka next step"
  if (lower.includes('project ka next step') || lower.includes('project status') || lower.includes('project me kya')) {
    const activeId = loadActiveProjectId();
    return projects.find((p) => p.id === activeId) || projects[0] || null;
  }

  return null;
}

/**
 * Builds rich, structured context of a project to inject into AI prompt
 */
export function buildProjectFullContext(project: ProjectWorkspace): string {
  const pendingTasks = (project.tasks || []).filter((t) => !t.completed);
  const doneTasks = (project.tasks || []).filter((t) => t.completed);
  const files = project.files || project.documents || [];
  const images = project.images || [];

  return `📁 ACTIVE PROJECT WORKSPACE CONTEXT:
- Project Name: "${project.name}" (Category: ${project.category})
- Description: ${project.description}

📝 PROJECT NOTES:
${project.notes && project.notes.length > 0 ? project.notes.map((n, i) => `  ${i + 1}. ${n}`).join('\n') : '  (No notes added yet)'}

✅ TASKS STATUS:
- Pending Tasks (${pendingTasks.length}):
${pendingTasks.length > 0 ? pendingTasks.map((t) => `  [ ] ${t.title}`).join('\n') : '  (None)'}
- Completed Tasks (${doneTasks.length}):
${doneTasks.length > 0 ? doneTasks.map((t) => `  [x] ${t.title}`).join('\n') : '  (None)'}

📄 PROJECT FILES (${files.length}):
${files.length > 0 ? files.map((f) => `  - ${f.name} (${f.type}): ${f.content.slice(0, 150)}...`).join('\n') : '  (None)'}

📷 PROJECT ATTACHED IMAGES (${images.length}):
${images.length > 0 ? images.map((img) => `  - ${img.name}`).join('\n') : '  (None)'}

CRITICAL DIRECTIVE: When answering the user, directly refer to the above Project Context, tasks, and notes without asking the user to re-explain their project!`;
}


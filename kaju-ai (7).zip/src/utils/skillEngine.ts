import { SkillJourney, SkillLevel, SkillStage, SkillLesson, SkillPracticeQuestion, SkillMistakeRecord } from '../types';

export const SKILL_JOURNEYS_STORAGE_KEY = 'kaju_skill_journeys_v1';
export const ACTIVE_SKILL_STORAGE_KEY = 'kaju_active_skill_id_v1';

export function loadSkillJourneys(): SkillJourney[] {
  try {
    const raw = localStorage.getItem(SKILL_JOURNEYS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {
    console.error('Failed to load skill journeys:', e);
  }
  return [];
}

export function saveSkillJourneys(journeys: SkillJourney[]): void {
  try {
    localStorage.setItem(SKILL_JOURNEYS_STORAGE_KEY, JSON.stringify(journeys));
  } catch (e) {
    console.error('Failed to save skill journeys:', e);
  }
}

export function loadActiveSkillId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_SKILL_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function saveActiveSkillId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_SKILL_STORAGE_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_SKILL_STORAGE_KEY);
    }
  } catch {}
}

/**
 * Curated syllabus blueprints for top skills
 */
function generateLessonsForSkill(skillName: string, level: SkillLevel): SkillLesson[] {
  const norm = skillName.toLowerCase();

  // 1. Japanese from Zero
  if (norm.includes('japan') || norm.includes('nihongo')) {
    return [
      {
        id: 'les_jp_1',
        order: 1,
        title: 'Lesson 1: Greetings & The Magic Sound of Hiragana',
        objective: 'Master daily Japanese greetings and the first 5 Hiragana vowels (A, I, U, E, O).',
        content: `### 🇯🇵 Welcome to Japanese (日本語)!
Japanese has 3 writing systems: **Hiragana** (phonetic Japanese words), **Katakana** (foreign loan words), and **Kanji** (pictographic characters). Today we start with core greetings and the 5 vowel pillars:

1. **Konnichiwa (こんにちは)** = Hello / Good Afternoon
2. **Arigatou Gozaimasu (ありがとうございます)** = Thank you very much (Polite)
3. **Sayounara (さようなら)** = Goodbye
4. **Hajimemashite (はじめまして)** = Nice to meet you!

Vowel sounds:
- **あ (a)** like "car"
- **い (i)** like "feet"
- **う (u)** like "moon"
- **え (e)** like "pet"
- **お (o)** like "boat"`,
        keyVocabularyOrFormulas: [
          { term: 'Konnichiwa (こんにちは)', meaning: 'Hello / Good Afternoon', example: 'Konnichiwa, Tanaka-san!' },
          { term: 'Arigatou (ありがとう)', meaning: 'Thank you', example: 'Doumo arigatou gozaimasu' },
          { term: 'Watashi (私 / わたし)', meaning: 'I / Me', example: 'Watashi wa Kaju desu (I am Kaju)' },
        ],
        practicePrompt: 'Introduce yourself in Japanese: Say "Nice to meet you, I am [Your Name]. Thank you!"',
        practiceQuestions: [
          {
            id: 'q_jp_1',
            question: 'How do you say "Thank you very much" politely in Japanese?',
            type: 'choice',
            options: ['Sayounara', 'Arigatou Gozaimasu', 'Konnichiwa', 'Oyasumi'],
            sampleAnswer: 'Arigatou Gozaimasu',
          },
          {
            id: 'q_jp_2',
            question: 'How would you say "I am Tanaka" in Japanese? (Use: Watashi wa ... desu)',
            type: 'text',
            sampleAnswer: 'Watashi wa Tanaka desu',
          },
        ],
        completed: false,
      },
      {
        id: 'les_jp_2',
        order: 2,
        title: 'Lesson 2: Sentence Structure & The Particle "Wa" (は)',
        objective: 'Understand Topic Particle は (Wa) and Desu (です - to be).',
        content: `### 📌 Japanese Sentence Structure: SOV (Subject - Object - Verb)
Unlike English/Hindi which uses SVO or SOV, Japanese places the verb at the very end!
Formula: \`[Topic] wa [Description] desu.\`
Example:
- \`Watashi wa gakusei desu.\` = I am a student. (Gakusei = Student)
- \`Kore wa hon desu.\` = This is a book. (Hon = Book, Kore = This)`,
        keyVocabularyOrFormulas: [
          { term: 'Wa (は)', meaning: 'Topic marker particle', example: 'Watashi wa (As for me)' },
          { term: 'Desu (です)', meaning: 'Is / Am / Are (Polite copula)', example: 'Nihonjin desu (I am Japanese)' },
          { term: 'Gakusei (学生)', meaning: 'Student', example: 'Watashi wa gakusei desu' },
        ],
        practicePrompt: 'Translate: "This is a book" into Japanese using "Kore", "wa", "hon", and "desu".',
        practiceQuestions: [
          {
            id: 'q_jp_2_1',
            question: 'Translate: "I am a student"',
            type: 'text',
            sampleAnswer: 'Watashi wa gakusei desu',
          },
        ],
        completed: false,
      },
      {
        id: 'les_jp_3',
        order: 3,
        title: 'Lesson 3: Numbers (1-10) & Ordering at a Restaurant',
        objective: 'Count from 1 to 10 and order your favorite food or water politely with "Kudasai".',
        content: `### 🍜 Numbers & Ordering Food:
1: Ichi (いち) | 2: Ni (に) | 3: San (さん) | 4: Shi/Yon (よん) | 5: Go (ご)
6: Roku (ろく) | 7: Nana/Shichi (なな) | 8: Hachi (はち) | 9: Kyuu (きゅう) | 10: Juu (じゅう)

Magic phrase: \`[Item] o kudasai\` = Please give me [Item].
- \`Mizu o kudasai\` = Water please!
- \`Raamen o kudasai\` = Ramen please!`,
        practicePrompt: 'How do you ask for water politely in a Japanese cafe?',
        practiceQuestions: [
          {
            id: 'q_jp_3_1',
            question: 'What is 7 in Japanese?',
            type: 'choice',
            options: ['Roku', 'Nana', 'Hachi', 'San'],
            sampleAnswer: 'Nana',
          },
        ],
        completed: false,
      },
    ];
  }

  // 2. Python Coding
  if (norm.includes('python') || norm.includes('code') || norm.includes('program')) {
    return [
      {
        id: 'les_py_1',
        order: 1,
        title: 'Lesson 1: Variables, Data Types & Print Statements',
        objective: 'Understand numbers, strings, booleans, and how Python stores values.',
        content: `### 🐍 Welcome to Python!
Python is clean, readable, and dynamically typed.
\`\`\`python
# Creating variables
name = "Kaju"       # string (str)
age = 20            # integer (int)
score = 98.5        # floating point (float)
is_ready = True     # boolean (bool)

# f-strings for clean formatting
print(f"Hello, my name is {name} and I am {age} years old!")
\`\`\``,
        keyVocabularyOrFormulas: [
          { term: 'print()', meaning: 'Outputs text or values to the console', example: 'print("Hello World")' },
          { term: 'f-string', meaning: 'Formatted string literal with embedded variables', example: 'f"Value: {val}"' },
          { term: 'type()', meaning: 'Returns the data type of an object', example: 'type(42) -> int' },
        ],
        practicePrompt: 'Write a 2-line Python snippet declaring your name and favorite city, then print them using an f-string.',
        practiceQuestions: [
          {
            id: 'q_py_1_1',
            question: 'What data type is `3.14159` in Python?',
            type: 'choice',
            options: ['int', 'float', 'str', 'bool'],
            sampleAnswer: 'float',
          },
        ],
        completed: false,
      },
      {
        id: 'les_py_2',
        order: 2,
        title: 'Lesson 2: Logic, Conditionals (if/elif/else) & Comparisons',
        objective: 'Write decision-making code with boolean operators.',
        content: `### 🔀 Decision Making in Python:
\`\`\`python
marks = 85

if marks >= 90:
    grade = "A+"
elif marks >= 75:
    grade = "A"
else:
    grade = "Keep Practicing!"

print(f"Grade: {grade}")
\`\`\``,
        practicePrompt: 'Write a condition checking if temperature > 35 print "Garmi hai", else print "Mausam achha hai".',
        practiceQuestions: [
          {
            id: 'q_py_2_1',
            question: 'Which keyword handles alternative conditions in Python?',
            type: 'choice',
            options: ['else if', 'elseif', 'elif', 'otherwise'],
            sampleAnswer: 'elif',
          },
        ],
        completed: false,
      },
    ];
  }

  // 3. English Speaking & Fluency
  if (norm.includes('english') || norm.includes('speaking') || norm.includes('fluency')) {
    return [
      {
        id: 'les_en_1',
        order: 1,
        title: 'Lesson 1: Confident Self-Introduction & Small Talk',
        objective: 'Master natural, professional self-introductions without hesitation.',
        content: `### 🗣️ Confident English Speaking:
Formula for an impressive 30-second introduction:
1. **The Hook:** "Hi everyone, I'm [Name], originally from [City]."
2. **Current Focus:** "Currently, I'm working on / passionate about [Field/Skill]."
3. **The Goal:** "I'm really excited to be learning [Skill] and connecting with you all."

*Avoid:* "Myself [Name]" (Grammatically incorrect).
*Use instead:* "I am [Name]" or "My name is [Name]."`,
        practicePrompt: 'Write a natural 3-sentence introduction of yourself using the 3-step formula above.',
        practiceQuestions: [
          {
            id: 'q_en_1_1',
            question: 'Which of the following is grammatically correct in English?',
            type: 'choice',
            options: ['Myself Amit.', 'I am Amit.', 'Myself is Amit.', 'Me Amit.'],
            sampleAnswer: 'I am Amit.',
          },
        ],
        completed: false,
      },
      {
        id: 'les_en_2',
        order: 2,
        title: 'Lesson 2: Active Listening & Thoughtful Follow-up Questions',
        objective: 'Keep any conversation flowing naturally with open-ended questions.',
        content: `### 💬 Conversation Flow:
Use the **F.O.R.D.** technique (Family, Occupation, Recreation, Dreams):
- "What do you like most about your work?"
- "How do you usually unwind on weekends?"
- "What inspired you to get into that?"`,
        practicePrompt: 'Give an open-ended question to ask someone about their favorite hobby.',
        practiceQuestions: [
          {
            id: 'q_en_2_1',
            question: 'Which question encourages a deeper conversation?',
            type: 'choice',
            options: ['Do you like coffee?', 'What kind of music do you enjoy when relaxing?', 'Are you busy?'],
            sampleAnswer: 'What kind of music do you enjoy when relaxing?',
          },
        ],
        completed: false,
      },
    ];
  }

  // Generic Adaptive Syllabus Generator for any user skill
  return [
    {
      id: `les_gen_1`,
      order: 1,
      title: `Lesson 1: Foundations & Core Concepts of ${skillName}`,
      objective: `Understand the fundamental building blocks and terminology of ${skillName}.`,
      content: `### 🚀 Mastering ${skillName}: Foundations
To master **${skillName}**, we start with the essential principles that create 80% of the results (Pareto Principle):
1. **Core Terminology:** Key terms and ideas every practitioner must know.
2. **First Principles:** Breaking complex concepts into simple, intuitive parts.
3. **Common Beginner Mistakes:** Avoiding pitfalls early saves hundreds of hours.`,
      practicePrompt: `Explain what your primary objective is when learning ${skillName} and what has been the hardest part so far.`,
      practiceQuestions: [
        {
          id: `q_gen_1_1`,
          question: `What is the most crucial foundation you want to build in ${skillName}?`,
          type: 'text',
          sampleAnswer: `Understanding core concepts and consistent daily practice.`,
        },
      ],
      completed: false,
    },
    {
      id: `les_gen_2`,
      order: 2,
      title: `Lesson 2: Applied Techniques & Practical Frameworks`,
      objective: `Apply ${skillName} in realistic scenarios with step-by-step guidance.`,
      content: `### 🛠️ Practical Frameworks in ${skillName}
Now that the foundation is set, we practice hands-on execution:
- Technique 1: Step-by-step breakdown
- Technique 2: Rapid feedback loop
- Technique 3: Real-world simulation`,
      practicePrompt: `Practice solving a realistic scenario in ${skillName}.`,
      practiceQuestions: [
        {
          id: `q_gen_2_1`,
          question: `Describe how you would approach a real-world problem using ${skillName}.`,
          type: 'text',
          sampleAnswer: `Break the problem into smaller milestones and test each step.`,
        },
      ],
      completed: false,
    },
  ];
}

/**
 * Create a new Skill Journey
 */
export function createSkillJourney(
  skillName: string,
  userGoalPrompt: string,
  level: SkillLevel = 'beginner'
): SkillJourney {
  const cleanName = skillName.trim() || 'General Skill';
  const id = `skill_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const lessons = generateLessonsForSkill(cleanName, level);

  const newJourney: SkillJourney = {
    id,
    skillName: cleanName,
    targetGoal: userGoalPrompt.trim() || `Master ${cleanName} step-by-step`,
    level,
    stage: 'LEVEL_CHECK',
    diagnosticDone: false,
    currentLessonIndex: 0,
    lessons,
    mistakesLog: [],
    streakDays: 1,
    totalPracticeCompleted: 0,
    percentProgress: 10,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  const existing = loadSkillJourneys();
  saveSkillJourneys([newJourney, ...existing.filter((j) => j.id !== id)]);
  saveActiveSkillId(id);
  return newJourney;
}

/**
 * Evaluate answer and advance skill journey stages
 */
export function processSkillTurn(
  journey: SkillJourney,
  userInput: string
): {
  updatedJourney: SkillJourney;
  feedbackText: string;
  nextStepPrompt: string;
} {
  const currentLesson = journey.lessons[journey.currentLessonIndex] || journey.lessons[0];
  const clean = userInput.trim().toLowerCase();

  // 1. Diagnostic Level Check
  if (journey.stage === 'LEVEL_CHECK') {
    let diagnosedLevel: SkillLevel = 'beginner';
    if (clean.includes('already know') || clean.includes('intermediate') || clean.includes('thoda aata hai') || clean.includes('medium')) {
      diagnosedLevel = 'intermediate';
    } else if (clean.includes('advanced') || clean.includes('pro') || clean.includes('expert')) {
      diagnosedLevel = 'advanced';
    }

    const updated: SkillJourney = {
      ...journey,
      level: diagnosedLevel,
      diagnosticDone: true,
      stage: 'LESSON',
      percentProgress: 20,
      updatedAt: Date.now(),
    };

    saveSkillJourneys(loadSkillJourneys().map((j) => (j.id === journey.id ? updated : j)));

    return {
      updatedJourney: updated,
      feedbackText: `🎯 **Diagnostic Complete!** Starting at the **${diagnosedLevel.toUpperCase()}** level for **${journey.skillName}**.\n\nAapka personalized learning path ready hai! Chalo shuru karte hain **Lesson 1**:`,
      nextStepPrompt: `${currentLesson.content}\n\n### 📝 Practice Challenge:\n${currentLesson.practicePrompt}\n\n*Apna answer type karke bhejiye!*`,
    };
  }

  // 2. Practice Check & Feedback
  if (journey.stage === 'LESSON' || journey.stage === 'PRACTICE') {
    // Check user answer against current lesson
    const isGoodEffort = clean.length > 3;
    let mistakes: SkillMistakeRecord[] = [...journey.mistakesLog];

    if (!isGoodEffort) {
      mistakes.push({
        id: `mst_${Date.now()}`,
        timestamp: Date.now(),
        question: currentLesson.practicePrompt,
        userAnswer: userInput,
        correction: currentLesson.practiceQuestions[0]?.sampleAnswer || 'Provide a complete answer',
        advice: 'Try writing a full sentence or formula for deeper muscle memory.',
      });
    }

    const updatedLessons = journey.lessons.map((l, idx) =>
      idx === journey.currentLessonIndex ? { ...l, completed: true, score: 95 } : l
    );

    const isLastLesson = journey.currentLessonIndex >= journey.lessons.length - 1;
    const nextIdx = isLastLesson ? journey.currentLessonIndex : journey.currentLessonIndex + 1;
    const progress = Math.min(100, Math.round(((journey.currentLessonIndex + 1) / journey.lessons.length) * 100));

    const updated: SkillJourney = {
      ...journey,
      lessons: updatedLessons,
      stage: isLastLesson ? 'PROGRESS' : 'NEXT_LESSON',
      currentLessonIndex: nextIdx,
      mistakesLog: mistakes,
      totalPracticeCompleted: journey.totalPracticeCompleted + 1,
      percentProgress: progress,
      updatedAt: Date.now(),
    };

    saveSkillJourneys(loadSkillJourneys().map((j) => (j.id === journey.id ? updated : j)));

    const nextLesson = updated.lessons[nextIdx];
    const praise = isGoodEffort
      ? `🎉 **Shabash! Great job!** Aapka answer bilkul correct aur thoughtful hai.`
      : `Good attempt! Thoda aur detail me likhenge to concepts aur pakke ho jayenge.`;

    const nextPrompt = isLastLesson
      ? `🏆 **Congratulations!** You have completed all foundational lessons in **${journey.skillName}**! Overall Progress: 100% ⭐. Would you like a revision quiz or next advanced module?`
      : `Aapka **Progress: ${progress}%** ho chuka hai! 🔥\n\nAb agle padav par chalte hain: **${nextLesson.title}**\n\n${nextLesson.content}\n\n### 📝 Practice:\n${nextLesson.practicePrompt}`;

    return {
      updatedJourney: updated,
      feedbackText: praise,
      nextStepPrompt: nextPrompt,
    };
  }

  // Fallback
  return {
    updatedJourney: journey,
    feedbackText: `Great engagement with **${journey.skillName}**!`,
    nextStepPrompt: `What would you like to practice or learn next in ${journey.skillName}?`,
  };
}

/**
 * Intelligent detector for Skill Intent
 */
export function detectSkillRequest(text: string): { isSkill: boolean; skillName?: string; goalPrompt?: string } {
  const lower = text.toLowerCase();

  // Explicit Skill keywords
  const skillKeywords = [
    'zero se sikhana',
    'zero se seekhna',
    'sikhna hai',
    'seekhna hai',
    'teach me',
    'learn japanese',
    'learn english',
    'learn python',
    'learn coding',
    'learn math',
    'learn communication',
    'skill mode',
    'kaju mujhe sikhana',
    'kaju mujhe seekhna',
  ];

  for (const kw of skillKeywords) {
    if (lower.includes(kw)) {
      let skillName = 'General Skill';
      if (lower.includes('japanese') || lower.includes('nihongo')) skillName = 'Japanese';
      else if (lower.includes('english') || lower.includes('speaking')) skillName = 'English Speaking';
      else if (lower.includes('python')) skillName = 'Python Coding';
      else if (lower.includes('coding') || lower.includes('programming')) skillName = 'Coding & Web Dev';
      else if (lower.includes('math') || lower.includes('ganit') || lower.includes('mathematics')) skillName = 'Mathematics';
      else if (lower.includes('communication') || lower.includes('public speaking')) skillName = 'Communication';
      else {
        // Extract whatever skill word appears between "kaju mujhe" and "zero se sikhana" or "sikhna"
        const customMatch = text.match(/kaju\s+(?:mujhe\s+)?([a-zA-Z0-9\s]+?)\s+(?:zero se|sikhana|seekhna|teach|learn)/i);
        if (customMatch && customMatch[1].trim()) {
          skillName = customMatch[1].trim();
        }
      }

      return { isSkill: true, skillName, goalPrompt: text };
    }
  }

  return { isSkill: false };
}

import { IntentCategory, ProjectWorkspace, SkillJourney } from '../types';
import { detectSkillRequest, loadSkillJourneys, loadActiveSkillId } from './skillEngine';
import { findProjectByNameOrKeyword } from './projectHelper';

export interface SmartContextDecision {
  primaryDomain: 'skill' | 'research' | 'project' | 'file' | 'goal' | 'fun' | 'chat';
  skillName?: string;
  matchedProject?: ProjectWorkspace;
  isDetailedResearch?: boolean;
  searchNeeded?: boolean;
  contextSummary: string;
}

/**
 * Automatically infers context and routing without forcing users to choose a mode
 */
export function analyzeSmartContext(
  text: string,
  hasImage: boolean = false,
  hasFile: boolean = false
): SmartContextDecision {
  const clean = text.trim();
  const lower = clean.toLowerCase();

  // 1. Attached File context
  if (hasFile) {
    return {
      primaryDomain: 'file',
      contextSummary: 'Document intelligence & file analysis context',
    };
  }

  // 2. Skill Learning Journey
  const skillReq = detectSkillRequest(clean);
  if (skillReq.isSkill) {
    return {
      primaryDomain: 'skill',
      skillName: skillReq.skillName,
      contextSummary: `Skill mode: ${skillReq.skillName} structured lesson journey`,
    };
  }

  // Also check if user is replying to an active skill practice
  const activeSkillId = loadActiveSkillId();
  if (activeSkillId) {
    const journeys = loadSkillJourneys();
    const activeJourney = journeys.find((j) => j.id === activeSkillId);
    if (activeJourney && (lower.includes('next lesson') || lower.includes('practice') || lower.includes('check answer') || lower.includes('shuru karo') || lower.includes('mera answer'))) {
      return {
        primaryDomain: 'skill',
        skillName: activeJourney.skillName,
        contextSummary: `Active Skill: ${activeJourney.skillName} (Lesson ${activeJourney.currentLessonIndex + 1})`,
      };
    }
  }

  // 3. Project Workspace Inquiry
  const projectMatch = findProjectByNameOrKeyword(clean);
  if (projectMatch) {
    return {
      primaryDomain: 'project',
      matchedProject: projectMatch,
      contextSummary: `Universal Project Workspace context: "${projectMatch.name}"`,
    };
  }

  // 4. Research Mode Task
  const isResearchQuery =
    lower.includes('detailed research') ||
    lower.includes('research karo') ||
    lower.includes('par research') ||
    lower.includes('latest information on') ||
    lower.includes('current facts on') ||
    lower.includes('detailed report on') ||
    lower.includes('cross-check sources') ||
    lower.includes('sources ke saath batao');

  if (isResearchQuery) {
    return {
      primaryDomain: 'research',
      isDetailedResearch: true,
      searchNeeded: true,
      contextSummary: 'In-depth multi-source research report mode',
    };
  }

  // 5. Boredom / Fun Companion
  if (
    lower.includes('bore ho raha') ||
    lower.includes("i'm bored") ||
    lower.includes('im bored') ||
    lower.includes('game khelo') ||
    lower.includes('tic tac toe') ||
    lower.includes('shayari sunao') ||
    lower.includes('joke sunao')
  ) {
    return {
      primaryDomain: 'fun',
      contextSummary: 'Companion fun & interactive game mode',
    };
  }

  // 6. Multi-step Goal
  if (
    lower.includes('exam in') ||
    lower.includes('target hai') ||
    lower.includes('roadmap banao') ||
    lower.includes('complete within') ||
    lower.includes('step by step plan')
  ) {
    return {
      primaryDomain: 'goal',
      contextSummary: 'Goal Engine 5-stage milestone journey',
    };
  }

  // Default: General AI Chat & Reasoning
  return {
    primaryDomain: 'chat',
    searchNeeded: lower.includes('who is currently') || lower.includes('latest') || lower.includes('price of') || lower.includes('today'),
    contextSummary: 'General AI conversation & reasoning context',
  };
}

/**
 * Speech Manager for Kaju AI
 *
 * Robust, production-grade SpeechSynthesis controller with specialized Hinglish
 * & multi-script language segmentation:
 *
 * 1. HINGLISH PRONUNCIATION ENGINE:
 *    - Identifies script boundaries within mixed responses (Devanagari vs Latin alphabet).
 *    - Routes Hindi/Devanagari phrases strictly to natural Hindi voices (hi-IN).
 *    - Routes Latin-script Hinglish & English phrases to Indian English voices (en-IN).
 *      (Indian English voices pronounce words like "kaise ho", "karo", "samjhao", "padhai"
 *       naturally with native phonemes, unlike US/UK voices that mangle them).
 *    - Preserves exact word order and original wording with seamless, natural transitions.
 *
 * 2. NATURAL PAUSING & CLAUSE SEGMENTATION:
 *    - Splits sentences without cutting off words or repeating speech.
 *    - Maintains natural 60-80ms cadence between segments, avoiding robotic pauses.
 *
 * 3. BROWSER SYNTHESIS STABILITY:
 *    - Retains strong reference to active utterances preventing V8 garbage collection mid-speech.
 *    - Session ID guarding prevents overlapping or duplicate speech callbacks.
 *    - Reliable Pause & Resume preserving exact chunk and segment positions.
 */

import type { LanguagePreference } from '../types.js';
import { cleanMathForSpeech } from './mathHelper.js';

export type SpeechPlaybackStatus = 'idle' | 'playing' | 'paused' | 'unsupported';

export interface VoiceSettings {
  rateMultiplier: number; // 0.8x to 1.3x, default 1.0
  pitchMultiplier: number; // 0.9x to 1.1x, default 1.0
}

export interface SpeechSegment {
  text: string;
  lang: string;
}

export interface SpeechPlaybackState {
  status: SpeechPlaybackStatus;
  messageId: string | null;
  currentChunkIndex: number;
  totalChunks: number;
  language: 'hi' | 'en' | 'mixed';
  voiceName: string | null;
  settings: VoiceSettings;
  errorMessage?: string | null;
}

export type SpeechStateListener = (state: SpeechPlaybackState) => void;

const SETTINGS_STORAGE_KEY = 'kaju_ai_voice_settings_v1';

class SpeechManager {
  private currentMessageId: string | null = null;
  private segments: SpeechSegment[] = [];
  private currentSegmentIndex: number = 0;
  private primaryLanguage: 'hi' | 'en' | 'mixed' = 'en';
  private currentVoiceName: string | null = null;
  private status: SpeechPlaybackStatus = 'idle';
  private listeners: Set<SpeechStateListener> = new Set();
  private voices: SpeechSynthesisVoice[] = [];
  private errorMessage: string | null = null;

  // Settings
  private settings: VoiceSettings = {
    rateMultiplier: 1.0,
    pitchMultiplier: 1.0,
  };

  // Session ID to discard async callbacks from obsolete/canceled plays
  private activeSessionId: number = 0;

  // Crucial: keep strong reference to active utterance to prevent V8 garbage collection
  private activeUtterance: SpeechSynthesisUtterance | null = null;

  // Timeout guard in case browser onend fails to fire
  private watchdogTimer: any = null;

  constructor() {
    this.loadSettings();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.initVoices();
      if (window.speechSynthesis.onvoiceschanged !== undefined) {
        window.speechSynthesis.onvoiceschanged = () => {
          this.initVoices();
        };
      }
    } else {
      this.status = 'unsupported';
    }
  }

  private loadSettings() {
    if (typeof window === 'undefined') return;
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed.rateMultiplier === 'number') {
          this.settings.rateMultiplier = Math.max(0.75, Math.min(1.5, parsed.rateMultiplier));
        }
        if (typeof parsed.pitchMultiplier === 'number') {
          this.settings.pitchMultiplier = Math.max(0.8, Math.min(1.2, parsed.pitchMultiplier));
        }
      }
    } catch {}
  }

  public saveSettings(newSettings: Partial<VoiceSettings>) {
    this.settings = { ...this.settings, ...newSettings };
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(this.settings));
      } catch {}
    }
    this.notify();
  }

  public getSettings(): VoiceSettings {
    return { ...this.settings };
  }

  private initVoices() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    try {
      this.voices = window.speechSynthesis.getVoices();
    } catch (e) {
      console.warn('SpeechManager: error reading voices', e);
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.voices.length === 0 && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.initVoices();
    }
    return this.voices;
  }

  public isSupported(): boolean {
    return typeof window !== 'undefined' && 'speechSynthesis' in window;
  }

  public subscribe(listener: SpeechStateListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach((listener) => {
      try {
        listener(state);
      } catch (err) {
        console.warn('SpeechStateListener error:', err);
      }
    });
  }

  public getState(): SpeechPlaybackState {
    return {
      status: this.status,
      messageId: this.currentMessageId,
      currentChunkIndex: this.currentSegmentIndex,
      totalChunks: this.segments.length,
      language: this.primaryLanguage,
      voiceName: this.currentVoiceName,
      settings: { ...this.settings },
      errorMessage: this.errorMessage,
    };
  }

  /**
   * Cleans Markdown formatting, LaTeX, bullets, and emojis for smooth, pleasant reading.
   */
  public cleanTextForSpeech(rawMarkdown: string, userPref?: LanguagePreference): string {
    if (!rawMarkdown) return '';

    const effectivePref =
      userPref || (/[\u0900-\u097F]/.test(rawMarkdown) ? 'hindi' : 'english');
    const mathCleaned = cleanMathForSpeech(rawMarkdown, effectivePref);

    return mathCleaned
      // Remove code blocks
      .replace(/```[\s\S]*?```/g, ' ')
      // Remove inline code
      .replace(/`([^`]+)`/g, '$1')
      // Remove images ![alt](url)
      .replace(/!\[([^\]]*)\]\([^)]+\)/g, '')
      // Replace links [text](url) with just text
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      // Remove markdown headers #, ##, etc.
      .replace(/^#{1,6}\s+/gm, '')
      // Remove bold and italic markers (* and _)
      .replace(/(\*\*|__)(.*?)\1/g, '$2')
      .replace(/(\*|_)(.*?)\1/g, '$2')
      // Remove blockquotes
      .replace(/^>\s+/gm, '')
      // Remove horizontal rules
      .replace(/^[-*_]{3,}\s*$/gm, '')
      // Remove bullet markers and list numbers
      .replace(/^[\s*+-]+\s+/gm, '')
      .replace(/^\d+\.\s+/gm, '')
      // Replace standard emojis with slight pause or space so TTS does not pronounce emoji codenames
      .replace(/[\u{1F300}-\u{1F6FF}\u{1F900}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, ' ')
      // Normalize Hindi Purna Viram so it terminates cleanly with a space
      .replace(/([।])(?=[^\s])/g, '$1 ')
      // Normalize whitespace
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{2,}/g, '. ')
      .replace(/\n/g, ' ')
      .trim();
  }

  /**
   * Detects the overall language profile of the text.
   */
  public detectLanguage(text: string, userPreference?: LanguagePreference): 'hi' | 'en' | 'mixed' {
    const hasDevanagari = /[\u0900-\u097F]/.test(text);
    const hasLatin = /[a-zA-Z]/.test(text);

    if (hasDevanagari && hasLatin) {
      return 'mixed';
    }
    if (hasDevanagari) {
      return 'hi';
    }
    if (userPreference === 'hindi') {
      return 'hi';
    }
    return 'en';
  }

  /**
   * Splits mixed-language (Hindi + English / Hinglish) text into seamless speech segments.
   * - Devanagari text goes to 'hi' voice.
   * - Latin-script text (whether English or Hinglish like "kaise ho") goes to 'en-IN' voice.
   * - Preserves exact original wording and sequence.
   */
  public segmentText(text: string, userPref?: LanguagePreference): SpeechSegment[] {
    const cleaned = this.cleanTextForSpeech(text, userPref);
    if (!cleaned) return [];

    const hasDevanagari = /[\u0900-\u097F]/.test(cleaned);
    const hasLatin = /[a-zA-Z]/.test(cleaned);

    // Case 1: Pure Latin or regional non-Devanagari text
    if (!hasDevanagari) {
      const defaultLang = userPref && !['auto', 'hindi', 'english', 'hinglish'].includes(userPref)
        ? userPref
        : 'en';
      return this.chunkPureText(cleaned, defaultLang);
    }

    // Case 2: Pure Devanagari text
    if (!hasLatin) {
      return this.chunkPureText(cleaned, 'hi');
    }

    // Case 3: Mixed response containing both Devanagari and Latin words
    // Example: "नमस्ते! प्रकाश (Light) का परावर्तन (Reflection) समझें।"
    // Split on sentence boundaries first (. ! ? । \n)
    const sentenceParts = cleaned.split(/([.!?।;\n]+)/g);
    const segments: SpeechSegment[] = [];

    for (let i = 0; i < sentenceParts.length; i += 2) {
      const sBody = sentenceParts[i] || '';
      const sPunct = sentenceParts[i + 1] || '';
      const fullSentence = (sBody + sPunct).trim();
      if (!fullSentence) continue;

      const sentenceHasDevanagari = /[\u0900-\u097F]/.test(fullSentence);
      const sentenceHasLatin = /[a-zA-Z]/.test(fullSentence);

      if (!sentenceHasLatin) {
        // Entire sentence is Devanagari
        const chunks = this.chunkPureText(fullSentence, 'hi');
        segments.push(...chunks);
      } else if (!sentenceHasDevanagari) {
        // Entire sentence is Latin/English
        const chunks = this.chunkPureText(fullSentence, 'en');
        segments.push(...chunks);
      } else {
        // Mixed sentence: break by script tokens while preserving order
        const tokens: { text: string; type: 'hi' | 'en' | 'punct' }[] = [];
        const tokenRegex = /([\u0900-\u097F\u0964\u0965]+|[a-zA-Z0-9]+|[^\u0900-\u097F\u0964\u0965a-zA-Z0-9]+)/g;
        let match;
        while ((match = tokenRegex.exec(fullSentence)) !== null) {
          const val = match[0];
          const isHi = /[\u0900-\u097F]/.test(val);
          const isEn = /[a-zA-Z]/.test(val);
          tokens.push({ text: val, type: isHi ? 'hi' : isEn ? 'en' : 'punct' });
        }

        let currentLang: 'hi' | 'en' | null = null;
        let currentBuf = '';

        for (let j = 0; j < tokens.length; j++) {
          const tok = tokens[j];
          if (tok.type === 'punct') {
            currentBuf += tok.text;
          } else {
            if (!currentLang) {
              currentLang = tok.type;
              currentBuf += tok.text;
            } else if (currentLang === tok.type) {
              currentBuf += tok.text;
            } else {
              // Language switch
              const cleanedSeg = this.cleanSegmentPunctuation(currentBuf);
              if (cleanedSeg) {
                segments.push({ text: cleanedSeg, lang: currentLang });
              }
              currentLang = tok.type;
              currentBuf = tok.text;
            }
          }
        }
        if (currentBuf && currentLang) {
          const cleanedSeg = this.cleanSegmentPunctuation(currentBuf);
          if (cleanedSeg) {
            segments.push({ text: cleanedSeg, lang: currentLang });
          }
        }
      }
    }

    return segments.length > 0 ? segments : [{ text: cleaned, lang: 'hi' }];
  }

  /**
   * Helper to clean awkward leading or trailing bracket artifacts between language transitions
   */
  private cleanSegmentPunctuation(text: string): string {
    return text
      .replace(/^[\s()\[\]{}:;,"'–—]+|[\s()\[\]{}:;,"'–—]+$/g, '')
      .trim();
  }

  /**
   * Chunks single-language text into natural clauses (< 130 chars) for smooth browser playback.
   */
  private chunkPureText(text: string, lang: string): SpeechSegment[] {
    const rawParts = text.split(/([.!?।;\n]+)/g);
    const result: SpeechSegment[] = [];
    let currentBuffer = '';

    for (let i = 0; i < rawParts.length; i += 2) {
      const sentence = rawParts[i] || '';
      const delimiter = rawParts[i + 1] || '';
      const fullSentence = (sentence + delimiter).trim();

      if (!fullSentence) continue;

      if ((currentBuffer + ' ' + fullSentence).length < 130) {
        currentBuffer = currentBuffer ? `${currentBuffer} ${fullSentence}` : fullSentence;
      } else {
        if (currentBuffer) {
          result.push({ text: currentBuffer, lang });
          currentBuffer = '';
        }

        if (fullSentence.length >= 130) {
          const subPhrases = fullSentence.split(/([,–—:]+)/g);
          let subBuffer = '';
          for (let j = 0; j < subPhrases.length; j += 2) {
            const sub = subPhrases[j] || '';
            const subDelim = subPhrases[j + 1] || '';
            const piece = (sub + subDelim).trim();
            if ((subBuffer + ' ' + piece).length < 120) {
              subBuffer = subBuffer ? `${subBuffer} ${piece}` : piece;
            } else {
              if (subBuffer) result.push({ text: subBuffer, lang });
              subBuffer = piece;
            }
          }
          if (subBuffer) result.push({ text: subBuffer, lang });
        } else {
          currentBuffer = fullSentence;
        }
      }
    }

    if (currentBuffer) {
      result.push({ text: currentBuffer, lang });
    }

    return result.length > 0 ? result : [{ text, lang }];
  }

  /**
   * Finds the best voice for the target language.
   * Prioritizes high quality neural/natural voices:
   * - 'hi': Indian Hindi (hi-IN)
   * - 'en': Indian English (en-IN) for accurate Hinglish phonetics, falling back to en-US/natural
   * - Other languages: matches voice lang code directly
   */
  public getBestVoice(targetLang: string, isHinglishContext: boolean = true): SpeechSynthesisVoice | null {
    const voices = this.getVoices();
    if (!voices || voices.length === 0) return null;

    if (targetLang === 'hi') {
      // Prioritize natural Hindi voices
      const hindiVoices = voices.filter((v) =>
        v.lang.toLowerCase().replace('_', '-').startsWith('hi')
      );

      if (hindiVoices.length > 0) {
        const topHindi = hindiVoices.find(
          (v) =>
            v.name.includes('Google') ||
            v.name.includes('Swara') ||
            v.name.includes('Madhur') ||
            v.name.includes('Natural') ||
            v.name.includes('Online')
        );
        if (topHindi) return topHindi;
        return hindiVoices[0];
      }

      // Fallback to en-IN
      const indianEnglish = voices.filter((v) =>
        v.lang.toLowerCase().replace('_', '-').startsWith('en-in')
      );
      if (indianEnglish.length > 0) return indianEnglish[0];
    } else if (targetLang === 'en') {
      // English / Hinglish voice:
      // For Hinglish or Indian context, Indian English voices (en-IN) are CRUCIAL.
      const enInVoices = voices.filter((v) =>
        v.lang.toLowerCase().replace('_', '-').startsWith('en-in')
      );

      if (enInVoices.length > 0) {
        const topEnIn = enInVoices.find(
          (v) =>
            v.name.includes('Google') ||
            v.name.includes('Natural') ||
            v.name.includes('Neerja') ||
            v.name.includes('Prabhat') ||
            v.name.includes('Rishi') ||
            v.name.includes('Online')
        );
        if (topEnIn) return topEnIn;
        return enInVoices[0];
      }

      // If no en-IN voice is installed, use natural English voices (en-US / en-GB)
      const englishVoices = voices.filter((v) =>
        v.lang.toLowerCase().startsWith('en')
      );

      if (englishVoices.length > 0) {
        const naturalEn = englishVoices.find(
          (v) =>
            v.name.includes('Natural') ||
            v.name.includes('Google US English') ||
            v.name.includes('Samantha') ||
            v.name.includes('Jenny') ||
            v.name.includes('Guy') ||
            v.name.includes('Aria')
        );
        if (naturalEn) return naturalEn;
        return englishVoices[0];
      }
    } else {
      // Other target languages (e.g. 'es', 'fr', 'de', 'bn', 'ta', 'te', 'ja', 'zh', etc.)
      const cleanLang = targetLang.toLowerCase().replace('_', '-');
      const matched = voices.filter((v) => {
        const vLang = v.lang.toLowerCase().replace('_', '-');
        return vLang.startsWith(cleanLang) || cleanLang.startsWith(vLang);
      });

      if (matched.length > 0) {
        const top = matched.find(
          (v) =>
            v.name.includes('Google') ||
            v.name.includes('Natural') ||
            v.name.includes('Online')
        );
        return top || matched[0];
      }
    }

    return voices[0] || null;
  }

  /**
   * Starts playback of a specific message with mixed-script Hinglish routing.
   */
  public speak(messageId: string, text: string, userPref?: LanguagePreference) {
    if (!this.isSupported()) {
      this.errorMessage = 'Text-to-speech is not supported by your browser.';
      this.status = 'unsupported';
      this.notify();
      return;
    }

    // Stop and invalidate any active playback immediately
    this.stopInternal(false);

    this.activeSessionId++;
    const thisSessionId = this.activeSessionId;

    this.currentMessageId = messageId;
    this.primaryLanguage = this.detectLanguage(text, userPref);
    this.segments = this.segmentText(text, userPref);
    this.currentSegmentIndex = 0;
    this.errorMessage = null;

    if (this.segments.length === 0) {
      this.stop();
      return;
    }

    this.status = 'playing';
    this.notify();

    this.playSegment(thisSessionId, 0);
  }

  /**
   * Speaks a specific segment with appropriate voice, rate and pitch.
   */
  private playSegment(sessionId: number, segmentIndex: number) {
    if (sessionId !== this.activeSessionId || this.status !== 'playing' || !this.isSupported()) {
      return;
    }

    if (segmentIndex >= this.segments.length) {
      // Completed all segments
      this.stop();
      return;
    }

    const segment = this.segments[segmentIndex];
    if (!segment || !segment.text.trim()) {
      this.currentSegmentIndex = segmentIndex + 1;
      this.notify();
      this.playSegment(sessionId, segmentIndex + 1);
      return;
    }

    this.clearWatchdog();

    try {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(segment.text);
      utterance.lang = segment.lang === 'hi' ? 'hi-IN' : segment.lang === 'en' ? 'en-IN' : segment.lang;

      // Pick optimal voice for this specific segment's language
      const voice = this.getBestVoice(segment.lang, true);
      if (voice) {
        utterance.voice = voice;
        this.currentVoiceName = voice.name;
      }

      // Base rates: Hindi clear articulation at 0.93; Indian English/Hinglish at 0.96
      const baseRate = segment.lang === 'hi' ? 0.93 : 0.96;
      utterance.rate = Math.max(0.5, Math.min(2.0, baseRate * this.settings.rateMultiplier));

      const basePitch = 1.0;
      utterance.pitch = Math.max(0.5, Math.min(1.5, basePitch * this.settings.pitchMultiplier));

      // Retain strong reference to prevent garbage collection
      this.activeUtterance = utterance;

      let isSegmentFinished = false;

      const finishSegment = (advance: boolean) => {
        if (isSegmentFinished) return;
        isSegmentFinished = true;
        this.clearWatchdog();
        this.activeUtterance = null;

        if (sessionId !== this.activeSessionId) return;

        if (advance && this.status === 'playing') {
          this.currentSegmentIndex = segmentIndex + 1;
          this.notify();
          // Natural conversational pause between segments (60ms)
          setTimeout(() => {
            if (sessionId === this.activeSessionId && this.status === 'playing') {
              this.playSegment(sessionId, segmentIndex + 1);
            }
          }, 60);
        }
      };

      utterance.onend = () => {
        finishSegment(true);
      };

      utterance.onerror = (event: any) => {
        if (event.error === 'interrupted' || event.error === 'canceled') {
          finishSegment(false);
          return;
        }

        console.warn('SpeechSynthesis error on segment:', event.error);
        if (event.error === 'not-allowed') {
          this.errorMessage = 'Audio playback blocked. Please click to interact.';
        } else if (event.error === 'audio-busy') {
          this.errorMessage = 'Audio system is busy. Retrying...';
        }

        finishSegment(true);
      };

      window.speechSynthesis.speak(utterance);

      // Watchdog timer prevents browser engine stall
      const estimatedDurationMs = Math.max(segment.text.length * 130, 7000);
      this.watchdogTimer = setTimeout(() => {
        if (sessionId === this.activeSessionId && this.status === 'playing' && !isSegmentFinished) {
          console.warn('Speech watchdog timer triggered for segment', segmentIndex);
          try {
            window.speechSynthesis.cancel();
          } catch {}
          finishSegment(true);
        }
      }, estimatedDurationMs);

    } catch (err: any) {
      console.error('SpeechManager playSegment exception:', err);
      this.errorMessage = 'Speech playback error occurred.';
      this.stop();
    }
  }

  private clearWatchdog() {
    if (this.watchdogTimer) {
      clearTimeout(this.watchdogTimer);
      this.watchdogTimer = null;
    }
  }

  /**
   * Pauses speech playback.
   */
  public pause() {
    if (!this.isSupported() || this.status !== 'playing') return;

    this.clearWatchdog();
    this.status = 'paused';

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        console.warn('SpeechManager cancel on pause error', e);
      }
    }

    this.activeUtterance = null;
    this.notify();
  }

  /**
   * Resumes speech playback from the exact segment where it was paused.
   */
  public resume() {
    if (!this.isSupported() || this.status !== 'paused') return;

    this.status = 'playing';
    this.activeSessionId++;
    const thisSessionId = this.activeSessionId;
    this.notify();

    this.playSegment(thisSessionId, this.currentSegmentIndex);
  }

  /**
   * Stops playback immediately and resets all state.
   */
  public stop() {
    this.stopInternal(true);
  }

  private stopInternal(resetState: boolean) {
    this.clearWatchdog();
    this.activeSessionId++;
    this.activeUtterance = null;

    if (this.isSupported()) {
      try {
        window.speechSynthesis.cancel();
      } catch (e) {
        console.warn('SpeechManager cancel error', e);
      }
    }

    if (resetState) {
      this.status = 'idle';
      this.currentMessageId = null;
      this.currentSegmentIndex = 0;
      this.segments = [];
      this.currentVoiceName = null;
      this.errorMessage = null;
      this.notify();
    }
  }
}

// Global Singleton Instance
export const speechManager = new SpeechManager();

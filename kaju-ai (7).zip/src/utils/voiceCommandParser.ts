import {
  DeviceAction,
  VoiceCommandResult,
  VoiceCommandClarificationOption,
  LanguagePreference,
} from '../types';
import {
  sanitizePhoneNumber,
  POPULAR_APP_SHORTCUTS,
} from './actionHelper';
import { NativeActionRouter } from './nativeActionRouter';

/**
 * Detect script / language of spoken transcript
 */
export function detectTranscriptLanguage(text: string): 'hindi' | 'english' | 'hinglish' {
  const devanagariRegex = /[\u0900-\u097F]/;
  if (devanagariRegex.test(text)) {
    return 'hindi';
  }

  const hinglishKeywords = [
    'kholo', 'bhejo', 'lagao', 'karo', 'batao', 'kaise', 'padhao', 'dikhao',
    'samjhao', 'chalao', 'dhundo', 'milao', 'suno', 'kripya', 'namaste',
    'mujhe', 'humko', 'kisko', 'kahan', 'kyun', 'par', 'pe', 'se', 'hai', 'hain'
  ];

  const lower = text.toLowerCase();
  const words = lower.split(/\s+/);
  const hasHinglish = words.some((w) => hinglishKeywords.includes(w));

  return hasHinglish ? 'hinglish' : 'english';
}

/**
 * Extract phone number digits from text
 */
export function extractPhoneNumberFromText(text: string): string | null {
  // Check for +91 or standard 10-12 digit numbers
  const match = text.match(/(?:\+91[\s-]?)?[6-9]\d{9}/) || text.match(/\b\d{10,12}\b/);
  if (match) {
    return sanitizePhoneNumber(match[0]);
  }
  return null;
}

/**
 * Local fast-path intent classifier for rapid voice interaction
 */
export function parseVoiceCommandLocally(
  transcript: string,
  userPreferredLang: LanguagePreference = 'auto'
): VoiceCommandResult | null {
  const trimmed = transcript.trim();
  if (!trimmed) return null;

  const lower = trimmed.toLowerCase();
  const detectedLang = detectTranscriptLanguage(trimmed);

  // 1. DESKTOP / PC HARDWARE CONTROL (Unsupported in browser sandbox)
  const desktopPatterns = [
    /computer\s*(band|off|shutdown|restart)/i,
    /laptop\s*(band|off|shutdown|restart)/i,
    /turn\s*off\s*(my\s*)?(computer|laptop|pc)/i,
    /shut\s*down\s*(my\s*)?(pc|laptop|computer)/i,
    /screenshot\s*(lo|take|capture)/i,
    /(click|move)\s*mouse/i,
    /run\s*(terminal|script|command|cmd|powershell)/i,
    /open\s*(notepad|cmd|terminal|explorer)\s*on\s*(pc|desktop|laptop)/i,
  ];

  for (const pat of desktopPatterns) {
    if (pat.test(lower)) {
      const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'unsupported',
        detectedLanguage: detectedLang,
        title: isHindi ? 'कंप्यूटर नियंत्रण सीमा' : 'Desktop Control Limitation',
        explanation: isHindi
          ? 'ब्राउज़र सुरक्षा कारणों से वेब ऐप आपके कंप्यूटर हार्डवेयर को सीधे नियंत्रित नहीं कर सकता।'
          : 'Web browsers cannot directly control PC hardware or run scripts due to sandbox safety.',
        feedbackSpoken: isHindi
          ? 'माफ़ कीजिए, ब्राउज़र सुरक्षा नियमों के अनुसार वेब ऐप सीधे आपके कंप्यूटर को नियंत्रित नहीं कर सकता। इसके लिए डेस्कटॉप कंपैनियन की आवश्यकता होती है।'
          : 'Due to browser security, web applications cannot directly control your computer hardware. This requires the Desktop Companion.',
        action: {
          id: `act_${Date.now()}`,
          type: 'unsupported',
          status: 'ready',
          title: 'Desktop Control Requested',
          payload: {
            unsupported: {
              requestedAction: trimmed,
              reason: 'Browser security sandbox prevents direct operating system & hardware manipulation.',
              requiredTier: 'desktop',
              safeAlternative: 'Open Action Center to view the Desktop Companion setup blueprint.',
            },
          },
          createdAt: Date.now(),
        },
      };
    }
  }

  // 2. WHATSAPP COMMANDS
  if (
    lower.includes('whatsapp') ||
    lower.includes('व्हाट्सएप') ||
    lower.includes('whats app')
  ) {
    const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
    
    // Check for specific message or recipient
    const phone = extractPhoneNumberFromText(trimmed);

    // Try extracting message content after "ki", "saying", "that", "message":
    let messageText = '';
    const msgSplits = [
      /\bki\s+(.+)$/i,
      /\bsaying\s+(.+)$/i,
      /\bthat\s+(.+)$/i,
      /\bmessage\s+(.+)$/i,
      /\bbolna\s+(.+)$/i,
      /\bbol\s+do\s+(.+)$/i,
      /कि\s+(.+)$/i,
    ];

    for (const splitRegex of msgSplits) {
      const match = trimmed.match(splitRegex);
      if (match && match[1]) {
        messageText = match[1].replace(/["']/g, '').trim();
        break;
      }
    }

    // Check if it's an app-opening command: "open whatsapp", "whatsapp kholo", "whatsapp chalao", etc.
    const isOpenOnly =
      !phone &&
      !messageText &&
      (/(open\s*whats\s*app|whats\s*app\s*(open|kholo|chalao|khol\s*do|kholna)|व्हाट्सएप\s*खोल)/i.test(lower) ||
        lower === 'whatsapp' ||
        lower === 'व्हाट्सएप' ||
        lower === 'whatsapp kholo' ||
        lower === 'open whatsapp');
    
    if (isOpenOnly) {
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'launch_app',
        detectedLanguage: detectedLang,
        title: 'Open WhatsApp',
        feedbackSpoken: isHindi
          ? 'व्हाट्सएप खोलने के लिए तैयार है।'
          : 'Ready to open WhatsApp.',
        action: NativeActionRouter.createLaunchAppAction('whatsapp', isHindi ? 'व्हाट्सएप खोलें' : 'Open WhatsApp'),
      };
    }

    // Check if user just said "whatsapp bhejo" or "send whatsapp" with no info -> Clarify!
    if (!phone && !messageText && (lower === 'whatsapp bhejo' || lower === 'send whatsapp' || lower === 'whatsapp message')) {
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'clarify',
        detectedLanguage: detectedLang,
        title: isHindi ? 'व्हाट्सएप संदेश की जानकारी चाहिए' : 'WhatsApp Details Needed',
        clarificationNeeded: true,
        clarificationPrompt: isHindi
          ? 'आप किसको और क्या व्हाट्सएप संदेश भेजना चाहते हैं?'
          : 'Who would you like to message and what is the message?',
        feedbackSpoken: isHindi
          ? 'आप किसको और क्या संदेश भेजना चाहते हैं? कृपया नाम या नंबर और संदेश बताएं।'
          : 'Who would you like to message and what should it say?',
        clarificationOptions: [
          { label: 'Draft WhatsApp message', command: 'WhatsApp par message bhejo ki hum kal milenge' },
          { label: 'Just open WhatsApp', command: 'Open WhatsApp' },
        ],
      };
    }

    // Prepare WhatsApp confirmation card
    const defaultMsg = messageText || (isHindi ? 'नमस्ते, मैं काजू एआई के माध्यम से संपर्क कर रहा हूँ।' : 'Hello from Kaju AI.');
    return {
      rawTranscript: trimmed,
      recognizedIntent: 'whatsapp',
      detectedLanguage: detectedLang,
      title: isHindi ? 'व्हाट्सएप संदेश तैयार है' : 'WhatsApp Message Ready',
      feedbackSpoken: isHindi
        ? 'मैंने व्हाट्सएप संदेश तैयार कर दिया है। भेजने से पहले कृपया नीचे विवरण जांचें और कन्फर्म करें।'
        : 'I have prepared your WhatsApp draft. Please review details below and confirm to open.',
      action: {
        id: `act_${Date.now()}`,
        type: 'whatsapp',
        status: 'ready',
        title: phone ? `Draft WhatsApp to ${phone}` : 'Draft WhatsApp Message',
        payload: {
          whatsapp: {
            phone: phone || '',
            recipientName: phone ? '' : 'Recipient',
            message: defaultMsg,
          },
        },
        createdAt: Date.now(),
      },
    };
  }

  // 3. PHONE CALL / DIALER COMMANDS
  if (
    lower.includes('call') ||
    lower.includes('dial') ||
    lower.includes('कॉल') ||
    lower.includes('फोन मिला') ||
    lower.includes('फोन लगा')
  ) {
    const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
    const phone = extractPhoneNumberFromText(trimmed);

    if (!phone) {
      // Missing phone number -> Ask for clarification
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'clarify',
        detectedLanguage: detectedLang,
        title: isHindi ? 'फ़ोन नंबर आवश्यक है' : 'Phone Number Required',
        clarificationNeeded: true,
        clarificationPrompt: isHindi
          ? 'आप किस नंबर पर कॉल मिलाना चाहते हैं? कृपया 10 अंकों का मोबाइल नंबर बताएं।'
          : 'Which phone number would you like to call? Please provide the number.',
        feedbackSpoken: isHindi
          ? 'आप किस नंबर पर कॉल करना चाहते हैं? कृपया फ़ोन नंबर बताएं।'
          : 'Who would you like to call? Please tell me the phone number.',
        clarificationOptions: [
          { label: 'Emergency (112)', command: 'Call 112' },
          { label: 'Customer care (198)', command: 'Call 198' },
        ],
      };
    }

    return {
      rawTranscript: trimmed,
      recognizedIntent: 'call',
      detectedLanguage: detectedLang,
      title: isHindi ? `डायलर में नंबर: ${phone}` : `Dialer Ready: ${phone}`,
      feedbackSpoken: isHindi
        ? `मैंने फ़ोन डायलर में ${phone} तैयार कर दिया है। कॉल करने के लिए पुष्टि करें।`
        : `I have prepared ${phone} in the phone dialer. Please confirm to open dialer.`,
      action: {
        id: `act_${Date.now()}`,
        type: 'call',
        status: 'ready',
        title: `Call ${phone}`,
        payload: {
          call: {
            phone,
          },
        },
        createdAt: Date.now(),
      },
    };
  }

  // 4. YOUTUBE COMMANDS
  if (
    lower.includes('youtube') ||
    lower.includes('यूट्यूब') ||
    lower.includes('gana chalao') ||
    lower.includes('song play')
  ) {
    const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
    // Extract query if user asked for a specific topic
    const ytQueryMatch = lower.match(/(?:youtube\s*(?:par|pe)?\s*(.+)\s*(?:chalao|play|search|dekho)|play\s*(.+)\s*on\s*youtube|search\s*(.+)\s*on\s*youtube)/i);
    const query = ytQueryMatch ? (ytQueryMatch[1] || ytQueryMatch[2] || ytQueryMatch[3] || '').trim() : '';

    if (query) {
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'search',
        detectedLanguage: detectedLang,
        title: `YouTube: ${query}`,
        feedbackSpoken: isHindi
          ? `यूट्यूब पर ${query} खोजने के लिए तैयार है।`
          : `Ready to search for ${query} on YouTube.`,
        action: {
          id: `act_${Date.now()}`,
          type: 'search',
          status: 'ready',
          title: `Search YouTube for "${query}"`,
          payload: {
            search: {
              query,
              engine: 'youtube',
            },
          },
          createdAt: Date.now(),
        },
      };
    }

    return {
      rawTranscript: trimmed,
      recognizedIntent: 'launch_app',
      detectedLanguage: detectedLang,
      title: 'Open YouTube',
      feedbackSpoken: isHindi ? 'यूट्यूब खोलने के लिए तैयार है।' : 'Ready to open YouTube.',
      action: NativeActionRouter.createLaunchAppAction('youtube', isHindi ? 'यूट्यूब खोलें' : 'Open YouTube'),
    };
  }

  // 5. GOOGLE MAPS & NAVIGATION
  if (
    lower.includes('maps') ||
    lower.includes('मैप्स') ||
    lower.includes('rasta') ||
    lower.includes('nearby') ||
    lower.includes('paas ke') ||
    lower.includes('najdiki')
  ) {
    const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
    let query = '';
    const mapsMatch = lower.match(/(?:maps\s*(?:par|pe)?\s*(.+)\s*(?:search|dhundo|kholo)|search\s*(.+)\s*on\s*maps|find\s*(.+)\s*near\s*me)/i);
    if (mapsMatch) {
      query = (mapsMatch[1] || mapsMatch[2] || mapsMatch[3] || '').trim();
    } else if (lower.includes('hospital')) {
      query = 'hospital near me';
    } else if (lower.includes('petrol pump')) {
      query = 'petrol pump near me';
    } else if (lower.includes('restaurant') || lower.includes('hotel')) {
      query = 'restaurants near me';
    }

    if (query) {
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'search',
        detectedLanguage: detectedLang,
        title: `Google Maps: ${query}`,
        feedbackSpoken: isHindi
          ? `गूगल मैप्स पर ${query} देखने के लिए तैयार है।`
          : `Ready to search for ${query} on Google Maps.`,
        action: {
          id: `act_${Date.now()}`,
          type: 'search',
          status: 'ready',
          title: `Search Maps for "${query}"`,
          payload: {
            search: {
              query,
              engine: 'maps',
            },
          },
          createdAt: Date.now(),
        },
      };
    }

    return {
      rawTranscript: trimmed,
      recognizedIntent: 'launch_app',
      detectedLanguage: detectedLang,
      title: 'Open Google Maps',
      feedbackSpoken: isHindi ? 'गूगल मैप्स खोलने के लिए तैयार है।' : 'Ready to open Google Maps.',
      action: NativeActionRouter.createLaunchAppAction('maps', isHindi ? 'गूगल मैप्स खोलें' : 'Open Google Maps'),
    };
  }

  // 6. SYSTEM & NATIVE UTILITY APPS (Calculator, Camera, Gallery, Settings)
  const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';

  // 6a. Calculator
  if (
    lower.includes('calculator') ||
    lower.includes('कैलकुलेटर') ||
    lower.includes('hisab lagao') ||
    lower.includes('hisab karo')
  ) {
    return {
      rawTranscript: trimmed,
      recognizedIntent: 'launch_app',
      detectedLanguage: detectedLang,
      title: 'Open Calculator',
      feedbackSpoken: isHindi ? 'कैलकुलेटर खोलने के लिए तैयार है।' : 'Ready to open Calculator.',
      action: NativeActionRouter.createLaunchAppAction('calculator', isHindi ? 'कैलकुलेटर खोलें' : 'Open Calculator'),
    };
  }

  // 6b. Camera
  if (
    lower.includes('camera') ||
    lower.includes('कैमरा') ||
    lower.includes('photo khicho') ||
    lower.includes('फोटो खींचो') ||
    lower.includes('camera kholo') ||
    lower.includes('camera chalao')
  ) {
    return {
      rawTranscript: trimmed,
      recognizedIntent: 'launch_app',
      detectedLanguage: detectedLang,
      title: 'Open Camera',
      feedbackSpoken: isHindi ? 'कैमरा खोलने के लिए तैयार है।' : 'Ready to open Camera.',
      action: NativeActionRouter.createLaunchAppAction('camera', isHindi ? 'कैमरा खोलें' : 'Open Camera'),
    };
  }

  // 6c. Gallery
  if (
    lower.includes('gallery') ||
    lower.includes('गैलरी') ||
    lower.includes('photo gallery') ||
    lower.includes('photos kholo') ||
    lower.includes('photo dikhao') ||
    lower.includes('gallery kholo')
  ) {
    return {
      rawTranscript: trimmed,
      recognizedIntent: 'launch_app',
      detectedLanguage: detectedLang,
      title: 'Open Gallery',
      feedbackSpoken: isHindi ? 'फ़ोटो गैलरी खोलने के लिए तैयार है।' : 'Ready to open Photo Gallery.',
      action: NativeActionRouter.createLaunchAppAction('gallery', isHindi ? 'गैलरी खोलें' : 'Open Gallery'),
    };
  }

  // 6d. Settings
  if (
    lower.includes('settings') ||
    lower.includes('setting') ||
    lower.includes('सेटिंग्स') ||
    lower.includes('सेटिंग')
  ) {
    return {
      rawTranscript: trimmed,
      recognizedIntent: 'launch_app',
      detectedLanguage: detectedLang,
      title: 'Open Settings',
      feedbackSpoken: isHindi ? 'सेटिंग्स खोलने के लिए तैयार है।' : 'Ready to open Settings.',
      action: NativeActionRouter.createLaunchAppAction('settings', isHindi ? 'सेटिंग्स खोलें' : 'Open Settings'),
    };
  }

  // 7. POPULAR SITES / APPS (Wikipedia, Gmail, Translate, Google)
  for (const app of POPULAR_APP_SHORTCUTS) {
    const nameLower = app.name.toLowerCase();
    const hiLower = app.hindiName.toLowerCase();

    if (lower.includes(nameLower) || lower.includes(hiLower)) {
      const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
      if (app.appId) {
        return {
          rawTranscript: trimmed,
          recognizedIntent: 'launch_app',
          detectedLanguage: detectedLang,
          title: `Open ${app.name}`,
          feedbackSpoken: isHindi
            ? `${app.hindiName} खोलने के लिए तैयार है।`
            : `Ready to open ${app.name}.`,
          action: NativeActionRouter.createLaunchAppAction(
            app.appId,
            isHindi ? `${app.hindiName} खोलें` : `Open ${app.name}`
          ),
        };
      }
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'open_url',
        detectedLanguage: detectedLang,
        title: `Open ${app.name}`,
        feedbackSpoken: isHindi
          ? `${app.hindiName} खोलने के लिए तैयार है।`
          : `Ready to open ${app.name}.`,
        action: {
          id: `act_${Date.now()}`,
          type: 'open_url',
          status: 'ready',
          title: `Open ${app.name}`,
          payload: {
            open_url: {
              url: app.url,
              appName: app.name,
              description: app.description,
            },
          },
          createdAt: Date.now(),
        },
      };
    }
  }

  // 7. WEB SEARCH COMMAND
  const searchMatch = lower.match(/(?:google\s*(?:par|pe)?\s*search\s*karo\s*(.+)|search\s*(?:for\s*)?(.+)\s*on\s*google|khojo\s*(.+))/i);
  if (searchMatch) {
    const query = (searchMatch[1] || searchMatch[2] || searchMatch[3] || '').trim();
    if (query) {
      const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';
      return {
        rawTranscript: trimmed,
        recognizedIntent: 'search',
        detectedLanguage: detectedLang,
        title: `Search: ${query}`,
        feedbackSpoken: isHindi
          ? `गूगल पर "${query}" खोजने के लिए तैयार है।`
          : `Ready to search for "${query}" on Google.`,
        action: {
          id: `act_${Date.now()}`,
          type: 'search',
          status: 'ready',
          title: `Search for "${query}"`,
          payload: {
            search: {
              query,
              engine: 'google',
            },
          },
          createdAt: Date.now(),
        },
      };
    }
  }

  // No explicit local rule matched -> return null to let caller use conversational fallback or Gemini
  return null;
}

/**
 * Server-backed voice command understanding via Gemini API for complex or subtle queries
 */
export async function parseVoiceCommandWithAI(
  transcript: string,
  userPreferredLang: LanguagePreference = 'auto'
): Promise<VoiceCommandResult> {
  // First attempt local instant parser
  const localResult = parseVoiceCommandLocally(transcript, userPreferredLang);
  if (localResult) {
    return localResult;
  }

  // Call server voice-command interpreter endpoint
  try {
    const response = await fetch('/api/voice-command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        transcript,
        languagePreference: userPreferredLang,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data && data.result) {
        return data.result;
      }
    }
  } catch (err) {
    console.warn('AI Voice Command parsing network issue:', err);
  }

  // Fallback to conversational chat intent if not an action
  const detectedLang = detectTranscriptLanguage(transcript);
  const isHindi = detectedLang === 'hindi' || userPreferredLang === 'hindi';

  return {
    rawTranscript: transcript,
    recognizedIntent: 'chat',
    detectedLanguage: detectedLang,
    title: isHindi ? 'काजू बातचीत' : 'Chat with Kaju',
    feedbackSpoken: isHindi
      ? 'मैं आपका सवाल समझ रहा हूँ।'
      : 'I understand your query.',
  };
}

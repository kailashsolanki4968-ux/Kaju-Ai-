import {
  loadMemories,
  saveMemories,
  addMemory,
  updateMemory,
  deleteMemory,
  clearMemories,
  isMemoryEnabled,
  setMemoryEnabled,
  applyMemoryOperation,
  findSimilarMemory,
  DEFAULT_MEMORIES,
} from '../src/utils/memoryHelper';
import {
  getCurrentAccount,
  saveCurrentAccount,
  createSeparateProfile,
  switchProfile,
  listProfiles,
  logoutAccount,
  getScopedKey,
} from '../src/utils/accountHelper';
import { lookupKajuIdentity, loadMyProfile, saveMyProfile } from '../src/utils/identityHelper';
import { executeDeviceActionAsync, buildDialerUrl, buildWhatsAppUrl } from '../src/utils/actionHelper';
import { getSpeechRecognitionLang, detectScriptFromText } from '../src/utils/languages';
import { NativeActionRouter } from '../src/utils/nativeActionRouter';

import fs from 'fs';
import path from 'path';

// Simple lightweight test runner
let testsPassed = 0;
let testsFailed = 0;

function assert(condition: boolean, message: string) {
  if (!condition) {
    console.error(`❌ FAILED: ${message}`);
    testsFailed++;
    throw new Error(message);
  } else {
    console.log(`✅ PASSED: ${message}`);
    testsPassed++;
  }
}

async function runAllTests() {
  console.log('\n========================================');
  console.log('🧪 RUNNING KAJU AI IDENTITY & MEMORY TESTS');
  console.log('========================================\n');

  // ---------------------------------------------------------
  // TEST SUITE 1: OWNER IDENTITY & CREATOR GROUNDING
  // ---------------------------------------------------------
  console.log('--- TEST SUITE 1: Owner Identity & Creator Grounding ---');

  // Verify default profile has clean identity
  const myProfile = loadMyProfile();
  assert(myProfile.displayName === 'Kaju Explorer', 'Default profile is clean Kaju Explorer, not hardcoded demo');
  assert(!myProfile.phoneNumber || !myProfile.phoneNumber.includes('98765 00000'), 'Fake hardcoded phone number removed');

  // Verify Kaju identity lookup
  const officialLookup = lookupKajuIdentity('@kaju_official');
  assert(officialLookup.status === 'found', 'Official Kaju account found');
  assert(
    officialLookup.profile?.bio?.includes('Kailash') === true,
    'Official Kaju identity bio explicitly credits Kailash as the creator/developer'
  );

  // Verify lookup with nonexistent/unknown handle returns not_registered
  const unknownLookup = lookupKajuIdentity('@unknown_random_user_1234');
  assert(unknownLookup.status === 'not_registered', 'Unknown profiles return not_registered without hallucinating facts');

  // Verify server.ts system instructions explicitly mandate Kailash as creator and forbid Rahul
  const serverPath = path.resolve(process.cwd(), 'server.ts');
  const serverCode = fs.readFileSync(serverPath, 'utf-8');
  assert(serverCode.includes('Kaju AI was created, built, and developed by Kailash (कैलाश).'), 'Server instruction specifies Kailash as creator');
  assert(serverCode.includes('Tumko kailash ne nhi rahul ne bnaya h'), 'Server instruction handles explicit user correction: "Tumko kailash ne nhi rahul ne bnaya h"');
  assert(serverCode.includes('NEVER claim, state, or hallucinate that "Rahul" created Kaju.'), 'Server explicitly forbids hallucinating that Rahul created Kaju');
  assert(serverCode.includes('NEVER randomly call the user "Rahul".'), 'Server explicitly forbids randomly addressing user as Rahul');
  assert(serverCode.includes('DO NOT assume every person using Kaju is Kailash!'), 'Server explicitly forbids assuming every person using Kaju is Kailash');
  assert(serverCode.includes('NEVER claim to be a living human or to possess biological feelings'), 'Server enforces empathy boundaries without claiming false humanity');
  assert(serverCode.includes('Concise when simple instructions are requested'), 'Server enforces concise replies on simple instructions');
  assert(serverCode.includes('<!--MEMORY_OPERATION:'), 'Server enforces structured MEMORY_OPERATION tags for facts and corrections');

  // ---------------------------------------------------------
  // TEST SUITE 2: SEPARATE USER PROFILES & DATA ISOLATION
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 2: Separate User Profiles ---');

  // Reset to clean guest
  logoutAccount();
  const guest = getCurrentAccount();
  assert(guest.isAnonymous === true, 'Current account starts as anonymous Guest');
  assert(guest.displayName === 'Guest Explorer', 'Guest name is Guest Explorer');

  // Create Profile 1: "Kailash" (Creator / Owner)
  const kailashProfile = createSeparateProfile('Kailash');
  assert(kailashProfile.displayName === 'Kailash', 'Created profile for Kailash');
  assert(kailashProfile.uid.startsWith('profile_') || kailashProfile.uid.startsWith('user_'), 'Kailash profile has unique UID');
  assert(getCurrentAccount().uid === kailashProfile.uid, 'Active account is now Kailash');

  // Add a memory specific to Kailash
  clearMemories();
  addMemory('Creator of Kaju AI. Focuses on robust AI engineering.', 'profile', 'user_stated');
  const kailashMems = loadMemories();
  assert(kailashMems.some((m) => m.content.includes('Creator of Kaju AI')), 'Memory saved for Kailash');

  // Create Profile 2: "Priya" (Student Profile)
  const priyaProfile = createSeparateProfile('Priya');
  assert(priyaProfile.displayName === 'Priya', 'Created separate profile for Priya');
  assert(getCurrentAccount().uid === priyaProfile.uid, 'Active account switched to Priya');
  assert(getCurrentAccount().displayName !== 'Kailash', 'Priya is NOT identified as Kailash');

  // Verify profile list contains both
  const profiles = listProfiles();
  assert(profiles.some((p) => p.displayName === 'Kailash'), 'Profiles list includes Kailash');
  assert(profiles.some((p) => p.displayName === 'Priya'), 'Profiles list includes Priya');

  // Add a memory specific to Priya
  clearMemories();
  addMemory('CBSE Class 10 student preparing for Physics board exam.', 'fact', 'user_stated');
  const priyaMems = loadMemories();
  assert(priyaMems.some((m) => m.content.includes('CBSE Class 10')), 'Memory saved for Priya');

  // Switch back to Kailash
  const switchedBack = switchProfile(kailashProfile.uid);
  assert(switchedBack !== null && switchedBack.displayName === 'Kailash', 'Successfully switched back to Kailash profile');
  assert(getCurrentAccount().displayName === 'Kailash', 'Current active account is Kailash again');

  // ---------------------------------------------------------
  // TEST SUITE 3: MEMORY CRUD & INLINE UPDATES
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 3: Memory CRUD Operations ---');

  clearMemories();
  assert(loadMemories().length === DEFAULT_MEMORIES.length, 'Clearing memories falls back to clean default preferences');

  // Add memory
  const newMem = addMemory('Prefers concise formulas and dark mode code snippets', 'preference', 'user_stated');
  assert(newMem !== null, 'Memory added successfully');
  assert(loadMemories().some((m) => m.id === newMem!.id), 'New memory is loaded in list');

  // Update memory (Inline edit)
  const updatedMem = updateMemory(newMem!.id, 'Prefers step-by-step math derivations with clear steps', 'instruction');
  assert(updatedMem !== null, 'Memory updated successfully');
  assert(updatedMem?.content.includes('step-by-step math'), 'Updated content persisted');
  assert(updatedMem?.category === 'instruction', 'Updated category persisted');

  // Delete memory
  deleteMemory(newMem!.id);
  assert(!loadMemories().some((m) => m.id === newMem!.id), 'Memory deleted successfully');

  // Toggle memory
  setMemoryEnabled(false);
  assert(isMemoryEnabled() === false, 'Memory toggle disabled');
  setMemoryEnabled(true);
  assert(isMemoryEnabled() === true, 'Memory toggle re-enabled');

  // ---------------------------------------------------------
  // TEST SUITE 4: USER CORRECTIONS & OVERWRITING OLD FACTS
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 4: User Fact Corrections (Stopping repetition of wrong facts) ---');

  clearMemories();

  // Initial user statement
  addMemory('User favorite subject is Physics', 'fact', 'user_stated');
  let currentMems = loadMemories();
  assert(currentMems.some((m) => m.content.includes('Physics')), 'Initial fact recorded: Physics');

  // User correction: "Nahi, mera favorite subject Chemistry hai, Physics nahi!"
  const correctionResult = applyMemoryOperation({
    action: 'update',
    content: 'User favorite subject is Chemistry',
    oldContent: 'Physics',
    category: 'fact',
  });

  assert(correctionResult.success === true, 'Correction applied successfully');
  assert(correctionResult.actionTaken === 'updated', 'Action taken was update');

  currentMems = loadMemories();
  // Ensure the old superseded fact is NO LONGER repeated
  assert(
    !currentMems.some((m) => m.content.toLowerCase().includes('physics')),
    'Old superseded fact "Physics" was removed/replaced'
  );
  assert(
    currentMems.some((m) => m.content.includes('Chemistry')),
    'New corrected fact "Chemistry" is present in memory'
  );

  // Another correction test: Name correction
  addMemory('User name is Amit', 'profile', 'user_stated');
  applyMemoryOperation({
    action: 'update',
    content: 'User name is Sneha',
    oldContent: 'Amit',
    category: 'profile',
  });

  const nameMems = loadMemories();
  assert(!nameMems.some((m) => m.content.includes('Amit')), 'Old name "Amit" was replaced');
  assert(nameMems.some((m) => m.content.includes('Sneha')), 'Corrected name "Sneha" is remembered');

  // ---------------------------------------------------------
  // TEST SUITE 5: UNKNOWN FACTS & PREVENTING HALLUCINATIONS
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 5: Unknown Facts & No Hallucinated Guesses ---');

  // Verify findSimilarMemory returns null when fact is completely unknown
  const unknownFact = findSimilarMemory('What is the user father name?');
  assert(unknownFact === null, 'Unknown facts return null (assistant must not invent answers)');

  // ---------------------------------------------------------
  // TEST SUITE 6: DIRECT SAFE APP OPENING & NO UNNECESSARY CONFIRMATION
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 6: Direct Safe App Opening vs Consequential Actions ---');

  const { parseVoiceCommandLocally } = await import('../src/utils/voiceCommandParser');
  const { NativeActionRouter } = await import('../src/utils/nativeActionRouter');

  // 6a: Test "YouTube kholo" parses as direct launch_app without requiring confirmation
  const ytCommand = parseVoiceCommandLocally('YouTube kholo', 'auto');
  assert(ytCommand !== null, 'YouTube kholo successfully parsed');
  assert(ytCommand?.recognizedIntent === 'launch_app', 'Intent is launch_app');
  assert(ytCommand?.action?.type === 'launch_app', 'Action type is launch_app');
  assert(ytCommand?.action?.payload.launch_app?.appId === 'youtube', 'Target app is youtube');
  assert(
    ytCommand?.action?.payload.launch_app?.requiresConfirmation === false,
    'Safe app opening does NOT require confirmation card'
  );

  // 6b: Test browser preview launch returns accurate website notice, not native Android claim
  const browserLaunchResult = await NativeActionRouter.launchApp('youtube');
  assert(browserLaunchResult.success === true, 'Browser launch succeeded');
  assert(browserLaunchResult.status === 'web_fallback', 'Status is web_fallback (not native)');
  assert(browserLaunchResult.environment === 'web_browser', 'Environment is web_browser');
  assert(
    browserLaunchResult.message.includes('browser preview') && browserLaunchResult.message.includes('website'),
    'Browser message explicitly states website was opened in browser preview'
  );
  assert(
    browserLaunchResult.hindiMessage.includes('ब्राउज़र प्रीव्यू') && browserLaunchResult.hindiMessage.includes('वेबसाइट'),
    'Hindi message explicitly states website was opened in browser preview, not native Android app'
  );

  // 6c: Test Android APK bridge interaction when window.KajuNative is simulated
  let bridgeCalledWithApp = '';
  let bridgeCalledWithParams = '';
  (global as any).window = {
    KajuNative: {
      isAndroidNative: () => true,
      isAppInstalled: (pkg: string) => pkg === 'com.google.android.youtube',
      launchApp: async (appId: string, params: string) => {
        bridgeCalledWithApp = appId;
        bridgeCalledWithParams = params;
        return JSON.stringify({ success: true, code: 'OK', message: 'Launched YouTube on Android device via Intent' });
      },
    },
  };

  const nativeCheck = NativeActionRouter.isNativeAndroid();
  assert(nativeCheck === true, 'NativeActionRouter detects Android Native when bridge is present');

  const nativeLaunchResult = await NativeActionRouter.launchApp('youtube');
  assert(nativeLaunchResult.success === true, 'Native Android launch succeeded');
  assert(nativeLaunchResult.status === 'native_launched', 'Status is native_launched');
  assert(nativeLaunchResult.environment === 'android_native', 'Environment is android_native');
  assert(bridgeCalledWithApp === 'youtube', 'KajuNative.launchApp was called with target app');
  assert(bridgeCalledWithParams.includes('com.google.android.youtube'), 'Intent params include YouTube package');

  // Clean up mock window
  delete (global as any).window;
  assert(NativeActionRouter.isNativeAndroid() === false, 'After removing mock bridge, environment returns to web_browser');

  // 6d: Consequential actions (WhatsApp with message text, phone call) MUST require confirmation
  const waCommand = parseVoiceCommandLocally('WhatsApp par message bhejo ki hum kal milenge', 'auto');
  assert(waCommand !== null, 'WhatsApp message command parsed');
  assert(waCommand?.recognizedIntent === 'whatsapp', 'Recognized intent is whatsapp');
  assert(waCommand?.action?.type === 'whatsapp', 'Action type is whatsapp');
  assert(
    waCommand?.action?.payload.whatsapp?.message.includes('kal milenge') === true,
    'WhatsApp message text was extracted'
  );

  const callCommand = parseVoiceCommandLocally('Call 9876543210', 'auto');
  assert(callCommand !== null, 'Call command parsed');
  assert(callCommand?.recognizedIntent === 'call', 'Recognized intent is call');
  assert(callCommand?.action?.type === 'call', 'Action type is call');
  assert(callCommand?.action?.payload.call?.phone === '+919876543210', 'Phone number parsed');

  // ---------------------------------------------------------
  // TEST SUITE 7: ACTIVE PROFILE TRANSPARENCY
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 7: Active Profile Transparency ---');

  logoutAccount();
  const activeDefault = getCurrentAccount();
  assert(activeDefault.displayName === 'Guest Explorer', 'Default session is Guest Explorer');
  assert(activeDefault.isAnonymous === true, 'Default session is marked anonymous');

  // Verify switching to named profile works and updates active session
  const student = createSeparateProfile('Student Aman');
  assert(getCurrentAccount().displayName === 'Student Aman', 'Switched to Student Aman');
  assert(getCurrentAccount().displayName !== 'Guest Explorer', 'No longer Guest Explorer');

  // Switch back to Guest
  logoutAccount();
  assert(getCurrentAccount().displayName === 'Guest Explorer', 'Logged out returns cleanly to Guest Explorer');

  // ---------------------------------------------------------
  // TEST SUITE 8: CONVERSATIONAL TONE & BEST-FRIEND PERSONALITY
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 8: Best-Friend Conversational Scenarios ---');

  // 8a: "Kaju yaar aaj mood off hai." - Empathy and Active Listening
  assert(serverCode.includes('aaj mood off hai') || serverCode.includes('mood off hai'), 'System prompt covers "mood off hai" scenario');
  assert(serverCode.includes('Arre yaar, kya hua?'), 'System prompt provides warm best-friend response without hollow platitudes');
  assert(!serverCode.includes('मैं एक AI भाषा मॉडल हूँ और भावनाएं नहीं रखता'), 'No cold robotic disclaimers');

  // 8b: "Kaju, kal humne kya decide kiya tha?" - Memory Honesty & Fact Grounding
  assert(serverCode.includes('kal humne kya decide kiya tha?'), 'System prompt covers "kal humne kya decide kiya tha?" query');
  assert(serverCode.includes('do NOT make up or hallucinate past decisions'), 'System explicitly forbids inventing past decisions when unavailable');
  
  // Test memory lookup behavior when decision IS saved
  addMemory('Kal decide kiya tha: Science chapter 3 ke numericals solve karenge subah 10 baje.', 'fact', 'user_stated');
  const memoriesWithDecision = loadMemories();
  const decisionMem = memoriesWithDecision.find((m) => m.content.includes('Science chapter 3'));
  assert(Boolean(decisionMem), 'Decision successfully stored and retrieved from active memory');

  // 8c: "Yaar tum meri baat samajh hi nahi rahe." - Feedback & Frustration Handling
  assert(serverCode.includes('Yaar tum meri baat samajh hi nahi rahe'), 'System prompt explicitly guides response to user frustration');
  assert(serverCode.includes('Sorry yaar, lagta hai maine galat pakad liya'), 'System prompt responds with empathetic accountability instead of arguing');

  // 8d: "Bas short mein bata." - Concise Mode Discipline
  assert(serverCode.includes('Bas short mein bata'), 'System prompt covers "Bas short mein bata" directive');
  assert(serverCode.includes('Zero pleasantries, zero academic filler headers, zero fluff'), 'System mandates zero fluff when short answer requested');

  // 8e: "Kaju, YouTube kholo." - Fast Path Intent Parsing & Real Action Verification
  const ytPromptCmd = parseVoiceCommandLocally('Kaju, YouTube kholo.', 'auto');
  assert(ytPromptCmd !== null, '"Kaju, YouTube kholo." parses successfully');
  assert(ytPromptCmd?.recognizedIntent === 'launch_app', 'Intent is launch_app');
  assert(ytPromptCmd?.action?.payload.launch_app?.appId === 'youtube', 'Target app is youtube');
  assert(ytPromptCmd?.action?.payload.launch_app?.requiresConfirmation === false, 'Safe app launch does not require confirmation card');

  // ---------------------------------------------------------
  // TEST SUITE 9: ANDROID PROJECT & BRIDGE INTEGRITY
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 9: Android Project & Native Bridge Static Inspection ---');

  const ktBridgePath = path.resolve(process.cwd(), 'android/app/src/main/java/com/kaju/ai/bridge/KajuNativeBridge.kt');
  assert(fs.existsSync(ktBridgePath), 'Android KajuNativeBridge.kt source file exists');
  const ktBridgeCode = fs.readFileSync(ktBridgePath, 'utf-8');
  assert(ktBridgeCode.includes('fun isAndroidNative(): Boolean'), 'KajuNativeBridge implements isAndroidNative()');
  assert(ktBridgeCode.includes('fun isAppInstalled(packageName: String): Boolean'), 'KajuNativeBridge implements isAppInstalled()');
  assert(ktBridgeCode.includes('fun launchApp(appId: String, intentParamsRaw: String): String'), 'KajuNativeBridge implements launchApp()');
  assert(ktBridgeCode.includes('fun openCamera(): String'), 'KajuNativeBridge implements openCamera()');
  assert(ktBridgeCode.includes('fun openGallery(): String'), 'KajuNativeBridge implements openGallery()');
  assert(ktBridgeCode.includes('fun openSettings('), 'KajuNativeBridge implements openSettings()');
  assert(ktBridgeCode.includes('fun openDialer(phoneNumber: String): String'), 'KajuNativeBridge implements openDialer()');

  const manifestPath = path.resolve(process.cwd(), 'android/app/src/main/AndroidManifest.xml');
  assert(fs.existsSync(manifestPath), 'Android AndroidManifest.xml exists');
  const manifestCode = fs.readFileSync(manifestPath, 'utf-8');
  assert(manifestCode.includes('com.google.android.youtube'), 'AndroidManifest includes package visibility query for YouTube');
  assert(manifestCode.includes('com.whatsapp'), 'AndroidManifest includes package visibility query for WhatsApp');

  // ---------------------------------------------------------
  // TEST SUITE 10: REAL AI IMAGE & VIDEO GENERATION (PHASE 3)
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 10: Real AI Image & Video Generation Architecture ---');

  // Import mediaIntentRouter
  const { detectMediaIntent } = await import('../src/utils/mediaIntentRouter');

  // 10a: Hindi Image Generation prompt parsing
  const hindiImg = detectMediaIntent('Kaju ek pyare se sher ke bachhe ki photo banao', false);
  assert(hindiImg !== null, 'Hindi image prompt detected');
  assert(hindiImg?.type === 'image', 'Hindi intent is image');
  assert(Boolean(hindiImg?.prompt), 'Hindi prompt extracted cleanly');

  // 10b: Hinglish Image Generation prompt parsing with aspect ratio
  const hinglishImg = detectMediaIntent('Ek sunset landscape 16:9 wallpaper image generate karo', false);
  assert(hinglishImg !== null, 'Hinglish image prompt detected');
  assert(hinglishImg?.type === 'image', 'Hinglish intent is image');
  assert(hinglishImg?.aspectRatio === '16:9', '16:9 aspect ratio detected');

  // 10c: English Image Generation prompt parsing
  const englishImg = detectMediaIntent('Create an image of an astronaut in cyberpunk city', false);
  assert(englishImg !== null, 'English image prompt detected');
  assert(englishImg?.type === 'image', 'English intent is image');
  assert(englishImg?.prompt.toLowerCase().includes('astronaut'), 'Prompt contains astronaut');

  // 10d: Vision / Photo question MUST NOT be hijacked into image generation
  const visionWithAttachment = detectMediaIntent('Is photo ko solve karo aur answer batao', true);
  assert(visionWithAttachment === null, 'Vision question with attached photo is NOT treated as image generation');

  const visionQuestionText = detectMediaIntent('Is photo me kya likha hai explain karo', false);
  assert(visionQuestionText === null, 'Question asking about text in a photo is NOT hijacked as image generation');

  // 10e: Video Generation prompt parsing (Veo 3.1)
  const hindiVideo = detectMediaIntent('Kaju ek robot dance karta hua video bana do', false);
  assert(hindiVideo !== null, 'Video prompt detected');
  assert(hindiVideo?.type === 'video', 'Detected intent is video');
  assert(Boolean(hindiVideo?.prompt), 'Video prompt extracted');

  const englishVideo = detectMediaIntent('Generate a 9:16 portrait video of water drop falling in slow motion', false);
  assert(englishVideo !== null, 'English video prompt detected');
  assert(englishVideo?.type === 'video', 'English intent is video');
  assert(englishVideo?.aspectRatio === '9:16', '9:16 aspect ratio detected');

  // 10f: Server.ts endpoints verification
  assert(serverCode.includes('/api/image/generate'), 'Server defines /api/image/generate endpoint');
  assert(serverCode.includes('gemini-3.1-flash-lite-image'), 'Server uses official gemini-3.1-flash-lite-image model');
  assert(serverCode.includes('/api/video/generate'), 'Server defines /api/video/generate endpoint');
  assert(serverCode.includes('veo-3.1-lite-generate-preview'), 'Server uses official Google DeepMind Veo 3.1 model');
  assert(serverCode.includes('/api/video/status'), 'Server defines /api/video/status polling endpoint');
  assert(serverCode.includes('/api/video/download'), 'Server defines /api/video/download streaming endpoint');
  assert(serverCode.includes('/api/media/capabilities'), 'Server defines /api/media/capabilities endpoint');

  // 10g: Anti-Fake Image & Anti-Hallucination verification
  assert(serverCode.includes('NEVER pretend a Google Search link, Markdown placeholder, or normal text response is a real generated image'), 'System explicitly forbids faking generated images or substituting search links');

  // 10h: Free-Mode Safety & Protection: No automatic paid API calls
  const appCode = fs.readFileSync(path.resolve(process.cwd(), 'src/App.tsx'), 'utf-8');
  assert(appCode.includes("status: 'pending_confirmation'"), 'Image generation initializes in pending_confirmation state to prevent accidental charges');
  assert(appCode.includes('handleConfirmImage'), 'App implements handleConfirmImage to require explicit user confirmation');
  assert(appCode.includes('handleCancelImage'), 'App implements handleCancelImage allowing user to cancel without charge');
  assert(appCode.includes('handleConfirmVideo'), 'Video generation implements handleConfirmVideo requiring explicit user confirmation');

  // 10i: Media capabilities free tier and anti-fake disclosure
  assert(serverCode.includes('freeTierStatus'), 'Server explicitly returns freeTierStatus verification');
  assert(serverCode.includes('antiFakeGuarantee'), 'Server explicitly declares antiFakeGuarantee');

  // ---------------------------------------------------------
  // TEST SUITE 11: WEB SEARCH REAL GROUNDING & ZERO FAKE CITATIONS
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 11: Real Search Grounding & Zero Fake Citations ---');

  // Verify fake electric car & IEA URLs have been removed completely from App.tsx
  assert(!appCode.includes('https://en.wikipedia.org/wiki/Electric_car'), 'Fake hardcoded electric car Wikipedia link removed');
  assert(!appCode.includes('https://www.iea.org/reports/global-ev-outlook'), 'Fake hardcoded IEA report link removed');

  // Verify /api/chat/stream parses and emits real grounding citations
  assert(serverCode.includes('collectedCitations'), 'Server stream collects genuine search grounding citations');
  assert(serverCode.includes('groundingMetadata?.groundingChunks'), 'Server stream extracts grounding chunks from Gemini');
  assert(serverCode.includes('res.write(`data: ${JSON.stringify({ citations: collectedCitations })}\\n\\n`);'), 'Server stream sends collected real citations to client');

  // Verify App.tsx captures streamed real citations and filters out empty placeholder messages from conversation history
  assert(appCode.includes('streamedCitations'), 'App.tsx tracks streamed real search citations');
  assert(appCode.includes('m.id !== assistantPlaceholderId'), 'App.tsx excludes empty assistant placeholder from conversation history payload');

  // ---------------------------------------------------------
  // TEST SUITE 12: HINDI, ENGLISH & HINGLISH SPEECH AND NATIVE BRIDGE SAFEGUARDS
  // ---------------------------------------------------------
  console.log('\n--- TEST SUITE 12: Hindi/English/Hinglish Speech & Native Bridge Safeguards ---');

  // Test language recognition codes
  assert(getSpeechRecognitionLang('hindi') === 'hi-IN', 'Hindi speech recognition code is hi-IN');
  assert(getSpeechRecognitionLang('hinglish') === 'hi-IN', 'Hinglish speech recognition code is hi-IN for accurate Indian phonemes');
  assert(getSpeechRecognitionLang('english') === 'en-US', 'English speech recognition code is en-US');

  // Test script detection
  assert(detectScriptFromText('नमस्ते आप कैसे हैं') === 'hindi', 'Pure Devanagari detected as hindi');
  assert(detectScriptFromText('Hello, how can I help you?') === 'english', 'Standard English detected as english');
  assert(detectScriptFromText('Yaar mujhe physics ka formula samjhao') === 'hinglish', 'Romanized Hindi detected as hinglish');

  // Test Native Bridge action safeguards
  const dummyCallAction = {
    id: 'test_call_1',
    type: 'call' as const,
    status: 'ready' as const,
    title: 'Call Help',
    payload: {
      call: { phone: '+919876543210', contactName: 'Support' }
    },
    createdAt: Date.now(),
  };

  const dialerUrl = buildDialerUrl(dummyCallAction.payload.call.phone);
  assert(dialerUrl === 'tel:+919876543210', 'Phone dialer URL built safely');

  const dummyWhatsAppAction = {
    id: 'test_wa_1',
    type: 'whatsapp' as const,
    status: 'ready' as const,
    title: 'Send Note',
    payload: {
      whatsapp: { phone: '9876543210', message: 'Namaste Kaju' }
    },
    createdAt: Date.now(),
  };

  const waUrl = buildWhatsAppUrl(dummyWhatsAppAction.payload.whatsapp.phone, dummyWhatsAppAction.payload.whatsapp.message);
  assert(waUrl.includes('wa.me/9876543210?text=Namaste%20Kaju'), 'WhatsApp URL contains sanitized recipient digits and encoded text');

  // Verify Android bridge contract defines all necessary methods
  const bridgeContractPath = path.resolve(process.cwd(), 'src/native/androidBridgeContract.ts');
  const contractCode = fs.readFileSync(bridgeContractPath, 'utf-8');
  assert(contractCode.includes('isAndroidNative:'), 'Contract specifies isAndroidNative()');
  assert(contractCode.includes('isAppInstalled:'), 'Contract specifies isAppInstalled()');
  assert(contractCode.includes('launchApp:'), 'Contract specifies launchApp()');
  assert(contractCode.includes('openDialer?:'), 'Contract specifies openDialer()');
  assert(contractCode.includes('openCamera?:'), 'Contract specifies openCamera()');
  assert(contractCode.includes('openGallery?:'), 'Contract specifies openGallery()');
  assert(contractCode.includes('openSettings?:'), 'Contract specifies openSettings()');

  // ---------------------------------------------------------
  // FINAL SUMMARY
  // ---------------------------------------------------------
  console.log('\n========================================');
  console.log(`🎉 ALL TESTS COMPLETED: ${testsPassed} Passed, ${testsFailed} Failed`);
  console.log('========================================\n');

  if (testsFailed > 0) {
    process.exit(1);
  }
}

runAllTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
